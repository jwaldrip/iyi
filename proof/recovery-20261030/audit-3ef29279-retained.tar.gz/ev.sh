#!/bin/bash
# Independent evidence reruns for W=3ef29279 on a /private/tmp clone. Writes only under AUD.
set -u
AUD=/private/tmp/iyi-proof-audit-3ef29279
W="$AUD/w"
WORIG=/Users/jwaldrip/dev/worktrees/iyi-o3-integration-20261028
P=/Users/jwaldrip/dev/worktrees/iyi-stale-integration-repair
PY=/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3
PATHPIN=/Users/jwaldrip/.cache/iyi-corpus-venv/bin:/opt/homebrew/opt/curl/bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/bin:/bin:/usr/sbin:/sbin
export HOME=/Users/jwaldrip
step="$1"
cd "$W" || exit 99
case "$step" in
  default)
    env PATH="$PATHPIN" "$PY" -B -X pycache_prefix="$AUD/pyc-default" proof/smoke_test.py >"$AUD/smoke.txt" 2>"$AUD/smoke.err"
    echo $? >"$AUD/smoke.rc" ;;
  coverage)
    env PATH="$PATHPIN" "$PY" -B -X pycache_prefix="$AUD/pyc-cov" proof/smoke_test.py --coverage "$AUD/cov" >"$AUD/coverage.txt" 2>"$AUD/coverage.err"
    echo $? >"$AUD/coverage.rc" ;;
  optimize)
    env PATH="$PATHPIN" "$PY" -B -O -X pycache_prefix="$AUD/pyc-opt" proof/smoke_test.py >"$AUD/opt-O.txt" 2>&1
    echo $? >"$AUD/opt-O.rc"
    env PATH="$PATHPIN" PYTHONOPTIMIZE=1 "$PY" -B -X pycache_prefix="$AUD/pyc-opt2" proof/smoke_test.py >"$AUD/opt-env.txt" 2>&1
    echo $? >"$AUD/opt-env.rc" ;;
  o3)
    env PATH="$PATHPIN" "$PY" -B -X pycache_prefix="$AUD/pyc-o3" -c 'from proof.smoke_test import run_o3_suite; raise SystemExit(run_o3_suite())' >"$AUD/o3.txt" 2>"$AUD/o3.err"
    echo $? >"$AUD/o3.rc" ;;
  plan)
    env PATH="$PATHPIN" "$PY" -B -X pycache_prefix="$AUD/pyc-plan" proof/run_proof.py plan --p "$P" --w "$W" --compiler "$P/.build/iyi" >"$AUD/plan.txt" 2>"$AUD/plan.err"
    echo $? >"$AUD/plan.rc" ;;
  *) echo "unknown step $step"; exit 98 ;;
esac
