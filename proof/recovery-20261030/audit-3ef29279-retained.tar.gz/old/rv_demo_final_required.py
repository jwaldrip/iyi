"""Reviewer demo: final does not re-derive Run 3's required driver set from the
latest Run 1/Run 2 attempts. A genuine Run 1 rerun after Run 3 (calibration
exclusions differ between attempts) adds a required std driver, and final
still reports PASS. Uses the real StageFixture with one stub change: the gate
prints a std calibration exclusion only once a flip file exists."""
import json
import os
import sys

RV = "/private/tmp/iyi-proof-review-720ad779"
W = os.path.join(RV, "w")
sys.path.insert(0, W)
import proof.run_proof as stages_mod  # noqa: E402
import proof.smoke_test as smoke_mod  # noqa: E402

ROOT = os.path.join(RV, "demo-final-required")
os.makedirs(ROOT, exist_ok=False)
FLIP = os.path.join(ROOT, "calibration-flip")
original = smoke_mod._stage_stub_payloads


def patched(scenario):
    payloads = original(scenario)
    text = payloads["bench/stale_equivalence.sh"].decode()
    addition = (
        f"if [ -e '{FLIP}' ]; then printf '%s\\n' "
        "'  [excluded after calibration] bench/std_extra_exercise.iyi: calibration differed'; fi\n"
    )
    assert text.count("exit 0\n") == 1
    payloads["bench/stale_equivalence.sh"] = text.replace("exit 0\n", addition + "exit 0\n").encode()
    return payloads


smoke_mod._stage_stub_payloads = patched

with smoke_mod.StageFixture() as fx:
    args = fx.args()
    fx.pin_data = fx.pin()
    r1a = stages_mod.cmd_run1(args, disk_min_gb=0.0)
    r2 = stages_mod.cmd_run2(args, disk_min_gb=0.0)
    r3 = stages_mod.cmd_run3(args, drivers=fx.drivers, driver_limit_sec=5.0, grace_sec=0.1, disk_min_gb=0.0)
    frozen = json.load(open(os.path.join(fx.report, "run3", "required.json")))
    open(FLIP, "w").close()
    r1b = stages_mod.cmd_run1(args, disk_min_gb=0.0)
    a2 = os.path.join(fx.report, "run1", "a2")
    exclusions = json.load(open(os.path.join(a2, "exclusions.json")))
    run1_a2 = json.load(open(os.path.join(a2, "result.json")))
    recomputed = stages_mod._compute_required_drivers(
        fx.drivers,
        os.path.join(a2, "exclusions.json"),
        os.path.join(fx.report, "run2", "a1", "run2.jsonl"),
    )
    rf = stages_mod.cmd_final(args)
    final = json.load(open(os.path.join(fx.report, "final.json")))
    print(json.dumps({
        "run1_a1": r1a, "run2": r2, "run3": r3, "required_json_frozen": frozen,
        "run1_a2_rc": r1b, "run1_a2_status": run1_a2["status"], "run1_a2_exclusions": exclusions,
        "required_recomputed_from_latest": recomputed,
        "final_rc": rf, "final_status": final["status"], "final_units": final["units"],
        "final_reasons": final["reasons"], "earlier_failures": final["earlier_failures"],
    }, indent=1, sort_keys=True))
    # what run3 itself says about the same state
    r3b = stages_mod.cmd_run3(args, drivers=fx.drivers, driver_limit_sec=5.0, grace_sec=0.1, disk_min_gb=0.0)
    print(json.dumps({"run3_again_rc": r3b}))
