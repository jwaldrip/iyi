"""Reviewer demo: real shim + real verify_ledger on driver-faithful calls.

Scenario regex-416: std_regex_exercise.sh:416 exports
IYI_PATH="$WORK/patched:$REPO/src:$REPO/samples/iyi" in a subshell and calls
refuses(), whose $IYI line 231 builds "$WORK/mutated_refusal.iyi".
Scenario http-1384: std_http_exercise.sh:1384 runs
IYI_PATH="$WORK/refbreak:$IYI_PATH" "$IYI" build --no-codegen ...
Each seed has a control that differs only in IYI_PATH being canonical.
Writes only under RV.
"""
import json
import os
import secrets
import subprocess
import sys

RV = "/private/tmp/iyi-proof-review-720ad779"
W = os.path.join(RV, "w")
sys.path.insert(0, W)

import proof.proofkit as proofkit_mod  # noqa: E402
import proof.smoke_test as smoke_mod  # noqa: E402

PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
ROOT = os.path.join(RV, "demo-misclassified")
os.makedirs(ROOT, exist_ok=False)
REAL = smoke_mod._fake_real_compiler(
    os.path.join(ROOT, "fake"), version_line="iyi fake [626463375]"
)
REPO = os.path.realpath(W)
CANONICAL = [os.path.realpath(os.path.join(REPO, "src")), os.path.realpath(os.path.join(REPO, "samples/iyi"))]
PLATFORM_TMP = os.path.realpath(
    subprocess.run(["getconf", "DARWIN_USER_TEMP_DIR"], capture_output=True, text=True, check=True).stdout.strip()
)


def scenario(name, driver, iyi_path_first, argv, files):
    base = os.path.join(ROOT, name)
    t = os.path.join(base, "t")
    s = os.path.join(base, "s")
    c = os.path.join(base, "c")
    for d in (t, s, c):
        os.makedirs(d)
    work = os.path.join(t, "tmp.work")
    os.makedirs(work)
    for rel in files:
        path = os.path.join(work, rel)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as handle:
            handle.write("# demo\n")
    nonce = secrets.token_hex(16)
    ledger = os.path.join(base, "ledger.jsonl")
    with open(ledger, "x") as handle:
        handle.write(json.dumps({"v": 1, "kind": "header", "nonce": nonce, "driver": driver, "attempt": 1, "chain_id": "c" * 32}, sort_keys=True, separators=(",", ":")) + "\n")
    config = {
        "real": REAL,
        "census": os.path.realpath(os.path.join(REPO, "proof", "census", f"{driver}.json")),
        "ledger": ledger,
        "nonce": nonce,
        "driver": driver,
        "work_tmp": os.path.realpath(t),
        "scratch": s,
        "repo": REPO,
        "canonical_roots": CANONICAL,
        "platform_tmp": PLATFORM_TMP,
    }
    config_path = os.path.join(base, "shim.json")
    with open(config_path, "x") as handle:
        json.dump(config, handle)
    env = proofkit_mod.base_env(None, {"TMPDIR": t, "IYI_CACHE_DIR": c})
    roots = ([iyi_path_first.replace("$WORK", work)] if iyi_path_first else []) + CANONICAL
    env["IYI_PATH"] = os.pathsep.join(roots)
    concrete = [token.replace("$WORK", work) for token in argv]
    proc = subprocess.run(
        [PY, "-B", os.path.join(REPO, "proof", "roundtrip_shim.py"), "--config", config_path, "--", *concrete],
        cwd=REPO, env=env, stdin=subprocess.DEVNULL, capture_output=True, text=True,
    )
    with open(ledger) as handle:
        lines = handle.read().splitlines()
    records = [json.loads(line) for line in lines[1:]]
    verdict = proofkit_mod.verify_ledger(
        ledger, census=json.load(open(config["census"])), driver=driver, nonce=nonce,
        attempt=1, chain_id="c" * 32, work_tmp=os.path.realpath(t), repo=REPO,
        platform_tmp=PLATFORM_TMP,
    )
    print(f"== {name}")
    print(f"   IYI_PATH={env['IYI_PATH']}")
    print(f"   argv={concrete}")
    print(f"   shim_exit={proc.returncode} stderr={proc.stderr.strip()!r}")
    for record in records:
        print("   record:", json.dumps({k: record.get(k) for k in ("phase", "mode", "command", "canonical", "first_noncanonical_root", "variant_ids", "reason", "exit")}, sort_keys=True))
    print(f"   verify_ledger statuses={sorted(verdict.statuses)}")
    for reason in verdict.reasons:
        if reason.startswith("MISCLASSIFIED"):
            print(f"   reason: {reason}")
    return proc.returncode, verdict


r1 = scenario("regex-416-seed", "regex", "$WORK/patched", ["build", "-o", "$WORK/mutated_refusal", "$WORK/mutated_refusal.iyi"], ["patched/std/regex.iyi", "mutated_refusal.iyi"])
r2 = scenario("regex-416-control", "regex", None, ["build", "-o", "$WORK/mutated_refusal", "$WORK/mutated_refusal.iyi"], ["mutated_refusal.iyi"])
r3 = scenario("http-1384-seed", "http", "$WORK/refbreak", ["build", "--no-codegen", "-o", "$WORK/refused", "$WORK/captures.iyi"], ["refbreak/std/http.iyi", "captures.iyi"])
r4 = scenario("http-1384-control", "http", None, ["build", "--no-codegen", "-o", "$WORK/refused", "$WORK/captures.iyi"], ["captures.iyi"])
print("SUMMARY", json.dumps({
    "regex_seed": [r1[0], "MISCLASSIFIED" in r1[1].statuses],
    "regex_control": [r2[0], "MISCLASSIFIED" in r2[1].statuses],
    "http_seed": [r3[0], "MISCLASSIFIED" in r3[1].statuses],
    "http_control": [r4[0], "MISCLASSIFIED" in r4[1].statuses],
}))
