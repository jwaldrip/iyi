"""Reviewer demo for attack (e): driver-script drift after pin is caught
before the driver runs, both with the run3 census revalidation in place and
with check_identity alone (census revalidation bypassed for the second case
by calling the stage on a copy whose drift is committed, so the census sha
check and W-HEAD both fire)."""
import json
import os
import subprocess
import sys

RV = "/private/tmp/iyi-proof-review-720ad779"
W = os.path.join(RV, "w")
sys.path.insert(0, W)
import proof.proofkit as proofkit_mod  # noqa: E402
import proof.run_proof as stages_mod  # noqa: E402
import proof.smoke_test as smoke_mod  # noqa: E402


def drift(fx, commit: bool):
    script = os.path.join(fx.w, "bench", "std_stage_exercise.sh")
    before = open(script, "rb").read()
    after = before.replace(b"status=0\n", b"status=0\necho drifted\n", 1)
    assert before.count(b"status=0\n") >= 1 and after != before
    open(script, "wb").write(after)
    if commit:
        subprocess.run(["git", "-C", fx.w, "commit", "-qam", "drift"], check=True)
    return {"bytes_differ": before != after, "committed": commit}


for commit in (False, True):
    with smoke_mod.StageFixture() as fx:
        args = fx.args()
        fx.pin_data = fx.pin()
        assert stages_mod.cmd_run1(args, disk_min_gb=0.0) == 0
        assert stages_mod.cmd_run2(args, disk_min_gb=0.0) == 0
        applied = drift(fx, commit)
        rc = stages_mod.cmd_run3(args, drivers=fx.drivers, driver_limit_sec=5.0, grace_sec=0.1, disk_min_gb=0.0)
        attempt = stages_mod.latest_attempt_dir(os.path.join(fx.report, "run3", "stage"))
        result = json.load(open(os.path.join(attempt, "result.json")))
        print(json.dumps({
            "case": "committed drift" if commit else "uncommitted drift",
            "applied": applied, "run3_rc": rc, "status": result["status"], "checks": result["checks"],
            "reasons": result["reasons"][:3],
            "driver_log_exists": os.path.exists(os.path.join(attempt, "driver.log")),
            "ledger_exists": os.path.exists(os.path.join(attempt, "ledger.jsonl")),
        }, sort_keys=True))
