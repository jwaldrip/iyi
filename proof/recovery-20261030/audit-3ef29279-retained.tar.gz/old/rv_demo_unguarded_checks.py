"""Reviewer demo: the checks that the full smoke suite cannot detect losing
(mutants m08, m10, m11, m12, m13) do work when exercised directly. Each case
starts from a passing stage chain and applies exactly one change."""
import json
import os
import sys

RV = "/private/tmp/iyi-proof-review-720ad779"
W = os.path.join(RV, "w")
sys.path.insert(0, W)
import proof.run_proof as stages_mod  # noqa: E402
import proof.smoke_test as smoke_mod  # noqa: E402

original = smoke_mod._stage_driver_census


def chain(fx):
    args = fx.args()
    fx.pin_data = fx.pin()
    assert stages_mod.cmd_run1(args, disk_min_gb=0.0) == 0
    assert stages_mod.cmd_run2(args, disk_min_gb=0.0) == 0
    return args


def result(fx, unit):
    attempt = stages_mod.latest_attempt_dir(os.path.join(fx.report, *unit.split("/")))
    return json.load(open(os.path.join(attempt, "result.json"))), attempt


# m08: run3 disk minimum
with smoke_mod.StageFixture() as fx:
    args = chain(fx)
    rc = stages_mod.cmd_run3(args, drivers=fx.drivers, driver_limit_sec=5.0, grace_sec=0.1, disk_min_gb=1e9)
    record, attempt = result(fx, "run3/stage")
    print(json.dumps({"case": "m08 run3 disk minimum 1e9 GB", "rc": rc, "status": record["status"],
                      "disk": record["checks"].get("disk"), "driver_ran": os.path.exists(os.path.join(attempt, "driver.log"))}))

# m11/m12/m13: final identity, unit mismatch, attempt mismatch
for case in ("m11-final-identity", "m12-unit", "m13-attempt"):
    with smoke_mod.StageFixture() as fx:
        args = chain(fx)
        assert stages_mod.cmd_run3(args, drivers=fx.drivers, driver_limit_sec=5.0, grace_sec=0.1, disk_min_gb=0.0) == 0
        assert stages_mod.cmd_final(args) == 0
        record, attempt = result(fx, "run3/stage")
        path = os.path.join(attempt, "result.json")
        saved_path = os.environ["PATH"]
        if case == "m11-final-identity":
            os.environ["PATH"] = saved_path + ":/private/tmp/iyi-proof-review-720ad779"
            applied = "PATH appended one entry before final"
        elif case == "m12-unit":
            record["unit"] = "run3/other"
            json.dump(record, open(path, "w"), indent=2, sort_keys=True)
            applied = "result unit run3/stage -> run3/other"
        else:
            record["attempt"] = 2
            json.dump(record, open(path, "w"), indent=2, sort_keys=True)
            applied = "result attempt 1 -> 2"
        try:
            rc = stages_mod.cmd_final(args)
        finally:
            os.environ["PATH"] = saved_path
        final = json.load(open(os.path.join(fx.report, "final.json")))
        print(json.dumps({"case": case, "applied": applied, "final_rc": rc, "final_status": final["status"],
                          "identity": final["identity"]["status"], "reasons": final["reasons"][:2]}))


# m10: post-driver identity. One stub change: the stage driver touches the
# real compiler's mtime (read from its own shim.json) after its build.
def patched(driver, scenario):
    script_bytes, census = original(driver, scenario)
    text = script_bytes.decode()
    anchor = 'echo "the std/stage exercise holds"\n'
    touch = ("python3 -c 'import json,os,sys; os.utime(json.load(open(sys.argv[1]))[\"real\"])' "
             "\"$(dirname -- \"$TMPDIR\")/shim.json\"\n")
    assert text.count(anchor) == 1
    text = text.replace(anchor, touch + anchor)
    lines = text.split("\n")
    census["pass_sentinel"]["line"] = lines.index(anchor.rstrip("\n")) + 1
    census["script_sha256"] = __import__("hashlib").sha256(text.encode()).hexdigest()
    return text.encode(), census


smoke_mod._stage_driver_census = patched
with smoke_mod.StageFixture() as fx:
    args = chain(fx)
    rc = stages_mod.cmd_run3(args, drivers=fx.drivers, driver_limit_sec=5.0, grace_sec=0.1, disk_min_gb=0.0)
    record, attempt = result(fx, "run3/stage")
    print(json.dumps({"case": "m10 compiler mtime changed during the driver", "rc": rc, "status": record["status"],
                      "checks": record["checks"], "reasons": [r for r in record["reasons"] if "identity" in r][:1]}))
smoke_mod._stage_driver_census = original
