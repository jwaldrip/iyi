#!/bin/bash
# Reviewer evidence reruns for W=720ad779 on a /tmp clone. Writes only under RV.
set -u
RV=/tmp/iyi-proof-review-720ad779
W="$RV/w"
PY=/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3
PATHPIN=/Users/jwaldrip/.cache/iyi-corpus-venv/bin:/opt/homebrew/opt/curl/bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/bin:/bin:/usr/sbin:/sbin
step="$1"
cd "$W" || exit 99
case "$step" in
  default)
    env PATH="$PATHPIN" "$PY" -B -X pycache_prefix="$RV/pyc-default" proof/smoke_test.py >"$RV/smoke.txt" 2>"$RV/smoke.err"
    echo $? >"$RV/smoke.rc" ;;
  coverage)
    env PATH="$PATHPIN" "$PY" -B -X pycache_prefix="$RV/pyc-cov" proof/smoke_test.py --coverage "$RV/cov" >"$RV/coverage.txt" 2>"$RV/coverage.err"
    echo $? >"$RV/coverage.rc" ;;
  optimize)
    env PATH="$PATHPIN" "$PY" -B -O -X pycache_prefix="$RV/pyc-opt" proof/smoke_test.py >"$RV/opt-O.txt" 2>&1
    echo $? >"$RV/opt-O.rc"
    env PATH="$PATHPIN" PYTHONOPTIMIZE=1 "$PY" -B -X pycache_prefix="$RV/pyc-opt2" proof/smoke_test.py >"$RV/opt-env.txt" 2>&1
    echo $? >"$RV/opt-env.rc" ;;
  o3)
    env PATH="$PATHPIN" "$PY" -B -X pycache_prefix="$RV/pyc-o3" -c 'from proof.smoke_test import run_o3_suite; raise SystemExit(run_o3_suite())' >"$RV/o3.txt" 2>"$RV/o3.err"
    echo $? >"$RV/o3.rc" ;;
  plan)
    env PATH="$PATHPIN" "$PY" -B -X pycache_prefix="$RV/pyc-plan" proof/run_proof.py plan --p /Users/jwaldrip/dev/worktrees/iyi-stale-integration-repair --w "$W" --compiler /Users/jwaldrip/dev/worktrees/iyi-stale-integration-repair/.build/iyi >"$RV/plan.txt" 2>"$RV/plan.err"
    echo $? >"$RV/plan.rc" ;;
  *) echo "unknown step $step"; exit 98 ;;
esac
