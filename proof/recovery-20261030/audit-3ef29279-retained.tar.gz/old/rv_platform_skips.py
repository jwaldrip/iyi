"""List every platform-class skip with the nearest enclosing guard lines, to
check the contract rule: a platform skip's guard tests only uname, PSEP,
Windows, /proc or /dev/shm; any other guard makes it a tool skip."""
import glob
import json
import os
import re

W = "/private/tmp/iyi-proof-review-720ad779/w"
GUARD = re.compile(r"^\s*(if|elif|while|case)\b|\|\||&&")
ALLOWED = re.compile(r"uname|PSEP|WINDOWS|Windows|/proc|/dev/shm|OSTYPE|MSYS|MINGW|CYGWIN|darwin|Darwin|Linux")
for path in sorted(glob.glob(os.path.join(W, "proof", "census", "*.json"))):
    census = json.load(open(path))
    lines = open(os.path.join(W, census["script"]), encoding="utf-8").read().splitlines()
    for entry in census.get("skips", []):
        if entry["class"] != "platform":
            continue
        number = entry["line"]
        guards = []
        for k in range(number - 1, max(0, number - 12), -1):
            text = lines[k - 1].strip()
            if GUARD.search(text):
                guards.append((k, text[:140]))
            if text.startswith(("if ", "elif ")) and guards:
                break
        allowed = any(ALLOWED.search(g[1]) for g in guards)
        print(json.dumps({"driver": census["driver"], "line": number, "what": entry["what"][:90],
                          "echo": lines[number - 1].strip()[:140], "guards": guards[:3],
                          "guard_mentions_platform_token": allowed}))
