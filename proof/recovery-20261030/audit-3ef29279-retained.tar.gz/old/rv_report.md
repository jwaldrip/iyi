# Independent review: observed-corpus proof toolchain at 720ad779

**Verdict: NO-GO.** Running the full chain with this toolchain would fail on regex and http no matter how the compiler behaves. Separately, `final` can report PASS on a state that `run3` itself calls INVALID. I proved both by execution.

**Scope.** W HEAD is 720ad779952f302912803c82ebe3acbdbbc44e39, and P1 is 626463375298d357ffcb3223059f4d3adce6fb10. I ran everything on a `git clone --no-hardlinks` at RV/w (RV=/tmp/iyi-proof-review-720ad779). I used the pinned PATH, `python3 -B` and a unique `-X pycache_prefix`.
- **Worktrees untouched.** W and P porcelain are empty before and after. P's ignored-file count was 33360 before and after `plan`.
- **Unavoidable scratch outside RV.** Stage fixtures create and remove `/tmp/iyp-*` and `/tmp/iyi-o2-pin-*`, because D5 forces R to be `/private/tmp/iyp-*`. None are left behind.
- **Not run:** the corpus chain, `collector_free_floor.sh`, the relay, and the C-1/C-2 canaries. The canaries remain UNKNOWN to me.

## 1. State (section 8.1): PROVEN

- **W:** clean at 720ad779. `git ls-remote` gives 720ad779 for `proof/o3-integration-20261028`. The diff against P1 outside `proof/` is empty: all 34 changed paths are under `proof/`. `git grep build_census` and `git grep -i helper_exec` both exit 1.
- **P:** clean at 626463375. `origin/fix/stale-integration-repair` equals P1. Commit time is 1793257131.
- **Binaries:** `iyi --version` gives `[626463375]`. `strings` finds `626463375` in all four binaries (iyi, crystal, iyi-daemon, crystal-daemon). Their mtimes run from 1793257735 to 1793257796, all later than the commit. The iyi sha256 is 4aec5c40…9b87d16.

## 2. Evidence reruns (section 8.2): match EV

| Item | RV result | Matches EV |
|---|---|---|
| Default suite | exit 0; 240/240 seeds, 58/58 controls; HEADER clean=true | Yes. The seed and control id sets are identical. 12 `expect` strings differ only in temp-dir names (checked by normalization). |
| Coverage gate | exit 0; missing lines proofkit 0, run_proof 6, artifact_legs 1, roundtrip_shim 14, all allowlisted | Yes, identical |
| `-O` and `PYTHONOPTIMIZE=1` | both exit 2 | Yes |
| O3 suite | exit 0; 23/23 seeds, 6/6 controls | Yes |
| Plan against P with W=RV/w | exit 0; 29 validated; timeout is gtimeout 9.11; platform tmp `/private/var/folders/cx/…/T`; no new `/tmp/iyp-*`; P and W porcelain unchanged | Yes, but see F9: the probe isn't shown |
| Git checks | all pass | Yes |
| Dead-symbol screen | no top-level symbol is referenced only by its definition | n/a |

Outputs are in RV: `smoke.txt`, `coverage.txt`, `cov/`, `o3.txt`, `opt-*.txt`, `plan.txt` and `compare.txt`.

## 3. Findings

### F1. P1, PROVEN: the regex driver is refused by the shim at runtime, so Run 3 cannot pass

- **Where:**
  - `bench/std_regex_exercise.sh:416` runs `(export IYI_PATH="$WORK/patched${PSEP}…"; refuses …)`.
  - `refuses()` (`:218`) builds at `:231`: `"$IYI" build -o "$WORK/$name" "$WORK/$name.iyi"`.
  - `proof/census/regex.json` declares site `[231]` as `canonical-other` with no variants.
  - Five `mutate` calls pass a pattern, so this path runs on darwin: `:458`, `:459`, `:460`, `:467`, `:491`.
- **Evidence:** `RV/demo-misclassified.txt`. The real shim, with a fake REAL and the driver's exact env and argv, exits 125 with `REFUSED unclassified variant match` and writes a `refused` record. `verify_ledger` then returns MISCLASSIFIED. The control, with a canonical IYI_PATH, round-trips with exit 0 and no MISCLASSIFIED. The driver also prints "the broken module still refused" and sets `status=1`.
- **Why the validator misses it:** it reasons per line. An environment exported through a subshell into a function call is invisible to it.
- **Fix:**
  - Declare `regex:231` as `mixed`, with a negative variant whose `first_root` is `{WORK}/patched`, source `{WORK}/mutated_refusal.iyi` and output `{WORK}/mutated_refusal`. Count the calls from `:416`.
  - Add a validator rule: every function containing an invocation line whose call sites set or export `IYI_PATH`/`CRYSTAL_PATH` (prefix or subshell `export`) must be `mixed` or `negative`/`positive`.

### F2. P1, PROVEN: http's unchanged builds over a non-canonical root are MISCLASSIFIED, so Run 3 cannot pass

- **Where:**
  - `bench/std_http_exercise.sh:1384` and `:1405` run `IYI_PATH="$WORK/refbreak${PSEP}$IYI_PATH" "$IYI" build --no-codegen …`. These are reached at top level from `:1417-1464`, unguarded.
  - The census calls them `unchanged`, which is correct per C6.
  - `proofkit.py:3092-3102` flags every non-canonical `build`/`run` record with no variant ids, whatever its mode.
- **Evidence:** in `RV/demo-misclassified.txt`, the seed produces an exec record with mode `unchanged`, `canonical: false` and no variant ids. `verify_ledger` returns `{MISCLASSIFIED}`. The canonical control does not.
- **Decision needed.** C7's literal text ("a non-canonical build or run without variant ids") conflicts with C6 (unchanged mode for `--no-codegen` regardless of roots). The owner has to pick one:
  1. Exempt `unchanged` and `passthrough` records from that rule.
  2. Give the two http sites negative variants and stop treating them as unchanged.

  Either way it needs a seed using the real http shape.

### F3. P1, PROVEN: `final` doesn't re-derive the required drivers, so a Run 1 or Run 2 rerun after Run 3 reaches final PASS without the newly required driver

- **Where:**
  - `run_proof.py:1253-1274` trusts `run3/required.json` as written.
  - Only `cmd_run3` (`:1083-1113`) recomputes the set from the latest run1 exclusions and run2 rows.
- **Evidence:** `RV/demo-final-required.txt`, a real StageFixture chain with one stub change: the gate prints a std calibration exclusion once a flip file exists.
  - Run 1 a1, Run 2 and Run 3 all PASS.
  - Run 1 a2 PASSes, excluding `bench/std_extra_exercise.iyi`.
  - The required set recomputed from the latest attempts is `["stage","extra"]`, but `required.json` is `["stage"]`.
  - `final` exits 0 with PASS, units run1 a2, run2 a1 and run3/stage a1.
  - `run3` on the same state reports `INVALID: required.json mismatch`.
- **Why it matters:** the chain rules allow rerunning a stage, and Run 3 accepts prerequisites "regardless of status", so this order (fix a failed Run 1 after Run 3) is expected.
- **Fix:** in `final`, recompute the required set from the latest run1 and run2 attempts (and `DRIVERS_29`). Require it to equal `required.json`, and require every Run 3 latest attempt to be newer than both. Add the seed above.

### F4. P1, PROVEN: NOT-EXERCISED cannot fire for 165 of the 182 required negative variants

- **Where:** `proofkit.py:3208-3248` checks coverage only through declared vars, and positives through a roundtrip. A required negative variant with `vars: {}` that never runs leaves no trace.
- **Scale:** across the 29 censuses, 165 required negative variants have no vars (http 143, file 5, fuzz 2, regex 2, smtp 2, and one each in 11 more). C7 requires NOT-EXERCISED for "a required variant value with no record".
- **Evidence:** `RV/demo-not-exercised.txt`. On a passing stage ledger, a never-called required negative variant gives:
  - `{NOT-EXERCISED}` when it declares a var;
  - `[]` (PASS) when it has no vars.
- **What it lets through:** a negative mutation build that the driver silently doesn't make, or that dies in the shim before a record is written (an uncaught exception or ledger write error in exec mode; `roundtrip_shim.py:1220`, `:836-838`), passes verification. At sites without a phrase check, a non-zero exit reads as "caught" (for example `regex:424-432`).
- **Fix:** treat each required variant as needing at least one record bound to its id, and add a no-vars seed.

### F5. P2, PROVEN: contract checks the full suite cannot detect losing

Each mutant changes one line in a fresh clone, then the full default suite runs (`RV/mutants.jsonl`, `RV/mut/*.out`). All of the survivors below still exit 0 with 240/240 seeds and 58/58 controls.

| Mutant (check disabled) | Location | Suite |
|---|---|---|
| m11 final `check_identity` (C3 "once in final") | `run_proof.py:1282-1286` | **green** |
| m10 identity after each Run 3 driver (C3/C8) | `run_proof.py:1052` | **green** |
| m08 Run 3 ≥ 20 GB disk (C8) | `run_proof.py:912-922` | **green** |
| m12 / m13 final unit / attempt equals path (I2) | `run_proof.py:1166-1169` | **green** |
| m20 final `not required` | `run_proof.py:1291` | **green** |
| m03 roots, m04 timeout path, m05 nm path, m19 python version | `proofkit.py:866-925` | **green** |
| m01, m02, m07, m09, m14 | various | caught only by the omnibus `o7.seed.coverage-*` seeds (see F11) |
| m06, m15, m16, m17, m18, m21 (read before stat), m22 (read after utime) | various | caught by specific seeds |

The checks themselves work: `RV/demo-unguarded.txt` drives m08 to STOP, m11 to INVALID (PATH-CHANGED), m12 and m13 to FAIL with the named mismatch, and m10 to INVALID (COMPILER-MTIME-CHANGED during the driver). So nothing is broken today, but these checks have no guard against regression. Fix: one seed and control each.

### F6. P2, PROVEN (latent): D2's "variables must be wildcards" rule isn't enforced

- **Where:** a skip regex written against the placeholder `IYIVAR` validates but can never match at runtime. The rendering is at `proofkit.py:1307-1370`.
- **Evidence:** `RV/iyivar-seed.txt`. With `dns:213`'s regex changed to use the literal `\(IYIVAR\)`, `validate_census` returns `[]`, and `_skip_hits` misses a real printed skip line that the original regex catches. No current census contains `IYIVAR`, and the censuses are sha-pinned, so this is latent.
- **Fix:** reject the `IYIVAR` literal in skip and sentinel regexes, or render with two distinct placeholders and require both to match.

### F7. P3, PROVEN: manual seed 5's stated result fails on the `.times` clause

`.times` writes only on log growth plus one final sample (`proofkit.py:1014-1026`), so it can't show how long a silent stage ran.
- The gate's `run1_1.times` has 2 samples 38 ms apart; the gate slept 200 ms.
- The driver's `driver.times` has one line, `… 0`.

Fix: write a `<t0> 0` sample at spawn.

### F8. P3, informational: manual seed 4 is caught, but not with exactly `[E1-exec-token]`

Replacing fuzz's `exec_lines` `[76,97,163]` with `[73]` (the `fi`) gives `E1-exec-token` plus three `E1-stray-reference`, which are correct, because the real exec lines become undeclared. Adding 73 to the list gives exactly `[E1-exec-token]`.

### F9. P3: `plan` doesn't show the atime probe

The spec requires plan to show "the probe observable", but `inspect_pin_inputs` (`proofkit.py:488-626`) never runs it. Only `write_pin` does (`:678`). I ran the probe on RV's volume and it passed (atime moved 95 ms past mtime). `/private/tmp` and the platform temp root are on the same device (16777234).

### F10. P3: four tool-dependent skips are classified `platform`

These are `regex:51`, `xz:48`, `xz:52` and `zstd:43`, all guarded by python, lzma or zstd availability. That breaks C5's platform-guard rule, and the validator doesn't check it. Each `exit 0`s before its sentinel, so the run fails closed, but as FAIL rather than ENV-BLOCKED.

### F11. P3: omnibus coverage seeds go beyond the I5 seams

`o7.seed.coverage-*` seeds monkeypatch `git_clean`, `git_rev_parse`, `sha256_file`, `_first_output_line`, and the process-global `shutil.which` and `os.listdir` (`smoke_test.py:11829-11835`, `12074-12176`). One seed id stands for dozens of behaviours. That breaks seed discipline (a seed is one change, isolated, using only the I5 seams), and weakens what the coverage gate's 100% means.

### F12. P3: an unexercised branch inside an allowlisted range

The shim's `main` usage refusal (`roundtrip_shim.py:1246-1248`) is inside the allowlisted range 1244-1255, but no fixture, in-process or subprocess, runs it.

### F13. P3: artifact_legs looks for "cannot name it" only in the last 300 bytes

`artifact_legs.py:400-405` checks only the tail of C3's stderr. An earlier match becomes FAIL rather than STOP.

## 4. The five manual seeds (section 8.3): results in `RV/seeds.out`

| Seed | Applied exactly once | Ran | Result | Matches stated result |
|---|---|---|---|---|
| Forged PASS | control chain reaches final PASS; then the diff is exactly `checks.ledger: PASS→NOT-EXECUTED` with status kept PASS | yes | final exit 1, FAIL; reason `run3/stage attempt 1 forged status stored='PASS' recomputed='NOT-EXECUTED'` | **Yes** |
| `$dir` template | dns.negative.292 `first_root` `{WORK}/{dir}`→`{WORK}/$dir`; 1 change | yes | `[C5.7-template]` (line 292); control `[]` | **Yes** |
| Stale nonce | only line 1 of the passing ledger changed (sha before and after recorded) | yes | verify `{STALE}`; the shim exits 125 with `REFUSED ledger header nonce does not match config`; ledger 3089→3089 bytes; control appends (3089→3702, exit 0) | **Yes** |
| Fixed-offset `fi` | fuzz `exec_lines` →`[73]` (`fi`) | yes | E1-exec-token + 3× E1-stray-reference | **No**: extra violations, see F8. Caught. |
| Stage vs driver bound | slow-gate and driver-timeout scenarios, limit seam 0.1 s, one stub file each (plus census sha) | yes | gate PASS, run1 exit 0; driver TIMEOUT, survivors `[]`, no `sleep 30` left | **No** on `.times` (F7). Rest yes. |

## 5. Allowlist audit (section 8.4)

There are seven entries:
- `roundtrip_shim` 1240-1241 (`_exec_real`), 1244-1255 (`main`), 1256, and 1259-1260 (`__main__`);
- `run_proof` 1440-1446 and 1447 (`__main__`, including the `-O` refusal);
- `artifact_legs` 793-794.

All fall within P10's allowed places. None contains decision or verdict logic beyond `main`'s CLI glue. The one caveat is F12. **None rejected.** The `>>>>>>` lines in RV/cov are exactly these ranges.

## 6. Census spot checks (section 8.5): all hold

- **autocert:** the build is at :85 in `build()` (:82) and the exec at :103 in `run_own()` (:100). There is no `helper_exec`.
- **signal:68:** `mixed`, with own exec evidence (exec lines 80, 123, 411, token `"$WORK/$name"`).
- **regex:522:** `mixed`, with no own evidence.
- **Positive sites:**
  - compress:464 (exec 465);
  - math:555 (exec 557, `"$WORK/software/program"`);
  - tls:795 (exec 802, inside `downgraded`);
  - file:628 (exec 632, `"$WORK/$2-prog"`).
- **fuzz:** the token is `"$WORK/fuzz"`.
- **dns:** all 8 verdict lines carry a failure mark.
- **Templates and patterns:** no template contains `$`, a backquote, `*`, `?` or `[`. All 11 pattern variables have a reason line, and none admits `/`.

Spot checks don't catch F1 or F10.

## 7. Targeted attacks

- **(a) Amendment E** (`RV/matcher-attacks.txt`, real `match_variants` and the E2 regex):
  - **Unclassified (no match):** a root outside both, two levels below t/ or the platform root, t/ itself, a stale attempt's t/, a platform-prefix sibling, a symlink out, `{WORK}` inconsistent across fields, an undeclared value, a copied exercise.
  - **Matches:** symlinks whose realpath lands one level under a permitted root.
  - **Residual, by design:** any child of the shared platform root matches, including stale WORK directories. The nonce binds the records (seed 3).
- **(b)** The forged-final, stale-nonce, stage-vs-driver and fixed-offset guards hold (section 4). The forged-final guard does not cover F3.
- **(c)** See F5. These checks cannot fail under the current suite: final identity, post-driver identity, Run 3 disk, final unit/attempt, and four identity sub-checks.
- **(d) E3:** the shim hashes before `link`/`utime`. `verify_ledger` stats every `out_ref` before any read (`proofkit.py:3400-3436`). Mutants m18, m21 and m22 are caught.
- **(e) Script drift** (`RV/demo-script-drift.txt`): uncommitted or committed driver drift after the pin is caught by Run 3's `validate_census` (C5.1-sha) before the driver runs. There is no `driver.log` and no ledger. `check_identity` (W-DIRTY / W-HEAD) is the second line of defence.
- **(f)** Stages exit non-zero on any non-PASS (`run_proof.py:361`, `605`, `726`, `1147`, `1310`). The exception is F3: `final` PASSes over a stale required set.
- **(g) Skips:** tool hits are always ENV-BLOCKED, and with an empty baseline a platform hit is PARTIAL. The not_skips are fine (10 total; the one without a failure signal, `file:525`, is a `printf` to a file). Weaknesses are F6 and F10.

## 8. Review-1f coverage (section 8.6)

Each review-1f line range maps to at least one seed that ran and passed in RV `smoke.txt`. All 33 `review.*` keys have one.

| review-1f lines | Finding | Seeds |
|---|---|---|
| 11 | Run 3 hashlib crash | s5.seed.run3-import (+ s5.control.stage-chain) |
| 13 | final always PASS | s5.seed.final-forged-pass, final-missing-result, final-chain-mismatch, final-earlier-failure-omitted; manual seed 1 |
| 15-31 | matcher, whitelist, roots | s2.seed.matcher-variable-root, -unknown-dir, -outside-attempt, -copied-exercise, -two-same-kind, -conflicting-kinds, -negative-noquestion; s3.seed.unknown-patched-root; o7.seed.matcher-platform-two-level, -t-two-level; s2.seed.regression-1f; manual seed 2 |
| 33-36 | 2100 s stage caps | s5.seed.run1-slow-gate, s5.seed.run3-driver-timeout; manual seed 5 |
| 38-44 | verify_ledger census and nonce | s3.seed.ledger-stale-header, -misclassified, -not-exercised, -unfaithful, -divergence, -not-roundtripped, -positive-negative-only; o5.seed.header-chain, record-foreign-nonce, own-source-copy, e3-ref-missing, interrupted, run-signal; manual seed 3 (no-vars NOT-EXERCISED is unguarded: F4) |
| 46-60 | validator and census defects | s2.seed.validator-* (every rule, including the e1-* seeds), s2.seed.regression-1f; manual seeds 2 and 4 |
| 62 | skips unclassified | s5.seed.skip-env-blocked, skip-partial, skip-platform |
| 64-81 | smoke coverage, weak tests, asserts, `-O` | harness.seed.coverage-gap, optimize-refusal; s1.seed.ast-detects-assert; s1.seed.pin-nondescendant, pin-missing-stamp, identity-inode/-mtime/-path/-cross-invocation; amend-a.* (5); amend-b.* (6) |
| 82 | atime probe | amend-b.seed.probe-unobservable, probe-stat-mutates |
| 83 | pin and plan enforcement | s1.seed.plan-dirty, plan-stale-compiler, plan-invalid-census |
| 84-92 | shim `run` semantics and refusals | s3.seed.run-consumer-failure, run-signal-death, run-o-executes, implicit-file, run-sandbox, stdin-filename, unknown-option, cross-compile-roundtripped, roots-not-from-real, option-value-as-source, refusal-not-recorded |
| 93 | Run 3 prerequisites and continuation | s5.seed.run3-missing-prerequisite, required-mismatch, census-missing-continues |
| 96-98 | fresh cache, RG2r, exclusions location | s5.seed.gate-env-reused, rg2r-zero, exclusions-wrong-location |
| 99-103 | artifact_legs | s4.seed.row-oserror, nm-unpinned, outputs-missing, not-reusable-nested |
| 104-106 | run_bounded survivors | s1.seed.timeout-grandchild, log-holder-survivor |
| 107-108 | R path; duplicate sites | s1.seed.report-dir-name; s2.seed.validator-duplicate-site |
| 110-113 | retained outputs | harness header; s1.seed.plan-invalid-census; s2.seed.regression-1f |
| 115-122 | accepted items | review.accepted.* seeds (s1.seed.identity-binary-bytes, env-scrub, route-a-drivers, run1-missing-sentinel, sample-exclusion, p-nonzero-not-added, frame-function, symbol-c2, wrong-count, canonical-argv-drift, not-executed, ledger-divergence, copy-modified, regression-1f) |

No guard is checked by source text only; a scan found none. The weak spots are the omnibus coverage seeds (F11) and the unguarded checks (F5).

## 9. What GO needs

1. Fix F1 to F4, with seeds that use the real regex and http shapes, the run1-rerun ordering, and a no-vars variant. F2 needs the owner's decision first.
2. Add seeds for every F5 survivor.
3. Rerun the evidence set. A fresh reviewer then starts over.

F6 to F13 can ride along, but F6 and F10 should be closed before any census edit.
