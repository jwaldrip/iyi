#!/usr/bin/env python3
import argparse
import json
import os
import time
STATUS = 'PASS'
DROP_SAMPLE = False
WRITE_REPORT = True
RETURN_CODE = 0
INTERRUPT = False
parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True)
parser.add_argument('--compiler', required=True)
parser.add_argument('--work', required=True)
parser.add_argument('--report', required=True)
parser.add_argument('--workers', required=True)
parser.add_argument('--nm', required=True)
parser.add_argument('--expect-samples', type=int, required=True)
parser.add_argument('--expect-std', type=int, required=True)
parser.add_argument('--expect-total', type=int, required=True)
args = parser.parse_args()
if INTERRUPT:
    open(os.path.join(os.environ['TMPDIR'], 'interrupt-ready'), 'w').write('ready')
    time.sleep(30)
rows = []
sample_count = args.expect_samples - (1 if DROP_SAMPLE else 0)
for index in range(sample_count):
    rows.append({'kind':'sample','base':f'sample_{index}','name':f'samples/iyi/sample_{index}.iyi','status':STATUS,'p_nonzero':False})
for index in range(args.expect_std):
    base = 'std_stage_exercise' if index == 0 else f'std_fixture_{index:03d}_exercise'
    rows.append({'kind':'std','base':base,'name':f'bench/{base}.iyi','status':STATUS,'p_nonzero':(os.path.exists('/private/tmp/iyi-proof-audit-3ef29279/run2-rerun/flip') and index == 1)})
if WRITE_REPORT:
    with open(args.report, 'w', encoding='utf-8') as output:
        for row in rows:
            output.write(json.dumps(row) + '\n')
raise SystemExit(RETURN_CODE)
