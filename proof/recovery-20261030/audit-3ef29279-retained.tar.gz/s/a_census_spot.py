"""Census spot checks (addendum6 8.5) read directly from RV/w's census and
driver bytes, independent of the validator."""
import glob
import json
import os
import re

W = "/private/tmp/iyi-proof-audit-3ef29279/w"


def load(driver):
    census = json.load(open(os.path.join(W, "proof", "census", f"{driver}.json")))
    lines = open(os.path.join(W, census["script"]), encoding="utf-8").read().splitlines()
    return census, lines


def site_at(census, line):
    return next((s for s in census["sites"] if line in s["lines"]), None)


def evidence_for(census, line):
    return [e for e in census.get("exec_evidence", []) if e["site_line"] == line]


out = {}
# autocert direct
c, L = load("autocert")
own_sites = [s for s in c["sites"] if s["kind"] == "canonical-own"]
ev = c["exec_evidence"]
def enclosing_function(n):
    for k in range(n, 0, -1):
        m = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\(\)\s*\{", L[k - 1])
        if m:
            return m.group(1), k
    return None, None
out["autocert"] = {
    "own_sites": [(s["lines"], [L[n - 1].strip()[:90] for n in s["lines"]], enclosing_function(s["lines"][0])) for s in own_sites],
    "evidence": [(e["site_line"], e["exec_lines"], [L[n - 1].strip()[:90] for n in e["exec_lines"]], [enclosing_function(n) for n in e["exec_lines"]], e["exec_token"], e["name_from_calls"]) for e in ev],
    "helper_exec_anywhere": "helper_exec" in json.dumps(c),
}
# signal:68 mixed + own exec evidence; regex:522 mixed not own
c, L = load("signal")
s = site_at(c, 68)
out["signal68"] = {"kind": s["kind"], "variants": [v["id"] for v in s["variants"]], "evidence": [(e["exec_lines"], e["exec_token"], e["out_template"]) for e in evidence_for(c, 68)], "text": L[67].strip()}
c, L = load("regex")
s = site_at(c, 522)
out["regex522"] = {"kind": s["kind"], "variants": [(v["id"], v["sources"]) for v in s["variants"]], "evidence": evidence_for(c, 522), "text": L[521].strip()}
# positive sites
for driver, line in (("compress", 464), ("math", 555), ("tls", 795), ("file", 628)):
    c, L = load(driver)
    s = site_at(c, line)
    out[f"{driver}{line}"] = {"kind": s["kind"], "variant_kinds": sorted({v["kind"] for v in s["variants"]}),
                              "evidence": [(e["exec_lines"], e["exec_token"], e["out_template"]) for e in evidence_for(c, line)],
                              "exec_texts": [L[n - 1].strip()[:100] for e in evidence_for(c, line) for n in e["exec_lines"]]}
# fuzz token
c, L = load("fuzz")
out["fuzz"] = [(e["site_line"], e["exec_token"], e["exec_lines"]) for e in c["exec_evidence"]]
# dns verdict failure marks
c, L = load("dns")
bad = []
for e in c["exec_evidence"]:
    for n in e["verdict_lines"]:
        if not any(mark in L[n - 1] for mark in e["failure_marks"]):
            bad.append((n, L[n - 1].strip()))
out["dns_verdict_lines_without_mark"] = bad
out["dns_verdict_count"] = sum(len(e["verdict_lines"]) for e in c["exec_evidence"])
# templates and pattern vars over all 29
dollar = []
patterns = []
for path in sorted(glob.glob(os.path.join(W, "proof", "census", "*.json"))):
    c = json.load(open(path))
    L = open(os.path.join(W, c["script"]), encoding="utf-8").read().splitlines()
    for s in c["sites"]:
        for v in s.get("variants", []):
            for field in ("first_root", "output"):
                if isinstance(v.get(field), str) and re.search(r"[$`*?\[]", v[field]):
                    dollar.append((c["driver"], v["id"], field, v[field]))
            for src in v.get("sources", []):
                if re.search(r"[$`*?\[]", src):
                    dollar.append((c["driver"], v["id"], "sources", src))
            for name, spec in v.get("vars", {}).items():
                if "pattern" in spec:
                    reason = spec.get("pattern_reason_line")
                    patterns.append((c["driver"], v["id"], name, spec["pattern"], reason,
                                     L[reason - 1].strip()[:110] if isinstance(reason, int) and 0 < reason <= len(L) else None,
                                     "/" in spec["pattern"] or "." in spec["pattern"].replace("\\.", "")))
    for e in c.get("exec_evidence", []):
        if re.search(r"[$`*?\[]", e["out_template"]):
            dollar.append((c["driver"], "exec_evidence", "out_template", e["out_template"]))
out["templates_with_shell_syntax"] = dollar
out["pattern_vars"] = patterns
print(json.dumps(out, indent=1))
