"""Compare SEED/CONTROL ids, expect/got and totals between parent EV and reviewer RV."""
import re
import sys

pairs = [
    ("/private/tmp/j2-default.out", "/private/tmp/iyi-proof-audit-3ef29279/smoke.txt"),
    ("/private/tmp/j2-cov.out", "/private/tmp/iyi-proof-audit-3ef29279/coverage.txt"),
    ("/private/tmp/o3-j2.out", "/private/tmp/iyi-proof-audit-3ef29279/o3.txt"),
]
SEED = re.compile(r"^SEED (\S+) expect=(.*?) got=(.*?) applied=")
CONTROL = re.compile(r"^CONTROL (\S+) (\S+)")


def parse(path):
    seeds, controls, totals, other = {}, {}, [], []
    for line in open(path, encoding="utf-8", errors="replace"):
        line = line.rstrip("\n")
        m = SEED.match(line)
        if m:
            seeds[m.group(1)] = (m.group(2), m.group(3))
            continue
        m = CONTROL.match(line)
        if m:
            controls[m.group(1)] = m.group(2)
            continue
        if line.startswith(("TOTAL", "HARNESS", "COVERAGE module", "COVERAGE GATE")):
            totals.append(re.sub(r"listing=\S+", "listing=*", line))
    return seeds, controls, totals


for parent, mine in pairs:
    ps, pc, pt = parse(parent)
    ms, mc, mt = parse(mine)
    print(f"== {parent} vs {mine}")
    print(f"   seeds parent={len(ps)} mine={len(ms)} controls parent={len(pc)} mine={len(mc)}")
    print(f"   seed ids equal={set(ps) == set(ms)} control ids equal={set(pc) == set(mc)}")
    print(f"   seeds with expect!=got (mine)={[k for k, (e, g) in ms.items() if e != g]}")
    print(f"   controls not PASS (mine)={[k for k, v in mc.items() if v != 'PASS']}")
    diff_expect = [k for k in ps if k in ms and ps[k][0] != ms[k][0]]
    print(f"   expect differs parent/mine={diff_expect[:20]}")
    print(f"   totals equal={pt == mt}")
    for line in mt:
        print("   ", line)
