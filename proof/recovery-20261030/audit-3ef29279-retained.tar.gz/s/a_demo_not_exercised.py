"""Reviewer demo: verify_ledger NOT-EXERCISED for a required negative variant
that was never called. Control: the variant declares a var with values (the
shape the existing seeds use). Seed: the same variant with vars {} (the shape
of 165 of the 186 required negative variants in the 29 censuses)."""
import copy
import json
import os
import sys

RV = "/private/tmp/iyi-proof-audit-3ef29279"
W = os.path.join(RV, "w")
sys.path.insert(0, W)
import proof.proofkit as proofkit_mod  # noqa: E402
import proof.run_proof as stages_mod  # noqa: E402
import proof.smoke_test as smoke_mod  # noqa: E402

with smoke_mod.StageFixture() as fx:
    args = fx.args()
    fx.pin_data = fx.pin()
    stages_mod.cmd_run1(args, disk_min_gb=0.0)
    stages_mod.cmd_run2(args, disk_min_gb=0.0)
    stages_mod.cmd_run3(args, drivers=fx.drivers, driver_limit_sec=5.0, grace_sec=0.1, disk_min_gb=0.0)
    attempt = os.path.join(fx.report, "run3", "stage", "a1")
    config = json.load(open(os.path.join(attempt, "shim.json")))
    census = json.load(open(config["census"]))
    common = dict(driver="stage", nonce=config["nonce"], attempt=1, chain_id=fx.pin_data["chain_id"],
                  work_tmp=config["work_tmp"], repo=config["repo"], platform_tmp=config["platform_tmp"])
    ledger = os.path.join(attempt, "ledger.jsonl")
    base = proofkit_mod.verify_ledger(ledger, census=census, **common)

    def with_variant(vars_value):
        extended = copy.deepcopy(census)
        extended["sites"].append({
            "lines": [9999], "command": "build", "kind": "negative", "contains": [],
            "variants": [{
                "id": "stage.negative.never-called", "kind": "negative", "darwin": "required",
                "first_root": "{WORK}/patched", "sources": ["{REPO}/bench/std_stage_exercise.iyi"],
                "output": None, "requires": [], "vars": vars_value,
                "verdict": {"lines": [9999], "contains": []},
            }],
        })
        return extended

    control = proofkit_mod.verify_ledger(ledger, census=with_variant({"dir": {"lines": [9999], "values": ["patched"]}}), **common)
    seed = proofkit_mod.verify_ledger(ledger, census=with_variant({}), **common)
    print(json.dumps({
        "passing_ledger_statuses": sorted(base.statuses),
        "never_called_variant_with_values": sorted(control.statuses),
        "never_called_variant_without_vars": sorted(seed.statuses),
        "reasons_with_values": [r for r in control.reasons if "never-called" in r],
    }, indent=1))
