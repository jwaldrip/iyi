"""Reviewer manual seeds (addendum6 section 8.3) on /tmp copies.

Each seed: a passing control, exactly one change shown to have landed, the
run, and the observed result against the stated expectation. Evidence is
copied under RV before fixtures clean themselves up.
"""
import copy
import glob
import hashlib
import json
import os
import shutil
import subprocess
import sys

RV = "/private/tmp/iyi-proof-audit-3ef29279"
W = os.path.join(RV, "w")
OUT = os.path.join(RV, "seeds")
sys.path.insert(0, W)

import proof.proofkit as proofkit_mod  # noqa: E402
import proof.run_proof as stages_mod  # noqa: E402
import proof.smoke_test as smoke_mod  # noqa: E402

PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
os.makedirs(OUT, exist_ok=False)
REPORT = []


def emit(seed, **fields):
    line = json.dumps({"seed": seed, **fields}, sort_keys=True, default=str)
    print(line)
    REPORT.append(line)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def json_diff(before: dict, after: dict, prefix=""):
    changes = []
    for key in sorted(set(before) | set(after)):
        b, a = before.get(key, "<absent>"), after.get(key, "<absent>")
        if isinstance(b, dict) and isinstance(a, dict):
            changes.extend(json_diff(b, a, f"{prefix}{key}."))
        elif b != a:
            changes.append((f"{prefix}{key}", b, a))
    return changes


def run_chain(fx):
    fx.pin_data = fx.pin()
    r1 = stages_mod.cmd_run1(fx.args(), disk_min_gb=0.0)
    r2 = stages_mod.cmd_run2(fx.args(), disk_min_gb=0.0)
    r3 = stages_mod.cmd_run3(fx.args(), drivers=fx.drivers, driver_limit_sec=5.0, grace_sec=0.1, disk_min_gb=0.0)
    return r1, r2, r3


# ---------------------------------------------------------------- Seeds 1 and 3
with smoke_mod.StageFixture() as fx:
    r1, r2, r3 = run_chain(fx)
    final_control_rc = stages_mod.cmd_final(fx.args(), drivers=fx.drivers)
    final_path = os.path.join(fx.report, "final.json")
    final_control = json.load(open(final_path))
    shutil.copyfile(final_path, os.path.join(OUT, "seed1-final-control.json"))
    emit("forged-pass.control", run1=r1, run2=r2, run3=r3, final_rc=final_control_rc,
         final_status=final_control["status"], reasons=final_control["reasons"])

    # ---- Seed 3 (stale nonce) uses this passing ledger before Seed 1 mutates results.
    attempt = os.path.join(fx.report, "run3", "stage", "a1")
    ledger = os.path.join(attempt, "ledger.jsonl")
    shim_config = json.load(open(os.path.join(attempt, "shim.json")))
    census = json.load(open(shim_config["census"]))
    header = json.loads(open(ledger).readline())
    common = dict(census=census, driver="stage", nonce=shim_config["nonce"], attempt=1,
                  chain_id=fx.pin_data["chain_id"], work_tmp=shim_config["work_tmp"],
                  repo=shim_config["repo"], platform_tmp=shim_config["platform_tmp"])
    control_ledger = os.path.join(OUT, "seed3-ledger-control.jsonl")
    seed_ledger = os.path.join(OUT, "seed3-ledger-stale.jsonl")
    shutil.copyfile(ledger, control_ledger)
    shutil.copyfile(ledger, seed_ledger)
    control_verdict = proofkit_mod.verify_ledger(control_ledger, **common)
    raw = open(seed_ledger, "rb").read()
    old_nonce = header["nonce"].encode()
    new_nonce = b"0" * 32
    replaced = raw.replace(old_nonce, new_nonce, 1)
    # the header is line 1; records also carry the nonce, so prove only line 1 changed
    raw_lines, new_lines = raw.split(b"\n"), replaced.split(b"\n")
    changed_lines = [i + 1 for i, (a, b) in enumerate(zip(raw_lines, new_lines)) if a != b]
    open(seed_ledger, "wb").write(replaced)
    seed_verdict = proofkit_mod.verify_ledger(seed_ledger, **common)
    emit("stale-nonce.verify", control_statuses=sorted(control_verdict.statuses),
         applied={"occurrences_in_file_before": raw.count(old_nonce), "changed_lines": changed_lines,
                  "header_nonce_after": json.loads(open(seed_ledger).readline())["nonce"],
                  "sha_before": sha(raw), "sha_after": sha(replaced)},
         seed_statuses=sorted(seed_verdict.statuses), seed_reasons=list(seed_verdict.reasons))

    # shim against the stale ledger: same config, ledger key pointing at the copy
    def shim_run(ledger_path, label, argv):
        config = dict(shim_config)
        config["ledger"] = ledger_path
        config_path = os.path.join(OUT, f"seed3-shim-{label}.json")
        json.dump(config, open(config_path, "w"))
        env = proofkit_mod.base_env(fx.pin_data, {"TMPDIR": shim_config["work_tmp"]})
        before = open(ledger_path, "rb").read()
        proc = subprocess.run([PY, "-B", os.path.join(shim_config["repo"], "proof", "roundtrip_shim.py"),
                               "--config", config_path, "--", *argv],
                              cwd=shim_config["repo"], env=env, stdin=subprocess.DEVNULL,
                              capture_output=True, text=True)
        after = open(ledger_path, "rb").read()
        return proc.returncode, proc.stderr.strip(), len(before), len(after), before == after

    rc, err, lb, la, same = shim_run(seed_ledger, "stale", ["doc", "x.iyi"])
    emit("stale-nonce.shim", rc=rc, stderr=err, ledger_bytes_before=lb, ledger_bytes_after=la, unchanged=same)
    rc, err, lb, la, same = shim_run(control_ledger, "control", ["doc", "x.iyi"])
    emit("stale-nonce.shim-control", rc=rc, stderr=err, ledger_bytes_before=lb, ledger_bytes_after=la, unchanged=same)

    # ---- Seed 1: forge run3/stage result: one required check non-PASS, status left PASS
    result_path = os.path.join(attempt, "result.json")
    before_bytes = open(result_path, "rb").read()
    record = json.loads(before_bytes)
    forged = copy.deepcopy(record)
    forged["checks"]["ledger"] = "NOT-EXECUTED"
    after_bytes = (json.dumps(forged, indent=2, sort_keys=True) + "\n").encode()
    open(result_path, "wb").write(after_bytes)
    diff = json_diff(record, json.loads(open(result_path).read()))
    final_seed_rc = stages_mod.cmd_final(fx.args(), drivers=fx.drivers)
    final_seed = json.load(open(final_path))
    shutil.copyfile(final_path, os.path.join(OUT, "seed1-final-forged.json"))
    shutil.copyfile(result_path, os.path.join(OUT, "seed1-run3-result-forged.json"))
    emit("forged-pass.seed", applied={"diff": diff, "status_kept": forged["status"],
                                      "sha_before": sha(before_bytes), "sha_after": sha(after_bytes)},
         final_rc=final_seed_rc, final_status=final_seed["status"], units=final_seed["units"],
         reasons=final_seed["reasons"])

# ---------------------------------------------------------------- Seed 2: $dir template
dns_census_path = os.path.join(W, "proof", "census", "dns.json")
dns_text = open(dns_census_path, encoding="utf-8").read()
dns = json.loads(dns_text)
script_bytes = open(os.path.join(W, dns["script"]), "rb").read()
control = proofkit_mod.validate_census(dns, script_bytes, dns["script"])
seed = copy.deepcopy(dns)
hits = []
for site in seed["sites"]:
    for variant in site.get("variants", []):
        if variant.get("first_root") == "{WORK}/{dir}":
            hits.append((site["lines"], variant["id"]))
target_site, target_id = hits[0]
changed = 0
for site in seed["sites"]:
    for variant in site.get("variants", []):
        if variant["id"] == target_id and changed == 0:
            variant["first_root"] = "{WORK}/$dir"
            changed += 1
violations = proofkit_mod.validate_census(seed, script_bytes, dns["script"])
json.dump(seed, open(os.path.join(OUT, "seed2-dns.json"), "w"), indent=1)
emit("dollar-dir.template", control=[v[0] for v in control], candidates=len(hits),
     applied={"variant": target_id, "site_lines": target_site, "changes": changed,
              "diff": json_diff({"v": dns}, {"v": seed})[:3] if False else None},
     violations=violations, rule_ids=[v[0] for v in violations])

# ---------------------------------------------------------------- Seed 4: fixed-offset fi
fuzz_path = os.path.join(W, "proof", "census", "fuzz.json")
fuzz = json.load(open(fuzz_path))
fuzz_lines = open(os.path.join(W, fuzz["script"]), encoding="utf-8").read().splitlines()
fuzz_bytes = open(os.path.join(W, fuzz["script"]), "rb").read()
control = proofkit_mod.validate_census(fuzz, fuzz_bytes, fuzz["script"])
own_sites = [s for s in fuzz["sites"] if s["kind"] in ("canonical-own", "mixed")]
evidence_index = next(i for i, e in enumerate(fuzz["exec_evidence"]) if any(e["site_line"] in s["lines"] for s in own_sites))
evidence = fuzz["exec_evidence"][evidence_index]
site_line = evidence["site_line"]
first_fi = next(n for n in range(site_line + 1, len(fuzz_lines) + 1) if fuzz_lines[n - 1].strip() == "fi")
seed = copy.deepcopy(fuzz)
seed["exec_evidence"][evidence_index]["exec_lines"] = evidence["exec_lines"] + [first_fi]
violations = proofkit_mod.validate_census(seed, fuzz_bytes, fuzz["script"])
json.dump(seed, open(os.path.join(OUT, "seed4-fuzz.json"), "w"), indent=1)
emit("fixed-offset-fi", control=[v[0] for v in control],
     applied={"evidence_index": evidence_index, "site_line": site_line,
              "exec_lines_before": evidence["exec_lines"], "exec_lines_after": evidence["exec_lines"] + [first_fi],
              "fi_text": fuzz_lines[first_fi - 1], "token": evidence["exec_token"]},
     violations=violations, rule_ids=[v[0] for v in violations])

# ---------------------------------------------------------------- Seed 5: stage bound versus driver bound
LIMIT = 0.1
with smoke_mod.StageFixture("run1-slow-gate") as fx:
    fx.pin_data = fx.pin()
    rc = stages_mod.cmd_run1(fx.args(), disk_min_gb=0.0)
    result = smoke_mod._stage_result(fx.report, "run1")
    attempt = stages_mod.latest_attempt_dir(os.path.join(fx.report, "run1"))
    times = open(os.path.join(attempt, "run1_1.times")).read().split("\n")
    shutil.copyfile(os.path.join(attempt, "run1_1.times"), os.path.join(OUT, "seed5-run1_1.times"))
    emit("stage-bound.run1-gate", applied=smoke_mod._scenario_applied(fx), limit_seam=LIMIT,
         rc=rc, status=result.get("status"), gate=result.get("checks", {}).get("gate-1.1"),
         elapsed_ns=result["ended_ns"] - result["started_ns"], times=[t for t in times if t])

with smoke_mod.StageFixture("driver-timeout") as fx:
    fx.pin_data = fx.pin()
    fx.write_prerequisites()
    pgid_probe_before = subprocess.run(["/bin/ps", "-axo", "pid=,command="], capture_output=True, text=True).stdout
    rc = stages_mod.cmd_run3(fx.args(), drivers=fx.drivers, driver_limit_sec=LIMIT, grace_sec=0.1, disk_min_gb=0.0)
    result = smoke_mod._stage_result(fx.report, "run3/stage")
    attempt = stages_mod.latest_attempt_dir(os.path.join(fx.report, "run3", "stage"))
    times = open(os.path.join(attempt, "driver.times")).read().split("\n")
    shutil.copyfile(os.path.join(attempt, "driver.times"), os.path.join(OUT, "seed5-driver.times"))
    script = open(os.path.join(fx.w, "bench", "std_stage_exercise.sh")).read()
    leftovers = [line for line in subprocess.run(["/bin/ps", "-axo", "pid=,command="], capture_output=True, text=True).stdout.splitlines()
                 if "sleep 30" in line]
    emit("stage-bound.run3-driver", applied={"scenario_files_changed": fx.stub_difference_count,
                                             "sleep_line_present": "sleep 30; status=0" in script},
         limit_seam=LIMIT, rc=rc, status=result.get("status"), exit_check=result.get("checks", {}).get("exit"),
         survivors=result.get("survivors"), sleep30_processes_after=leftovers,
         elapsed_ns=result["ended_ns"] - result["started_ns"], times=[t for t in times if t])

open(os.path.join(OUT, "seeds.jsonl"), "w").write("\n".join(REPORT) + "\n")
