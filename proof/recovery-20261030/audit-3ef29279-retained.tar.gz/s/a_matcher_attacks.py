"""Amendment E attacks on the real matcher (match_variants) and the ledger OUT
regex (verify_ledger E2), using dns.json's {WORK}/{dir} variant. Writes only
under RV (symlinks are created under RV; platform_tmp paths are never created).
"""
import json
import os
import subprocess
import sys

RV = "/private/tmp/iyi-proof-audit-3ef29279"
W = os.path.join(RV, "w")
sys.path.insert(0, W)
import proof.proofkit as proofkit_mod  # noqa: E402
import proof.roundtrip_shim as shim_mod  # noqa: E402

ROOT = os.path.join(RV, "matcher-attacks")
os.makedirs(ROOT, exist_ok=False)
REPO = os.path.realpath(W)
census = json.load(open(os.path.join(W, "proof", "census", "dns.json")))
PLATFORM = os.path.realpath(subprocess.run(["getconf", "DARWIN_USER_TEMP_DIR"], capture_output=True, text=True, check=True).stdout.strip())
t = os.path.realpath(os.path.join(ROOT, "R", "run3", "dns", "a2", "t"))
stale_t = os.path.realpath(os.path.join(ROOT, "R", "run3", "dns", "a1", "t"))
for d in (t, stale_t):
    os.makedirs(d)
own = os.path.join(REPO, "bench", "std_dns_exercise.iyi")
os.symlink("/private/tmp/iyi-proof-audit-3ef29279/matcher-attacks/elsewhere", os.path.join(t, "link-out"))
os.makedirs(os.path.join(ROOT, "elsewhere"))
os.symlink(os.path.join(PLATFORM, "tmp.SYMLINKED"), os.path.join(t, "link-platform"))
os.symlink(t, os.path.join(ROOT, "t-alias"))


def match(root, out, sources=(own,)):
    status, ids, kind, bindings = shim_mod.match_variants(
        census, "build", root, list(sources), out, t, REPO, platform_tmp=PLATFORM)
    return status, ids, kind, bindings


cases = [
    ("control: t/<w>/noquestion", os.path.join(t, "tmp.A", "noquestion"), os.path.join(t, "tmp.A", "noquestion", "program")),
    ("control: platform/<w>/noquestion", os.path.join(PLATFORM, "tmp.A", "noquestion"), os.path.join(PLATFORM, "tmp.A", "noquestion", "program")),
    ("outside both roots", "/private/tmp/iyi-proof-audit-3ef29279/x/noquestion", "/private/tmp/iyi-proof-audit-3ef29279/x/noquestion/program"),
    ("nested two below t", os.path.join(t, "tmp.A", "deeper", "noquestion"), os.path.join(t, "tmp.A", "deeper", "noquestion", "program")),
    ("nested two below platform", os.path.join(PLATFORM, "tmp.A", "deeper", "noquestion"), os.path.join(PLATFORM, "tmp.A", "deeper", "noquestion", "program")),
    ("t itself as WORK (one component)", os.path.join(t, "noquestion"), os.path.join(t, "noquestion", "program")),
    ("stale attempt a1/t", os.path.join(stale_t, "tmp.A", "noquestion"), os.path.join(stale_t, "tmp.A", "noquestion", "program")),
    ("platform prefix sibling", PLATFORM + "X/tmp.A/noquestion", PLATFORM + "X/tmp.A/noquestion/program"),
    ("symlink in t to outside", os.path.join(t, "link-out", "noquestion"), os.path.join(t, "link-out", "noquestion", "program")),
    ("symlink in t to platform child", os.path.join(t, "link-platform", "noquestion"), os.path.join(t, "link-platform", "noquestion", "program")),
    ("t reached via symlinked alias", os.path.join(ROOT, "t-alias", "tmp.A", "noquestion"), os.path.join(ROOT, "t-alias", "tmp.A", "noquestion", "program")),
    ("WORK differs between root and output", os.path.join(t, "tmp.A", "noquestion"), os.path.join(t, "tmp.B", "noquestion", "program")),
    ("WORK differs root(t) vs output(platform)", os.path.join(t, "tmp.A", "noquestion"), os.path.join(PLATFORM, "tmp.A", "noquestion", "program")),
    ("undeclared dir value", os.path.join(t, "tmp.A", "notadir"), os.path.join(t, "tmp.A", "notadir", "program")),
    ("copied exercise as source", os.path.join(t, "tmp.A", "noquestion"), os.path.join(t, "tmp.A", "noquestion", "program")),
]
results = {}
for label, root, out in cases:
    sources = (own,)
    if label == "copied exercise as source":
        sources = ("/private/tmp/x/std_dns_exercise.iyi",)
    status, ids, kind, bindings = match(root, out, sources)
    results[label] = status
    print(json.dumps({"case": label, "status": status, "ids": ids, "kind": kind, "bindings": bindings,
                      "root_realpath": os.path.realpath(root)}))

# verify_ledger E2 OUT regex with the same roots: nested and outside must not match
pattern = proofkit_mod._ledger_out_regex("{WORK}/{name}", work_tmp=t, repo=REPO, name="dns-plain", platform_tmp=PLATFORM)
for label, out in (("e2 control t", os.path.join(t, "tmp.A", "dns-plain")),
                   ("e2 control platform", os.path.join(PLATFORM, "tmp.A", "dns-plain")),
                   ("e2 nested", os.path.join(t, "tmp.A", "x", "dns-plain")),
                   ("e2 outside", "/private/tmp/q/dns-plain"),
                   ("e2 stale attempt", os.path.join(stale_t, "tmp.A", "dns-plain"))):
    print(json.dumps({"case": label, "fullmatch": bool(pattern.fullmatch(os.path.realpath(out)))}))
print("SUMMARY", json.dumps(results, sort_keys=True))
