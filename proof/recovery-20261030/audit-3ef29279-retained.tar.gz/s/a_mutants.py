"""Reviewer mutation runs: each mutant is a fresh local clone of RV/w with
exactly one textual change (asserted to match once), then the full default
smoke suite. Reports which seeds/controls fail. Writes only under RV/mut."""
import concurrent.futures
import json
import os
import re
import subprocess
import sys

RV = "/private/tmp/iyi-proof-audit-3ef29279"
SRC = os.path.join(RV, "w")
MUT = os.path.join(RV, "mut")
PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
PATHPIN = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin:/opt/homebrew/opt/curl/bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/bin:/bin:/usr/sbin:/sbin"

MUTANTS = [
    ("m01-python-realpath", "proof/proofkit.py",
     '        "python realpath",\n        pin["python_path"],\n        os.path.realpath(sys.executable),\n',
     '        "python realpath",\n        pin["python_path"],\n        pin["python_path"],\n'),
    ("m02-census-changed", "proof/proofkit.py",
     '        "census sha256 map",\n        pin["census_sha256"],\n        current_census_shas,\n',
     '        "census sha256 map",\n        pin["census_sha256"],\n        pin["census_sha256"],\n'),
    ("m03-canonical-roots", "proof/proofkit.py",
     '        "canonical roots",\n        pin["canonical_roots"],\n        roots,\n',
     '        "canonical roots",\n        pin["canonical_roots"],\n        pin["canonical_roots"],\n'),
    ("m04-timeout-realpath", "proof/proofkit.py",
     '        "timeout realpath",\n        pin["timeout_path"],\n        timeout_real,\n',
     '        "timeout realpath",\n        pin["timeout_path"],\n        pin["timeout_path"],\n'),
    ("m05-nm-realpath", "proof/proofkit.py",
     '_require_equal("NM-CHANGED", "nm realpath", pin["nm_path"], nm_real)',
     '_require_equal("NM-CHANGED", "nm realpath", pin["nm_path"], pin["nm_path"])'),
    ("m06-platform-tmp-identity", "proof/proofkit.py",
     '        "platform temp root",\n        pin["platform_tmp"],\n        current_platform_tmp,\n',
     '        "platform temp root",\n        pin["platform_tmp"],\n        pin["platform_tmp"],\n'),
    ("m07-run3-no-refused", "proof/run_proof.py",
     '        if "observed-roundtrip-shim: REFUSED" in log_text:\n',
     '        if False:\n'),
    ("m08-run3-disk", "proof/run_proof.py",
     '        disk_min_gb,\n        checks,\n        reasons,\n        check_name="disk",\n',
     '        0.0,\n        checks,\n        reasons,\n        check_name="disk",\n'),
    ("m09-run3-census-revalidate", "proof/run_proof.py",
     '        violations = validate_census(census, script_bytes, script_relpath)\n',
     '        violations = []\n'),
    ("m10-run3-post-driver-identity", "proof/run_proof.py",
     '    _check_stage_identity(pin, checks, reasons)\n    return _finish_attempt(\n        attempt_dir, pin, unit, checks, reasons, started_ns, survivors\n    )\n\n\ndef cmd_run3(',
     '    return _finish_attempt(\n        attempt_dir, pin, unit, checks, reasons, started_ns, survivors\n    )\n\n\ndef cmd_run3('),
    ("m11-final-identity", "proof/run_proof.py",
     '        check_identity(pin)\n    except IdentityError as error:\n        identity["status"] = "INVALID"\n',
     '        pass\n    except IdentityError as error:\n        identity["status"] = "INVALID"\n'),
    ("m12-final-unit-mismatch", "proof/run_proof.py",
     '    if record.get("unit") != unit:\n',
     '    if False:\n'),
    ("m13-final-attempt-mismatch", "proof/run_proof.py",
     '    if record.get("attempt") != attempt:\n',
     '    if False:\n'),
    ("m14-baseline-header", "proof/run_proof.py",
     'r"^-- running sibling: std_([A-Za-z0-9_]+)_exercise\\.sh\\s*$",',
     'r"^-- NEVER sibling: std_([A-Za-z0-9_]+)_exercise\\.sh\\s*$",'),
    ("m15-ledger-begin-end-fields", "proof/proofkit.py",
     '            if field not in ("phase", "t_ns") and (\n',
     '            if False and (\n'),
    ("m16-ledger-foreign-nonce", "proof/proofkit.py",
     '            record.get("nonce") != header["nonce"]\n            or record.get("driver") != header["driver"]\n',
     '            False\n            and record.get("driver") != header["driver"]\n'),
    ("m17-shim-refusal-record", "proof/roundtrip_shim.py",
     '    record["exit"] = 125\n    try:\n        write_record(str(config["ledger"]), record)\n',
     '    record["exit"] = 125\n    try:\n        pass\n'),
    ("m18-shim-e3-utime", "proof/roundtrip_shim.py",
     '            os.utime(output, ns=(atime_set_ns, out_mtime_ns))\n',
     '            pass\n'),
    ("m19-python-version", "proof/proofkit.py",
     '        "python version",\n        pin["python_version"],\n        sys.version.splitlines()[0],\n',
     '        "python version",\n        pin["python_version"],\n        pin["python_version"],\n'),
    ("m20-final-required-recompute-control", "proof/run_proof.py",
     '    elif reasons or not required or any(value != "PASS" for value in statuses):\n',
     '    elif reasons or any(value != "PASS" for value in statuses):\n'),
]
SEED = re.compile(r"^SEED (\S+) expect=(.*?) got=(.*?) applied=")


def run(mutant):
    mutant_id, rel, old, new = mutant
    target = os.path.join(MUT, mutant_id)
    subprocess.run(["git", "clone", "--quiet", SRC, target], check=True)
    path = os.path.join(target, rel)
    text = open(path, encoding="utf-8").read()
    count = text.count(old)
    if count != 1:
        return {"id": mutant_id, "error": f"anchor count {count}"}
    mutated = text.replace(old, new, 1)
    open(path, "w", encoding="utf-8").write(mutated)
    diff = subprocess.run(["git", "-C", target, "diff", "--stat"], capture_output=True, text=True).stdout.strip()
    env = dict(os.environ)
    env["PATH"] = PATHPIN
    out_path = os.path.join(MUT, f"{mutant_id}.out")
    with open(out_path, "w") as out:
        proc = subprocess.run([PY, "-B", "-X", f"pycache_prefix={target}-pyc", os.path.join(target, "proof", "smoke_test.py")],
                              cwd=target, env=env, stdout=out, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
    failed_seeds, failed_controls, total = [], [], ""
    for line in open(out_path, encoding="utf-8", errors="replace"):
        m = SEED.match(line)
        if m and m.group(2) != m.group(3):
            failed_seeds.append(m.group(1))
        if line.startswith("CONTROL ") and " FAIL " in line:
            failed_controls.append(line.split()[1])
        if line.startswith("TOTAL"):
            total = line.strip()
    return {"id": mutant_id, "rc": proc.returncode, "diff": diff, "failed_seeds": failed_seeds,
            "failed_controls": failed_controls, "total": total}


if __name__ == "__main__":
    os.makedirs(MUT, exist_ok=True)
    selected = [m for m in MUTANTS if len(sys.argv) < 2 or m[0] in sys.argv[1:]]
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        for result in pool.map(run, selected):
            print(json.dumps(result, sort_keys=True), flush=True)
