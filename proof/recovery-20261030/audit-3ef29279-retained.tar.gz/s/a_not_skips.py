"""List every census not_skips line with two lines of following context, and
flag the ones with no failure signal nearby (status=1 / exit 1 / return 1 /
FAIL), which would be candidates for a silently passing skip."""
import glob
import json
import os
import re

W = "/private/tmp/iyi-proof-audit-3ef29279/w"
total = 0
suspects = []
for path in sorted(glob.glob(os.path.join(W, "proof", "census", "*.json"))):
    census = json.load(open(path))
    lines = open(os.path.join(W, census["script"]), encoding="utf-8").read().splitlines()
    for entry in census.get("not_skips", []):
        total += 1
        number = entry["line"]
        window = [text.strip() for text in lines[max(0, number - 3):number + 3]]
        context = " | ".join(window)
        if not re.search(r"status=1|exit 1|return 1|FAIL|return 2", context):
            suspects.append(f"{census['driver']}:{number} :: {lines[number - 1].strip()[:150]} :: next={' | '.join(t.strip() for t in lines[number:number + 3])[:160]}")
print("total_not_skips", total)
print("without_failure_signal_within_3_lines", len(suspects))
for item in suspects:
    print(" ", item)
