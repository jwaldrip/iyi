"""Map every REVIEW_ITEMS key (review-1f findings plus contract items) to the fixture
ids that actually ran in smoke.txt and whether each matched expectation."""
import json
import os
import re
import sys

AUD = "/private/tmp/iyi-proof-audit-3ef29279"
sys.path.insert(0, os.path.join(AUD, "w"))
import proof.smoke_test as smoke  # noqa: E402

SEED = re.compile(r"^SEED (\S+) expect=(.*?) got=(.*?) applied=")
seeds, controls = {}, {}
for line in open(os.path.join(AUD, "smoke.txt"), encoding="utf-8", errors="replace"):
    m = SEED.match(line)
    if m:
        seeds[m.group(1)] = (m.group(2) == m.group(3))
    elif line.startswith("CONTROL "):
        parts = line.split()
        controls[parts[1]] = (parts[2] == "PASS")
rows = []
for key, ids in smoke.REVIEW_ITEMS.items():
    ran_seeds = [i for i in ids if i in seeds]
    bad = [i for i in ids if (i in seeds and not seeds[i]) or (i in controls and not controls[i])]
    missing = [i for i in ids if i not in seeds and i not in controls]
    rows.append({"key": key, "fixtures": len(ids), "seeds_ran": len(ran_seeds), "bad": bad, "not_run": missing})
out = os.path.join(AUD, "review-map.jsonl")
open(out, "w").write("\n".join(json.dumps(r) for r in rows) + "\n")
no_seed = [r["key"] for r in rows if r["seeds_ran"] == 0]
bad = [r for r in rows if r["bad"]]
print("keys", len(rows), "review.*", sum(r["key"].startswith("review.") for r in rows), "keys_without_ran_seed", no_seed, "keys_with_bad", [(r["key"], r["bad"]) for r in bad])
print("not_run_any", [(r["key"], r["not_run"]) for r in rows if r["not_run"]])
