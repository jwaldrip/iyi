"""Scan every census-cited $IYI invocation line for option tokens the shim's
OPTION_TABLE would refuse, and for command words. Read-only over RV/w."""
import glob
import json
import os
import re
import shlex
import sys

W = "/private/tmp/iyi-proof-audit-3ef29279/w"
sys.path.insert(0, W)
import proof.roundtrip_shim as shim_mod  # noqa: E402

INV = re.compile(r'(\$IYI|"\$IYI"|\$\{IYI\})(?![A-Za-z0-9_:])')
problems = []
for path in sorted(glob.glob(os.path.join(W, "proof", "census", "*.json"))):
    census = json.load(open(path))
    lines = open(os.path.join(W, census["script"]), encoding="utf-8", errors="replace").read().splitlines()
    for number, text in enumerate(lines, 1):
        if text.lstrip().startswith("#") or not INV.search(text):
            continue
        tail = text[INV.search(text).end():]
        # join backslash continuations
        n = number
        while tail.rstrip().endswith("\\") and n < len(lines):
            tail = tail.rstrip()[:-1] + " " + lines[n]
            n += 1
        tail = re.sub(r"\$\([^)]*\)", "X", tail)
        try:
            words = shlex.split(tail, posix=True)
        except ValueError:
            words = tail.split()
        stop = {";", "&&", "||", "|", ">", "2>&1", ")", "then", "}"}
        cleaned = []
        for word in words:
            if word in stop or word.startswith(">") or word.startswith("2>") or word.startswith("<"):
                break
            cleaned.append(word)
        if not cleaned:
            continue
        command = cleaned[0]
        for token in cleaned[1:]:
            if token == "--":
                break
            if token.startswith("-") and token != "-" and not token.startswith("$"):
                if shim_mod._option(token) is None:
                    problems.append((census["driver"], number, command, token, text.strip()[:140]))
print(json.dumps(problems, indent=1))
print("problem_count", len(problems))
