"""Audit mutation runner. Each mutant is a fresh APFS clone of AUD/w with exactly
one textual change whose anchor must match exactly once. The full default smoke
suite is then run against the mutant clone (PYTHONPATH/cwd bound to the clone,
never W). Retains diff, full output and a one-line JSON result per mutant.
Usage: b_mutants.py [--list] [id ...]"""
import concurrent.futures
import json
import os
import re
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import a_mutants as base  # noqa: E402

AUD = "/private/tmp/iyi-proof-audit-3ef29279"
SRC = os.path.join(AUD, "w")
MUT = os.path.join(AUD, "mut")
PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
PATHPIN = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin:/opt/homebrew/opt/curl/bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/bin:/bin:/usr/sbin:/sbin"

EXTRA = [
    ("g01-F7-times-t0-sample", "proof/proofkit.py",
     '            times_file.write(f"{time.monotonic_ns()} 0\\n")\n',
     '            pass\n'),
    ("g02-F9-plan-probe", "proof/run_proof.py",
     '        probe = probe_atime_observable(probe_dir)\n',
     '        probe = {"sha256": "x", "inode": 0, "atime_after_exec_ns": 0}\n'),
    ("g03-F13-cannot-name-tail-only", "proof/artifact_legs.py",
     'if leg == "C3" and "cannot name it" in stderr_text:\n',
     'if leg == "C3" and "cannot name it" in stderr_text[-300:]:\n'),
    ("g04-F3-final-required-mismatch", "proof/run_proof.py",
     '    if required != recomputed_required:\n',
     '    if False:\n'),
    ("g05-F2-unchanged-exemption-removed", "proof/proofkit.py",
     '            and not variant_ids\n            and mode != "unchanged"\n        ):\n',
     '            and not variant_ids\n        ):\n'),
    ("g06-F2-noncanonical-rule-disabled", "proof/proofkit.py",
     '            and not variant_ids\n            and mode != "unchanged"\n        ):\n',
     '            and not variant_ids\n            and mode != "unchanged"\n            and mode == "never"\n        ):\n'),
    ("g07-F4-required-no-record-disabled", "proof/proofkit.py",
     '        if not any(\n            variant_id in _ledger_variant_ids(record)\n            for record in records\n        ):\n',
     '        if False and not any(\n            variant_id in _ledger_variant_ids(record)\n            for record in records\n        ):\n'),
    ("g08-value-coverage-disabled", "proof/proofkit.py",
     '                    if value not in observed:\n',
     '                    if False:\n'),
    ("g09-E3-inode-disabled", "proof/proofkit.py",
     '        if getattr(stat_result, "st_ino", None) != record.get("out_ino"):\n',
     '        if False:\n'),
    ("g10-E3-atime-disabled", "proof/proofkit.py",
     '            or observed_atime <= recorded_mtime\n',
     '            or False\n'),
    ("g11-OUT-MODIFIED-disabled", "proof/proofkit.py",
     '        if observed_sha != expected_sha:\n',
     '        if False:\n'),
    ("g12-E3-read-before-stat", "proof/proofkit.py",
     '            stat_result = stat_fn(out_ref)\n',
     '            sha256_file(out_ref)\n            stat_result = stat_fn(out_ref)\n'),
    ("g13-unmatched-own-positive-disabled", "proof/proofkit.py",
     '    for index in sorted(scoped_indices - matched_indices):\n',
     '    for index in []:\n'),
    ("g14-E2-name-count-lenient", "proof/proofkit.py",
     '            if (required and len(matches) != 1) or (\n',
     '            if (required and len(matches) > 1) or (\n'),
    ("g15-positive-roundtrip-disabled", "proof/proofkit.py",
     '        if variant.get("kind") == "positive" and not any(\n',
     '        if False and variant.get("kind") == "positive" and not any(\n'),
    ("g16-F1-env-callsite-disabled", "proof/proofkit.py",
     '    violations.extend(\n        _environment_callsite_violations(\n',
     '    violations.extend(\n        () and _environment_callsite_violations(\n'),
    ("g17-F6-skip-iyivar-disabled", "proof/proofkit.py",
     '        if "IYIVAR" in str(entry.get("regex", "")):\n',
     '        if False and "IYIVAR" in str(entry.get("regex", "")):\n'),
    ("g18-F6-sentinel-iyivar-disabled", "proof/proofkit.py",
     '            if "IYIVAR" in str(sentinel_regex):\n',
     '            if False and "IYIVAR" in str(sentinel_regex):\n'),
    ("g19-F10-platform-guard-disabled", "proof/proofkit.py",
     '                and not _platform_skip_guarded(lines, number)\n',
     '                and False and not _platform_skip_guarded(lines, number)\n'),
    ("g20-run-form-never-executed", "proof/proofkit.py",
     '        and argv[0] == record.get("out")\n',
     '        and argv[0] == "never"\n'),
    ("g21-AmendE-nested-work-allowed", "proof/roundtrip_shim.py",
     '                    f"(?P<iyi_work>(?:{root_body}){re.escape(os.sep)}[^/]+)"\n',
     '                    f"(?P<iyi_work>(?:{root_body}){re.escape(os.sep)}.+)"\n'),
    ("g22-AmendE-platform-tmp-dropped", "proof/roundtrip_shim.py",
     '                if platform_tmp is not None:\n                    roots.append(os.path.realpath(platform_tmp))\n',
     '                if False:\n                    roots.append(os.path.realpath(platform_tmp))\n'),
]
ALL = list(base.MUTANTS) + EXTRA
SEED = re.compile(r"^SEED (\S+) expect=(.*?) got=(.*?) applied=")


def run(mutant):
    mutant_id, rel, old, new = mutant
    os.makedirs(MUT, exist_ok=True)
    target = os.path.join(MUT, mutant_id)
    if os.path.exists(target):
        return {"id": mutant_id, "error": "target exists"}
    source_path = os.path.join(SRC, rel)
    count = open(source_path, encoding="utf-8").read().count(old)
    if count != 1:
        return {"id": mutant_id, "error": f"anchor count {count}"}
    subprocess.run(["cp", "-cR", SRC, target], check=True)
    path = os.path.join(target, rel)
    text = open(path, encoding="utf-8").read()
    mutated = text.replace(old, new, 1)
    open(path, "w", encoding="utf-8").write(mutated)
    diff = subprocess.run(["git", "-C", target, "diff", "-U0"], capture_output=True, text=True).stdout
    files = subprocess.run(["git", "-C", target, "diff", "--name-only"], capture_output=True, text=True).stdout.split()
    open(os.path.join(MUT, f"{mutant_id}.diff"), "w").write(diff)
    env = dict(os.environ)
    env["PATH"] = PATHPIN
    env["HOME"] = "/Users/jwaldrip"
    env.pop("PYTHONPATH", None)
    out_path = os.path.join(MUT, f"{mutant_id}.out")
    with open(out_path, "w") as out:
        proc = subprocess.run(
            [PY, "-B", "-X", f"pycache_prefix={target}-pyc", os.path.join(target, "proof", "smoke_test.py")],
            cwd=target, env=env, stdout=out, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
    failed_seeds, failed_controls, total, errors = [], [], "", []
    for line in open(out_path, encoding="utf-8", errors="replace"):
        m = SEED.match(line)
        if m and m.group(2) != m.group(3):
            failed_seeds.append(m.group(1))
        if line.startswith("CONTROL ") and " FAIL " in line:
            failed_controls.append(line.split()[1])
        if line.startswith("TOTAL"):
            total = line.strip()
        if line.startswith("HARNESS") and "PASS" not in line:
            errors.append(line.strip()[:200])
    shutil.rmtree(target + "-pyc", ignore_errors=True)
    return {"id": mutant_id, "rc": proc.returncode, "changed_files": files,
            "diff_lines_changed": sum(1 for l in diff.splitlines() if l.startswith(("+", "-")) and not l.startswith(("+++", "---"))),
            "failed_seeds": failed_seeds, "failed_controls": failed_controls, "total": total, "harness": errors}


if __name__ == "__main__":
    args = sys.argv[1:]
    if args[:1] == ["--list"]:
        for m in ALL:
            print(m[0])
        sys.exit(0)
    jobs = int(os.environ.get("MUT_JOBS", "6"))
    selected = [m for m in ALL if not args or m[0] in args]
    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as pool:
        for result in pool.map(run, selected):
            line = json.dumps(result, sort_keys=True)
            print(line, flush=True)
            open(os.path.join(AUD, "mutants.jsonl"), "a").write(line + "\n")
