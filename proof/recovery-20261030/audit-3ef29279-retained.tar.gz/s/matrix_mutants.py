"""For each listed guard mutant: clone AUD/w (APFS cp -c), apply the single anchored change
(exactly once, from b_mutants.EXTRA), run the independent ledger matrix with MATRIX_CODE bound to
the clone, and report which matrix cases change relative to the unmutated base2 results
(verdict PASS -> FAIL means the mutant lets that negative case through / breaks that control)."""
import concurrent.futures
import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import b_mutants as bm  # noqa: E402

AUD = bm.AUD
PY = bm.PY
BASE = {}
for line in open(os.path.join(AUD, "matrix-results-base2.jsonl")):
    row = json.loads(line)
    BASE[row["case"]] = row
IDS = sys.argv[1:]
MX = os.path.join(AUD, "mutm")
os.makedirs(MX, exist_ok=True)


def one(mid):
    mutant = [m for m in bm.ALL if m[0] == mid][0]
    _, rel, old, new = mutant
    target = os.path.join(MX, mid)
    text = open(os.path.join(bm.SRC, rel), encoding="utf-8").read()
    if text.count(old) != 1:
        return {"id": mid, "error": f"anchor count {text.count(old)}"}
    subprocess.run(["cp", "-cR", bm.SRC, target], check=True)
    path = os.path.join(target, rel)
    mutated = open(path, encoding="utf-8").read().replace(old, new, 1)
    open(path, "w", encoding="utf-8").write(mutated)
    diff = subprocess.run(["git", "-C", target, "diff", "-U0"], capture_output=True, text=True).stdout
    open(os.path.join(MX, f"{mid}.diff"), "w").write(diff)
    env = dict(os.environ, MATRIX_CODE=target, MATRIX_TAG=f"mut-{mid}", PATH=bm.PATHPIN, HOME="/Users/jwaldrip")
    env.pop("PYTHONPATH", None)
    out = os.path.join(AUD, f"matrix-mut-{mid}.txt")
    with open(out, "w") as handle:
        proc = subprocess.run([PY, "-B", "-X", f"pycache_prefix={target}-pyc", os.path.join(AUD, "s", "a_ledger_matrix.py")],
                              env=env, stdout=handle, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
    results_path = os.path.join(AUD, f"matrix-results-mut-{mid}.jsonl")
    if not os.path.exists(results_path):
        return {"id": mid, "rc": proc.returncode, "error": "no results file (see matrix-mut-%s.txt)" % mid}
    rows = [json.loads(l) for l in open(results_path)]
    changed = []
    for row in rows:
        base = BASE.get(row["case"])
        if base is None:
            continue
        if row["verdict"] != base["verdict"] or row.get("blocking") != base.get("blocking") or row.get("ids") != base.get("ids") \
                or row.get("positive_not_exercised") != base.get("positive_not_exercised") or row.get("neg_not_exercised") != base.get("neg_not_exercised"):
            changed.append({"case": row["case"], "verdict": row["verdict"], "blocking": row.get("blocking"), "base_blocking": base.get("blocking")})
    return {"id": mid, "rc": proc.returncode, "diff_lines": sum(1 for l in diff.splitlines() if l[:1] in "+-" and l[:3] not in ("+++", "---")),
            "cases": len(rows), "changed_vs_base": changed}


with concurrent.futures.ThreadPoolExecutor(max_workers=int(os.environ.get("MM_JOBS", "3"))) as pool:
    for res in pool.map(one, IDS):
        line = json.dumps(res, sort_keys=True)
        print(line, flush=True)
        open(os.path.join(AUD, "matrix-mutants.jsonl"), "a").write(line + "\n")
