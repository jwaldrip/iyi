import json, os, sys
AUD='/private/tmp/iyi-proof-audit-3ef29279'
sys.path.insert(0, AUD+'/w')
import proof.smoke_test as smoke
import proof.run_proof as stages
root=AUD+'/run2-rerun'
os.mkdir(root)
flip=root+'/flip'
original=smoke._stage_stub_payloads
def patched(scenario, fixture_root=''):
    payloads=original(scenario,fixture_root)
    src=payloads['proof/artifact_legs.py'].decode()
    old="'p_nonzero':False})"
    parts=src.rsplit(old,1)
    if len(parts)!=2 or src.count(old)!=2: raise RuntimeError('unexpected anchor count')
    new=f"'p_nonzero':(os.path.exists({flip!r}) and index == 1)}})"
    mutated=new.join(parts)
    if mutated.count(new)!=1: raise RuntimeError('mutation did not apply once')
    payloads['proof/artifact_legs.py']=mutated.encode()
    open(root+'/stub-control.py','w').write(src)
    open(root+'/stub-changed.py','w').write(mutated)
    return payloads
smoke._stage_stub_payloads=patched
with smoke.StageFixture() as fx:
    fx.pin(); args=fx.args()
    r1=stages.cmd_run1(args,disk_min_gb=0.0)
    r2=stages.cmd_run2(args,disk_min_gb=0.0)
    r3=stages.cmd_run3(args,drivers=fx.drivers,driver_limit_sec=30,grace_sec=.1,disk_min_gb=0)
    base=stages.cmd_final(args,drivers=fx.drivers)
    old=json.load(open(fx.report+'/final.json'))
    open(flip,'x').close()
    r2b=stages.cmd_run2(args,disk_min_gb=0)
    f=stages.cmd_final(args,drivers=fx.drivers)
    final=json.load(open(fx.report+'/final.json'))
    result={'run1':r1,'run2':r2,'run3':r3,'control_final_rc':base,'control_status':old['status'],'rerun2_rc':r2b,'seed_final_rc':f,'seed_status':final['status'],'reasons':final['reasons']}
    print(json.dumps(result,indent=2))
    json.dump(result,open(root+'/result.json','w'),indent=2)
