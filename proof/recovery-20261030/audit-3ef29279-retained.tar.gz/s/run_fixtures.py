"""Run selected smoke fixtures through the real Harness. Usage:
run_fixtures.py [--w DIR] (id | prefix:<p>)...   prints the harness SEED/CONTROL lines and a final
RESULT line listing every seed whose expectation was missed and every failed control."""
import sys

args = sys.argv[1:]
W = "/private/tmp/iyi-proof-audit-3ef29279/w"
if args[:1] == ["--w"]:
    W = args[1]
    args = args[2:]
sys.path.insert(0, W)
import proof.smoke_test as smoke  # noqa: E402

by_id = {f.fixture_id: f for f in smoke.FIXTURES}
wanted = []
for token in args:
    if token.startswith("prefix:"):
        wanted.extend(i for i in by_id if i.startswith(token[7:]) and i not in wanted)
    elif token in by_id:
        if token not in wanted:
            wanted.append(token)
    else:
        print("UNKNOWN", token)
        raise SystemExit(3)
harness = smoke.Harness()
for fixture_id in wanted:
    harness.run(by_id[fixture_id])
bad = (harness.executed_seed_ids - harness.passed_seed_ids) | harness.failed_control_ids
print("COUNTS fixtures", len(wanted))
print("RESULT", "FAIL" if bad or harness.execution_errors else "PASS", sorted(bad), harness.execution_errors)
raise SystemExit(1 if bad or harness.execution_errors else 0)
