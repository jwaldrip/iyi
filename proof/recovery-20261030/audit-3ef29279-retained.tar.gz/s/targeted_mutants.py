"""Targeted mutation runs (used because the full-suite mutation batches were starved by host I/O
stalls). Each mutant: APFS clone of AUD/w, one anchored change applied exactly once (diff kept),
then ONLY the fixture groups relevant to the guarded code run through the real Harness
(run_fixtures.py). Baseline failures of the same groups on the unmutated clone AUD/w are subtracted:
killed_by = (seeds missed + controls failed under mutant) - (same on baseline).
Usage: targeted_mutants.py baseline | mutants [id ...]"""
import concurrent.futures
import json
import os
import re
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import b_mutants as bm  # noqa: E402

AUD, PY, SRC = bm.AUD, bm.PY, bm.SRC
OUTD = os.path.join(AUD, "tmut")
os.makedirs(OUTD, exist_ok=True)
GROUPS = {
    "ledger": ["prefix:o5.", "prefix:s3.", "prefix:amend-b."],
    "validator": ["prefix:o3.", "prefix:s2.", "prefix:o7.seed.validator", "prefix:o7.control.validator", "prefix:o7.seed.pk2-"],
    "ident": ["prefix:o7.seed.guard-", "prefix:o7.control.guard-", "prefix:s1."],
    "shim": ["prefix:o4.", "prefix:amend-a.", "prefix:s2.seed.matcher", "prefix:s2.control.matcher"],
    "stage": ["prefix:s5.", "prefix:o7.seed.final", "prefix:o7.control.final", "prefix:o7.seed.d4"],
    "legs": ["prefix:o6.", "prefix:s4."],
    "pk": ["prefix:o7.seed.pk-", "prefix:s1.", "prefix:o2."],
}
MAP = {}
for m in ("m01", "m02", "m03", "m04", "m05", "m06", "m19"):
    MAP[m] = ["ident"]
for m in ("m07", "m08", "m09", "m10", "m11", "m12", "m13", "m14", "m20", "g04"):
    MAP[m] = ["ident", "stage"]
for m in ("m15", "m16", "g05", "g06", "g07", "g08", "g09", "g10", "g11", "g12", "g13", "g14", "g15", "g20"):
    MAP[m] = ["ledger"]
for m in ("m17", "m18", "g21", "g22"):
    MAP[m] = ["shim", "ledger"]
for m in ("g16", "g17", "g18", "g19"):
    MAP[m] = ["validator"]
MAP["g01"] = ["pk", "stage"]
MAP["g02"] = ["pk", "stage"]
MAP["g03"] = ["legs"]
BAD = re.compile(r"^RESULT (\S+) (\[.*?\]) ")


def prefixes(groups):
    out = []
    for g in groups:
        for p in GROUPS[g]:
            if p not in out:
                out.append(p)
    return out


def run_groups(code_root, tag, groups):
    env = dict(os.environ, PATH=bm.PATHPIN, HOME="/Users/jwaldrip")
    env.pop("PYTHONPATH", None)
    out = os.path.join(OUTD, f"{tag}.out")
    with open(out, "w") as handle:
        proc = subprocess.run([PY, "-B", "-X", f"pycache_prefix={OUTD}/pyc-{tag}", os.path.join(AUD, "s", "run_fixtures.py"), "--w", code_root, *prefixes(groups)],
                              cwd=code_root, env=env, stdout=handle, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL)
    text = open(out, encoding="utf-8", errors="replace").read()
    missed = []
    for line in text.splitlines():
        m = re.match(r"^SEED (\S+) expect=(.*?) got=(.*?) applied=", line)
        if m and m.group(2) != m.group(3):
            missed.append(m.group(1))
        if line.startswith("CONTROL ") and " FAIL " in line:
            missed.append(line.split()[1])
    fixtures = re.search(r"^COUNTS fixtures (\d+)", text, re.M)
    shutil.rmtree(f"{OUTD}/pyc-{tag}", ignore_errors=True)
    return {"rc": proc.returncode, "fixtures": int(fixtures.group(1)) if fixtures else None, "failing": sorted(set(missed)), "traceback": "Traceback" in text}


def baseline():
    result = {}
    for g in GROUPS:
        result[g] = run_groups(SRC, f"base-{g}", [g])
        print(json.dumps({"group": g, **result[g]}), flush=True)
    json.dump(result, open(os.path.join(AUD, "tmut-baseline.json"), "w"), indent=1)


def one(mid):
    mutant = [m for m in bm.ALL if m[0] == mid][0]
    _, rel, old, new = mutant
    short = mid.split("-")[0]
    text = open(os.path.join(SRC, rel), encoding="utf-8").read()
    if text.count(old) != 1:
        return {"id": mid, "error": f"anchor count {text.count(old)}"}
    target = os.path.join(OUTD, mid)
    if os.path.exists(target):
        shutil.rmtree(target)
    subprocess.run(["cp", "-cR", SRC, target], check=True)
    path = os.path.join(target, rel)
    mutated = open(path, encoding="utf-8").read().replace(old, new, 1)
    open(path, "w", encoding="utf-8").write(mutated)
    diff = subprocess.run(["git", "-C", target, "diff", "-U0"], capture_output=True, text=True).stdout
    open(os.path.join(OUTD, f"{mid}.diff"), "w").write(diff)
    changed = sum(1 for l in diff.splitlines() if l[:1] in "+-" and l[:3] not in ("+++", "---"))
    res = run_groups(target, mid, MAP[short])
    base = json.load(open(os.path.join(AUD, "tmut-baseline.json")))
    base_fail = set()
    for g in MAP[short]:
        base_fail |= set(base[g]["failing"])
    killed = sorted(set(res["failing"]) - base_fail)
    shutil.rmtree(target, ignore_errors=True)
    return {"id": mid, "groups": MAP[short], "diff_lines_changed": changed, "fixtures": res["fixtures"], "mutant_failing": res["failing"],
            "baseline_failing_same_groups": sorted(base_fail), "killed_by": killed, "traceback": res["traceback"]}


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "baseline":
        baseline()
    else:
        ids = sys.argv[2:] or [m[0] for m in bm.ALL if m[0].split("-")[0] in MAP]
        with concurrent.futures.ThreadPoolExecutor(max_workers=int(os.environ.get("TM_JOBS", "3"))) as pool:
            for res in pool.map(one, ids):
                line = json.dumps(res, sort_keys=True)
                print(line, flush=True)
                open(os.path.join(AUD, "tmut-results.jsonl"), "a").write(line + "\n")
