import json
import os
import subprocess
import sys
import time

W = "/private/tmp/iyi-proof-audit-3ef29279/w"
sys.path.insert(0, W)
import proof.proofkit as pk
import proof.run_proof as stages_mod
import proof.smoke_test as smoke

with smoke.StageFixture() as fx:
    fx.pin(); fx.write_prerequisites()
    t = time.monotonic()
    rc = stages_mod.cmd_run3(fx.args(), drivers=fx.drivers, driver_limit_sec=60.0, grace_sec=0.1, disk_min_gb=0.0)
    el = time.monotonic() - t
    rec = smoke._stage_result(fx.report, "run3/stage")
    att = stages_mod.latest_attempt_dir(os.path.join(fx.report, "run3", "stage"))
    times = open(os.path.join(att, "driver.times")).read().split("\n")
    print("rc", rc, "status", rec.get("status"), "elapsed_total_cmd_run3", round(el, 3))
    t0, t1 = int(times[0].split()[0]), int(times[-2].split()[0])
    print("driver_wall_s", round((t1 - t0) / 1e9, 3))
    cfg = json.load(open(os.path.join(att, "shim.json")))
    pin = fx.pin_data if hasattr(fx, "pin_data") else json.load(open(os.path.join(fx.report, "pin.json")))
    env = pk.base_env(pin, {"TMPDIR": cfg["work_tmp"], "IYI_CACHE_DIR": os.path.join(att, "c")})
    work = os.path.join(cfg["work_tmp"], "tmp.timing")
    os.makedirs(work, exist_ok=True)
    launcher = os.path.join(att, "bin", "iyi")

    def timed(label, argv):
        s = time.monotonic()
        p = subprocess.run([launcher, *argv], cwd=cfg["repo"], env=env, stdin=subprocess.DEVNULL, capture_output=True, text=True)
        print(label, "rc", p.returncode, "s", round(time.monotonic() - s, 3), p.stderr.strip()[:120])

    timed("launcher-doc(unchanged)", ["doc", "x.iyi"])
    timed("launcher-build(roundtrip)", ["build", "-o", os.path.join(work, "stage-plain"), os.path.join(cfg["repo"], "bench", "std_stage_exercise.iyi")])
    real = cfg["real"]
    for label, argv in (("real-version", ["--version"]), ("real-env", ["env", "IYI_PATH", "IYI_CACHE_DIR"])):
        s = time.monotonic()
        p = subprocess.run([real, *argv], cwd=cfg["repo"], env=env, capture_output=True, text=True)
        print(label, "rc", p.returncode, "s", round(time.monotonic() - s, 3))
    s = time.monotonic()
    subprocess.run(["/bin/bash", "-c", 'WORK="$(mktemp -d)"; echo $WORK'], env=env, capture_output=True)
    out = os.path.join(work, "stage-plain")
    for k in range(3):
        s = time.monotonic()
        p = subprocess.run([out], env=env, capture_output=True, text=True)
        print("exec-OUT#%d" % k, "rc", p.returncode, "s", round(time.monotonic() - s, 3), p.stdout.strip()[:60], p.stderr.strip()[:80])
    print("bash-mktemp s", round(time.monotonic() - s, 3))
