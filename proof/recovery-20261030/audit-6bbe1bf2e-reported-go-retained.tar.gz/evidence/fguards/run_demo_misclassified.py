"""Reviewer demo: real shim + real verify_ledger on driver-faithful calls for F2."""
import json
import os
import pathlib
import secrets
import subprocess
import sys

RV = pathlib.Path("/private/tmp/iyi-proof-review-6bbe1bf2e")
W = RV / "w"
sys.path.insert(0, str(W))

import proof.proofkit as proofkit_mod
import proof.smoke_test as smoke_mod

PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
ROOT = os.path.join(RV, "evidence/fguards/demo-misclassified")
os.makedirs(ROOT, exist_ok=True)
REAL = smoke_mod._fake_real_compiler(
    os.path.join(ROOT, "fake"), version_line="iyi fake [626463375]"
)
REPO = os.path.realpath(W)
CANONICAL = [os.path.realpath(os.path.join(REPO, "src")), os.path.realpath(os.path.join(REPO, "samples/iyi"))]
PLATFORM_TMP = os.path.realpath(
    subprocess.run(["getconf", "DARWIN_USER_TEMP_DIR"], capture_output=True, text=True, check=True).stdout.strip()
)


def scenario(name, driver, iyi_path_first, argv, files):
    base = os.path.join(ROOT, name)
    t = os.path.join(base, "t")
    s = os.path.join(base, "s")
    c = os.path.join(base, "c")
    for d in (t, s, c):
        os.makedirs(d, exist_ok=True)
    work = os.path.join(t, "tmp.work")
    os.makedirs(work, exist_ok=True)
    for rel in files:
        path = os.path.join(work, rel)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as handle:
            handle.write("# demo\n")
    nonce = secrets.token_hex(16)
    ledger = os.path.join(base, "ledger.jsonl")
    with open(ledger, "w") as handle:
        handle.write(json.dumps({"v": 1, "kind": "header", "nonce": nonce, "driver": driver, "attempt": 1, "chain_id": "c" * 32}, sort_keys=True, separators=(",", ":")) + "\n")
    config = {
        "real": REAL,
        "census": os.path.realpath(os.path.join(REPO, "proof", "census", f"{driver}.json")),
        "ledger": ledger,
        "nonce": nonce,
        "driver": driver,
        "work_tmp": os.path.realpath(t),
        "scratch": s,
        "repo": REPO,
        "canonical_roots": CANONICAL,
        "platform_tmp": PLATFORM_TMP,
    }
    config_path = os.path.join(base, "shim.json")
    with open(config_path, "w") as handle:
        json.dump(config, handle)
    env = proofkit_mod.base_env(None, {"TMPDIR": t, "IYI_CACHE_DIR": c})
    roots = ([iyi_path_first.replace("$WORK", work)] if iyi_path_first else []) + CANONICAL
    env["IYI_PATH"] = os.pathsep.join(roots)
    concrete = [token.replace("$WORK", work) for token in argv]
    proc = subprocess.run(
        [PY, "-B", os.path.join(REPO, "proof", "roundtrip_shim.py"), "--config", config_path, "--", *concrete],
        cwd=REPO, env=env, stdin=subprocess.DEVNULL, capture_output=True, text=True,
    )
    with open(ledger) as handle:
        lines = handle.read().splitlines()
    records = [json.loads(line) for line in lines[1:]]
    verdict = proofkit_mod.verify_ledger(
        ledger, census=json.load(open(config["census"])), driver=driver, nonce=nonce,
        attempt=1, chain_id="c" * 32, work_tmp=os.path.realpath(t), repo=REPO,
        platform_tmp=PLATFORM_TMP,
    )
    return {
        "name": name,
        "shim_rc": proc.returncode,
        "stderr": proc.stderr.strip(),
        "records": records,
        "statuses": sorted(verdict.statuses),
        "reasons": [r for r in verdict.reasons if r.startswith("MISCLASSIFIED")],
    }


r1 = scenario("regex-416-seed", "regex", "$WORK/patched", ["build", "-o", "$WORK/mutated_refusal", "$WORK/mutated_refusal.iyi"], ["patched/std/regex.iyi", "mutated_refusal.iyi"])
r2 = scenario("regex-416-control", "regex", None, ["build", "-o", "$WORK/mutated_refusal", "$WORK/mutated_refusal.iyi"], ["mutated_refusal.iyi"])
r3 = scenario("http-1384-seed", "http", "$WORK/refbreak", ["build", "--no-codegen", "-o", "$WORK/refused", "$WORK/captures.iyi"], ["refbreak/std/http.iyi", "captures.iyi"])
r4 = scenario("http-1384-control", "http", None, ["build", "--no-codegen", "-o", "$WORK/refused", "$WORK/captures.iyi"], ["captures.iyi"])
r5 = scenario("http-passthrough-noncanonical-seed", "http", "$WORK/refbreak", ["build", "--emit-iyimod", "$WORK/mods", "-o", "$WORK/refused", "$WORK/captures.iyi"], ["refbreak/std/http.iyi", "captures.iyi"])
r6 = scenario("http-passthrough-canonical-control", "http", None, ["build", "--emit-iyimod", "$WORK/mods", "-o", "$WORK/refused", "$WORK/captures.iyi"], ["captures.iyi"])

summary = {
    "r1_regex_seed": r1,
    "r2_regex_control": r2,
    "r3_http_seed": r3,
    "r4_http_control": r4,
    "r5_http_passthrough_seed": r5,
    "r6_http_passthrough_control": r6,
    "f2_guard": {
        "unchanged_noncanonical_misclassified": "MISCLASSIFIED" in r3["statuses"],
        "passthrough_noncanonical_misclassified": "MISCLASSIFIED" in r5["statuses"],
        "passthrough_canonical_misclassified": "MISCLASSIFIED" in r6["statuses"],
    }
}
out_path = os.path.join(RV, "evidence/fguards/demo_misclassified.json")
with open(out_path, "w") as f:
    json.dump(summary, f, indent=2)

print("demo_misclassified PASS, saved to", out_path)
print("F2 verdict:", summary["f2_guard"])
