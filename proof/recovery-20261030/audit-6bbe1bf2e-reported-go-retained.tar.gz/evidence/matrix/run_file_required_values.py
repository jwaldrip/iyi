"""Independently verify that each of the 17 negative required values individually missing => NOT-EXERCISED."""
import json
import os
import pathlib
import sys

RV = pathlib.Path("/private/tmp/iyi-proof-review-6bbe1bf2e")
W = RV / "w"
sys.path.insert(0, str(W))

import proof.proofkit as pk

base = os.path.join(RV, "evidence/matrix/matrix-base/file-N-negatives-required-all")
cfg = json.load(open(os.path.join(base, "shim.json")))
census = json.load(open(cfg["census"]))
raw = open(os.path.join(base, "ledger.jsonl")).read().splitlines()
header = raw[0]
records = [json.loads(x) for x in raw[1:]]

ids = ("file.negative.169.required", "file.negative.230.required", "file.negative.428.required")
kw = dict(
    census=census, driver="file", nonce=cfg["nonce"], attempt=1, chain_id="c" * 32,
    work_tmp=cfg["work_tmp"], repo=cfg["repo"], platform_tmp=cfg["platform_tmp"]
)
out = os.path.join(RV, "evidence/matrix/file-required-values")
os.makedirs(out, exist_ok=True)


def verify(path):
    return pk.verify_ledger(path, **kw)


control = verify(os.path.join(base, "ledger.jsonl"))
control_reasons = [r for r in control.reasons if r.startswith("NOT-EXERCISED") and any(i in r for i in ids)]
assert not control_reasons, f"Control has unexpected NOT-EXERCISED: {control_reasons}"

rows = []
for site in census["sites"]:
    for v in site.get("variants", []):
        if v["id"] not in ids:
            continue
        for value in v["vars"]["dir"]["values"]:
            matches = [i for i, r in enumerate(records) if r.get("bindings", {}).get(v["id"], {}).get("dir") == value]
            if len(matches) != 1:
                raise RuntimeError(f"{v['id']}:{value} matches {matches}")
            altered = [r for i, r in enumerate(records) if i != matches[0]]
            path = os.path.join(out, f"{v['id']}-{value}.jsonl")
            with open(path, "w") as fh:
                fh.write(header + "\n" + "\n".join(json.dumps(r) for r in altered) + "\n")
            verdict = verify(path)
            reasons = [r for r in verdict.reasons if r.startswith("NOT-EXERCISED") and any(i in r for i in ids)]
            expected = f"{v['id']} never binds dir={value!r}"
            ok = not control_reasons and any(expected in r for r in reasons)
            rows.append({
                "id": v["id"],
                "value": value,
                "removed_record_index": matches[0] + 1,
                "control_reasons": control_reasons,
                "seed_reasons": reasons,
                "pass": ok
            })
            print(f"{v['id']} dir={value}: pass={ok} expected_in_reasons={any(expected in r for r in reasons)}")

json.dump(rows, open(os.path.join(out, "results.json"), "w"), indent=2)
print("cases", len(rows), "passed", sum(r["pass"] for r in rows), "failed", [(r["id"], r["value"]) for r in rows if not r["pass"]])
assert all(r["pass"] for r in rows)
assert len(rows) == 17
print("All 17 negative required values PASS.")
