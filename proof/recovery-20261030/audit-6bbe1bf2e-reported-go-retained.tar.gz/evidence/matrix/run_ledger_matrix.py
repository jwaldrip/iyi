"""Independent ledger/evidence matrix on RV/w."""
import copy
import hashlib
import json
import os
import pathlib
import secrets
import subprocess
import sys

RV = pathlib.Path("/private/tmp/iyi-proof-review-6bbe1bf2e")
W = RV / "w"
CODE = str(W)
sys.path.insert(0, CODE)

import proof.proofkit as pk
import proof.roundtrip_shim as shim
import proof.smoke_test as smoke

PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
REPO = os.path.realpath(CODE)
PLATFORM = os.path.realpath(subprocess.run(["getconf", "DARWIN_USER_TEMP_DIR"], capture_output=True, text=True, check=True).stdout.strip())
CANON = [os.path.realpath(os.path.join(REPO, "src")), os.path.realpath(os.path.join(REPO, "samples/iyi"))]
ROOT = os.path.join(RV, "evidence/matrix/matrix-base")
os.makedirs(ROOT, exist_ok=True)
FAKE = smoke._fake_real_compiler(os.path.join(ROOT, "fake"), version_line="iyi fake [626463375]")
RESULTS = []


def census_of(driver):
    return json.load(open(os.path.join(REPO, "proof", "census", f"{driver}.json")))


def own_src(driver):
    return os.path.join(REPO, "bench", f"std_{driver}_exercise.iyi")


def own_names(census):
    for ev in census["exec_evidence"]:
        site = [s for s in census["sites"] if s["lines"][0] == ev["site_line"]][0]
        if site["kind"] in ("canonical-own", "mixed") and ev["out_template"] == "{WORK}/{name}":
            names = list(ev["name_from_calls"].values())
            if len(names) == 2 and names[0].endswith("plain"):
                return names
    raise SystemExit("no own names")


def call(first, argv, action="run", out=None, tag=""):
    return {"first": first, "argv": argv, "action": action, "out": out, "tag": tag}


def own_calls(driver):
    plain, release = own_names(census_of(driver))
    src = own_src(driver)
    return [
        call(None, ["build", "-o", f"$WORK/{plain}", src], "run", f"$WORK/{plain}", "own-plain"),
        call(None, ["build", "--release", "-o", f"$WORK/{release}", src], "run", f"$WORK/{release}", "own-release"),
    ]


def positive_calls(driver):
    src = own_src(driver)
    if driver == "compress":
        return [call("$WORK/small", ["build", "--release", "-o", "$WORK/small.bin", src], "run", "$WORK/small.bin", "pos-small")]
    if driver == "math":
        return [call("$WORK/software", ["build", "--release", "-o", "$WORK/software/program", src], "run", "$WORK/software/program", "pos-software")]
    if driver == "tls":
        return [call(f"$WORK/{n}", ["build", "-o", f"$WORK/{n}/tlsx", src], "run", f"$WORK/{n}/tlsx", f"pos-{n}") for n in ("downgrade", "downgrade-unchecked")]
    if driver == "file":
        return [call(f"$WORK/{n}", ["build", "-o", f"$WORK/{n}-prog", f"$WORK/{n}-prog.iyi"], "run", f"$WORK/{n}-prog", f"pos-{n}") for n in ("nul_cut", "realpath_through")]
    return []


POSITIVE_IDS = {
    "compress": ["compress.positive.464"],
    "math": ["math.positive.555"],
    "tls": ["tls.positive.downgrade.795"],
    "file": ["file.positive.628.required", "file.positive.628.platform-excluded"]
}


def run_case(case_id, driver, calls, note=""):
    base = os.path.join(ROOT, case_id)
    t, s, c = (os.path.join(base, x) for x in ("t", "s", "c"))
    for d in (t, s, c):
        os.makedirs(d, exist_ok=True)
    work = os.path.join(os.path.realpath(t), "tmp.work")
    os.makedirs(work, exist_ok=True)

    def sub(token):
        return token.replace("$WORK", work)

    for cl in calls:
        if cl["first"]:
            os.makedirs(sub(cl["first"]), exist_ok=True)
        if cl["out"]:
            os.makedirs(os.path.dirname(sub(cl["out"])), exist_ok=True)
        for token in cl["argv"]:
            if token.endswith(".iyi") and "$WORK" in token:
                with open(sub(token), "w") as fh:
                    fh.write("# stub source\n")
    nonce = secrets.token_hex(16)
    ledger = os.path.join(base, "ledger.jsonl")
    with open(ledger, "w") as handle:
        handle.write(json.dumps({"v": 1, "kind": "header", "nonce": nonce, "driver": driver, "attempt": 1, "chain_id": "c" * 32}, sort_keys=True, separators=(",", ":")) + "\n")
    census_path = os.path.realpath(os.path.join(REPO, "proof", "census", f"{driver}.json"))
    config = {"real": FAKE, "census": census_path, "ledger": ledger, "nonce": nonce, "driver": driver, "work_tmp": os.path.realpath(t),
              "scratch": s, "repo": REPO, "canonical_roots": CANON, "platform_tmp": PLATFORM}
    config_path = os.path.join(base, "shim.json")
    with open(config_path, "w") as fh:
        json.dump(config, fh)
    rcs, actions = [], []
    for cl in calls:
        env = pk.base_env(None, {"TMPDIR": t, "IYI_CACHE_DIR": c})
        roots = ([sub(cl["first"])] if cl["first"] else []) + CANON
        env["IYI_PATH"] = os.pathsep.join(roots)
        argv = [sub(x) for x in cl["argv"]]
        proc = subprocess.run([PY, "-B", os.path.join(REPO, "proof", "roundtrip_shim.py"), "--config", config_path, "--", *argv],
                              cwd=REPO, env=env, stdin=subprocess.DEVNULL, capture_output=True, text=True)
        rcs.append(proc.returncode)
        act = {"tag": cl["tag"], "action": cl["action"], "shim_rc": proc.returncode, "stderr": proc.stderr.strip()[:100]}
        out = sub(cl["out"]) if cl["out"] else None
        if cl["action"] != "none" and proc.returncode == 0 and out and os.path.exists(out):
            ino_before = os.stat(out).st_ino
            if cl["action"] == "cp":
                with open(out, "r+b") as fh:
                    fh.write(b"#!/bin/sh\necho substituted\n")
                    fh.truncate()
            elif cl["action"] == "mv":
                other = out + ".other"
                with open(other, "w") as fh:
                    fh.write("#!/bin/sh\necho substituted\n")
                os.chmod(other, 0o755)
                os.replace(other, out)
            run = subprocess.run([out], env=env, capture_output=True, text=True)
            act.update({"exec_rc": run.returncode, "ino_before": ino_before, "ino_after": os.stat(out).st_ino})
        actions.append(act)
    verdict = pk.verify_ledger(ledger, census=json.load(open(census_path)), driver=driver, nonce=nonce, attempt=1, chain_id="c" * 32,
                               work_tmp=os.path.realpath(t), repo=REPO, platform_tmp=PLATFORM)
    blocking = sorted(set(verdict.statuses) - {"NOT-EXERCISED"})
    pos_ne = [r for r in verdict.reasons if r.startswith("NOT-EXERCISED") and any(v in r for v in POSITIVE_IDS.get(driver, []))]
    return {"case": case_id, "driver": driver, "note": note, "shim_rcs": rcs, "actions": actions, "statuses": sorted(verdict.statuses),
            "blocking": blocking, "positive_not_exercised": pos_ne,
            "reasons": [r for r in verdict.reasons if not r.startswith("NOT-EXERCISED")][:6],
            "_all_reasons": verdict.reasons}


def diff_calls(a, b):
    ma, mb = {c["tag"]: c for c in a}, {c["tag"]: c for c in b}
    return sorted(t for t in set(ma) | set(mb) if ma.get(t) != mb.get(t))


def record(res, expect_blocking, extra_ok=True, expect_rc125=False, expect_pos_ne=False, control_calls=None, seed_calls=None):
    ok = res["blocking"] == expect_blocking and (bool(res["positive_not_exercised"]) == expect_pos_ne)
    if expect_rc125:
        ok = ok and 125 in res["shim_rcs"]
    res["expected_blocking"] = expect_blocking
    res["expect_pos_not_exercised"] = expect_pos_ne
    if control_calls is not None and seed_calls is not None:
        d = diff_calls(control_calls, seed_calls)
        res["applied_diff_indices"] = d
        ok = ok and len(d) == 1
    res["verdict"] = "PASS" if ok else "FAIL"
    RESULTS.append(res)
    print(json.dumps({k: res[k] for k in ("case", "verdict", "blocking", "expected_blocking", "positive_not_exercised", "shim_rcs")}, sort_keys=True), flush=True)


def with_action(calls, tag, action):
    out = copy.deepcopy(calls)
    hit = [c for c in out if c["tag"] == tag]
    assert len(hit) == 1, tag
    hit[0]["action"] = action
    return out


print("Running matrix suites for compress, math, tls, file...")
for driver in ("compress", "math", "tls", "file"):
    control = own_calls(driver) + positive_calls(driver)
    record(run_case(f"{driver}-control", driver, control, "all own and positive built and executed"), [], expect_pos_ne=False)
    first_pos = positive_calls(driver)[0]["tag"]
    # A: positive never run
    seed = with_action(control, first_pos, "none")
    record(run_case(f"{driver}-A-positive-never-run", driver, seed), ["NOT-EXECUTED"], control_calls=control, seed_calls=seed)
    # B: copy-over positive
    seed = with_action(control, first_pos, "cp")
    record(run_case(f"{driver}-B-positive-copy-over", driver, seed), ["OUT-MODIFIED"], control_calls=control, seed_calls=seed)
    # C: move-over positive
    seed = with_action(control, first_pos, "mv")
    record(run_case(f"{driver}-C-positive-move-over", driver, seed), ["NOT-EXECUTED"], control_calls=control, seed_calls=seed)
    # D: own plain never run
    seed = with_action(control, "own-plain", "none")
    record(run_case(f"{driver}-D-own-never-run", driver, seed), ["NOT-EXECUTED"], control_calls=control, seed_calls=seed)
    # D2: own release copy-over, D3: own plain move-over
    seed = with_action(control, "own-release", "cp")
    record(run_case(f"{driver}-D2-own-copy-over", driver, seed), ["OUT-MODIFIED"], control_calls=control, seed_calls=seed)
    seed = with_action(control, "own-plain", "mv")
    record(run_case(f"{driver}-D3-own-move-over", driver, seed), ["NOT-EXECUTED"], control_calls=control, seed_calls=seed)
    # E: missing own release record
    seed = [c for c in control if c["tag"] != "own-release"]
    record(run_case(f"{driver}-E-missing-own-record", driver, seed), ["NOT-EXECUTED"], control_calls=control, seed_calls=seed)
    # F: duplicate own plain
    dup = copy.deepcopy([c for c in control if c["tag"] == "own-plain"][0])
    dup["tag"] = "own-plain-dup"
    seed = control + [dup]
    record(run_case(f"{driver}-F-duplicate-own-name", driver, seed), ["NOT-EXECUTED"], control_calls=control, seed_calls=seed)
    # G: own record whose OUT matches no evidence name
    extra = call(None, ["build", "-o", "$WORK/zz-unmatched", own_src(driver)], "run", "$WORK/zz-unmatched", "own-unmatched")
    seed = control + [extra]
    res = run_case(f"{driver}-G-unmatched-own", driver, seed)
    res["unmatched_reason_present"] = any("matches no execution evidence" in r for r in res["reasons"])
    record(res, ["NOT-EXECUTED"], control_calls=control, seed_calls=seed)
    # H: wrong variant
    if driver == "tls":
        wrong = call("$WORK/downgrade", ["build", "-o", "$WORK/downgrade-unchecked/tlsx", own_src(driver)], "run", "$WORK/downgrade-unchecked/tlsx", "pos-wrong")
    elif driver == "file":
        wrong = call("$WORK/nul_cut", ["build", "-o", "$WORK/realpath_through-prog", "$WORK/nul_cut-prog.iyi"], "run", "$WORK/realpath_through-prog", "pos-wrong")
    elif driver == "compress":
        wrong = call("$WORK/small2", ["build", "--release", "-o", "$WORK/small.bin", own_src(driver)], "run", "$WORK/small.bin", "pos-wrong")
    else:
        wrong = call("$WORK/software2", ["build", "--release", "-o", "$WORK/software/program", own_src(driver)], "run", "$WORK/software/program", "pos-wrong")
    seed = control + [wrong]
    record(run_case(f"{driver}-H-wrong-variant", driver, seed), ["MISCLASSIFIED"], expect_rc125=True, control_calls=control, seed_calls=seed)
    # I: required positive absent entirely
    if driver == "tls":
        seed = [c for c in control if c["tag"] != "pos-downgrade"]
    elif driver == "file":
        seed = [c for c in control if c["tag"] != "pos-nul_cut"]
    else:
        seed = [c for c in control if not c["tag"].startswith("pos-")]
    res = run_case(f"{driver}-I-positive-absent", driver, seed)
    record(res, ["NOT-EXECUTED"], expect_pos_ne=True, control_calls=control, seed_calls=seed)
    if driver == "tls":
        seed = [c for c in control if c["tag"] != "pos-downgrade-unchecked"]
        record(run_case("tls-I2-one-positive-value-absent", driver, seed), ["NOT-EXECUTED"], expect_pos_ne=True, control_calls=control, seed_calls=seed)
    # J: auxiliary canonical-other never run, with valid own
    aux = {"compress": "reserved", "file": "read_nonexistent", "math": None, "tls": None}[driver]
    if aux:
        extra = call(None, ["build", "-o", f"$WORK/{aux}", f"$WORK/{aux}.iyi"], "none", f"$WORK/{aux}", "aux-canonical-other")
        seed = control + [extra]
        record(run_case(f"{driver}-J-aux-canonical-other-never-run", driver, seed, "aux canonical-other is not own: no NOT-EXECUTED"), [], control_calls=control, seed_calls=seed)

# file Darwin split: excluded positive present-without-witness fails; excluded positive absent is fine
control = own_calls("file") + positive_calls("file")
seed = with_action(control, "pos-realpath_through", "none")
record(run_case("file-K-excluded-positive-present-no-witness", "file", seed), ["NOT-EXECUTED"], control_calls=control, seed_calls=seed)
seed = [c for c in control if c["tag"] != "pos-realpath_through"]
record(run_case("file-L-excluded-positive-absent-ok", "file", seed), [], control_calls=control, seed_calls=seed)
seed = with_action(control, "pos-realpath_through", "cp")
record(run_case("file-M-excluded-positive-copy-over", "file", seed), ["OUT-MODIFIED"], control_calls=control, seed_calls=seed)

# signal: mixed site, own exec evidence plus non-own negative record at the same site
control = own_calls("signal") + [call("$WORK/untaken-std", ["build", "-o", "$WORK/untaken", own_src("signal")], "none", None, "mixed-negative-nonown")]
record(run_case("signal-control-mixed-nonown", "signal", control, "non-own negative at mixed site adds no evidence demand"), [])
seed = with_action(control, "own-plain", "none")
record(run_case("signal-D-mixed-own-never-run", "signal", seed), ["NOT-EXECUTED"], control_calls=control, seed_calls=seed)
seed = [c for c in control if c["tag"] != "own-release"]
record(run_case("signal-E-mixed-own-missing", "signal", seed), ["NOT-EXECUTED"], control_calls=control, seed_calls=seed)

# file Darwin splits for negative sites 169, 230, 428
SITES = {
    "169": ("file.negative.169.required", ["predictable"], "file.negative.169.platform-excluded", ["follows"]),
    "230": ("file.negative.230.required", ["star_sep", "q_byte", "brace_text", "class_neg", "no_escape"], "file.negative.230.platform-excluded", ["dir_onto_file"]),
    "428": ("file.negative.428.required", ["lone_cr", "no_append", "rplus_trunc", "wplus_keep", "aplus_noread", "lock_contention", "lock_kept", "lock_nowait", "lock_block", "perm_dropped", "touch_unread"],
            "file.negative.428.platform-excluded", ["append_seek", "exists_read"]),
}
src = own_src("file")
required_all = [(site, v) for site, (_, req, _, _) in SITES.items() for v in req]
excluded_all = [(site, v) for site, (_, _, _, exc) in SITES.items() for v in exc]


def neg_calls(include_required, include_excluded):
    return [call(f"$WORK/{v}", ["run", src], "none", None, f"neg-{site}-{v}") for site, v in include_required + include_excluded]


NEG_IDS = [SITES[s][0] for s in SITES] + [SITES[s][2] for s in SITES]


def neg_run(case_id, calls):
    base = os.path.join(ROOT, case_id)
    res = run_case(case_id, "file", calls)
    ledger = os.path.join(base, "ledger.jsonl")
    cfg = json.load(open(os.path.join(base, "shim.json")))
    v = pk.verify_ledger(ledger, census=json.load(open(cfg["census"])), driver="file", nonce=cfg["nonce"], attempt=1, chain_id="c" * 32,
                         work_tmp=cfg["work_tmp"], repo=REPO, platform_tmp=PLATFORM)
    recs = [json.loads(l) for l in open(ledger).read().splitlines()[1:]]
    ids = sorted({i for r in recs for i in r.get("variant_ids", [])})
    return res, [r for r in v.reasons if r.startswith("NOT-EXERCISED") and any(i in r for i in NEG_IDS)], ids


neg_control = neg_calls(required_all, [])
neg_cases = {
    "file-N-negatives-required-all": neg_control,
    "file-N2-negatives-excluded-also-present": neg_calls(required_all, excluded_all),
    "file-N3-negatives-touch_unread-absent": neg_calls([x for x in required_all if x != ("428", "touch_unread")], []),
    "file-N4-negatives-excluded-follows-absent-ok": neg_calls(required_all, [])
}

for case_id, calls in neg_cases.items():
    res, neg_ne, ids = neg_run(case_id, calls)
    if case_id == "file-N-negatives-required-all":
        ok = neg_ne == [] and len(ids) == 3
        exp = "no NOT-EXERCISED for any required split variant; 3 required ids bound"
    elif case_id == "file-N2-negatives-excluded-also-present":
        ok = neg_ne == [] and len(ids) == 6
        exp = "excluded values match (6 ids bound) but never required"
    elif case_id == "file-N3-negatives-touch_unread-absent":
        ok = len(neg_ne) == 1 and "touch_unread" in neg_ne[0]
        exp = "exactly the absent required touch_unread value is NOT-EXERCISED"
    else:
        ok = neg_ne == [] and len(ids) == 3
        exp = "excluded values absent: not required"
    res.update({"neg_not_exercised": neg_ne, "bound_variant_ids": ids, "expectation": exp, "verdict": "PASS" if ok else "FAIL"})
    RESULTS.append(res)
    print(json.dumps({"case": case_id, "verdict": res["verdict"], "neg_not_exercised": neg_ne, "bound_ids": ids}, sort_keys=True), flush=True)

# matcher: all four required/excluded pairs through the real match_variants
census = census_of("file")
work_tmp = os.path.join(ROOT, "mt")
os.makedirs(os.path.join(work_tmp, "tmp.w"), exist_ok=True)
w = os.path.realpath(os.path.join(work_tmp, "tmp.w"))
MATCH = [
    ("run", "predictable", [src], None, "file.negative.169.required"),
    ("run", "follows", [src], None, "file.negative.169.platform-excluded"),
    ("run", "star_sep", [src], None, "file.negative.230.required"),
    ("run", "dir_onto_file", [src], None, "file.negative.230.platform-excluded"),
    ("run", "touch_unread", [src], None, "file.negative.428.required"),
    ("run", "append_seek", [src], None, "file.negative.428.platform-excluded"),
    ("build", "nul_cut", [os.path.join(w, "nul_cut-prog.iyi")], os.path.join(w, "nul_cut-prog"), "file.positive.628.required"),
    ("build", "realpath_through", [os.path.join(w, "realpath_through-prog.iyi")], os.path.join(w, "realpath_through-prog"), "file.positive.628.platform-excluded"),
    ("run", "unlisted_value", [src], None, None)
]
for cmd, value, sources, out, expected in MATCH:
    status, ids, kind, bindings = shim.match_variants(census, cmd, os.path.join(w, value), sources, out, work_tmp, REPO, platform_tmp=PLATFORM)
    ok = (ids == [expected]) if expected else (status == "unclassified" and ids == [])
    RESULTS.append({"case": f"matcher-{value}", "status": status, "ids": ids, "kind": kind, "bindings": bindings, "verdict": "PASS" if ok else "FAIL"})
    print(json.dumps({"case": f"matcher-{value}", "status": status, "ids": ids, "kind": kind, "verdict": "PASS" if ok else "FAIL"}, sort_keys=True), flush=True)

out_file = os.path.join(RV, "evidence/matrix/matrix_results.jsonl")
with open(out_file, "w") as fh:
    fh.write("\n".join(json.dumps(r, sort_keys=True, default=str) for r in RESULTS) + "\n")

fails = [r["case"] for r in RESULTS if r["verdict"] != "PASS"]
print("SUMMARY matrix cases", len(RESULTS), "fails:", fails)
assert not fails, f"Matrix failures: {fails}"
print("All ledger matrix cases PASS.")
