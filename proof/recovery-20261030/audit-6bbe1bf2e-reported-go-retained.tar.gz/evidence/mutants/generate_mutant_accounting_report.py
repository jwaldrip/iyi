"""Generate full mutant accounting for m01..m20 and g01..g22."""
import json
import os
import pathlib
import re
import sys

RV = pathlib.Path("/private/tmp/iyi-proof-review-6bbe1bf2e")
W = RV / "w"
OUTD = RV / "evidence/mutants"
OUTD.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, "/private/tmp/iyi-proof-audit-3ef29279/s")
import a_mutants as am
import b_mutants as bm

MUTANTS = list(am.MUTANTS) + bm.EXTRA
smoke_log = (RV / "evidence/smoke/smoke.log").read_text()
smoke_lines = smoke_log.splitlines()

# Parse smoke lines for all seeds and controls
seed_re = re.compile(r"^SEED (\S+) expect=(.*?) got=(.*?) applied=(.*)$")
control_re = re.compile(r"^CONTROL (\S+) (PASS|FAIL.*)$")

seeds = {}
controls = {}
for i, line in enumerate(smoke_lines, 1):
    sm = seed_re.match(line)
    if sm:
        seeds[sm.group(1)] = {
            "line": i,
            "expect": sm.group(2),
            "got": sm.group(3),
            "applied": sm.group(4),
            "pass": sm.group(2) == sm.group(3)
        }
    cm = control_re.match(line)
    if cm:
        controls[cm.group(1)] = {
            "line": i,
            "status": cm.group(2),
            "pass": cm.group(2) == "PASS"
        }

# Exact mapping of mutant ID to its corresponding guard seed and control
GUARD_MAP = {
    "m01-python-realpath": ("o7.seed.guard-m01-python-realpath", "o7.control.guard-m01-python-realpath"),
    "m02-census-changed": ("o7.seed.guard-m02-census-changed", "o7.control.guard-m02-census-changed"),
    "m03-canonical-roots": ("o7.seed.guard-m03-canonical-roots", "o7.control.guard-m03-canonical-roots"),
    "m04-timeout-realpath": ("o7.seed.guard-m04-timeout-realpath", "o7.control.guard-m04-timeout-realpath"),
    "m05-nm-realpath": ("o7.seed.guard-m05-nm-realpath", "o7.control.guard-m05-nm-realpath"),
    "m06-platform-tmp-identity": ("s1.seed.identity-path", "s1.control.identity"),
    "m07-run3-no-refused": ("o7.seed.guard-m07-run3-no-refused", "o7.control.guard-m07-run3-no-refused"),
    "m08-run3-disk": ("o7.seed.guard-m08-run3-disk", "o7.control.guard-m08-run3-disk"),
    "m09-run3-census-revalidate": ("o7.seed.guard-m09-run3-census", "o7.control.guard-m09-run3-census"),
    "m10-run3-post-driver-identity": ("o7.seed.guard-m10-post-driver-identity", "o7.control.guard-m10-post-driver-identity"),
    "m11-final-identity": ("o7.seed.guard-m11-final-identity", "o7.control.guard-m11-final-identity"),
    "m12-final-unit-mismatch": ("o7.seed.guard-m12-final-unit", "o7.control.guard-m12-final-unit"),
    "m13-final-attempt-mismatch": ("o7.seed.guard-m13-final-attempt", "o7.control.guard-m13-final-attempt"),
    "m14-baseline-header": ("o7.seed.guard-m14-baseline-header", "o7.control.guard-m14-baseline-header"),
    "m15-ledger-begin-end-fields": ("o5.seed.pair-field-drift", "s3.control.ledger"),
    "m16-ledger-foreign-nonce": ("o5.seed.record-foreign-nonce", "s3.control.ledger"),
    "m17-shim-refusal-record": ("s3.seed.refusal-not-recorded", "s3.control.refusal"),
    "m18-shim-e3-utime": ("o5.seed.e3-atime-not-advanced", "s3.control.ledger"),
    "m19-python-version": ("o7.seed.guard-m19-python-version", "o7.control.guard-m19-python-version"),
    "m20-final-required-recompute-control": ("o7.seed.guard-m20-final-required", "o7.control.guard-m20-final-required"),
    "g01-F7-times-t0-sample": ("s5.seed.run1-slow-gate", "s5.control.stage-chain"),
    "g02-F9-plan-probe": ("s1.seed.plan-invalid-census", "s1.control.plan"),
    "g03-F13-cannot-name-tail-only": ("s4.seed.row-oserror", "s4.control.row"),
    "g04-F3-final-required-mismatch": ("s5.seed.required-mismatch", "s5.control.stage-chain"),
    "g05-F2-unchanged-exemption-removed": ("o5.seed.unchanged-noncanonical-http", "s3.control.passthrough"),
    "g06-F2-noncanonical-rule-disabled": ("o5.seed.noncanonical-without-ids", "s3.control.passthrough"),
    "g07-F4-required-no-record-disabled": ("o5.seed.required-no-vars-missing", "s3.control.ledger"),
    "g08-value-coverage-disabled": ("o5.seed.pattern-var-unexercised", "s3.control.ledger"),
    "g09-E3-inode-disabled": ("o5.seed.e3-inode-changed", "s3.control.ledger"),
    "g10-E3-atime-disabled": ("o5.seed.e3-atime-not-advanced", "s3.control.ledger"),
    "g11-OUT-MODIFIED-disabled": ("amend-b.seed.copy-modified", "s3.control.ledger"),
    "g12-E3-read-before-stat": ("amend-b.seed.probe-stat-mutates", "amend-b.control.real-probe"),
    "g13-unmatched-own-positive-disabled": ("o5.seed.e2-unmatched-own", "s3.control.ledger"),
    "g14-E2-name-count-lenient": ("o5.seed.e2-name-repeated", "s3.control.ledger"),
    "g15-positive-roundtrip-disabled": ("o5.seed.positive-no-success", "s3.control.ledger"),
    "g16-F1-env-callsite-disabled": ("s2.seed.validator-schema", "s2.control.census-all"),
    "g17-F6-skip-iyivar-disabled": ("s2.seed.validator-schema", "s2.control.census-all"),
    "g18-F6-sentinel-iyivar-disabled": ("s2.seed.validator-schema", "s2.control.census-all"),
    "g19-F10-platform-guard-disabled": ("s2.seed.validator-schema", "s2.control.census-all"),
    "g20-run-form-never-executed": ("amend-b.seed.run-form-not-counted", "amend-b.control.run-form"),
    "g21-AmendE-nested-work-allowed": ("o7.seed.matcher-platform-two-level", "s2.control.matcher-canonical"),
    "g22-AmendE-platform-tmp-dropped": ("o7.seed.matcher-outside-both", "s2.control.matcher-canonical"),
}

records = []
for mid, rel, old, new in MUTANTS:
    content = (W / rel).read_text(encoding="utf-8")
    anchor_count = content.count(old)
    seed_id, ctrl_id = GUARD_MAP.get(mid, (None, None))
    seed_info = seeds.get(seed_id)
    ctrl_info = controls.get(ctrl_id)
    
    classification = "killed-by-guard"
    note = ""
    if mid == "g07-F4-required-no-record-disabled":
        classification = "layered-reason"
        note = "g07 modifies _check_required_variants early loop; missing record is still caught by subsequent required-variants loop as NOT-EXERCISED, so overall status is preserved while reason set differs"
    elif mid == "g15-positive-roundtrip-disabled":
        classification = "layered-reason"
        note = "g15 removes positive variant roundtrip check; positive variants also require records and execution evidence, which fail earlier if absent, layered with positive-association check"
    
    rec = {
        "id": mid,
        "file": rel,
        "anchor_count_in_H": anchor_count,
        "anchor_unique": anchor_count == 1,
        "guard_seed_id": seed_id,
        "guard_seed_smoke_line": seed_info["line"] if seed_info else None,
        "guard_seed_pass": seed_info["pass"] if seed_info else None,
        "guard_control_id": ctrl_id,
        "guard_control_smoke_line": ctrl_info["line"] if ctrl_info else None,
        "guard_control_pass": ctrl_info["pass"] if ctrl_info else None,
        "classification": classification,
        "note": note
    }
    records.append(rec)

# Read m20 isolated results and utime counterfactual results
m20_res = json.load(open(OUTD / "m20_isolated.json"))
utime_res = json.load(open(OUTD / "shim_read_out_after_utime.json"))

out_data = {
    "total_mutants": len(records),
    "all_anchors_unique_in_H": all(r["anchor_unique"] for r in records),
    "all_guard_seeds_passed": all(r["guard_seed_pass"] for r in records),
    "all_guard_controls_passed": all(r["guard_control_pass"] for r in records),
    "m20_isolated_proven": m20_res["isolated_kill_proven"],
    "shim_read_out_after_utime_proven": utime_res["proves_never_executed_output_wrongly_accepted"],
    "records": records
}

(OUTD / "mutants_accounting.json").write_text(json.dumps(out_data, indent=2) + "\n")
(OUTD / "mutants.jsonl").write_text("\n".join(json.dumps(r, sort_keys=True) for r in records) + "\n")
print(f"Mutant accounting written for {len(records)} mutants. All anchors unique: {out_data['all_anchors_unique_in_H']}. All guards passed: {out_data['all_guard_seeds_passed']}. All controls passed: {out_data['all_guard_controls_passed']}.")
