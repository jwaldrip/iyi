"""Run m20 isolated test and shim-read-out-after-utime counterfactual."""
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time

RV = pathlib.Path("/private/tmp/iyi-proof-review-6bbe1bf2e")
W = RV / "w"
OUTD = RV / "evidence/mutants"
OUTD.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(W))

import proof.smoke_test as smoke
import proof.run_proof as stages_mod
import proof.proofkit as proofkit_mod

PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"

# 1. m20 isolated synthetic test
print("Running m20 isolated synthetic test...")
with smoke.StageFixture() as fx:
    fx.pin_data = fx.pin()
    r1 = stages_mod.cmd_run1(fx.args(), disk_min_gb=0.0)
    r2 = stages_mod.cmd_run2(fx.args(), disk_min_gb=0.0)
    r3 = stages_mod.cmd_run3(fx.args(), drivers=fx.drivers, driver_limit_sec=5.0, grace_sec=0.1, disk_min_gb=0.0)
    
    rc_nonempty = stages_mod.cmd_final(fx.args(), drivers=fx.drivers)
    final_nonempty = json.load(open(os.path.join(fx.report, "final.json")))
    assert rc_nonempty == 0 and final_nonempty["status"] == "PASS"
    
    # Overwrite required.json with matching empty frozen list: []
    req_path = os.path.join(fx.report, "run3", "required.json")
    json.dump([], open(req_path, "w"))
    
    # Control run with empty drivers list drivers=():
    rc_control = stages_mod.cmd_final(fx.args(), drivers=())
    final_control = json.load(open(os.path.join(fx.report, "final.json")))
    m20_control_passed = (rc_control == 1 and final_control["status"] == "FAIL")
    
    # Mutant: remove 'not required' from final check
    target_m20 = OUTD / "m20-iso"
    if target_m20.exists():
        shutil.rmtree(target_m20)
    subprocess.run(["git", "clone", "--no-hardlinks", "--quiet", str(W), str(target_m20)], check=True)
    rp_path = target_m20 / "proof/run_proof.py"
    rp_text = rp_path.read_text()
    old_m20 = '    elif reasons or not required or any(value != "PASS" for value in statuses):\n'
    new_m20 = '    elif reasons or any(value != "PASS" for value in statuses):\n'
    assert rp_text.count(old_m20) == 1
    rp_path.write_text(rp_text.replace(old_m20, new_m20, 1))
    
    cmd_m20 = [
        PY, "-B", "-c",
        f"""
import sys, json, os
sys.path.insert(0, '{target_m20}')
import proof.run_proof as rp
report = '{fx.report}'
class Args: pass
args = Args()
args.report_dir = report
args.report = report
args.p = '{fx.p}'
args.w = '{fx.w}'
args.compiler = '{fx.compiler}'
rc = rp.cmd_final(args, drivers=())
final = json.load(open(os.path.join(report, 'final.json')))
print(json.dumps({{'rc': rc, 'status': final['status'], 'reasons': final.get('reasons', [])}}))
"""
    ]
    p_m20 = subprocess.run(cmd_m20, capture_output=True, text=True)
    mutant_out = json.loads(p_m20.stdout.splitlines()[-1])
    m20_mutant_escaped = (mutant_out["rc"] == 0 and mutant_out["status"] == "PASS")
    shutil.rmtree(target_m20)

m20_iso_result = {
    "nonempty_control_status": final_nonempty["status"],
    "control_rc": rc_control,
    "control_status": final_control["status"],
    "control_detected_empty_required": m20_control_passed,
    "mutant_rc": mutant_out["rc"],
    "mutant_status": mutant_out["status"],
    "mutant_escapes_empty_required": m20_mutant_escaped,
    "isolated_kill_proven": m20_control_passed and m20_mutant_escaped
}
(OUTD / "m20_isolated.json").write_text(json.dumps(m20_iso_result, indent=2) + "\n")
print(f"m20 isolated kill proven: {m20_iso_result['isolated_kill_proven']} (control FAIL on empty required, mutant wrongly PASS)")

# 2. Read-after-utime shim mutation
print("Running read-after-utime shim mutation...")
target_utime = OUTD / "shim-read-out-after-utime"
if target_utime.exists():
    shutil.rmtree(target_utime)
subprocess.run(["git", "clone", "--no-hardlinks", "--quiet", str(W), str(target_utime)], check=True)
shim_path = target_utime / "proof/roundtrip_shim.py"
shim_text = shim_path.read_text()
old_utime = "            os.utime(output, ns=(atime_set_ns, out_mtime_ns))\n"
new_utime = "            os.utime(output, ns=(atime_set_ns, out_mtime_ns))\n            import time; time.sleep(0.05); _ = open(output, 'rb').read()\n"
assert shim_text.count(old_utime) == 1
shim_path.write_text(shim_text.replace(old_utime, new_utime, 1))

def test_shim_read_utime(shim_root):
    t = pathlib.Path(tempfile.mkdtemp(prefix="iyp-utime-test-", dir="/private/tmp"))
    work = t / "work"
    work.mkdir()
    nonce = "1" * 32
    ledger = t / "ledger.jsonl"
    ledger.write_text(json.dumps({"v": 1, "kind": "header", "nonce": nonce, "driver": "cookie", "attempt": 1, "chain_id": "c" * 32}) + "\n")
    census = str(W / "proof/census/cookie.json")
    (t / "s").mkdir()
    (t / "c").mkdir()
    fake = smoke._fake_real_compiler(os.path.join(t, "fake"), version_line="iyi fake [626463375]")
    cfg = {
        "real": fake,
        "census": census,
        "ledger": str(ledger),
        "nonce": nonce,
        "driver": "cookie",
        "work_tmp": str(t),
        "scratch": str(t / "s"),
        "repo": str(W),
        "canonical_roots": [str(W / "src"), str(W / "samples/iyi")],
        "platform_tmp": "/private/tmp"
    }
    (t / "shim.json").write_text(json.dumps(cfg))
    out = work / "cookie-plain"
    env = dict(os.environ, TMPDIR=str(t), IYI_CACHE_DIR=str(t / "c"), IYI_PATH=str(W / "src") + os.pathsep + str(W / "samples/iyi"))
    p = subprocess.run([PY, "-B", str(shim_root / "proof/roundtrip_shim.py"), "--config", str(t / "shim.json"), "--",
                        "build", "-o", str(out), str(W / "bench/std_cookie_exercise.iyi")],
                       cwd=str(W), env=env, capture_output=True, text=True)
    assert p.returncode == 0, p.stderr
    
    # DO NOT EXECUTE OUT!
    # verify_ledger checks if atime > mtime
    v = proofkit_mod.verify_ledger(
        str(ledger), census=json.load(open(census)), driver="cookie", nonce=nonce,
        attempt=1, chain_id="c" * 32, work_tmp=str(t), repo=str(W), platform_tmp="/private/tmp"
    )
    shutil.rmtree(t)
    atime_reason = any("out_ref atime did not advance" in r for r in v.reasons)
    return {
        "statuses": sorted(v.statuses),
        "atime_advance_failed": atime_reason,
        "reasons": v.reasons
    }

control_utime = test_shim_read_utime(W)
mutant_utime = test_shim_read_utime(target_utime)
shutil.rmtree(target_utime)

utime_result = {
    "control": control_utime,
    "mutant": mutant_utime,
    "control_detected_unexecuted": control_utime["atime_advance_failed"],
    "mutant_missed_unexecuted": not mutant_utime["atime_advance_failed"],
    "proves_never_executed_output_wrongly_accepted": (control_utime["atime_advance_failed"] and not mutant_utime["atime_advance_failed"])
}
(OUTD / "shim_read_out_after_utime.json").write_text(json.dumps(utime_result, indent=2) + "\n")
print(f"shim-read-out-after-utime proven: {utime_result['proves_never_executed_output_wrongly_accepted']}")
assert m20_iso_result["isolated_kill_proven"]
assert utime_result["proves_never_executed_output_wrongly_accepted"]
print("Both m20 and read-after-utime tests PASS.")
