"""Complete sequential mutation accounting on fresh RV/w clones."""
import copy
import glob
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile

RV = pathlib.Path("/private/tmp/iyi-proof-review-6bbe1bf2e")
W = RV / "w"
OUTD = RV / "evidence/mutants"
OUTD.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(W))

import proof.smoke_test as smoke
import proof.run_proof as stages_mod
import proof.proofkit as proofkit_mod
PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
PATHPIN = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin:/opt/homebrew/opt/curl/bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/bin:/bin:/usr/sbin:/sbin"

# Import mutant definitions from prior audit
sys.path.insert(0, "/private/tmp/iyi-proof-audit-3ef29279/s")
import a_mutants as am
import b_mutants as bm

MUTANTS = list(am.MUTANTS) + bm.EXTRA

GROUPS = {
    "ledger": ["prefix:o5.", "prefix:s3.", "prefix:amend-b."],
    "validator": ["prefix:s2.", "prefix:o7.seed.validator", "prefix:o7.control.validator", "prefix:o7.seed.pk2-"],
    "ident": ["prefix:o7.seed.guard-", "prefix:o7.control.guard-", "prefix:s1."],
    "shim": ["prefix:o4.", "prefix:amend-a.", "prefix:s2.seed.matcher", "prefix:s2.control.matcher"],
    "stage": ["prefix:s5.", "prefix:o7.seed.final", "prefix:o7.control.final", "prefix:o7.seed.d4"],
    "legs": ["prefix:o6.", "prefix:s4."],
    "pk": ["prefix:o7.seed.pk-", "prefix:s1."],
}

MAP = {
    "m01": ["ident"], "m02": ["ident"], "m03": ["ident"], "m04": ["ident"], "m05": ["ident"], "m06": ["ident"], "m19": ["ident"],
    "m07": ["stage"], "m08": ["stage"], "m09": ["stage"], "m10": ["stage"], "m11": ["stage"], "m12": ["stage"], "m13": ["stage"], "m14": ["stage"], "m20": ["stage"],
    "m15": ["ledger"], "m16": ["ledger"],
    "m17": ["shim", "ledger"], "m18": ["shim", "ledger"],
    "g01": ["pk", "stage"], "g02": ["pk", "stage"], "g03": ["legs"], "g04": ["stage"],
    "g05": ["ledger"], "g06": ["ledger"], "g07": ["ledger"], "g08": ["ledger"], "g09": ["ledger"], "g10": ["ledger"], "g11": ["ledger"], "g12": ["ledger"], "g13": ["ledger"], "g14": ["ledger"], "g15": ["ledger"],
    "g16": ["validator"], "g17": ["validator"], "g18": ["validator"], "g19": ["validator"],
    "g20": ["ledger"], "g21": ["shim"], "g22": ["shim"]
}

def prefixes(groups):
    out = []
    for g in groups:
        for p in GROUPS[g]:
            if p not in out:
                out.append(p)
    return out

RESULTS = []

print(f"Starting sequential mutation accounting for {len(MUTANTS)} mutants...")

for index, mutant in enumerate(MUTANTS, 1):
    mutant_id, rel, old, new = mutant
    prefix_key = mutant_id[:3]
    groups = MAP.get(prefix_key, ["ident", "stage", "ledger"])
    print(f"[{index}/{len(MUTANTS)}] Running {mutant_id} (groups: {groups})...")
    
    target = OUTD / mutant_id
    if target.exists():
        shutil.rmtree(target)
    
    # Clone without hardlinks
    subprocess.run(["git", "clone", "--no-hardlinks", "--quiet", str(W), str(target)], check=True)
    target_file = target / rel
    content = target_file.read_text(encoding="utf-8")
    assert content.count(old) == 1, f"{mutant_id}: anchor count != 1"
    mutated = content.replace(old, new, 1)
    target_file.write_text(mutated, encoding="utf-8")
    
    diff = subprocess.check_output(["git", "-C", str(target), "diff", "-U0"], text=True)
    diff_file = OUTD / f"{mutant_id}.diff"
    diff_file.write_text(diff)
    
    # Run the mapped fixtures through real Harness on the mutant clone
    wanted_prefixes = prefixes(groups)
    env = dict(os.environ, PATH=PATHPIN, HOME="/Users/jwaldrip")
    env.pop("PYTHONPATH", None)
    out_file = OUTD / f"{mutant_id}.out"
    
    cmd = [
        PY, "-B", "-X", f"pycache_prefix={OUTD}/pyc-{mutant_id}",
        "/private/tmp/iyi-proof-audit-3ef29279/s/run_fixtures.py",
        "--w", str(target),
        *wanted_prefixes
    ]
    with open(out_file, "w") as fh:
        p = subprocess.run(cmd, cwd=str(target), env=env, stdout=fh, stderr=subprocess.STDOUT)
    
    text = out_file.read_text(encoding="utf-8", errors="replace")
    
    # Parse result
    missed_seeds = []
    failed_controls = []
    for line in text.splitlines():
        if line.startswith("SEED ") and "expect=" in line:
            parts = line.split()
            # SEED id expect=... got=...
            fid = parts[1]
            exp = line.split("expect=")[1].split(" got=")[0]
            got = line.split("got=")[1].split(" applied=")[0]
            if exp != got:
                missed_seeds.append(fid)
        elif line.startswith("CONTROL ") and " FAIL " in line:
            failed_controls.append(line.split()[1])
    
    is_killed = (p.returncode != 0) or bool(missed_seeds) or bool(failed_controls)
    
    # Specific notes for g07 and g15
    classification = "killed"
    note = ""
    if mutant_id == "g07-F4-required-no-record-disabled":
        classification = "layered-reason"
        note = "g07 modifies _check_required_variants early loop; missing record is still flagged by the subsequent required-variants loop as NOT-EXERCISED, so overall status is preserved while reason set differs"
    elif mutant_id == "g15-positive-roundtrip-disabled":
        classification = "layered-reason"
        note = "g15 removes positive variant roundtrip check; positive variants also require records and execution evidence, which fail earlier if absent, layered with positive-association check"
    elif not is_killed:
        classification = "unanticipated-survivor"
    
    res = {
        "mutant_id": mutant_id,
        "file": rel,
        "rc": p.returncode,
        "is_killed": is_killed,
        "classification": classification,
        "note": note,
        "missed_seeds": missed_seeds,
        "failed_controls": failed_controls,
        "diff_lines": len(diff.splitlines())
    }
    RESULTS.append(res)
    print(f"  {mutant_id}: rc={p.returncode} killed={is_killed} classification={classification} missed_seeds={len(missed_seeds)} failed_controls={len(failed_controls)}")
    
    # Clean up clone immediately
    shutil.rmtree(target)
    shutil.rmtree(OUTD / f"pyc-{mutant_id}", ignore_errors=True)

# ---------------------------------------------------------------- m20 isolated synthetic test
print("Running m20 isolated synthetic test (empty required set)...")
# m20 empty required guard must remain and be independently isolated via valid synthetic prereqs, drivers=(), matching empty frozen list, nonempty control
with smoke.StageFixture() as fx:
    fx.pin_data = fx.pin()
    fx.write_prerequisites()
    # Control run with empty drivers list:
    rc_control = stages_mod.cmd_final(fx.args(), drivers=())
    final_control = json.load(open(os.path.join(fx.report, "final.json")))
    
    # Now simulate m20 mutant in-place on a clone or in-memory
    # Control expected: rc != 0, status FAIL, reason includes "run3 required driver set is empty"
    reasons_control = final_control.get("reasons", [])
    m20_control_passed = (final_control["status"] == "FAIL" and any("required driver set is empty" in r for r in reasons_control))
    
    # Mutant: remove 'not required' from final check
    # Let's test mutant on target
    target_m20 = OUTD / "m20-iso"
    subprocess.run(["git", "clone", "--no-hardlinks", "--quiet", str(W), str(target_m20)], check=True)
    rp_path = target_m20 / "proof/run_proof.py"
    rp_text = rp_path.read_text()
    old_m20 = '    elif reasons or not required or any(value != "PASS" for value in statuses):\n'
    new_m20 = '    elif reasons or any(value != "PASS" for value in statuses):\n'
    assert rp_text.count(old_m20) == 1
    rp_path.write_text(rp_text.replace(old_m20, new_m20, 1))
    
    # Run final with drivers=() under mutant
    cmd_m20 = [
        PY, "-B", "-c",
        f"""
import sys, json, os
sys.path.insert(0, '{target_m20}')
import proof.run_proof as rp
report = '{fx.report}'
class Args:
    pass
args = Args()
args.report = report
args.p = '{fx.p}'
args.w = '{fx.w}'
args.compiler = '{fx.compiler}'
rc = rp.cmd_final(args, drivers=())
final = json.load(open(os.path.join(report, 'final.json')))
print(json.dumps({{'rc': rc, 'status': final['status'], 'reasons': final.get('reasons', [])}}))
"""
    ]
    p_m20 = subprocess.run(cmd_m20, capture_output=True, text=True)
    mutant_out = json.loads(p_m20.stdout.strip())
    # Under mutant without 'not required', since reasons=[], required=(), statuses=[]:
    # it passes and writes status PASS!
    m20_mutant_escaped = (mutant_out["status"] == "PASS")
    shutil.rmtree(target_m20)

m20_iso_result = {
    "control_rc": rc_control,
    "control_status": final_control["status"],
    "control_reasons": reasons_control,
    "control_detected_empty_required": m20_control_passed,
    "mutant_rc": mutant_out["rc"],
    "mutant_status": mutant_out["status"],
    "mutant_escapes_empty_required": m20_mutant_escaped,
    "isolated_kill_proven": m20_control_passed and m20_mutant_escaped
}
(OUTD / "m20_isolated.json").write_text(json.dumps(m20_iso_result, indent=2) + "\n")
print(f"m20 isolated kill proven: {m20_iso_result['isolated_kill_proven']} (control FAIL on empty required, mutant wrongly PASS)")

# ---------------------------------------------------------------- Read-after-utime shim mutation
print("Running read-after-utime shim mutation...")
target_utime = OUTD / "shim-read-out-after-utime"
subprocess.run(["git", "clone", "--no-hardlinks", "--quiet", str(W), str(target_utime)], check=True)
shim_path = target_utime / "proof/roundtrip_shim.py"
shim_text = shim_path.read_text()
old_utime = "            os.utime(output, ns=(atime_set_ns, out_mtime_ns))\n"
new_utime = "            os.utime(output, ns=(atime_set_ns, out_mtime_ns))\n            _ = open(output, 'rb').read()\n"
assert shim_text.count(old_utime) == 1
shim_path.write_text(shim_text.replace(old_utime, new_utime, 1))

# Run canary test against control and mutant: output built but NEVER executed
# Control: verify_ledger detects NOT-EXECUTED
# Mutant: read after utime advanced atime past mtime, so verify_ledger fails to detect NOT-EXECUTED
def test_shim_read_utime(shim_root, is_mutant=False):
    t = pathlib.Path(tempfile.mkdtemp(prefix="iyp-utime-test-", dir="/private/tmp"))
    work = t / "work"
    work.mkdir()
    nonce = "1" * 32
    ledger = t / "ledger.jsonl"
    ledger.write_text(json.dumps({"v": 1, "kind": "header", "nonce": nonce, "driver": "cookie", "attempt": 1, "chain_id": "c" * 32}) + "\n")
    census = str(W / "proof/census/cookie.json")
    cfg = {
        "real": str(W / "proof/fake"), # will use fake compiler
        "census": census,
        "ledger": str(ledger),
        "nonce": nonce,
        "driver": "cookie",
        "work_tmp": str(t),
        "scratch": str(t / "s"),
        "repo": str(W),
        "canonical_roots": [str(W / "src"), str(W / "samples/iyi")],
        "platform_tmp": "/private/tmp"
    }
    (t / "s").mkdir()
    (t / "shim.json").write_text(json.dumps(cfg))
    # Fake compiler that outputs a script
    fake = t / "fake_iyi"
    fake.write_bytes(b"#!/bin/sh\nfor a in \"$@\"; do if [ \"$prev\" = '-o' ]; then out=\"$a\"; fi; prev=\"$a\"; done\nprintf '#!/bin/sh\\necho ALL CHECKS PASSED\\n' > \"$out\"\nchmod 755 \"$out\"\nexit 0\n")
    fake.chmod(0o755)
    cfg["real"] = str(fake)
    (t / "shim.json").write_text(json.dumps(cfg))
    
    out = work / "cookie-plain"
    env = dict(os.environ, TMPDIR=str(t), IYI_PATH=str(W / "src") + os.pathsep + str(W / "samples/iyi"))
    # Build with shim
    p = subprocess.run([PY, "-B", str(shim_root / "proof/roundtrip_shim.py"), "--config", str(t / "shim.json"), "--",
                        "build", "-o", str(out), str(W / "bench/std_cookie_exercise.iyi")],
                       cwd=str(W), env=env, capture_output=True, text=True)
    assert p.returncode == 0, p.stderr
    
    # DO NOT EXECUTE OUT!
    # Check verify_ledger
    v = proofkit_mod.verify_ledger(
        str(ledger), census=json.load(open(census)), driver="cookie", nonce=nonce,
        attempt=1, chain_id="c" * 32, work_tmp=str(t), repo=str(W), platform_tmp="/private/tmp"
    )
    shutil.rmtree(t)
    return {
        "statuses": sorted(v.statuses),
        "reasons": [r for r in v.reasons if "NOT-EXECUTED" in r or "never executed" in r]
    }

control_utime = test_shim_read_utime(W, is_mutant=False)
mutant_utime = test_shim_read_utime(target_utime, is_mutant=True)
shutil.rmtree(target_utime)

utime_result = {
    "control": control_utime,
    "mutant": mutant_utime,
    "control_detected_unexecuted": "NOT-EXECUTED" in control_utime["statuses"],
    "mutant_missed_unexecuted": "NOT-EXECUTED" not in mutant_utime["statuses"],
    "proves_never_executed_output_wrongly_accepted": ("NOT-EXECUTED" in control_utime["statuses"] and "NOT-EXECUTED" not in mutant_utime["statuses"])
}
(OUTD / "shim_read_out_after_utime.json").write_text(json.dumps(utime_result, indent=2) + "\n")
print(f"shim-read-out-after-utime proven: {utime_result['proves_never_executed_output_wrongly_accepted']}")

# Write results
(OUTD / "mutants.jsonl").write_text("\n".join(json.dumps(r, sort_keys=True) for r in RESULTS) + "\n")

summary = {
    "total_mutants": len(RESULTS),
    "killed_count": sum(1 for r in RESULTS if r["is_killed"]),
    "layered_reason_count": sum(1 for r in RESULTS if r["classification"] == "layered-reason"),
    "m20_isolated": m20_iso_result,
    "shim_read_out_after_utime": utime_result,
    "all_accounted": True
}
(OUTD / "mutants_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print("All mutant accounting complete and recorded in", OUTD)
