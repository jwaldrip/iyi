# Independent Proof Audit Report: Frozen H=6bbe1bf2e

**Verdict: GO**  
**Date:** 2026-10-31  
**Candidate Worktree:** `W2=/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030` at `6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd`  
**Base Worktree:** `P=/Users/jwaldrip/dev/worktrees/iyi-stale-integration-repair` at `626463375298d357ffcb3223059f4d3adce6fb10`  
**Review Execution Root:** `RV=/private/tmp/iyi-proof-review-6bbe1bf2e` (fresh clone at `RV/w` via `--no-hardlinks`)  
**Python Interpreter:** `/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3` (Python 3.14.6)  

---

## 1. Executive Summary

This independent proof audit evaluated the strict observed-corpus proof toolchain at frozen commit `H=6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd`. The candidate code was neither repaired nor modified. All obligations specified in the handoff contract (`local://iyi-review-451420109-handoff.txt`), planner specifications, and repair contracts were independently investigated, executed, and evidenced:

1. **Repository Identity & Integrity:** H descends from P1; product diff outside `proof/` is completely empty; remote-tracking branch matches H; porcelain is clean on P, W2, and clone; ignored file counts (13 for P, 9 for W2) and SHA256 hashes match exact parent records; all 4 P1 binaries in `P/.build` match the manifest (`p1-binaries.json`) byte-for-byte.
2. **Layout Check (Signature Layout Repair):** `artifact_legs_layout_check.py` passed all 7 self-test variants isolating C1..C5. Candidate comparison between base `451420109` and `6bbe1bf2e` passed C1..C5 with exact `__main__` guard span (811, 812).
3. **Isolated Plan:** Executed against P + RV/w with rc 0; 29 censuses validated; probe observable; timeout resolved; namespace completely isolated with zero residual `iyp-*` roots.
4. **Optimization Refusals:** Refused under both `-O` flag (rc 2) and `PYTHONOPTIMIZE=1` env (rc 2) with exact refusal notice.
5. **O3 Regression Suite:** Executed on RV/w; 23 seeds passed, 6 controls passed (23/6 PASS, rc 0).
6. **Default Smoke Suite:** Executed on RV/w; 432 seeds executed and passed, 84 controls executed and passed (0 missed, 0 failed, HARNESS PASS, rc 0, elapsed 499.1s).
7. **Coverage Gate & P10 Allowlist Audit:** All 7 allowlist entries audited; they cover exclusively top-level `__main__` dispatch and `os.execv` process replacement; zero decision or verdict code allowlisted; missing lines strictly match allowlist (proofkit: 0, run_proof: 6, artifact_legs: 1, roundtrip_shim: 14); annotated listings preserved under `evidence/coverage/cov/`.
8. **Native Canaries:** Cookie C1 producer, consumer, nonempty `.iyimod`, actual execution, stat before/after, and atime advance verified (hash read strictly after post-exec stat); Calc C2 all artifact legs verified; read-after-utime counterfactual proven.
9. **Registration Interval Proof:** Real SIGINT sent at partial registration; fixed implementation caught signal and restored handlers; relocation mutant escaped `_BoundedSignal`; AST scope check verified.
10. **Five Manual Probes:** All 5 manual probes independently exercised with exact applied evidence and expected outcomes (Seed 1 forged pass detected; Seed 2 dns `$dir` template C5.7 violation; Seed 3 stale nonce verifier STALE + shim rc 125 refused no append; Seed 4 fuzz fixed fi line 73 E1-exec-token violation; Seed 5 stage bound vs driver bound).
11. **Full Adversarial Obligations:** F1 (regex 231 C5.6), F2 (http 1384/1405 --no-codegen), F3 (final recompute after reruns), F6 (IYIVAR rejection), F10 (platform skip guard), touch_unread (ENV-BLOCKED with or without baseline), Matcher attacks (Amendment E), Ledger matrix (70 cases PASS), and all 17 negative required values individually missing verified to trigger NOT-EXERCISED.
12. **Mutation Accounting:** All 42 mutants (m01..m20, g01..g22) verified with unique single-hit anchors in H and corresponding passing guard seeds/controls in smoke suite; m20 isolated empty required set test proven; shim-read-out-after-utime counterfactual proven; g07 and g15 honestly documented as layered-reason checks.

---

## 2. Detailed Audit Sections

### 2.1 Repository & Binary Identity
- **H Commit:** `6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd`
- **P1 Commit:** `626463375298d357ffcb3223059f4d3adce6fb10`
- **Ancestor Check:** `git merge-base --is-ancestor P1 H` -> rc 0 (PASS)
- **Product Diff:** `git diff P1..H -- . :!proof` -> empty (PASS)
- **Remote Tracking:** `origin/proof/audit-deadlines-seams-20261030` -> matches H (PASS)
- **Working Tree Porcelain:**
  - P: clean
  - W2: clean
  - RV/w: clean
- **Ignored Files:**
  - P: 13 files, SHA256 `a4cf227e541b47cda4ef546aee71374c117c71a85b19198ea9a5e1d0b6e00a4e` (matches parent)
  - W2: 9 files, SHA256 `0f82411aee9ddd7a4bacf1c35bc741fb404d89e9bce26109ca9580e60583ec69` (matches parent)
- **Binaries in `P/.build` (all stamped 626463375):**
  - `iyi`: sha256 `f5738660a2bccf39efee9acdf00f2474829969907a623d9e0e33e0f920b4ae74`, size 50842576, inode 2624384932
  - `crystal`: sha256 `001cf890c9491f6e8f0a4d45a59222f4a4868d97e52a45a4134258bd62fa8d8a`, size 50852120, inode 2624393241
  - `iyi-daemon`: sha256 `b816b55f94abb4fa55ba3c3d74a5e2c00498d4ba1a986870a61351e20848560f`, size 50473688, inode 2624398158
  - `crystal-daemon`: sha256 `d366b31ac664c8d6aa177bb69612547a73187fbbf16d01b16000e659bd7f8937`, size 50483136, inode 2624401443
  *(All binaries verified against manifest without rebuilding).*

### 2.2 Layout Check (artifact_legs Signature Layout)
- **Checker:** `/Users/jwaldrip/dev/worktrees/iyi-stale-recovery-evidence-20261030/proof/recovery-20261030/annotation-layout/artifact_legs_layout_check.py`
- **Self-test:** Tested 7 synthetic variants against base `451420109`:
  - `repair`: PASS (expected=[], got=[])
  - `unfixed-base`: isolates `C1`
  - `stale-allowlist`: isolates `C3`
  - `one-signature-left-wrapped`: isolates `C1`
  - `semantic-edit`: isolates `C2`
  - `extra-smoke-edit`: isolates `C4`
  - `other-module-edit`: isolates `C5`
- **Candidate Verification:**
  - `C1`: no annotation-only lines in bytecode (PASS)
  - `C2`: AST identical to base (PASS)
  - `C3`: ALLOWLIST main guard span equals candidate top-level span (811, 812) (PASS)
  - `C4`: smoke_test AST identical to base with allowlist blanked (PASS)
  - `C5`: proofkit, run_proof, roundtrip_shim byte-identical to base (PASS)
  - Result: `LAYOUT CHECK PASS base=451420109dfb0bbcdf800e0143c30768c73e3e0b candidate=6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd`

### 2.3 Isolated Plan
- Command: `python3 -B proof/run_proof.py plan --p P --w RV/w --compiler P/.build/iyi`
- Output: rc 0, Censuses: 29 validated, Probe: sha256, inode, atime observable; Timeout resolved.
- Namespace Isolation:
  - P porcelain: clean before & after
  - W2 porcelain: clean before & after
  - P ignored count: 13 before & after, hash identical
  - W2 ignored count: 9 before & after, hash identical
  - Residual `iyp-*` roots in `/private/tmp`: exactly `['iyp-cf541b90']` before & after (zero leakage)

### 2.4 Optimization Refusals & O3 Suite
- `python3 -B -O proof/smoke_test.py`: rc 2, `smoke_test.py refuses optimized Python: sys.flags.optimize=1` (PASS)
- `PYTHONOPTIMIZE=1 python3 -B proof/smoke_test.py`: rc 2, `smoke_test.py refuses optimized Python: sys.flags.optimize=1` (PASS)
- O3 Suite (`run_o3_suite()`): 23 seeds executed & passed, 6 controls executed & passed, HARNESS PASS, rc 0.

### 2.5 Complete Default Smoke Suite
- Command: `python3 -B proof/smoke_test.py`
- Executed on uninstrumented `RV/w`
- Outcome: rc 0, elapsed 499.1s
- Results:
  - Seeds executed: 432, Seeds passed: 432, Seeds missed: 0, Seeds missing: 0
  - Controls executed: 84, Controls failed: 0, Controls missing: 0
  - HARNESS PASS

### 2.6 P10 Allowlist & Coverage Audit
- **Audited Allowlist Spans (7 entries total):**
  1. `proof.roundtrip_shim:1240-1241`: `_exec_real` `os.execv` site (cannot trace past process replacement).
  2. `proof.roundtrip_shim:1244-1255`: CLI argument parsing / dispatch in `main()`.
  3. `proof.roundtrip_shim:1256-1256`: `return outcome` in `main()`.
  4. `proof.roundtrip_shim:1259-1260`: top-level `if __name__ == "__main__": raise SystemExit(main())`.
  5. `proof.run_proof:1524-1530`: top-level `if sys.flags.optimize:` refusal guard.
  6. `proof.run_proof:1531-1531`: top-level `raise SystemExit(main())`.
  7. `proof.artifact_legs:811-812`: top-level `if __name__ == "__main__": raise SystemExit(main())`.
- **Allowlist Integrity:**
  - Every entry resides strictly inside CLI glue or top-level `__main__` guards.
  - Zero verdict codes, zero status evaluations, zero decision logic are allowlisted.
  - Missing lines across all four covered modules: proofkit: 0, run_proof: 6, artifact_legs: 1, roundtrip_shim: 14.
  - Every missing executable line falls within an audited allowlist entry.

### 2.7 Native Canaries & Counterfactuals
- **C1 (Cookie):**
  - Built with shim: rc 0, mods_count=2, producer rc=0, consumer rc=0.
  - Pre-execution stat: `before.st_ino == out.st_ino == end['out_ino']`, `before.st_atime_ns == end['atime_set_ns'] < before.st_mtime_ns`.
  - Executed: rc 0, `ALL CHECKS PASSED` observed.
  - Post-execution stat: `after.st_atime_ns > after.st_mtime_ns`.
  - Sha256 hash computed strictly *after* post-exec stat, matches `end['consumer']['out_sha256']`.
- **C2 (Calc):**
  - `run_row('samples/iyi/calc.iyi')`: rc 0, status `PASS`, all 5 artifact legs validated.
- **Read-After-Utime Counterfactual:**
  - Proved that reading an output binary after `os.utime` advances `atime > mtime` prematurely.
  - Under control, unexecuted output triggers `NOT-EXECUTED` ("out_ref atime did not advance").
  - Under mutant (premature read), `verify_ledger` fails to detect non-execution, proving the counterfactual.

### 2.8 Registration Interval Diagnostic
- Script: `registration-interval-proof.py`
- Fixed implementation: SIGINT sent during registration interval before `proc.wait` was caught by `_BoundedSignal` handler; process group was terminated; child processes cleaned up; handlers restored; `result.interrupted_signal == signal.SIGINT`.
- Relocated mutant: registration block moved outside protected try scope; SIGINT escaped as unhandled `_BoundedSignal`.
- AST scope check: verified that any fix relying only on outer finally blocks is rejected.

### 2.9 Five Manual Probes
1. **Seed 1 (Forged PASS):** In `StageFixture`, modified latest `result.json` check to `NOT-EXECUTED` while keeping status `PASS`. `cmd_final` caught the forgery, returned rc 1, status `FAIL`, reason: `run3/stage attempt 1 forged status stored='PASS' recomputed='NOT-EXECUTED'`.
2. **Seed 2 (DNS Template):** In `dns.json`, mutated `first_root` from `{WORK}/{dir}` to `{WORK}/$dir`. `validate_census` flagged exact violation `[("C5.7-template", 292, "dns.negative.292.first_root contains forbidden shell syntax: '{WORK}/$dir'")]`. Control had 0 violations.
3. **Seed 3 (Stale Header Nonce):** In ledger line 1, replaced header nonce with all zeros. `verify_ledger` flagged status `STALE`, reason `STALE: header nonce is '00000000000000000000000000000000'`. Shim against stale ledger returned rc 125, stderr `observed-roundtrip-shim: REFUSED ledger header nonce does not match config`, with 0 bytes appended to ledger. Control shim appended successfully.
4. **Seed 4 (Fuzz Fixed-Offset `fi`):** Appended line 73 (`fi`) to `exec_evidence[0]['exec_lines']` in `fuzz.json`. `validate_census` flagged exact violation `[("E1-exec-token", 73, "expected '\"$WORK/fuzz\"' after site line 69")]`. Control had 0 violations.
5. **Seed 5 (Stage Bound vs Driver Bound):**
   - Run 1 slow gate: `StageFixture("run1-slow-gate")` ran uncapped to completion (rc 0, status PASS), times recorded in `run1_1.times`.
   - Run 3 driver timeout: `StageFixture("driver-timeout")` with `sleep 30` standalone line timed out at 0.1s limit (rc 1, exit_check TIMEOUT), killed process group cleanly with 0 leftover `sleep 30` processes, times recorded in `driver.times`.

### 2.10 Adversarial Obligations & Ledger Matrix
- **F1 (Regex 231):** Declaring site 231 as `canonical-other` triggers `C5.6-env-call-variant` (function 'refuses' called with path override at line 416).
- **F2 (HTTP 1384/1405):** Proved that `--no-codegen` with unchanged noncanonical root is not misclassified, but negative passthrough without IDs is properly flagged `MISCLASSIFIED`.
- **F3 (Final Recompute):** Rerunning Run 1 after Run 3 with altered exclusions changes required drivers; `cmd_final` detects mismatch (`run3 required.json mismatch`) and fails with status `FAIL`.
- **F6 (IYIVAR Literal):** Literal IYIVAR in skip regex triggers `C5.4-skip-regex`; in pass sentinel triggers `C5.5-sentinel`.
- **F10 (Platform Skip Guard):** Reclassifying tool-dependent skips to `platform` triggers `C5.4-platform-guard` (platform skip not guarded only by platform state).
- **Touch Unread:** File 529 tool skip classifies `ENV-BLOCKED` both with and without baseline.
- **Matcher Attacks (Amendment E):** All 15 attacks tested against `match_variants`; attacks outside/nested/aliased return `unclassified`, valid controls return `matched`. E2 OUT regex correctly discriminates attempt directories.
- **Ledger Matrix (70 Cases):** Evaluated all own/positive E1-E4 variants across `compress`, `math`, `tls`, `file`:
  - Control cases: PASS
  - Never run: NOT-EXECUTED
  - Copy-over: OUT-MODIFIED
  - Move-over: NOT-EXECUTED
  - Wrong variant: MISCLASSIFIED + shim rc 125
  - Positive absent: NOT-EXERCISED
  - File Darwin splits: excluded positive absent is allowed; present without execution witness fails NOT-EXECUTED; copy-over fails OUT-MODIFIED.
  - All 70 matrix cases PASS.
- **17 Negative Required Values:** Tested all 17 negative required values across sites 169 (1), 230 (5), 428 (11). Removing any single value triggers `NOT-EXERCISED` specifically naming that value. 17/17 PASS.

### 2.11 Mutation Accounting (m01..m20, g01..g22)
- All 42 anchors verified to match exactly once in candidate H.
- All 42 guard seeds and controls verified passing in the baseline smoke log.
- **m20 Isolated Synthetic Test:** With `drivers=()` and matching empty `required.json`, control correctly fails (`status == "FAIL"`, `rc == 1`), while mutant without `not required` wrongly passes (`status == "PASS"`, `rc == 0`). Isolated kill proven.
- **shim-read-out-after-utime:** Proved that premature read after `os.utime` advances `atime > mtime` and causes `verify_ledger` to wrongly accept an unexecuted binary.
- **Layered/Reason-only Checks:**
  - `g07-F4-required-no-record-disabled`: missing record caught by subsequent loop as NOT-EXERCISED; overall status preserved while reason set differs.
  - `g15-positive-roundtrip-disabled`: positive variants require records and execution evidence which fail earlier if absent; layered with positive-association check.

---

## 3. Review-1f Semantic Mapping Summary

| Review-1f Range | Finding Description | Fixture ID | Control ID | Smoke Line | Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Line 9** | Run 3 crashes on first driver (missing `hashlib` import) | `s5.seed.run3-import` | `s5.control.stage-chain` | Line 1198 | **PASS** |
| **Line 11** | `final` always writes PASS (never reads attempt results) | `s5.seed.final-forged-pass` | `s5.control.stage-chain` | Line 1222 | **PASS** |
| **Lines 13-29** | Matcher cannot match variable roots (`$dir`, `$2`, `$name`) | `s2.seed.matcher-variable-root` | `s2.control.matcher-canonical` | Line 352 | **PASS** |
| **Lines 31-33** | Stage-wide timeout caps instead of per-driver bounds | `s5.seed.run3-driver-timeout` | `s5.control.stage-chain` | Line 1201 | **PASS** |
| **Lines 35-40** | `verify_ledger` ignores census, nonce, NOT-EXERCISED | `s3.seed.ledger-stale-header` | `s3.control.ledger` | Line 407 | **PASS** |
| **Lines 42-57** | Census validator fixed offsets, missing positive evidence | `s2.seed.validator-schema` | `s2.control.census-all` | Line 323 | **PASS** |
| **Line 59** | Skips never classified (tool skips passing as PASS) | `s5.seed.skip-env-blocked` | `s5.control.stage-chain` | Line 1203 | **PASS** |
| **Lines 62-79** | Smoke suite covers ~15 fixtures, weak assertions, -O | `harness.seed.optimize-refusal` | `harness.control.unoptimized` | Line 6 | **PASS** |
| **Line 80** | atime probe does not test what E3 depends on | `amend-b.seed.probe-unobservable` | `amend-b.control.real-probe` | Line 41 | **PASS** |
| **Line 81** | Pin and plan do not enforce census validation / binary | `s1.seed.plan-dirty` | `s1.control.plan` | Line 37 | **PASS** |
| **Lines 82-90** | Shim does not behave like real run (signals, roots, exit) | `s3.seed.run-consumer-failure` | `s3.control.run` | Line 367 | **PASS** |
| **Line 91** | Run 3 stops early on missing census; no rerun prereqs | `s5.seed.run3-missing-prerequisite` | `s5.control.stage-chain` | Line 1195 | **PASS** |
| **Lines 94-96** | Fresh cache/tmp dirs missing, exclusions location | `s5.seed.gate-env-reused` | `s5.control.gate-env-fresh` | Line 1184 | **PASS** |
| **Lines 97-101** | `artifact_legs` row OSError/RuntimeError, unpinned nm | `s4.seed.row-oserror` | `s4.control.row` | Line 468 | **PASS** |
| **Lines 102-104** | `run_bounded` does not record survivors, pipe leak | `s1.seed.timeout-grandchild` | `s1.control.bounded` | Line 32 | **PASS** |
| **Lines 105-106** | Report dir path overflow; duplicate census sites | `s1.seed.report-dir-name` | `s1.control.pin` | Line 22 | **PASS** |
| **Lines 108-113** | Retained outputs lack flags/version/HEAD | `harness.seed.optimize-refusal` | `harness.control.unoptimized` | Line 6 | **PASS** |
| **Lines 115-122** | Guarding accepted baseline mechanisms | `s1.seed.pin-dirty-w` | `s1.control.pin` | Line 14 | **PASS** |

---

## 4. Verification Artifacts & Evidence Files

All essential relative artifacts are cataloged in `RV/evidence-files.json` (886 total files):
- `evidence/identity/identity.json`: Full SHA256, mtime, inode, porcelain, and git descent verification.
- `evidence/layout/layout.json`, `selftest.log`, `layout-check.log`: 7 self-test variants and candidate check logs.
- `evidence/plan/plan.json`, `plan.log`: Isolated plan run logs and namespace before/after snapshots.
- `evidence/refusals/optimized-flag.json`, `optimized-env.json`, logs: Python -O refusal evidence.
- `evidence/o3/o3.json`, `o3.log`: Full 23/6 O3 suite output.
- `evidence/smoke/smoke.json`, `smoke.log`: Full 432/84 default smoke output.
- `evidence/coverage/coverage.json`, `cov/*.cover`: Annotated listings and allowlist audit.
- `evidence/canaries/canaries.json`, `canary-shim.json`, `canary-legs.json`, `canary-read-after-utime-counterfactual.json`: C1/C2 proof and atime counterfactual.
- `evidence/registration/run/results.json`, `registration.diff`: Real SIGINT diagnostic and AST check.
- `evidence/manual_seeds/seeds.jsonl`, artifacts: Seeds 1 to 5 raw observations and times files.
- `evidence/fguards/fguards.jsonl`, `demo_misclassified.json`, `demo_final_required.json`, `matcher_attacks.json`, `touch_unread.json`: Adversarial obligation runs.
- `evidence/matrix/matrix_results.jsonl`, `file-required-values/results.json`: 70 matrix cases and 17 negative value splits.
- `evidence/mutants/mutants_accounting.json`, `mutants.jsonl`, `m20_isolated.json`, `shim_read_out_after_utime.json`: 42 mutants accounting, m20 empty required set proof, and read-after-utime proof.
- `evidence/review_mapping/semantic_mapping.json`: Full review-1f range to fixture mapping table.

---

## 5. Conclusion & Recommendation

The observed-corpus proof toolchain at `6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd` is sound, fully guarded, and completely verified. Every NO-GO finding from Review-1f has a proven, load-bearing guard with an applied-once seeded failure and a passing control. The signature layout repair resolves the Python 3.14 annotation-only coverage issue without semantic alteration, and all 7 allowlisted spans are strictly confined to CLI glue and top-level entry guards.

**Final Verdict: GO.**
