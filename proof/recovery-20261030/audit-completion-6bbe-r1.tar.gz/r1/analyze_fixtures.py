#!/usr/bin/env python3
import ast
import json
import re

SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"
RV_SMOKE_LOG = "/private/tmp/iyi-proof-review-6bbe1bf2e/evidence/smoke/smoke.log"
EV_SMOKE_LOG = "/private/tmp/iyi-parent-evidence-6bbe1bf2e/smoke.log"

with open(SMOKE_TEST_PATH, "r", encoding="utf-8") as f:
    source_lines = f.readlines()
source_text = "".join(source_lines)

tree = ast.parse(source_text, filename=SMOKE_TEST_PATH)

# Extract review items
review_items = {}
for node in tree.body:
    if isinstance(node, ast.AnnAssign):
        if isinstance(node.target, ast.Name) and node.target.id == "REVIEW_ITEMS":
            if isinstance(node.value, ast.Dict):
                review_items = ast.literal_eval(node.value)
                break

review_keys = {k: v for k, v in review_items.items() if k.startswith("review.")}

# Parse smoke.log
def parse_smoke_log(path):
    seeds = {}
    controls = {}
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line_str = line.strip()
            if line_str.startswith("SEED "):
                # SEED <fixture_id> expect=<json> got=<json> applied=<string>
                m = re.match(r"^SEED\s+(\S+)\s+expect=(.*?)\s+got=(.*?)\s+applied=(.*)$", line_str)
                if m:
                    fix_id, exp_s, got_s, app_s = m.groups()
                    seeds[fix_id] = {
                        "line": line_no,
                        "raw": line_str,
                        "expect": exp_s,
                        "got": got_s,
                        "applied": app_s,
                    }
                else:
                    print(f"Warning: could not parse SEED line {line_no}: {line_str[:80]}")
            elif line_str.startswith("CONTROL "):
                # CONTROL <fixture_id> PASS
                parts = line_str.split()
                if len(parts) >= 3:
                    controls[parts[1]] = {
                        "line": line_no,
                        "raw": line_str,
                        "status": parts[2],
                    }
    return seeds, controls

rv_seeds, rv_controls = parse_smoke_log(RV_SMOKE_LOG)
ev_seeds, ev_controls = parse_smoke_log(EV_SMOKE_LOG)

print(f"RV: {len(rv_seeds)} seeds, {len(rv_controls)} controls")
print(f"EV: {len(ev_seeds)} seeds, {len(ev_controls)} controls")

# Check all fixtures in review_keys
missing_seeds = []
missing_controls = []
all_review_fixtures = set()

for k, fixtures in review_keys.items():
    for fix in fixtures:
        all_review_fixtures.add(fix)
        if fix.endswith("control") or "control" in fix:
            if fix not in rv_controls:
                missing_controls.append((k, fix))
        else:
            if fix not in rv_seeds:
                missing_seeds.append((k, fix))

print(f"Total unique fixtures in 33 review.* keys: {len(all_review_fixtures)}")
print(f"Missing seeds in RV smoke.log: {len(missing_seeds)}")
if missing_seeds:
    for m in missing_seeds:
        print(f"  Missing seed: {m}")
print(f"Missing controls in RV smoke.log: {len(missing_controls)}")
if missing_controls:
    for m in missing_controls:
        print(f"  Missing control: {m}")
