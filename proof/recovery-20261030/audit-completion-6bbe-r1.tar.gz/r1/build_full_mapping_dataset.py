#!/usr/bin/env python3
import ast
import json
import re

SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"
RV_SMOKE_LOG = "/private/tmp/iyi-proof-complete-6bbe1bf2e/r1/inputs/rv_smoke.log"

with open(SMOKE_TEST_PATH, "r", encoding="utf-8") as f:
    source_lines = f.readlines()
source_text = "".join(source_lines)
tree = ast.parse(source_text, filename=SMOKE_TEST_PATH)

# Parse smoke.log
seeds = {}
controls = {}
with open(RV_SMOKE_LOG, "r", encoding="utf-8") as f:
    for line_no, line in enumerate(f, 1):
        line_str = line.strip()
        if line_str.startswith("SEED "):
            m = re.match(r"^SEED\s+(\S+)\s+expect=(.*?)\s+got=(.*?)\s+applied=(.*)$", line_str)
            if m:
                fix_id, exp_s, got_s, app_s = m.groups()
                seeds[fix_id] = {
                    "line": line_no,
                    "expect": exp_s,
                    "got": got_s,
                    "applied": app_s,
                }
        elif line_str.startswith("CONTROL "):
            parts = line_str.split()
            if len(parts) >= 3:
                controls[parts[1]] = {
                    "line": line_no,
                    "status": parts[2],
                }

# Extract all 33 REVIEW_ITEMS
review_items = {}
for node in tree.body:
    if isinstance(node, ast.AnnAssign):
        if isinstance(node.target, ast.Name) and node.target.id == "REVIEW_ITEMS":
            if isinstance(node.value, ast.Dict):
                review_items = ast.literal_eval(node.value)
                break

review_keys = {k: v for k, v in review_items.items() if k.startswith("review.")}
assert len(review_keys) == 33

print(f"Loaded {len(seeds)} seeds, {len(controls)} controls, and {len(review_keys)} review.* keys")
