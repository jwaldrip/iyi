#!/usr/bin/env python3
import hashlib
import json
import os
import shutil
import subprocess

R1_DIR = "/private/tmp/iyi-proof-complete-6bbe1bf2e/r1"
INPUTS_DIR = os.path.join(R1_DIR, "inputs")
os.makedirs(INPUTS_DIR, exist_ok=True)

SOURCES = {
    "corpus-proof-review-1f.txt": "/Users/jwaldrip/.omp/agent/sessions/-dev-src-github.com-jwaldrip-iyi/2026-10-23T04-40-48-554Z_01a1670f-c2aa-7496-8dff-8051951bcb5a/local/corpus-proof-review-1f.txt",
    "rv_smoke.log": "/private/tmp/iyi-proof-review-6bbe1bf2e/evidence/smoke/smoke.log",
    "ev_smoke.log": "/private/tmp/iyi-parent-evidence-6bbe1bf2e/smoke.log",
    "rv_o3.log": "/private/tmp/iyi-proof-review-6bbe1bf2e/evidence/o3/o3.log",
    "ev_o3.log": "/private/tmp/iyi-parent-evidence-6bbe1bf2e/o3.log",
    "rv_smoke.json": "/private/tmp/iyi-proof-review-6bbe1bf2e/evidence/smoke/smoke.json",
    "rv_o3.json": "/private/tmp/iyi-proof-review-6bbe1bf2e/evidence/o3/o3.json",
    "ev_o3.json": "/private/tmp/iyi-parent-evidence-6bbe1bf2e/o3.json",
}

# 1. Copy files
manifest = {}

for name, src_path in SOURCES.items():
    dest_path = os.path.join(INPUTS_DIR, name)
    shutil.copy2(src_path, dest_path)
    with open(dest_path, "rb") as f:
        data = f.read()
    sha = hashlib.sha256(data).hexdigest()
    manifest[name] = {
        "source_path": src_path,
        "copied_path": dest_path,
        "size_bytes": len(data),
        "sha256": sha,
    }
    print(f"Copied {name}: {len(data)} bytes, sha256={sha}")

# 2. Extract H smoke_test.py blob via git show H:proof/smoke_test.py
W2_DIR = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030"
H = "6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd"
cmd = ["git", "-C", W2_DIR, "show", f"{H}:proof/smoke_test.py"]
blob_data = subprocess.check_output(cmd)

smoke_test_dest = os.path.join(INPUTS_DIR, "smoke_test.py")
with open(smoke_test_dest, "wb") as f:
    f.write(blob_data)

smoke_test_sha = hashlib.sha256(blob_data).hexdigest()
manifest["smoke_test.py"] = {
    "source_blob": f"{H}:proof/smoke_test.py",
    "copied_path": smoke_test_dest,
    "size_bytes": len(blob_data),
    "sha256": smoke_test_sha,
}
print(f"Copied smoke_test.py (from H): {len(blob_data)} bytes, sha256={smoke_test_sha}")

manifest_path = os.path.join(INPUTS_DIR, "inputs_manifest.json")
with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)

print(f"Manifest written to {manifest_path}")
