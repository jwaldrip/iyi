#!/usr/bin/env python3
import ast
import json
import re

SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"

with open(SMOKE_TEST_PATH, "r", encoding="utf-8") as f:
    source_text = f.read()
tree = ast.parse(source_text, filename=SMOKE_TEST_PATH)
for node in tree.body:
    if isinstance(node, ast.AnnAssign):
        if isinstance(node.target, ast.Name) and node.target.id == "REVIEW_ITEMS":
            if isinstance(node.value, ast.Dict):
                review_items = ast.literal_eval(node.value)
                break

print(f"Found {len(review_items)} total REVIEW_ITEMS")
review_keys = {k: v for k, v in review_items.items() if k.startswith("review.")}
print(f"Found {len(review_keys)} keys starting with 'review.'")

for k, v in review_keys.items():
    print(f"  {k}: {v}")
