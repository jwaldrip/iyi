#!/usr/bin/env python3
import ast
import json
import re

SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"

with open(SMOKE_TEST_PATH, "r", encoding="utf-8") as f:
    source_lines = f.readlines()
source_text = "".join(source_lines)

tree = ast.parse(source_text, filename=SMOKE_TEST_PATH)

fixtures_map = {} # fixture_id -> (kind, fn_name, fn_lineno, fn_end_lineno)

# Find all function definitions and their line ranges
fn_ranges = {}
for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef):
        fn_ranges[node.name] = (node.lineno, node.end_lineno)
for node in ast.walk(tree):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "Fixture":
        if len(node.args) >= 3:
            if isinstance(node.args[0], ast.Constant) and isinstance(node.args[1], ast.Constant):
                fid = node.args[0].value
                kind = node.args[1].value
                fn_node = node.args[2]
                fn_name = ""
                if isinstance(fn_node, ast.Name):
                    fn_name = fn_node.id
                elif isinstance(fn_node, ast.Call) and isinstance(fn_node.func, ast.Name):
                    # e.g. partial(target_fn, ...)
                    if fn_node.func.id == "partial" and len(fn_node.args) > 0:
                        target = fn_node.args[0]
                        if isinstance(target, ast.Name):
                            fn_name = f"partial({target.id})"
                        else:
                            fn_name = f"partial({ast.unparse(target)})"
                    else:
                        fn_name = ast.unparse(fn_node)
                else:
                    fn_name = ast.unparse(fn_node)
                
                call_span = f"smoke_test.py:{node.lineno}-{node.end_lineno}"
                fixtures_map[fid] = {
                    "kind": kind,
                    "fn_name": fn_name,
                    "call_lines": call_span,
                }

print(f"Total fixtures mapped: {len(fixtures_map)}")

# Inspect the 81 review fixtures
REVIEW_PATH = "/private/tmp/iyi-proof-complete-6bbe1bf2e/r1/explore_fixtures.py"
# Let's get review_items from tree directly
review_items = {}
for node in tree.body:
    if isinstance(node, ast.AnnAssign):
        if isinstance(node.target, ast.Name) and node.target.id == "REVIEW_ITEMS":
            if isinstance(node.value, ast.Dict):
                review_items = ast.literal_eval(node.value)
                break

review_keys = {k: v for k, v in review_items.items() if k.startswith("review.")}
review_fixtures = set()
for v in review_keys.values():
    review_fixtures.update(v)

for fid in sorted(review_fixtures):
    info = fixtures_map.get(fid)
    if info:
        print(f"{fid:40s} -> {info['fn_name']:35s} {info['call_lines']}")
    else:
        print(f"{fid:40s} -> NOT FOUND IN FIXTURES")
