#!/usr/bin/env python3
import json

REVIEW_1F_PATH = "/Users/jwaldrip/.omp/agent/sessions/-dev-src-github.com-jwaldrip-iyi/2026-10-23T04-40-48-554Z_01a1670f-c2aa-7496-8dff-8051951bcb5a/local/corpus-proof-review-1f.txt"

with open(REVIEW_1F_PATH, "r", encoding="utf-8") as f:
    lines = f.readlines()

ranges = [
    (9, 9, "9 (hashlib)"),
    (11, 11, "11"),
    (13, 29, "13-29"),
    (31, 33, "31-33"),
    (35, 40, "35-40"),
    (42, 57, "42-57"),
    (59, 59, "59"),
    (62, 79, "62-79"),
    (80, 80, "80"),
    (81, 81, "81"),
    (82, 90, "82-90"),
    (91, 91, "91"),
    (94, 96, "94-96"),
    (97, 101, "97-101"),
    (102, 104, "102-104"),
    (105, 106, "105-106"),
    (108, 113, "108-113"),
    (115, 122, "115-122"),
]

for start, end, label in ranges:
    print(f"=== RANGE {label} (lines {start}-{end}) ===")
    for idx in range(start - 1, end):
        if idx < len(lines):
            print(f"{idx+1:3d}: {lines[idx].rstrip()}")
    print()
