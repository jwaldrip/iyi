#!/usr/bin/env python3
import ast
import json
import re

SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"
RV_SMOKE_LOG = "/private/tmp/iyi-proof-complete-6bbe1bf2e/r1/inputs/rv_smoke.log"

with open(SMOKE_TEST_PATH, "r", encoding="utf-8") as f:
    source_lines = f.readlines()
source_text = "".join(source_lines)
tree = ast.parse(source_text, filename=SMOKE_TEST_PATH)

# Parse smoke.log
seeds = {}
controls = {}
with open(RV_SMOKE_LOG, "r", encoding="utf-8") as f:
    for line_no, line in enumerate(f, 1):
        line_str = line.strip()
        if line_str.startswith("SEED "):
            m = re.match(r"^SEED\s+(\S+)\s+expect=(.*?)\s+got=(.*?)\s+applied=(.*)$", line_str)
            if m:
                fix_id, exp_s, got_s, app_s = m.groups()
                seeds[fix_id] = {
                    "line": line_no,
                    "expect": exp_s,
                    "got": got_s,
                    "applied": app_s,
                }
        elif line_str.startswith("CONTROL "):
            parts = line_str.split()
            if len(parts) >= 3:
                controls[parts[1]] = {
                    "line": line_no,
                    "status": parts[2],
                }

# Extract REVIEW_ITEMS
review_items = {}
for node in tree.body:
    if isinstance(node, ast.AnnAssign):
        if isinstance(node.target, ast.Name) and node.target.id == "REVIEW_ITEMS":
            if isinstance(node.value, ast.Dict):
                review_items = ast.literal_eval(node.value)
                break

review_keys = {k: v for k, v in review_items.items() if k.startswith("review.")}

# Find all Fixture calls in tree
fixtures_calls = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "Fixture":
        if len(node.args) >= 3 and isinstance(node.args[0], ast.Constant) and isinstance(node.args[1], ast.Constant):
            fid = node.args[0].value
            kind = node.args[1].value
            fn_node = node.args[2]
            fn_name = ast.unparse(fn_node)
            fixtures_calls[fid] = {
                "kind": kind,
                "fn_name": fn_name,
                "lineno": node.lineno,
                "end_lineno": node.end_lineno,
            }

print(f"Found {len(review_keys)} review.* keys")
for rkey, fix_list in review_keys.items():
    print(f"\n{rkey}:")
    for fix in fix_list:
        if fix in seeds:
            s_info = seeds[fix]
            f_call = fixtures_calls.get(fix, {})
            print(f"  SEED {fix:35s} (smoke:{s_info['line']}) call at smoke_test.py:{f_call.get('lineno')}-{f_call.get('end_lineno')}")
        elif fix in controls:
            c_info = controls[fix]
            f_call = fixtures_calls.get(fix, {})
            print(f"  CTL  {fix:35s} (smoke:{c_info['line']}) call at smoke_test.py:{f_call.get('lineno')}-{f_call.get('end_lineno')}")
        else:
            print(f"  MISS {fix:35s} NOT IN SMOKE LOG")
