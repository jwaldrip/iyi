#!/usr/bin/env python3
import ast
import json
import re

SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"

with open(SMOKE_TEST_PATH, "r", encoding="utf-8") as f:
    source_lines = f.readlines()
source_text = "".join(source_lines)
tree = ast.parse(source_text, filename=SMOKE_TEST_PATH)

# Find all functions and their AST nodes
functions = {}
for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef):
        functions[node.name] = node

# Test extracting expected and applied lines from a FunctionDef node
def extract_citations(fn_name):
    fn_node = functions.get(fn_name)
    if not fn_node:
        return None, None
    
    expected_line = None
    applied_line = None
    
    for subnode in ast.walk(fn_node):
        # Look for expected= or expected assignment
        if isinstance(subnode, ast.keyword) and subnode.arg == "expected":
            expected_line = f"smoke_test.py:{subnode.value.lineno}-{subnode.value.end_lineno}"
        elif isinstance(subnode, ast.Assign):
            for t in subnode.targets:
                if isinstance(t, ast.Name) and t.id == "expected":
                    expected_line = f"smoke_test.py:{subnode.lineno}-{subnode.end_lineno}"
                elif isinstance(t, ast.Name) and t.id == "applied":
                    applied_line = f"smoke_test.py:{subnode.lineno}-{subnode.end_lineno}"
        elif isinstance(subnode, ast.keyword) and subnode.arg == "applied":
            applied_line = f"smoke_test.py:{subnode.value.lineno}-{subnode.value.end_lineno}"
            
    if not expected_line:
        expected_line = f"smoke_test.py:{fn_node.lineno}-{fn_node.end_lineno}"
    if not applied_line:
        applied_line = f"smoke_test.py:{fn_node.lineno}-{fn_node.end_lineno}"
        
    return expected_line, applied_line

test_fns = [
    "_fixture_run3_import_seed",
    "_final_seed",
    "_fixture_optimized_refusal_seed",
    "_fixture_coverage_gap_seed",
    "_fixture_env_scrub_seed",
    "_fixture_probe_unobservable_seed",
]

for fn in test_fns:
    exp_c, app_c = extract_citations(fn)
    print(f"{fn:35s}: exp={exp_c}, app={app_c}")
