#!/usr/bin/env python3
import json
import re

RV_O3_LOG = "/private/tmp/iyi-proof-review-6bbe1bf2e/evidence/o3/o3.log"
EV_O3_LOG = "/private/tmp/iyi-parent-evidence-6bbe1bf2e/o3.log"

def parse_o3_log(path):
    seeds = {}
    controls = {}
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line_str = line.strip()
            if line_str.startswith("SEED "):
                m = re.match(r"^SEED\s+(\S+)\s+expect=(.*?)\s+got=(.*?)\s+applied=(.*)$", line_str)
                if m:
                    fix_id, exp_s, got_s, app_s = m.groups()
                    seeds[fix_id] = {
                        "line": line_no,
                        "raw": line_str,
                        "expect": exp_s,
                        "got": got_s,
                        "applied": app_s,
                    }
                else:
                    print(f"Warning: could not parse SEED line {line_no} in O3: {line_str[:80]}")
            elif line_str.startswith("CONTROL "):
                parts = line_str.split()
                if len(parts) >= 3:
                    controls[parts[1]] = {
                        "line": line_no,
                        "raw": line_str,
                        "status": parts[2],
                    }
    return seeds, controls

rv_o3_seeds, rv_o3_controls = parse_o3_log(RV_O3_LOG)
ev_o3_seeds, ev_o3_controls = parse_o3_log(EV_O3_LOG)

print(f"RV O3: {len(rv_o3_seeds)} seeds, {len(rv_o3_controls)} controls")
print(f"EV O3: {len(ev_o3_seeds)} seeds, {len(ev_o3_controls)} controls")

print(f"Seed ID set diff: {set(rv_o3_seeds.keys()) ^ set(ev_o3_seeds.keys())}")
print(f"Control ID set diff: {set(rv_o3_controls.keys()) ^ set(ev_o3_controls.keys())}")
