#!/usr/bin/env python3
import ast
import json
import re

SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"

with open(SMOKE_TEST_PATH, "r", encoding="utf-8") as f:
    lines = f.readlines()

def search_text(pattern, start=1, end=len(lines)):
    results = []
    for i in range(start - 1, min(end, len(lines))):
        if re.search(pattern, lines[i]):
            results.append((i + 1, lines[i].rstrip()))
    return results

# Let's verify citations for key fixtures
fixtures_to_verify = [
    ("s5.seed.run3-import", r"def _fixture_run3_import_seed"),
    ("s5.seed.final-forged-pass", r"def _fixture_final_forged_pass_seed"),
    ("s5.seed.final-missing-result", r"def _fixture_final_missing_result_seed"),
    ("s2.seed.matcher-variable-root", r"def _o4_matcher_fixture"),
    ("s3.seed.unknown-patched-root", r"def _o4_unknown_root_seed"),
    ("s5.seed.run1-slow-gate", r"def _fixture_run1_slow_gate_seed"),
    ("s5.seed.run3-driver-timeout", r"def _fixture_run3_timeout_seed"),
    ("s3.seed.ledger-stale-header", r"def _o5_ledger_fixture"),
    ("s2.seed.validator-schema", r"def _fixture_validator_schema_seed"),
    ("s2.seed.validator-duplicate-site", r"def _fixture_validator_rule_seed"),
    ("s5.seed.skip-env-blocked", r"def _fixture_skip_env_blocked_seed"),
    ("harness.seed.optimize-refusal", r"def _fixture_optimized_refusal_seed"),
    ("harness.seed.coverage-gap", r"def _fixture_coverage_gap_seed"),
    ("amend-b.seed.probe-unobservable", r"def _fixture_probe_unobservable_seed"),
    ("s1.seed.plan-dirty", r"def _plan_reason_seed"),
    ("s3.seed.run-consumer-failure", r"def _o4_run_consumer_failure_seed"),
    ("s5.seed.run3-missing-prerequisite", r"def _fixture_run3_missing_prerequisite_seed"),
    ("s5.seed.gate-env-reused", r"def _fixture_gate_env_reused_seed"),
    ("s4.seed.row-oserror", r"def _fixture_o6_row_oserror_seed"),
    ("s1.seed.timeout-grandchild", r"def _fixture_timeout_grandchild_seed"),
    ("s1.seed.report-dir-name", r"def _pin_reason_seed"),
    ("s2.seed.regression-1f", r"def _fixture_regression_1f_seed"),
]

for fid, pat in fixtures_to_verify:
    res = search_text(pat)
    if res:
        print(f"{fid:35s}: line {res[0][0]}: {res[0][1]}")
    else:
        print(f"{fid:35s}: NOT FOUND for {pat}")
