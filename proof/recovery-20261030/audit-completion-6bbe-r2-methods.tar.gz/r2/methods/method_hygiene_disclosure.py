# Exact read-only mtime and size attribution method for hygiene disclosure
import os, datetime

def stat_info(p):
    st = os.stat(p)
    return {
        "path": p,
        "size_bytes": st.st_size,
        "mtime_epoch": st.st_mtime,
        "mtime_utc": datetime.datetime.fromtimestamp(st.st_mtime, datetime.timezone.utc).isoformat(),
        "ctime_utc": datetime.datetime.fromtimestamp(st.st_ctime, datetime.timezone.utc).isoformat(),
        "mode": oct(st.st_mode),
        "uid": st.st_uid,
        "gid": st.st_gid
    }
