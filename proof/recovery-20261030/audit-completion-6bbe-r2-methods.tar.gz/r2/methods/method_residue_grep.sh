#!/bin/sh
W="/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030"
H="6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd"
git -C "$W" grep -n build_census "$H"
rc1=$?
git -C "$W" grep -n helper_exec "$H"
rc2=$?
test "$rc1" -eq 1 && test "$rc2" -eq 1
