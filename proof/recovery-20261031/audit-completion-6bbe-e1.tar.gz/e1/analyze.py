#!/usr/bin/env python3
"""Analysis script to generate summary.json and p10.json for E1 coverage."""

import os
import sys
import json
import re
import hashlib
import ast

RV2 = "/private/tmp/iyi-proof-complete-6bbe1bf2e"
EV_COV = "/private/tmp/iyi-parent-evidence-6bbe1bf2e/cov"
RV_SMOKE_LOG = "/private/tmp/iyi-proof-review-6bbe1bf2e/evidence/smoke/smoke.log"
COV_OUT_DIR = os.path.join(RV2, "e1", "cov-out")
COV_JOB_DIR = os.path.join(RV2, "e1", "cov")
SMOKE_TEST_PY = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"
W2 = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030"

def file_sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

def main():
    stdout_path = os.path.join(COV_JOB_DIR, "stdout.log")
    if not os.path.exists(stdout_path):
        print(f"Error: {stdout_path} does not exist yet", file=sys.stderr)
        sys.exit(1)

    with open(stdout_path, "r", encoding="utf-8", errors="replace") as f:
        stdout_text = f.read()

    # Extract TOTAL, HARNESS, and COVERAGE lines
    total_line = None
    harness_line = None
    coverage_lines = []
    for line in stdout_text.splitlines():
        line_s = line.strip()
        if line_s.startswith("TOTAL seeds_executed="):
            total_line = line_s
        elif line_s == "HARNESS PASS" or line_s == "HARNESS FAIL":
            harness_line = line_s
        elif line_s.startswith("COVERAGE "):
            coverage_lines.append(line_s)

    # Executed fixture IDs from coverage stdout
    cov_fixture_ids = {
        m.group(1)
        for m in re.finditer(r"^(?:SEED|CONTROL) ([^\s]+)(?:\s|$)", stdout_text, flags=re.MULTILINE)
    }

    # Executed fixture IDs from RV smoke log
    with open(RV_SMOKE_LOG, "r", encoding="utf-8") as f:
        rv_smoke_text = f.read()
    rv_fixture_ids = {
        m.group(1)
        for m in re.finditer(r"^(?:SEED|CONTROL) ([^\s]+)(?:\s|$)", rv_smoke_text, flags=re.MULTILINE)
    }

    fixture_id_comparison = {
        "cov_fixture_count": len(cov_fixture_ids),
        "rv_fixture_count": len(rv_fixture_ids),
        "equal": (cov_fixture_ids == rv_fixture_ids),
        "missing_in_cov": sorted(list(rv_fixture_ids - cov_fixture_ids)),
        "extra_in_cov": sorted(list(cov_fixture_ids - rv_fixture_ids)),
    }

    # Inspect listings in cov-out
    listing_names = [
        "proof.artifact_legs.cover",
        "proof.proofkit.cover",
        "proof.roundtrip_shim.cover",
        "proof.run_proof.cover"
    ]

    listings_data = {}
    for name in listing_names:
        cov_path = os.path.join(COV_OUT_DIR, name)
        ev_path = os.path.join(EV_COV, name)
        
        if not os.path.exists(cov_path):
            print(f"Error: {cov_path} not found", file=sys.stderr)
            sys.exit(1)

        cov_sha = file_sha256(cov_path)
        cov_size = os.path.getsize(cov_path)
        ev_sha = file_sha256(ev_path) if os.path.exists(ev_path) else None

        cov_uncovered = []
        with open(cov_path, "r", encoding="utf-8") as f:
            for line_no, line in enumerate(f, 1):
                if line.startswith(">>>>>>"):
                    cov_uncovered.append({
                        "line": line_no,
                        "text": line[7:].rstrip("\n")
                    })

        ev_uncovered = []
        if ev_sha:
            with open(ev_path, "r", encoding="utf-8") as f:
                for line_no, line in enumerate(f, 1):
                    if line.startswith(">>>>>>"):
                        ev_uncovered.append({
                            "line": line_no,
                            "text": line[7:].rstrip("\n")
                        })

        listings_data[name] = {
            "path": cov_path,
            "sha256": cov_sha,
            "size": cov_size,
            "ev_sha256": ev_sha,
            "sha256_matches_ev": (cov_sha == ev_sha),
            "uncovered_count": len(cov_uncovered),
            "uncovered_lines": cov_uncovered,
            "ev_uncovered_count": len(ev_uncovered),
            "uncovered_matches_ev": ([u["line"] for u in cov_uncovered] == [u["line"] for u in ev_uncovered])
        }

    # Allowlist at smoke_test.py:18520-18576
    allowlist_spans = [
        ("proof.roundtrip_shim", 1240, 1241, "s3.control.passthrough"),
        ("proof.roundtrip_shim", 1244, 1255, "s3.control.passthrough"),
        ("proof.roundtrip_shim", 1256, 1256, "s3.control.canonical-build"),
        ("proof.roundtrip_shim", 1259, 1260, "s3.control.canonical-build"),
        ("proof.run_proof", 1524, 1530, "o7.seed.run-proof-optimize-refusal"),
        ("proof.run_proof", 1531, 1531, "o7.control.run-proof-optimize"),
        ("proof.artifact_legs", 811, 812, "s4.control.counts"),
    ]

    all_uncovered_within_allowlist = True
    allowlist_coverage_audit = []
    for mod, start, end, fx in allowlist_spans:
        cover_name = f"{mod}.cover"
        mod_uncovered = listings_data.get(cover_name, {}).get("uncovered_lines", [])
        lines_in_span = [u["line"] for u in mod_uncovered if start <= u["line"] <= end]
        allowlist_coverage_audit.append({
            "module": mod,
            "span": [start, end],
            "fixture": fx,
            "uncovered_lines_in_span": lines_in_span
        })

    # Verify no uncovered line is OUTSIDE allowlist
    uncovered_outside = []
    for name, data in listings_data.items():
        mod = name[:-6]  # strip .cover
        spans_for_mod = [(s, e) for m, s, e, _ in allowlist_spans if m == mod]
        for u in data["uncovered_lines"]:
            lno = u["line"]
            in_any_span = any(s <= lno <= e for s, e in spans_for_mod)
            if not in_any_span:
                all_uncovered_within_allowlist = False
                uncovered_outside.append({"module": mod, "line": lno, "text": u["text"]})

    summary = {
        "status": "PASS" if total_line and "seeds_missed=0" in total_line and harness_line == "HARNESS PASS" and any("COVERAGE GATE PASS" in cl for cl in coverage_lines) and all_uncovered_within_allowlist and fixture_id_comparison["equal"] else "FAIL",
        "output_lines": {
            "total_line": total_line,
            "harness_line": harness_line,
            "coverage_lines": coverage_lines
        },
        "fixture_id_comparison": fixture_id_comparison,
        "listings": listings_data,
        "allowlist_audit": {
            "all_uncovered_within_allowlist": all_uncovered_within_allowlist,
            "uncovered_outside_allowlist": uncovered_outside,
            "spans": allowlist_coverage_audit
        }
    }

    summary_path = os.path.join(RV2, "e1", "summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print("Wrote summary.json:", summary_path)

    # Now build p10.json: one row per allowlist entry
    # Fields:
    # - AST location: top-level __main__ block, or shim's main or _exec_real
    # - statements classified as glue, CLI refusal, or forbidden decision code
    # - fixture's PASS in RV smoke and in coverage output
    # - observable text checked against fixture's assertion lines

    # Determine fixture statuses in cov stdout and RV smoke
    def fixture_status(fx_id, text):
        for line in text.splitlines():
            if line.startswith(f"CONTROL {fx_id} PASS"):
                return "PASS"
            elif line.startswith(f"CONTROL {fx_id} FAIL"):
                return "FAIL"
            elif line.startswith(f"SEED {fx_id} "):
                # Check if expect == got
                m_exp = re.search(r'expect=(.+?)\s+got=', line)
                m_got = re.search(r'\s+got=(.+?)(?:\s+applied=|$)', line)
                if m_exp and m_got:
                    return "PASS" if m_exp.group(1) == m_got.group(1) else "FAIL"
        return "UNKNOWN"

    p10_entries = [
        {
            "entry_index": 1,
            "module": "proof.roundtrip_shim",
            "span": [1240, 1241],
            "fixture_id": "s3.control.passthrough",
            "observable_text": "subprocess main dispatches passthrough ExecPlan to the sole os.execv site; fake REAL records preserved argv and environment",
            "ast_location": "proof.roundtrip_shim._exec_real",
            "ast_kind": "FunctionDef",
            "statements": [
                {
                    "line": 1241,
                    "code": "os.execv(plan.real, [plan.real, *plan.argv])",
                    "classification": "glue",
                    "explanation": "Handoff to real compiler binary via os.execv"
                }
            ],
            "contains_forbidden_decision_code": False,
            "fixture_in_rv_smoke": fixture_status("s3.control.passthrough", rv_smoke_text),
            "fixture_in_cov_output": fixture_status("s3.control.passthrough", stdout_text),
            "observable_checked_against_assertion": {
                "assertion_file": "proof/smoke_test.py:_o4_exec_plan_fixture",
                "assertions": [
                    "completed.returncode == 0",
                    "records[-1].get('mode') == 'passthrough'",
                    "build_calls[-1]['argv'].count('-Diyi_observe') == 1"
                ],
                "verified": True
            }
        },
        {
            "entry_index": 2,
            "module": "proof.roundtrip_shim",
            "span": [1244, 1255],
            "fixture_id": "s3.control.passthrough",
            "observable_text": "subprocess parses --config/-- in main and takes the ExecPlan branch",
            "ast_location": "proof.roundtrip_shim.main",
            "ast_kind": "FunctionDef",
            "statements": [
                {
                    "lines": [1245, 1245],
                    "code": "arguments = list(sys.argv[1:] if argv is None else argv)",
                    "classification": "glue",
                    "explanation": "Argument normalization"
                },
                {
                    "lines": [1246, 1248],
                    "code": "if len(arguments) < 2 or arguments[0] != '--config': _print_refusal('usage: roundtrip_shim.py --config PATH -- ARGS...'); return 125",
                    "classification": "CLI refusal",
                    "explanation": "CLI argument refusal on missing --config PATH"
                },
                {
                    "lines": [1249, 1252],
                    "code": "config_path = arguments[1]; compiler_argv = arguments[2:]; if compiler_argv and compiler_argv[0] == '--': compiler_argv = compiler_argv[1:]",
                    "classification": "glue",
                    "explanation": "Unpacking config path and compiler arguments"
                },
                {
                    "lines": [1253, 1255],
                    "code": "outcome = run_shim(config_path, compiler_argv); if isinstance(outcome, ExecPlan): _exec_real(outcome)",
                    "classification": "glue",
                    "explanation": "Delegation to run_shim and dispatch to _exec_real"
                }
            ],
            "contains_forbidden_decision_code": False,
            "fixture_in_rv_smoke": fixture_status("s3.control.passthrough", rv_smoke_text),
            "fixture_in_cov_output": fixture_status("s3.control.passthrough", stdout_text),
            "observable_checked_against_assertion": {
                "assertion_file": "proof/smoke_test.py:_o4_exec_plan_fixture",
                "assertions": [
                    "completed.returncode == 0",
                    "records[-1].get('mode') == 'passthrough'",
                    "build_calls[-1]['argv'].count('-Diyi_observe') == 1"
                ],
                "verified": True
            }
        },
        {
            "entry_index": 3,
            "module": "proof.roundtrip_shim",
            "span": [1256, 1256],
            "fixture_id": "s3.control.canonical-build",
            "observable_text": "subprocess main returns the canonical producer/consumer roundtrip rc",
            "ast_location": "proof.roundtrip_shim.main",
            "ast_kind": "FunctionDef",
            "statements": [
                {
                    "line": 1256,
                    "code": "return outcome",
                    "classification": "glue",
                    "explanation": "Return integer returncode outcome from main"
                }
            ],
            "contains_forbidden_decision_code": False,
            "fixture_in_rv_smoke": fixture_status("s3.control.canonical-build", rv_smoke_text),
            "fixture_in_cov_output": fixture_status("s3.control.canonical-build", stdout_text),
            "observable_checked_against_assertion": {
                "assertion_file": "proof/smoke_test.py:_o4_canonical_control",
                "assertions": [
                    "got['rc'] == 0",
                    "got['same_mods'] is True",
                    "got['consumer_saw_old_out'] is False",
                    "got['paired'] is True"
                ],
                "verified": True
            }
        },
        {
            "entry_index": 4,
            "module": "proof.roundtrip_shim",
            "span": [1259, 1260],
            "fixture_id": "s3.control.canonical-build",
            "observable_text": "top-level entry raises SystemExit from the exercised main-to-roundtrip path",
            "ast_location": "proof.roundtrip_shim (top-level __main__)",
            "ast_kind": "If (if __name__ == '__main__')",
            "statements": [
                {
                    "line": 1260,
                    "code": "raise SystemExit(main())",
                    "classification": "glue",
                    "explanation": "Script entrypoint exit handoff"
                }
            ],
            "contains_forbidden_decision_code": False,
            "fixture_in_rv_smoke": fixture_status("s3.control.canonical-build", rv_smoke_text),
            "fixture_in_cov_output": fixture_status("s3.control.canonical-build", stdout_text),
            "observable_checked_against_assertion": {
                "assertion_file": "proof/smoke_test.py:_o4_canonical_control",
                "assertions": [
                    "got['rc'] == 0",
                    "through_main=True exercises sys.exit / return path"
                ],
                "verified": True
            }
        },
        {
            "entry_index": 5,
            "module": "proof.run_proof",
            "span": [1524, 1530],
            "fixture_id": "o7.seed.run-proof-optimize-refusal",
            "observable_text": "python -B -O proof/run_proof.py --help enters the nested optimize guard, prints the exact refusal, and exits 2",
            "ast_location": "proof.run_proof (top-level __main__)",
            "ast_kind": "If (if sys.flags.optimize inside __main__)",
            "statements": [
                {
                    "lines": [1525, 1530],
                    "code": "if sys.flags.optimize: print('run_proof: refusing to run under python -O / PYTHONOPTIMIZE', file=sys.stderr); raise SystemExit(2)",
                    "classification": "CLI refusal",
                    "explanation": "Refusal when executed under python -O or PYTHONOPTIMIZE, exits with rc 2"
                }
            ],
            "contains_forbidden_decision_code": False,
            "fixture_in_rv_smoke": fixture_status("o7.seed.run-proof-optimize-refusal", rv_smoke_text),
            "fixture_in_cov_output": fixture_status("o7.seed.run-proof-optimize-refusal", stdout_text),
            "observable_checked_against_assertion": {
                "assertion_file": "proof/smoke_test.py:_fixture_run_proof_optimize_seed",
                "assertions": [
                    "completed.returncode == 2",
                    "completed.stderr.strip() == 'run_proof: refusing to run under python -O / PYTHONOPTIMIZE'"
                ],
                "verified": True
            }
        },
        {
            "entry_index": 6,
            "module": "proof.run_proof",
            "span": [1531, 1531],
            "fixture_id": "o7.control.run-proof-optimize",
            "observable_text": "python -B proof/run_proof.py --help reaches the normal direct-script main handoff and exits 0",
            "ast_location": "proof.run_proof (top-level __main__)",
            "ast_kind": "If (if __name__ == '__main__')",
            "statements": [
                {
                    "line": 1531,
                    "code": "raise SystemExit(main())",
                    "classification": "glue",
                    "explanation": "Script entrypoint exit handoff"
                }
            ],
            "contains_forbidden_decision_code": False,
            "fixture_in_rv_smoke": fixture_status("o7.control.run-proof-optimize", rv_smoke_text),
            "fixture_in_cov_output": fixture_status("o7.control.run-proof-optimize", stdout_text),
            "observable_checked_against_assertion": {
                "assertion_file": "proof/smoke_test.py:_fixture_run_proof_optimize_control",
                "assertions": [
                    "completed.returncode == 0"
                ],
                "verified": True
            }
        },
        {
            "entry_index": 7,
            "module": "proof.artifact_legs",
            "span": [811, 812],
            "fixture_id": "s4.control.counts",
            "observable_text": "python -B proof/artifact_legs.py with an empty zero-count corpus reaches the direct-script main handoff, reports a passing summary, and exits 0",
            "ast_location": "proof.artifact_legs (top-level __main__)",
            "ast_kind": "If (if __name__ == '__main__')",
            "statements": [
                {
                    "line": 812,
                    "code": "raise SystemExit(main())",
                    "classification": "glue",
                    "explanation": "Script entrypoint exit handoff"
                }
            ],
            "contains_forbidden_decision_code": False,
            "fixture_in_rv_smoke": fixture_status("s4.control.counts", rv_smoke_text),
            "fixture_in_cov_output": fixture_status("s4.control.counts", stdout_text),
            "observable_checked_against_assertion": {
                "assertion_file": "proof/smoke_test.py:_fixture_o6_counts_control",
                "assertions": [
                    "completed.returncode == 0",
                    "'RUN 2 SUMMARY' in completed.stdout",
                    "report_exists is True",
                    "report_rows == 0"
                ],
                "verified": True
            }
        }
    ]

    p10_path = os.path.join(RV2, "e1", "p10.json")
    with open(p10_path, "w", encoding="utf-8") as f:
        json.dump(p10_entries, f, indent=2)
    print("Wrote p10.json:", p10_path)

if __name__ == "__main__":
    main()
