#!/usr/bin/env python3
"""RV2 receipt wrapper for isolated job execution.
Usage: $PY -B RV2/receipt.py JOB_DIR CWD [KEY=VALUE ...] -- ARGV...
"""
import os
import sys
import json
import time
import hashlib
import subprocess
from datetime import datetime, timezone

PATHPIN = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin:/opt/homebrew/opt/curl/bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/bin:/bin:/usr/sbin:/sbin"
HOME = "/Users/jwaldrip"
MIN_FREE_BYTES = 20 * 1024 * 1024 * 1024  # 20 GiB

def write_json_atomic(path, obj):
    data = (json.dumps(obj, indent=2, sort_keys=True) + "\n").encode("utf-8")
    dir_path = os.path.dirname(os.path.abspath(path))
    tmp_path = os.path.join(dir_path, f".{os.path.basename(path)}.tmp.{os.getpid()}")
    with open(tmp_path, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp_path, path)
    dir_fd = os.open(dir_path, os.O_RDONLY)
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)

def main():
    if len(sys.argv) < 4:
        sys.stderr.write("Usage: receipt.py JOB_DIR CWD [KEY=VALUE ...] -- ARGV...\n")
        sys.exit(2)
    job_dir = sys.argv[1]
    cwd = sys.argv[2]
    rest = sys.argv[3:]
    if "--" in rest:
        dash_idx = rest.index("--")
        key_values = rest[:dash_idx]
        argv = rest[dash_idx + 1:]
    else:
        key_values = []
        argv = rest
    if not argv:
        sys.stderr.write("Error: no ARGV provided after --\n")
        sys.exit(2)

    # 1. os.mkdir(JOB_DIR), which fails if the directory exists.
    os.mkdir(job_dir)

    # 2. If free space on /private/tmp is below 20 GiB, write refused.json, exit 3, and launch nothing.
    stat = os.statvfs("/private/tmp")
    free_bytes = stat.f_bavail * stat.f_frsize
    if free_bytes < MIN_FREE_BYTES:
        refused_data = {
            "error": "free space on /private/tmp below 20 GiB",
            "free_bytes": free_bytes,
            "required_bytes": MIN_FREE_BYTES,
            "utc": datetime.now(timezone.utc).isoformat()
        }
        write_json_atomic(os.path.join(job_dir, "refused.json"), refused_data)
        sys.exit(3)

    # 3. Build the environment: os.environ with PATH=PATHPIN, HOME=/Users/jwaldrip,
    # and any KEY=VALUE arguments applied. Remove PYTHONPATH, PYTHONHOME, PYTHONOPTIMIZE,
    # PYTHONINSPECT and PYTHONSTARTUP.
    env = dict(os.environ)
    env["PATH"] = PATHPIN
    env["HOME"] = HOME
    for k in ["PYTHONPATH", "PYTHONHOME", "PYTHONOPTIMIZE", "PYTHONINSPECT", "PYTHONSTARTUP"]:
        env.pop(k, None)
    for kv in key_values:
        if "=" in kv:
            k, v = kv.split("=", 1)
            env[k] = v

    # 4. Before launching, write command.json:
    # - argv, cwd, UTC time, monotonic_ns, free bytes;
    # - values only for PATH, HOME, TMPDIR, LANG, LC_* and any PYTHON*, IYI*, CRYSTAL* or GIT_* names;
    # - sha256 of the full sorted environment.
    filtered_env = {}
    for k, v in env.items():
        if k in ("PATH", "HOME", "TMPDIR", "LANG") or k.startswith("LC_") or k.startswith("PYTHON") or k.startswith("IYI") or k.startswith("CRYSTAL") or k.startswith("GIT_"):
            filtered_env[k] = v

    sorted_env = sorted(f"{k}={v}" for k, v in env.items())
    env_sha256 = hashlib.sha256(("\n".join(sorted_env) + "\n").encode("utf-8")).hexdigest()

    cmd_utc = datetime.now(timezone.utc).isoformat()
    cmd_monotonic_ns = time.monotonic_ns()
    command_data = {
        "argv": argv,
        "cwd": os.path.abspath(cwd),
        "utc": cmd_utc,
        "monotonic_ns": cmd_monotonic_ns,
        "free_bytes": free_bytes,
        "env": filtered_env,
        "env_sha256": env_sha256
    }
    write_json_atomic(os.path.join(job_dir, "command.json"), command_data)

    # 5. Launch with stdin=DEVNULL, stdout and stderr to JOB_DIR/stdout.log and
    # JOB_DIR/stderr.log (opened O_EXCL), and start_new_session=True.
    # Then write start.json: pid, pgid, UTC, monotonic_ns.
    stdout_path = os.path.join(job_dir, "stdout.log")
    stderr_path = os.path.join(job_dir, "stderr.log")
    stdout_fd = os.open(stdout_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
    stderr_fd = os.open(stderr_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)

    start_utc = datetime.now(timezone.utc).isoformat()
    start_monotonic_ns = time.monotonic_ns()
    proc = subprocess.Popen(
        argv,
        cwd=os.path.abspath(cwd),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=stdout_fd,
        stderr=stderr_fd,
        start_new_session=True
    )
    os.close(stdout_fd)
    os.close(stderr_fd)

    start_data = {
        "pid": proc.pid,
        "pgid": os.getpgid(proc.pid),
        "utc": start_utc,
        "monotonic_ns": start_monotonic_ns
    }
    write_json_atomic(os.path.join(job_dir, "start.json"), start_data)

    # 6. wait() with no timeout. No heartbeat, no signal handling, no kills.
    rc = proc.wait()

    # 7. Write end.json: rc, UTC, monotonic_ns, elapsed, stdout and stderr byte counts
    # and sha256, free bytes. Append one line to JOB_DIR/../receipts.jsonl and fsync it.
    # Exit with the child's rc.
    end_utc = datetime.now(timezone.utc).isoformat()
    end_monotonic_ns = time.monotonic_ns()
    elapsed_ns = end_monotonic_ns - start_monotonic_ns
    elapsed_sec = elapsed_ns / 1_000_000_000.0

    stat_end = os.statvfs("/private/tmp")
    end_free_bytes = stat_end.f_bavail * stat_end.f_frsize

    def file_stats(p):
        if not os.path.exists(p):
            return 0, hashlib.sha256(b"").hexdigest()
        with open(p, "rb") as f:
            content = f.read()
        return len(content), hashlib.sha256(content).hexdigest()

    stdout_bytes, stdout_sha256 = file_stats(stdout_path)
    stderr_bytes, stderr_sha256 = file_stats(stderr_path)

    end_data = {
        "rc": rc,
        "utc": end_utc,
        "monotonic_ns": end_monotonic_ns,
        "elapsed_ns": elapsed_ns,
        "elapsed_sec": elapsed_sec,
        "stdout_bytes": stdout_bytes,
        "stdout_sha256": stdout_sha256,
        "stderr_bytes": stderr_bytes,
        "stderr_sha256": stderr_sha256,
        "free_bytes": end_free_bytes
    }
    write_json_atomic(os.path.join(job_dir, "end.json"), end_data)

    receipt_entry = {
        "job_dir": os.path.abspath(job_dir),
        "argv": argv,
        "cwd": os.path.abspath(cwd),
        "rc": rc,
        "start_utc": start_utc,
        "end_utc": end_utc,
        "elapsed_sec": elapsed_sec,
        "stdout_bytes": stdout_bytes,
        "stdout_sha256": stdout_sha256,
        "stderr_bytes": stderr_bytes,
        "stderr_sha256": stderr_sha256
    }
    receipts_dir = os.path.dirname(os.path.abspath(job_dir))
    receipts_file = os.path.join(receipts_dir, "receipts.jsonl")
    line = (json.dumps(receipt_entry, sort_keys=True) + "\n").encode("utf-8")
    with open(receipts_file, "ab") as f:
        f.write(line)
        f.flush()
        os.fsync(f.fileno())
    dir_fd = os.open(receipts_dir, os.O_RDONLY)
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)
    sys.exit(rc)

if __name__ == "__main__":
    main()
