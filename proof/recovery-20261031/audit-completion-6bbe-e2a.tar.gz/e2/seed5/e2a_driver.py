#!/usr/bin/env python3
"""E2a Driver: Seed 5 driver-timeout leg and control leg.

This script executes either the 'seed' (driver-timeout at unchanged 0.1s limit)
or 'control' (control scenario at 60.0s normal limit) inside StageFixture,
while running a passive ctypes observer thread polling every 0.5ms using
/usr/lib/libproc.dylib (proc_listchildpids, proc_pidpath) and KERN_PROCARGS2.

Acceptance constraints:
- KERN_PROCARGS2 stops decoding at argc; NEVER reads or logs environment bytes.
- Same monotonic timebase as driver.times (time.monotonic_ns()).
- Before teardown, copies result.json, driver.times, driver.log, stub script, stage.json.
- Verifies post-execution process lookup error for witnessed sleeper and leader.
"""
import argparse
import ctypes
import ctypes.util
import hashlib
import json
import os
import shutil
import struct
import sys
import threading
import time
sys.dont_write_bytecode = True
libproc_path = ctypes.util.find_library("proc") or "/usr/lib/libproc.dylib"
libproc = ctypes.CDLL(libproc_path)
libproc.proc_listchildpids.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_int]
libproc.proc_listchildpids.restype = ctypes.c_int
libproc.proc_pidpath.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32]
libproc.proc_pidpath.restype = ctypes.c_int

libc = ctypes.CDLL(None)
libc.sysctl.argtypes = [
    ctypes.POINTER(ctypes.c_int),
    ctypes.c_uint,
    ctypes.c_void_p,
    ctypes.POINTER(ctypes.c_size_t),
    ctypes.c_void_p,
    ctypes.c_size_t,
]
libc.sysctl.restype = ctypes.c_int

CTL_KERN = 1
KERN_PROCARGS2 = 49


def get_argv(pid: int) -> tuple[str | None, list[str] | None]:
    """Retrieve executable path and argv for a given pid via KERN_PROCARGS2.

    CRITICAL PRIVACY/SAFETY CONTRACT:
    Stops decoding strictly at argc. Never inspects, decodes, or logs any
    environment bytes past the argument array.
    """
    mib = (ctypes.c_int * 3)(CTL_KERN, KERN_PROCARGS2, pid)
    size = ctypes.c_size_t(0)
    if libc.sysctl(mib, 3, None, ctypes.byref(size), None, 0) != 0:
        return None, None
    buf = ctypes.create_string_buffer(size.value)
    if libc.sysctl(mib, 3, buf, ctypes.byref(size), None, 0) != 0:
        return None, None
    raw = buf.raw[: size.value]
    if len(raw) < 4:
        return None, None
    argc = struct.unpack("i", raw[:4])[0]
    if argc < 0 or argc > 10000:
        return None, None
    idx = 4
    null_pos = raw.find(b"\x00", idx)
    if null_pos == -1:
        return None, None
    exec_path = raw[idx:null_pos].decode("utf-8", errors="replace")
    idx = null_pos
    while idx < len(raw) and raw[idx] == 0:
        idx += 1
    argv = []
    for _ in range(argc):
        null_pos = raw.find(b"\x00", idx)
        if null_pos == -1:
            break
        arg = raw[idx:null_pos].decode("utf-8", errors="replace")
        argv.append(arg)
        idx = null_pos + 1
    # STOP HERE: never inspect or extract environment variables from raw
    return exec_path, argv


class PassiveWitness:
    """Passive ctypes witness polling child processes every 0.5ms."""

    def __init__(self, driver_pid: int, sampler_path: str):
        self.driver_pid = driver_pid
        self.sampler_path = sampler_path
        self.stop_event = threading.Event()
        self.thread: threading.Thread | None = None
        self.sightings: list[dict] = []
        self.witnessed_sleepers: set[int] = set()
        self.witnessed_leaders: set[int] = set()
        self.observer_errors: list[str] = []
        self.iterations = 0

    def start(self):
        self.thread = threading.Thread(
            target=self._run,
            name="passive-ctypes-witness",
            daemon=True,
        )
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread is not None:
            self.thread.join()

    def _run(self):
        buf = (ctypes.c_int * 512)()
        s_buf = (ctypes.c_int * 512)()
        pathbuf = ctypes.create_string_buffer(4096)

        with open(self.sampler_path, "a", encoding="utf-8") as sampler_file:
            while not self.stop_event.is_set():
                self.iterations += 1
                try:
                    cnt = libproc.proc_listchildpids(
                        self.driver_pid,
                        buf,
                        ctypes.sizeof(buf),
                    )
                    if cnt > 0:
                        for i in range(cnt):
                            cpid = buf[i]
                            if cpid <= 0:
                                continue
                            epath, argv = get_argv(cpid)
                            if argv and argv == [
                                "bash",
                                "bench/std_stage_exercise.sh",
                            ]:
                                leader_pid = cpid
                                self.witnessed_leaders.add(leader_pid)
                                s_cnt = libproc.proc_listchildpids(
                                    leader_pid,
                                    s_buf,
                                    ctypes.sizeof(s_buf),
                                )
                                if s_cnt > 0:
                                    for j in range(s_cnt):
                                        scpid = s_buf[j]
                                        if scpid <= 0:
                                            continue
                                        sepath, sargv = get_argv(scpid)
                                        if sargv and sargv == ["sleep", "30"]:
                                            t_obs = time.monotonic_ns()
                                            try:
                                                pgid = os.getpgid(scpid)
                                            except ProcessLookupError:
                                                continue
                                            ret = libproc.proc_pidpath(
                                                scpid,
                                                pathbuf,
                                                len(pathbuf),
                                            )
                                            exe = (
                                                pathbuf.value.decode(
                                                    "utf-8",
                                                    errors="replace",
                                                )
                                                if ret > 0
                                                else (sepath or "/bin/sleep")
                                            )
                                            sighting = {
                                                "time": t_obs,
                                                "leader_pid": leader_pid,
                                                "sleeper_pid": scpid,
                                                "sleeper_pgid": pgid,
                                                "executable": exe,
                                            }
                                            sampler_file.write(
                                                json.dumps(sighting) + "\n"
                                            )
                                            sampler_file.flush()
                                            os.fsync(sampler_file.fileno())
                                            self.sightings.append(sighting)
                                            self.witnessed_sleepers.add(scpid)
                except Exception as error:
                    self.observer_errors.append(
                        f"Observer error: {type(error).__name__}: {error}"
                    )
                time.sleep(0.0005)


def compute_file_hash(path: str) -> dict:
    if not os.path.exists(path):
        return {"size": 0, "sha256": None, "exists": False}
    with open(path, "rb") as f:
        data = f.read()
    return {
        "size": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "exists": True,
    }


def main():
    parser = argparse.ArgumentParser(description="E2a targeted proof driver")
    parser.add_argument(
        "--mode",
        choices=["seed", "control"],
        required=True,
        help="Job mode: seed or control",
    )
    parser.add_argument(
        "--job-dir",
        required=True,
        help="Target job directory for receipts and copied artifacts",
    )
    args = parser.parse_args()

    mode = args.mode
    job_dir = os.path.abspath(args.job_dir)
    os.makedirs(job_dir, exist_ok=True)

    # Ensure clone root is in sys.path
    clone_root = os.getcwd()
    if clone_root not in sys.path:
        sys.path.insert(0, clone_root)

    import proof.proofkit as proofkit_mod
    import proof.run_proof as stages_mod
    import proof.smoke_test as smoke_test

    if mode == "seed":
        scenario = "driver-timeout"
        expected_stub_diff = 2
        limit_sec = smoke_test._O7_TIMEOUT_DRIVER_LIMIT_SEC  # 0.1s
    else:
        scenario = "control"
        expected_stub_diff = 0
        limit_sec = smoke_test._O7_NORMAL_DRIVER_LIMIT_SEC  # 60.0s

    grace_sec = smoke_test._O7_DRIVER_GRACE_SEC  # 0.1s
    disk_min_gb = 0.0

    sampler_path = os.path.join(job_dir, "sampler.jsonl")
    # Touch sampler_path so it exists even if 0 sightings occur (as in control)
    with open(sampler_path, "wb") as f:
        pass

    driver_pid = os.getpid()
    witness = PassiveWitness(driver_pid, sampler_path)

    t_launch_ns = time.monotonic_ns()
    with smoke_test.StageFixture(scenario) as fx:
        # Step 1: assert fx.stub_difference_count == expected_stub_diff
        assert fx.stub_difference_count == expected_stub_diff, (
            f"Scenario {scenario!r} stub_difference_count {fx.stub_difference_count} != {expected_stub_diff}"
        )

        # Step 2: fx.pin(), then fx.write_prerequisites()
        fx.pin_data = fx.pin()
        fx.write_prerequisites()

        # Start passive ctypes observer BEFORE cmd_run3
        witness.start()

        # Step 3: cmd_run3 fxargs/drivers with exact kwargs
        try:
            rc = stages_mod.cmd_run3(
                fx.args(),
                drivers=fx.drivers,
                driver_limit_sec=limit_sec,
                grace_sec=grace_sec,
                disk_min_gb=disk_min_gb,
            )
        finally:
            witness.stop()

        # Step 4: before teardown, copy run3/stage/<attempt>/{result.json, driver.times, driver.log},
        # the stub script and stage.json into the job directory.
        attempt_dir = stages_mod.latest_attempt_dir(
            os.path.join(fx.report, "run3", "stage")
        )
        if attempt_dir is None or not os.path.exists(attempt_dir):
            raise RuntimeError(f"Missing run3/stage attempt directory in {fx.report}")

        shutil.copyfile(
            os.path.join(attempt_dir, "result.json"),
            os.path.join(job_dir, "result.json"),
        )
        shutil.copyfile(
            os.path.join(attempt_dir, "driver.times"),
            os.path.join(job_dir, "driver.times"),
        )
        shutil.copyfile(
            os.path.join(attempt_dir, "driver.log"),
            os.path.join(job_dir, "driver.log"),
        )
        shutil.copyfile(
            os.path.join(fx.w, "bench", "std_stage_exercise.sh"),
            os.path.join(job_dir, "std_stage_exercise.sh"),
        )
        shutil.copyfile(
            os.path.join(fx.w, "proof", "census", "stage.json"),
            os.path.join(job_dir, "stage.json"),
        )

    t_complete_ns = time.monotonic_ns()

    # Post-execution assertions and verification
    result_path = os.path.join(job_dir, "result.json")
    with open(result_path, "r", encoding="utf-8") as f:
        result_data = json.load(f)

    times_path = os.path.join(job_dir, "driver.times")
    with open(times_path, "r", encoding="utf-8") as f:
        times_lines = [line.strip() for line in f if line.strip()]

    assert len(times_lines) >= 2, f"driver.times has fewer than 2 lines: {times_lines}"
    t0_str, size0_str = times_lines[0].split()
    t0 = int(t0_str)
    assert int(size0_str) == 0, f"driver.times initial size is not 0: {size0_str}"

    t_final_str, size_final_str = times_lines[-1].split()
    t_final = int(t_final_str)

    stub_script_path = os.path.join(job_dir, "std_stage_exercise.sh")
    with open(stub_script_path, "r", encoding="utf-8") as f:
        script_text = f.read()
    script_lines = script_text.splitlines()
    sleep_statements = [
        line.strip() for line in script_lines if line.strip() == "sleep 30"
    ]

    stage_census_path = os.path.join(job_dir, "stage.json")
    with open(stage_census_path, "r", encoding="utf-8") as f:
        actual_census = json.load(f)

    expected_script_bytes, expected_census = smoke_test._stage_driver_census(
        "stage", scenario
    )
    with open(stub_script_path, "rb") as f:
        actual_script_bytes = f.read()

    census_matches_derived = (actual_census == expected_census)
    script_matches_derived = (actual_script_bytes == expected_script_bytes)

    assertions: dict[str, object] = {
        "mode": mode,
        "scenario": scenario,
        "driver_limit_sec": limit_sec,
        "grace_sec": grace_sec,
        "disk_min_gb": disk_min_gb,
        "returncode": rc,
        "status": result_data.get("status"),
        "exit_check": result_data.get("checks", {}).get("exit"),
        "survivors_in_result": result_data.get("survivors"),
        "times_t0": t0,
        "times_t_final": t_final,
        "times_lines_count": len(times_lines),
        "observer_iterations": witness.iterations,
        "observer_errors": witness.observer_errors,
        "witnessed_leaders": sorted(witness.witnessed_leaders),
        "witnessed_sleepers": sorted(witness.witnessed_sleepers),
        "sightings_count": len(witness.sightings),
        "census_matches_derived": census_matches_derived,
        "script_matches_derived": script_matches_derived,
    }

    if mode == "seed":
        # Assertions for seed:
        # 1. returncode == 1
        # 2. status == "TIMEOUT"
        # 3. exit == "TIMEOUT"
        # 4. survivors == []
        assert rc == 1, f"Expected rc 1 for seed, got {rc}"
        assert result_data.get("status") == "TIMEOUT", (
            f"Expected status TIMEOUT, got {result_data.get('status')}"
        )
        assert result_data.get("checks", {}).get("exit") == "TIMEOUT", (
            f"Expected exit check TIMEOUT, got {result_data.get('checks', {}).get('exit')}"
        )
        assert result_data.get("survivors") == [], (
            f"Expected no survivors in result, got {result_data.get('survivors')}"
        )

        # 5. exactly one standalone sleep 30 statement
        assert len(sleep_statements) == 1, (
            f"Expected exactly 1 standalone sleep 30 statement, got {len(sleep_statements)}"
        )
        assert census_matches_derived, "stage.json did not match derived _stage_driver_census"
        assert script_matches_derived, "std_stage_exercise.sh did not match derived bytes"

        # 6. witness sightings
        assert len(witness.sightings) >= 1, "No sleeper sightings recorded in sampler.jsonl"
        first_sighting = witness.sightings[0]
        assertions["first_sighting"] = first_sighting
        assertions["sighting_minus_t0_ns"] = first_sighting["time"] - t0
        assertions["sighting_minus_t0_ms"] = (first_sighting["time"] - t0) / 1_000_000.0

        # Witnessed before t0 + 100_000_000 ns (0.1s limit)
        witnessed_before_deadline = first_sighting["time"] < (t0 + 100_000_000)
        witnessed_before_final_times = first_sighting["time"] < t_final
        assertions["witnessed_before_deadline"] = witnessed_before_deadline
        assertions["witnessed_before_final_times"] = witnessed_before_final_times

        assert witnessed_before_deadline, (
            f"First sleeper sighting at {first_sighting['time']} was not before t0 + 100ms ({t0 + 100_000_000})"
        )
        assert witnessed_before_final_times, (
            f"First sleeper sighting at {first_sighting['time']} was not before final driver.times ({t_final})"
        )

        # All sightings must have sleeper_pgid == leader_pid
        all_pgid_match = all(
            s["sleeper_pgid"] == s["leader_pid"] for s in witness.sightings
        )
        assertions["all_sleeper_pgid_equal_leader_pid"] = all_pgid_match
        assert all_pgid_match, "Not all sightings had sleeper_pgid == leader_pid"

        # 7. Post-call ProcessLookupError for witnessed sleepers and leaders
        sleeper_killed = True
        for scpid in witness.witnessed_sleepers:
            try:
                os.kill(scpid, 0)
                sleeper_killed = False
            except ProcessLookupError:
                pass
        assertions["sleeper_killed_lookup_error"] = sleeper_killed
        assert sleeper_killed, "A witnessed sleeper process survived after call returned!"

        leader_killed = True
        group_empty = True
        for lpid in witness.witnessed_leaders:
            try:
                os.kill(lpid, 0)
                leader_killed = False
            except ProcessLookupError:
                pass
            try:
                os.killpg(lpid, 0)
                group_empty = False
            except ProcessLookupError:
                pass
            remaining_members = proofkit_mod._process_group_members(lpid)
            if remaining_members:
                group_empty = False

        assertions["leader_killed_lookup_error"] = leader_killed
        assertions["group_empty"] = group_empty
        assert leader_killed, "A witnessed leader process survived after call returned!"
        assert group_empty, "Process group retained members after call returned!"

    else:
        # Assertions for control:
        # 1. returncode == 0
        # 2. status == "PASS"
        # 3. exit == "PASS"
        # 4. survivors == []
        assert rc == 0, f"Expected rc 0 for control, got {rc}"
        assert result_data.get("status") == "PASS", (
            f"Expected status PASS, got {result_data.get('status')}"
        )
        assert result_data.get("checks", {}).get("exit") == "PASS", (
            f"Expected exit check PASS, got {result_data.get('checks', {}).get('exit')}"
        )
        assert result_data.get("survivors") == [], (
            f"Expected no survivors in result, got {result_data.get('survivors')}"
        )

        # 5. exactly zero sleep 30 statements
        assert len(sleep_statements) == 0, (
            f"Expected 0 sleep 30 statements in control, got {len(sleep_statements)}"
        )
        assert census_matches_derived, "stage.json did not match derived _stage_driver_census"
        assert script_matches_derived, "std_stage_exercise.sh did not match derived bytes"

        # 6. witness sightings: 0 in control
        assert len(witness.sightings) == 0, (
            f"Expected 0 sleeper sightings in control, got {len(witness.sightings)}"
        )

        # 7. Post-call ProcessLookupError for leader
        leader_killed = True
        group_empty = True
        for lpid in witness.witnessed_leaders:
            try:
                os.kill(lpid, 0)
                leader_killed = False
            except ProcessLookupError:
                pass
            try:
                os.killpg(lpid, 0)
                group_empty = False
            except ProcessLookupError:
                pass
            remaining_members = proofkit_mod._process_group_members(lpid)
            if remaining_members:
                group_empty = False

        assertions["leader_killed_lookup_error"] = leader_killed
        assertions["group_empty"] = group_empty
        assert leader_killed, "Leader survived after call returned in control!"
        assert group_empty, "Process group retained members in control!"

    assertions["verdict"] = "PASS"

    # Compute hashes of all artifacts in job directory
    artifacts = {}
    for filename in [
        "result.json",
        "driver.times",
        "driver.log",
        "std_stage_exercise.sh",
        "stage.json",
        "sampler.jsonl",
    ]:
        p = os.path.join(job_dir, filename)
        artifacts[filename] = compute_file_hash(p)

    with open(os.path.join(job_dir, "artifacts_sha256.json"), "w", encoding="utf-8") as f:
        json.dump(artifacts, f, indent=2, sort_keys=True)
        f.write("\n")

    with open(os.path.join(job_dir, "assertions.json"), "w", encoding="utf-8") as f:
        json.dump(assertions, f, indent=2, sort_keys=True)
        f.write("\n")

    print(f"E2a {mode} completed successfully: verdict PASS, rc={rc}")
    sys.exit(rc)


if __name__ == "__main__":
    main()
