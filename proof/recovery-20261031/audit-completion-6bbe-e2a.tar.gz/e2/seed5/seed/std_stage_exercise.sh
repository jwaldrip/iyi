#!/bin/bash
REPO=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
sleep 30
status=0
WORK="$(mktemp -d)"
name=stage-plain
if ! "$IYI" build -o "$WORK/$name" "$REPO/bench/std_stage_exercise.iyi"; then
  status=1
elif ! "$WORK/$name"; then
  status=1
fi
echo "the std/stage exercise holds"
exit $status
