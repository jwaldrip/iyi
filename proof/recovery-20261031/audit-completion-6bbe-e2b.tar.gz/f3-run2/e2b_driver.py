#!/usr/bin/env python3
"""E2b Driver: F3 Run 2 leg (r2-seed and r2-ctl).

Per spec lines 293-309:
- Wrap _stage_stub_payloads in driver process only.
- In proof/artifact_legs.py stub's std loop (smoke_test.py:12056-12058):
  replace 'status':STATUS,'p_nonzero':False})
  with 'status':STATUS,'p_nonzero':(index == 1 and os.path.exists('<abs flip>'))})
  Count must be 1.
- Chain (run once as r2-seed and once as r2-ctl):
  1. StageFixture("control");
  2. pin, run1, run2, run3 with arguments at smoke_test.py:13197-13211;
  3. final0, which must be rc 0 PASS;
  4. the seed chain only: create the flip file;
  5. run2, whose new attempt must be rc 0 and PASS;
  6. final1.
- Pre-teardown capture of all stage outputs, JSONs, attempt IDs, hashes.
"""
import argparse
import difflib
import hashlib
import json
import os
import shutil
import sys
import time

sys.dont_write_bytecode = True


def compute_file_hash(path: str) -> dict:
    if not os.path.exists(path):
        return {"exists": False}
    with open(path, "rb") as f:
        data = f.read()
    return {
        "size": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "exists": True,
    }


def main():
    parser = argparse.ArgumentParser(description="E2b F3 Run 2 leg driver")
    parser.add_argument("--mode", choices=["seed", "control"], required=True)
    parser.add_argument("--job-dir", required=True)
    parser.add_argument("--abs-flip", default=None)
    args = parser.parse_args()

    mode = args.mode
    job_dir = os.path.abspath(args.job_dir)
    os.makedirs(job_dir, exist_ok=True)

    abs_flip = (
        os.path.abspath(args.abs_flip)
        if args.abs_flip
        else os.path.join(job_dir, "flip")
    )

    clone_root = os.getcwd()
    if clone_root not in sys.path:
        sys.path.insert(0, clone_root)

    import proof.run_proof as stages_mod
    import proof.smoke_test as smoke_test

    orig_stage_stub_payloads = smoke_test._stage_stub_payloads
    construction_records = []

    target_orig_snippet = "'status':STATUS,'p_nonzero':False})"
    target_repl_snippet = (
        f"'status':STATUS,'p_nonzero':(index == 1 and os.path.exists('{abs_flip}'))}})"
    )
    std_line_orig = (
        "    rows.append({'kind':'std','base':base,'name':f'bench/{base}.iyi','status':STATUS,'p_nonzero':False})\n"
    )

    def wrapped_stage_stub_payloads(
        scenario: str, fixture_root: str
    ) -> dict[str, bytes]:
        payloads = orig_stage_stub_payloads(scenario, fixture_root)
        if "proof/artifact_legs.py" in payloads:
            raw_bytes = payloads["proof/artifact_legs.py"]
            text = raw_bytes.decode("utf-8")
            assert (
                std_line_orig in text
            ), "std_line_orig not found in artifact_legs.py"
            assert text.count(target_orig_snippet) == 2, (
                f"Expected 2 occurrences of target_orig_snippet in artifact_legs.py, "
                f"found {text.count(target_orig_snippet)}"
            )

            std_line_repl = std_line_orig.replace(
                target_orig_snippet, target_repl_snippet, 1
            )
            new_text = text.replace(std_line_orig, std_line_repl, 1)

            assert (
                new_text.count(target_orig_snippet) == 1
            ), "Expected 1 occurrence remaining (sample loop)"
            assert (
                new_text.count(target_repl_snippet) == 1
            ), "Expected 1 replacement occurrence (std loop)"

            diff_lines = list(
                difflib.unified_diff(
                    text.splitlines(keepends=True),
                    new_text.splitlines(keepends=True),
                    fromfile="a/proof/artifact_legs.py",
                    tofile="b/proof/artifact_legs.py",
                )
            )

            construction_records.append(
                {
                    "scenario": scenario,
                    "fixture_root": fixture_root,
                    "abs_flip": abs_flip,
                    "original_snippet": target_orig_snippet,
                    "replacement_snippet": target_repl_snippet,
                    "replacement_count": 1,
                    "diff": "".join(diff_lines),
                    "original_std_line": std_line_orig,
                    "replacement_std_line": std_line_repl,
                }
            )
            payloads["proof/artifact_legs.py"] = new_text.encode("utf-8")
        return payloads

    smoke_test._stage_stub_payloads = wrapped_stage_stub_payloads

    print(
        f"=== E2b Driver starting mode={mode} in {job_dir} at {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} ==="
    )

    t0_chain = time.monotonic_ns()
    with smoke_test.StageFixture("control") as fx:
        assert (
            fx.stub_difference_count == 0
        ), f"Scenario 'control' stub_difference_count {fx.stub_difference_count} != 0"

        # Step 2: pin, run1, run2, run3 with arguments at smoke_test.py:13197-13211
        print("Step 2: pin, run1, run2, run3...")
        fx.pin_data = fx.pin()
        run1_rc = stages_mod.cmd_run1(
            fx.args(),
            disk_min_gb=0.0,
        )
        assert run1_rc == 0, f"run1 rc {run1_rc} != 0"

        run2_rc = stages_mod.cmd_run2(
            fx.args(),
            disk_min_gb=0.0,
        )
        assert run2_rc == 0, f"run2 rc {run2_rc} != 0"

        run3_rc = stages_mod.cmd_run3(
            fx.args(),
            drivers=fx.drivers,
            driver_limit_sec=smoke_test._O7_NORMAL_DRIVER_LIMIT_SEC,
            grace_sec=smoke_test._O7_DRIVER_GRACE_SEC,
            disk_min_gb=0.0,
        )
        assert run3_rc == 0, f"run3 rc {run3_rc} != 0"

        # Step 3: final0, which must be rc 0 PASS
        print("Step 3: final0...")
        final0_rc = stages_mod.cmd_final(
            fx.args(),
            drivers=fx.drivers,
        )
        final0_raw = os.path.join(fx.report, "final.json")
        with open(final0_raw, "r", encoding="utf-8") as f:
            final0_record = json.load(f)
        assert final0_rc == 0, f"final0 rc {final0_rc} != 0"
        assert (
            final0_record.get("status") == "PASS"
        ), f"final0 status {final0_record.get('status')} != PASS"
        assert (
            final0_record.get("reasons") == []
        ), f"final0 reasons not empty: {final0_record.get('reasons')}"

        with open(
            os.path.join(job_dir, "final0.json"), "w", encoding="utf-8"
        ) as f:
            json.dump(final0_record, f, indent=2, sort_keys=True)
            f.write("\n")

        # Step 4: the seed chain only: create the flip file
        print(f"Step 4: flip handling (mode={mode})...")
        assert not os.path.exists(
            abs_flip
        ), f"Flip file {abs_flip} already existed before step 4!"
        if mode == "seed":
            with open(abs_flip, "w", encoding="utf-8") as f:
                f.write("f3_run2_flip_enabled\n")
                f.flush()
                os.fsync(f.fileno())
            assert os.path.exists(
                abs_flip
            ), f"Flip file {abs_flip} failed to create!"
            print(f"Seed flip file created at {abs_flip}")
        else:
            assert not os.path.exists(
                abs_flip
            ), f"Flip file {abs_flip} should not exist in control!"
            print("Control mode: no flip file created.")

        # Step 5: run2, whose new attempt must be rc 0 and PASS
        print("Step 5: run2 rerun...")
        run2_rerun_rc = stages_mod.cmd_run2(
            fx.args(),
            disk_min_gb=0.0,
        )
        assert run2_rerun_rc == 0, f"run2 rerun rc {run2_rerun_rc} != 0"

        run2_a2_dir = os.path.join(fx.report, "run2", "a2")
        assert os.path.exists(
            run2_a2_dir
        ), f"Missing run2/a2 attempt directory in {fx.report}"
        with open(
            os.path.join(run2_a2_dir, "result.json"), "r", encoding="utf-8"
        ) as f:
            run2_a2_record = json.load(f)
        assert (
            run2_a2_record.get("status") == "PASS"
        ), f"run2 rerun status {run2_a2_record.get('status')} != PASS"

        # Check p_nonzero in run2 a2 report rows
        run2_a2_report = os.path.join(run2_a2_dir, "run2.jsonl")
        a2_rows = []
        with open(run2_a2_report, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    a2_rows.append(json.loads(line))
        p_nonzero_rows = [r for r in a2_rows if r.get("p_nonzero") is True]
        if mode == "seed":
            assert (
                len(p_nonzero_rows) == 1
            ), f"Expected 1 p_nonzero row in seed, got {len(p_nonzero_rows)}"
            assert (
                p_nonzero_rows[0].get("base") == "std_fixture_001_exercise"
            ), f"Unexpected p_nonzero row: {p_nonzero_rows[0]}"
        else:
            assert (
                len(p_nonzero_rows) == 0
            ), f"Expected 0 p_nonzero rows in control, got {len(p_nonzero_rows)}"

        # Step 6: final1
        print("Step 6: final1...")
        final1_rc = stages_mod.cmd_final(
            fx.args(),
            drivers=fx.drivers,
        )
        final1_raw = os.path.join(fx.report, "final.json")
        with open(final1_raw, "r", encoding="utf-8") as f:
            final1_record = json.load(f)

        with open(
            os.path.join(job_dir, "final1.json"), "w", encoding="utf-8"
        ) as f:
            json.dump(final1_record, f, indent=2, sort_keys=True)
            f.write("\n")

        # Copy individual run results before teardown
        shutil.copyfile(
            os.path.join(fx.report, "run1", "a1", "result.json"),
            os.path.join(job_dir, "run1_a1_result.json"),
        )
        shutil.copyfile(
            os.path.join(fx.report, "run2", "a1", "result.json"),
            os.path.join(job_dir, "run2_a1_result.json"),
        )
        shutil.copyfile(
            os.path.join(fx.report, "run2", "a1", "run2.jsonl"),
            os.path.join(job_dir, "run2_a1.jsonl"),
        )
        shutil.copyfile(
            os.path.join(fx.report, "run2", "a2", "result.json"),
            os.path.join(job_dir, "run2_a2_result.json"),
        )
        shutil.copyfile(
            os.path.join(fx.report, "run2", "a2", "run2.jsonl"),
            os.path.join(job_dir, "run2_a2.jsonl"),
        )
        shutil.copyfile(
            os.path.join(fx.report, "run3", "required.json"),
            os.path.join(job_dir, "run3_required.json"),
        )
        shutil.copyfile(
            os.path.join(fx.report, "run3", "stage", "a1", "result.json"),
            os.path.join(job_dir, "run3_stage_a1_result.json"),
        )

        if os.path.exists(os.path.join(fx.w, "proof", "artifact_legs.py")):
            shutil.copyfile(
                os.path.join(fx.w, "proof", "artifact_legs.py"),
                os.path.join(job_dir, "artifact_legs.py"),
            )

        # Snapshot full stage report tree before teardown
        stage_outputs_dir = os.path.join(job_dir, "stage_outputs")
        shutil.copytree(
            fx.report,
            os.path.join(stage_outputs_dir, "report"),
            dirs_exist_ok=True,
        )

        # Collect attempt manifest
        attempt_manifest = {
            "run1": [
                d
                for d in sorted(os.listdir(os.path.join(fx.report, "run1")))
                if d.startswith("a")
            ],
            "run2": [
                d
                for d in sorted(os.listdir(os.path.join(fx.report, "run2")))
                if d.startswith("a")
            ],
            "run3_drivers": {},
        }
        run3_dir = os.path.join(fx.report, "run3")
        for item in sorted(os.listdir(run3_dir)):
            item_path = os.path.join(run3_dir, item)
            if os.path.isdir(item_path):
                attempt_manifest["run3_drivers"][item] = [
                    d for d in sorted(os.listdir(item_path)) if d.startswith("a")
                ]

        with open(
            os.path.join(job_dir, "attempts.json"), "w", encoding="utf-8"
        ) as f:
            json.dump(attempt_manifest, f, indent=2, sort_keys=True)
            f.write("\n")

    t1_chain = time.monotonic_ns()
    elapsed_chain_sec = (t1_chain - t0_chain) / 1e9
    print(f"Fixture teardown completed. Chain elapsed: {elapsed_chain_sec:.2f}s")

    # Save construction records and diff patch
    if construction_records:
        rec = construction_records[0]
        with open(
            os.path.join(job_dir, "raw_stub_diff.patch"), "w", encoding="utf-8"
        ) as f:
            f.write(rec["diff"])
        with open(
            os.path.join(job_dir, "stub_construction.json"),
            "w",
            encoding="utf-8",
        ) as f:
            json.dump(rec, f, indent=2, sort_keys=True)
            f.write("\n")

    # Validate final assertions per spec
    assertions = {
        "mode": mode,
        "final0_rc": final0_rc,
        "final0_status": final0_record.get("status"),
        "final0_reasons": final0_record.get("reasons", []),
        "run2_rerun_rc": run2_rerun_rc,
        "run2_rerun_status": run2_a2_record.get("status"),
        "run2_rerun_attempt": "a2",
        "final1_rc": final1_rc,
        "final1_status": final1_record.get("status"),
        "final1_reasons": final1_record.get("reasons", []),
        "abs_flip": abs_flip,
        "flip_existed_at_final1": os.path.exists(abs_flip),
        "p_nonzero_rows_count": len(p_nonzero_rows),
    }

    if mode == "seed":
        assert final1_rc == 1, f"Seed final1 expected rc 1, got {final1_rc}"
        assert (
            final1_record.get("status") == "FAIL"
        ), f"Seed final1 expected FAIL, got {final1_record.get('status')}"
        assert any(
            "required.json mismatch" in r
            for r in final1_record.get("reasons", [])
        ), "Seed final1 missing required.json mismatch"
        assert any(
            "run3/fixture_001 has no attempt" in r
            for r in final1_record.get("reasons", [])
        ), "Seed final1 missing fixture_001 has no attempt"
        assert any(
            "run3/fixture_001 latest attempt is not newer than latest run1/run2" in r
            for r in final1_record.get("reasons", [])
        ), "Seed final1 missing fixture_001 freshness reason"
    else:
        assert final1_rc == 1, f"Control final1 expected rc 1, got {final1_rc}"
        assert (
            final1_record.get("status") == "FAIL"
        ), f"Control final1 expected FAIL, got {final1_record.get('status')}"
        assert not any(
            "required.json mismatch" in r
            for r in final1_record.get("reasons", [])
        ), "Control final1 should not have required.json mismatch"

    assertions["verdict"] = "PASS"

    with open(
        os.path.join(job_dir, "assertions.json"), "w", encoding="utf-8"
    ) as f:
        json.dump(assertions, f, indent=2, sort_keys=True)
        f.write("\n")

    # Compute sha256 of all artifacts in job_dir
    artifacts = {}
    for root, _dirs, files in os.walk(job_dir):
        for fname in sorted(files):
            full_p = os.path.join(root, fname)
            rel_p = os.path.relpath(full_p, job_dir)
            if rel_p == "artifacts_sha256.json":
                continue
            artifacts[rel_p] = compute_file_hash(full_p)

    with open(
        os.path.join(job_dir, "artifacts_sha256.json"), "w", encoding="utf-8"
    ) as f:
        json.dump(artifacts, f, indent=2, sort_keys=True)
        f.write("\n")

    print(
        f"E2b {mode} completed successfully: verdict PASS, final1_rc={final1_rc}"
    )
    sys.exit(final1_rc)


if __name__ == "__main__":
    main()
