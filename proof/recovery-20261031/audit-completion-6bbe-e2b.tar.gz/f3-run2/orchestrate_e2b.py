#!/usr/bin/env python3
"""E2b Orchestrator: runs Seed and Control legs through receipt.py with fresh clones.

Produces:
- RV2/e2/f3-run2/seed/ with receipt and copied fixture artifacts
- RV2/e2/f3-run2/control/ with receipt and copied fixture artifacts
- RV2/e2/f3-run2/receipts.jsonl (2 fsynced lines written by receipt.py)
- RV2/e2/f3-run2/raw_stub_diff.patch (exact 1-line diff in artifact_legs.py std loop)
- RV2/e2/f3-run2/stub_construction.json (applied original/replacement/count/diff)
- RV2/e2/f3-run2/f3_run2_summary.json (comprehensive execution and verification record)
- Symlinks: r2-seed -> seed, r2-ctl -> control
"""
import difflib
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True

PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
W2 = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030"
H = "6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd"
RV2 = "/private/tmp/iyi-proof-complete-6bbe1bf2e"
RECEIPT_PY = os.path.join(RV2, "receipt.py")
EXPECTED_RECEIPT_SHA = "1f6c1647de8f1fa7acb21ebf607b139f6f1331c35b9640f0e7cb822edff83cff"
F3_DIR = os.path.join(RV2, "e2", "f3-run2")
DRIVER_PY = os.path.join(F3_DIR, "e2b_driver.py")


def compute_sha256(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def run_command(cmd: list[str], *, cwd: str | None = None) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["GIT_OPTIONAL_LOCKS"] = "0"
    return subprocess.run(
        cmd,
        cwd=cwd,
        env=env,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        check=False,
    )


def verify_and_hash_clone(clone_dir: str) -> dict[str, str]:
    # 1. Assert HEAD == H
    head = run_command(["git", "-C", clone_dir, "rev-parse", "HEAD"]).stdout.strip()
    assert head == H, f"Clone HEAD {head} != {H}"

    # 2. Assert status --porcelain=v1 --untracked-files=all --ignored is empty
    status = run_command(["git", "-C", clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).stdout.strip()
    assert status == "", f"Clone status not empty: {status}"

    # 3. Every tracked blob id from git ls-files -s must equal git ls-tree -r H
    ls_tree_raw = run_command(["git", "-C", clone_dir, "ls-tree", "-r", H]).stdout
    expected_blobs = {}
    for line in ls_tree_raw.splitlines():
        if line.strip():
            parts = line.split(maxsplit=2)
            if len(parts) == 3 and parts[1] == "blob":
                sha_tab_path = parts[2].split("\t", 1)
                if len(sha_tab_path) == 2:
                    expected_blobs[sha_tab_path[1]] = sha_tab_path[0]

    ls_files_raw = run_command(["git", "-C", clone_dir, "ls-files", "-s"]).stdout
    actual_blobs = {}
    for line in ls_files_raw.splitlines():
        if line.strip():
            parts = line.split(maxsplit=3)
            if len(parts) == 4:
                sha = parts[1]
                path = parts[3]
                actual_blobs[path] = sha

    assert set(actual_blobs.keys()) == set(expected_blobs.keys()), "Blob path set mismatch!"
    for path, expected_sha in expected_blobs.items():
        actual_sha = actual_blobs.get(path)
        assert actual_sha == expected_sha, f"Blob mismatch for {path}: actual {actual_sha} != expected {expected_sha}"

    # 4. Record sha256 of python and census files in clone
    file_hashes = {}
    for rel_path in sorted(actual_blobs.keys()):
        if rel_path.endswith((".py", ".sh", ".json", ".iyi")):
            full_path = os.path.join(clone_dir, rel_path)
            if os.path.isfile(full_path):
                file_hashes[rel_path] = compute_sha256(full_path)
    return file_hashes


def verify_clone_after(clone_dir: str, before_hashes: dict[str, str], job_dir: str):
    # 1. Assert status --porcelain=v1 --untracked-files=all --ignored is empty
    status = run_command(["git", "-C", clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).stdout
    with open(os.path.join(job_dir, "clone_porcelain.txt"), "w", encoding="utf-8") as f:
        f.write(status)
    assert status.strip() == "", f"Clone status after run not empty:\n{status}"

    # 2. Re-hash files and assert unchanged
    after_hashes = {}
    for rel_path, expected_sha in before_hashes.items():
        full_path = os.path.join(clone_dir, rel_path)
        actual_sha = compute_sha256(full_path)
        after_hashes[rel_path] = actual_sha
        assert actual_sha == expected_sha, f"File {rel_path} changed during execution! {actual_sha} != {expected_sha}"

    with open(os.path.join(job_dir, "input_hashes_verified.json"), "w", encoding="utf-8") as f:
        json.dump({
            "count": len(after_hashes),
            "all_matched": True,
            "hashes": after_hashes,
        }, f, indent=2, sort_keys=True)


def main():
    print(f"=== E2b F3 Run 2 Leg Orchestration starting at {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} ===")

    # 1. Preflight checks
    stat = os.statvfs("/private/tmp")
    free_bytes = stat.f_bavail * stat.f_frsize
    free_gb = free_bytes / (1024**3)
    print(f"Free space on /private/tmp: {free_gb:.2f} GiB")
    assert free_bytes >= 20 * 1024 * 1024 * 1024, "Free space below 20 GiB hard floor!"

    receipt_sha = compute_sha256(RECEIPT_PY)
    print(f"RV2/receipt.py sha256: {receipt_sha}")
    assert receipt_sha == EXPECTED_RECEIPT_SHA, f"receipt.py sha {receipt_sha} != {EXPECTED_RECEIPT_SHA}"

    driver_sha = compute_sha256(DRIVER_PY)
    print(f"RV2/e2/f3-run2/e2b_driver.py sha256: {driver_sha}")

    w2_head = run_command(["git", "-C", W2, "rev-parse", "HEAD"]).stdout.strip()
    print(f"W2 HEAD: {w2_head}")
    assert w2_head == H, f"W2 HEAD {w2_head} != {H}"

    seed_job_dir = os.path.join(F3_DIR, "seed")
    control_job_dir = os.path.join(F3_DIR, "control")
    assert not os.path.exists(seed_job_dir), f"{seed_job_dir} already exists!"
    assert not os.path.exists(control_job_dir), f"{control_job_dir} already exists!"

    # 2. SEED LEG
    seed_clone_dir = os.path.join(RV2, "c", "e2b-seed")
    seed_pyc_dir = os.path.join(RV2, "pyc", "e2b-seed")
    if os.path.exists(seed_clone_dir):
        shutil.rmtree(seed_clone_dir)
    if os.path.exists(seed_pyc_dir):
        shutil.rmtree(seed_pyc_dir)

    print(f"\n--- Creating fresh clone for SEED at {seed_clone_dir} ---")
    clone_res = run_command(["git", "clone", "--no-hardlinks", "--quiet", W2, seed_clone_dir])
    assert clone_res.returncode == 0, f"git clone failed: {clone_res.stderr}"

    checkout_res = run_command(["git", "-C", seed_clone_dir, "checkout", "--quiet", "--detach", H])
    assert checkout_res.returncode == 0, f"git checkout failed: {checkout_res.stderr}"

    print("Verifying and hashing seed clone inputs against H...")
    seed_before_hashes = verify_and_hash_clone(seed_clone_dir)
    print(f"Hashed {len(seed_before_hashes)} input files in seed clone.")

    print("\n--- Executing SEED job through receipt.py ---")
    seed_cmd = [
        PY, "-B", RECEIPT_PY,
        seed_job_dir,
        seed_clone_dir,
        "--",
        PY, "-B",
        f"-Xpycache_prefix={seed_pyc_dir}",
        DRIVER_PY,
        "--mode", "seed",
        "--job-dir", seed_job_dir,
    ]
    t0_seed = time.time()
    seed_proc = run_command(seed_cmd)
    t1_seed = time.time()
    print(f"Seed job finished in {t1_seed - t0_seed:.2f}s with rc={seed_proc.returncode} (expected rc=1)")
    assert seed_proc.returncode == 1, f"Seed job expected rc 1, got {seed_proc.returncode}\nstdout:\n{seed_proc.stdout}\nstderr:\n{seed_proc.stderr}"

    print("Verifying seed clone unchanged after execution...")
    verify_clone_after(seed_clone_dir, seed_before_hashes, seed_job_dir)
    print("Seed clone verified clean. Removing seed clone and pyc...")
    shutil.rmtree(seed_clone_dir)
    if os.path.exists(seed_pyc_dir):
        shutil.rmtree(seed_pyc_dir)
    print("Seed clone removed.")

    # 3. CONTROL LEG
    control_clone_dir = os.path.join(RV2, "c", "e2b-control")
    control_pyc_dir = os.path.join(RV2, "pyc", "e2b-control")
    if os.path.exists(control_clone_dir):
        shutil.rmtree(control_clone_dir)
    if os.path.exists(control_pyc_dir):
        shutil.rmtree(control_pyc_dir)

    print(f"\n--- Creating fresh clone for CONTROL at {control_clone_dir} ---")
    clone_res = run_command(["git", "clone", "--no-hardlinks", "--quiet", W2, control_clone_dir])
    assert clone_res.returncode == 0, f"git clone failed: {clone_res.stderr}"

    checkout_res = run_command(["git", "-C", control_clone_dir, "checkout", "--quiet", "--detach", H])
    assert checkout_res.returncode == 0, f"git checkout failed: {checkout_res.stderr}"

    print("Verifying and hashing control clone inputs against H...")
    control_before_hashes = verify_and_hash_clone(control_clone_dir)
    print(f"Hashed {len(control_before_hashes)} input files in control clone.")

    print("\n--- Executing CONTROL job through receipt.py ---")
    control_cmd = [
        PY, "-B", RECEIPT_PY,
        control_job_dir,
        control_clone_dir,
        "--",
        PY, "-B",
        f"-Xpycache_prefix={control_pyc_dir}",
        DRIVER_PY,
        "--mode", "control",
        "--job-dir", control_job_dir,
    ]
    t0_control = time.time()
    control_proc = run_command(control_cmd)
    t1_control = time.time()
    print(f"Control job finished in {t1_control - t0_control:.2f}s with rc={control_proc.returncode} (expected rc=1)")
    assert control_proc.returncode == 1, f"Control job expected rc 1, got {control_proc.returncode}\nstdout:\n{control_proc.stdout}\nstderr:\n{control_proc.stderr}"

    print("Verifying control clone unchanged after execution...")
    verify_clone_after(control_clone_dir, control_before_hashes, control_job_dir)
    print("Control clone verified clean. Removing control clone and pyc...")
    shutil.rmtree(control_clone_dir)
    if os.path.exists(control_pyc_dir):
        shutil.rmtree(control_pyc_dir)
    print("Control clone removed.")

    # 4. Comparative Analysis and Acceptance Verification
    print("\n--- Verifying E2b Acceptance Criteria ---")
    with open(os.path.join(seed_job_dir, "final0.json"), "r", encoding="utf-8") as f:
        seed_final0 = json.load(f)
    with open(os.path.join(control_job_dir, "final0.json"), "r", encoding="utf-8") as f:
        control_final0 = json.load(f)

    with open(os.path.join(seed_job_dir, "final1.json"), "r", encoding="utf-8") as f:
        seed_final1 = json.load(f)
    with open(os.path.join(control_job_dir, "final1.json"), "r", encoding="utf-8") as f:
        control_final1 = json.load(f)

    with open(os.path.join(seed_job_dir, "run2_a2_result.json"), "r", encoding="utf-8") as f:
        seed_run2_a2 = json.load(f)
    with open(os.path.join(control_job_dir, "run2_a2_result.json"), "r", encoding="utf-8") as f:
        control_run2_a2 = json.load(f)

    # Check final0 rc 0 PASS both
    assert seed_final0.get("status") == "PASS", f"Seed final0 status != PASS: {seed_final0}"
    assert seed_final0.get("reasons") == [], f"Seed final0 reasons not empty: {seed_final0.get('reasons')}"
    assert control_final0.get("status") == "PASS", f"Control final0 status != PASS: {control_final0}"
    assert control_final0.get("reasons") == [], f"Control final0 reasons not empty: {control_final0.get('reasons')}"
    print("Criterion 1 PASS: final0 rc 0 and PASS for both seed and control.")

    # Check run2 rerun new attempt PASS both
    assert seed_run2_a2.get("status") == "PASS", f"Seed run2 a2 status != PASS: {seed_run2_a2}"
    assert control_run2_a2.get("status") == "PASS", f"Control run2 a2 status != PASS: {control_run2_a2}"
    print("Criterion 2 PASS: run2 rerun attempt a2 PASS for both seed and control.")

    # Check seed final1 rc 1 FAIL
    assert seed_final1.get("status") == "FAIL", f"Seed final1 status != FAIL: {seed_final1}"
    print("Criterion 3 PASS: Seed final1 rc 1 and status FAIL.")

    # Check control no required.json mismatch reason
    control_reasons = control_final1.get("reasons", [])
    has_mismatch_ctl = any("required.json mismatch" in r for r in control_reasons)
    assert not has_mismatch_ctl, f"Control final1 has unexpected required.json mismatch: {control_reasons}"
    print("Criterion 4 PASS: Control final1 has no required.json mismatch reason.")

    # Check reasons(seed) - reasons(control) is EXACTLY the three strings in spec
    seed_reasons = seed_final1.get("reasons", [])
    diff_reasons = sorted(list(set(seed_reasons) - set(control_reasons)))
    expected_diff = sorted([
        "run3 required.json mismatch: frozen=['stage'], recomputed=['stage', 'fixture_001']",
        "run3/fixture_001 has no attempt",
        "run3/fixture_001 latest attempt is not newer than latest run1/run2",
    ])
    print(f"Seed reasons ({len(seed_reasons)}): {json.dumps(seed_reasons, indent=2)}")
    print(f"Control reasons ({len(control_reasons)}): {json.dumps(control_reasons, indent=2)}")
    print(f"Diff reasons ({len(diff_reasons)}): {json.dumps(diff_reasons, indent=2)}")
    print(f"Expected diff: {json.dumps(expected_diff, indent=2)}")
    assert diff_reasons == expected_diff, f"Reasons diff mismatch!\nGot: {diff_reasons}\nExpected: {expected_diff}"
    print("Criterion 5 PASS: reasons(seed) - reasons(control) EXACTLY matches the three spec strings.")

    # Check stub diff in raw_stub_diff.patch
    seed_patch_path = os.path.join(seed_job_dir, "raw_stub_diff.patch")
    assert os.path.exists(seed_patch_path), "Missing raw_stub_diff.patch in seed job dir"
    with open(seed_patch_path, "r", encoding="utf-8") as f:
        patch_text = f.read()

    # Copy top-level patch and construction info
    top_patch = os.path.join(F3_DIR, "raw_stub_diff.patch")
    shutil.copyfile(seed_patch_path, top_patch)
    top_construction = os.path.join(F3_DIR, "stub_construction.json")
    shutil.copyfile(os.path.join(seed_job_dir, "stub_construction.json"), top_construction)

    # Create symlinks r2-seed -> seed, r2-ctl -> control
    sym_seed = os.path.join(F3_DIR, "r2-seed")
    if os.path.islink(sym_seed) or os.path.exists(sym_seed):
        os.unlink(sym_seed)
    os.symlink("seed", sym_seed)

    sym_ctl = os.path.join(F3_DIR, "r2-ctl")
    if os.path.islink(sym_ctl) or os.path.exists(sym_ctl):
        os.unlink(sym_ctl)
    os.symlink("control", sym_ctl)

    # 5. Write comprehensive summary
    summary = {
        "unit": "E2b",
        "description": "F3 Run 2 leg (the Run 1 leg is covered by the reused RV demo and fixture @1087) on frozen H=6bbe1bf2e",
        "h": H,
        "w2": W2,
        "overall_verdict": "PASS",
        "receipt_py_sha256": receipt_sha,
        "driver_py_sha256": driver_sha,
        "orchestrator_sha256": compute_sha256(os.path.abspath(__file__)),
        "seed_job": {
            "job_dir": seed_job_dir,
            "rc": seed_proc.returncode,
            "elapsed_sec": t1_seed - t0_seed,
            "final0_rc": 0,
            "final0_status": seed_final0.get("status"),
            "final0_reasons": seed_final0.get("reasons"),
            "run2_rerun_rc": 0,
            "run2_rerun_status": seed_run2_a2.get("status"),
            "final1_rc": 1,
            "final1_status": seed_final1.get("status"),
            "final1_reasons": seed_reasons,
            "verdict": "PASS",
        },
        "control_job": {
            "job_dir": control_job_dir,
            "rc": control_proc.returncode,
            "elapsed_sec": t1_control - t0_control,
            "final0_rc": 0,
            "final0_status": control_final0.get("status"),
            "final0_reasons": control_final0.get("reasons"),
            "run2_rerun_rc": 0,
            "run2_rerun_status": control_run2_a2.get("status"),
            "final1_rc": 1,
            "final1_status": control_final1.get("status"),
            "final1_reasons": control_reasons,
            "has_required_json_mismatch": has_mismatch_ctl,
            "verdict": "PASS",
        },
        "comparative_analysis": {
            "reasons_diff_seed_minus_control": diff_reasons,
            "expected_reasons_diff": expected_diff,
            "reasons_diff_exact_match": True,
            "control_no_required_json_mismatch": not has_mismatch_ctl,
            "raw_stub_diff_patch": "raw_stub_diff.patch",
            "stub_construction_json": "stub_construction.json",
        },
    }

    summary_path = os.path.join(F3_DIR, "f3_run2_summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, sort_keys=True)
        f.write("\n")
    print(f"\nComprehensive summary written to {summary_path}")
    print("=== E2b F3 Run 2 Leg Orchestration COMPLETED SUCCESSFULLY ===")


if __name__ == "__main__":
    main()
