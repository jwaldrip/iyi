#!/usr/bin/env python3
"""E2c Driver: m20 isolation jobs (h-seed, h-ctl, m-seed, m-ctl).

Per spec lines 311-318:
Four jobs, each a fresh StageFixture() followed by prepare_final_inputs().
The M jobs use a clone with the catalog's m20 change applied.
Keep each final.json and the m20 diff, and confirm rp:1371 occurs once at H.

| Job    | Clone      | Inputs                                  | Expected               |
|--------|------------|-----------------------------------------|------------------------|
| H-seed | H          | required.json=[], cmd_final(drivers=()) | rc 1, FAIL, reasons [] |
| H-ctl  | H          | cmd_final(drivers=fx.drivers)           | rc 0, PASS             |
| M-seed | m20 mutant | as H-seed                               | rc 0, PASS, reasons [] |
| M-ctl  | m20 mutant | as H-ctl                                | rc 0, PASS             |
"""
import argparse
import hashlib
import json
import os
import shutil
import sys

sys.dont_write_bytecode = True


def main():
    parser = argparse.ArgumentParser(description="E2c m20 isolation driver")
    parser.add_argument("--mode", choices=["h-seed", "h-ctl", "m-seed", "m-ctl"], required=True)
    parser.add_argument("--job-dir", required=True)
    args = parser.parse_args()

    mode = args.mode
    job_dir = os.path.abspath(args.job_dir)
    os.makedirs(job_dir, exist_ok=True)

    clone_root = os.getcwd()
    if clone_root not in sys.path:
        sys.path.insert(0, clone_root)

    import proof.run_proof as stages_mod
    import proof.smoke_test as smoke_test

    with smoke_test.StageFixture() as fx:
        fx.prepare_final_inputs()

        # Input setup per mode
        if mode in ("h-seed", "m-seed"):
            required_path = os.path.join(fx.report, "run3", "required.json")
            with open(required_path, "w", encoding="utf-8") as f:
                json.dump([], f)
            drivers = ()
        else:  # h-ctl, m-ctl
            drivers = fx.drivers

        # Capture and preserve report inputs before cmd_final
        stage_inputs_dir = os.path.join(job_dir, "stage_inputs")
        os.makedirs(stage_inputs_dir, exist_ok=True)
        for root, dirs, files in os.walk(fx.report):
            rel = os.path.relpath(root, fx.report)
            target_dir = os.path.join(stage_inputs_dir, rel) if rel != "." else stage_inputs_dir
            os.makedirs(target_dir, exist_ok=True)
            for file in files:
                shutil.copyfile(os.path.join(root, file), os.path.join(target_dir, file))

        # Specifically record what required.json contains
        required_path = os.path.join(fx.report, "run3", "required.json")
        with open(required_path, "r", encoding="utf-8") as f:
            required_contents = json.load(f)

        # Call cmd_final
        returncode = stages_mod.cmd_final(fx.args(), drivers=drivers)

        # Preserve final.json and all post-cmd_final report files
        final_path = os.path.join(fx.report, "final.json")
        assert os.path.exists(final_path), f"final.json was not created at {final_path}"
        with open(final_path, "r", encoding="utf-8") as f:
            final_data = json.load(f)

        shutil.copyfile(final_path, os.path.join(job_dir, "final.json"))

        stage_final_dir = os.path.join(job_dir, "stage_final")
        for root, dirs, files in os.walk(fx.report):
            rel = os.path.relpath(root, fx.report)
            target_dir = os.path.join(stage_final_dir, rel) if rel != "." else stage_final_dir
            os.makedirs(target_dir, exist_ok=True)
            for file in files:
                shutil.copyfile(os.path.join(root, file), os.path.join(target_dir, file))

        # Check and record assertions
        status = final_data.get("status")
        reasons = final_data.get("reasons", [])

        if mode == "h-seed":
            expected_rc = 1
            expected_status = "FAIL"
            expected_reasons = []
        elif mode == "h-ctl":
            expected_rc = 0
            expected_status = "PASS"
            expected_reasons = []
        elif mode == "m-seed":
            expected_rc = 0
            expected_status = "PASS"
            expected_reasons = []
        elif mode == "m-ctl":
            expected_rc = 0
            expected_status = "PASS"
            expected_reasons = []

        assertions = {
            "mode": mode,
            "expected_rc": expected_rc,
            "actual_rc": returncode,
            "rc_match": (returncode == expected_rc),
            "expected_status": expected_status,
            "actual_status": status,
            "status_match": (status == expected_status),
            "expected_reasons": expected_reasons,
            "actual_reasons": reasons,
            "reasons_match": (reasons == expected_reasons),
            "required_contents": required_contents,
            "drivers": list(drivers),
            "units": final_data.get("units", {}),
            "identity": final_data.get("identity", {}),
            "fixture_report": fx.report,
            "fixture_scratch": fx.scratch,
        }

        with open(os.path.join(job_dir, "assertions.json"), "w", encoding="utf-8") as f:
            json.dump(assertions, f, indent=2, sort_keys=True)

        # Critical spec check:
        # "H-seed reasons not [] means stop with actual evidence and return to planner, not repaired/relabelled."
        if mode == "h-seed" and reasons != []:
            print(f"CRITICAL: H-seed reasons not []: {reasons}", file=sys.stderr)
            sys.exit(returncode)

        assert returncode == expected_rc, f"{mode}: rc {returncode} != {expected_rc}"
        assert status == expected_status, f"{mode}: status {status} != {expected_status}"
        assert reasons == expected_reasons, f"{mode}: reasons {reasons} != {expected_reasons}"

    sys.exit(returncode)


if __name__ == "__main__":
    main()
