#!/usr/bin/env python3
"""E2c Orchestrator: runs m20 isolation jobs through receipt.py with fresh clones.

Per spec lines 311-318 and prompt:
Four separate fresh-clone jobs, each StageFixture() followed by prepare_final_inputs().
H-seed sets required.json=[] and calls cmd_final(drivers=()); expected rc1, FAIL, reasons[].
H-ctl cmd_final(drivers=fx.drivers); rc0 PASS.
M-seed and M-ctl same inputs/calls but fresh H clone with catalog m20 mutation applied once at run_proof.py:1371:
M-seed rc0 PASS reasons[]; M-ctl rc0 PASS.
Verify catalog bytes and actual H anchor once before patch, retain exact -U0 diff + counts/blob/hash.
Preserve all raw final JSON, inputs and receipts before teardown.
Do not edit fixture to force isolation.
Native clone identity/clean source preflight; final porcelain only intended m20 file for mutants; original clean otherwise.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True

PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
W2 = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030"
H = "6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd"
RV2 = "/private/tmp/iyi-proof-complete-6bbe1bf2e"
RECEIPT_PY = os.path.join(RV2, "receipt.py")
CATALOG_JSON = os.path.join(RV2, "catalog.json")
EXPECTED_RECEIPT_SHA = "1f6c1647de8f1fa7acb21ebf607b139f6f1331c35b9640f0e7cb822edff83cff"
EXPECTED_CATALOG_SHA = "0be27cf2864598b110b0aff797063a9ce81c329cc68dca51bf3cf8cb4bee4403"
M20_DIR = os.path.join(RV2, "e2", "m20-isolation")
DRIVER_PY = os.path.join(M20_DIR, "e2c_driver.py")


def compute_sha256(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def run_command(cmd: list[str], *, cwd: str | None = None) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["GIT_OPTIONAL_LOCKS"] = "0"
    return subprocess.run(
        cmd,
        cwd=cwd,
        env=env,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        check=False,
    )


def verify_and_hash_clone(clone_dir: str) -> dict[str, str]:
    # 1. Assert HEAD == H
    head = run_command(["git", "-C", clone_dir, "rev-parse", "HEAD"]).stdout.strip()
    assert head == H, f"Clone HEAD {head} != {H}"

    # 2. Assert status --porcelain=v1 --untracked-files=all --ignored is empty
    status = run_command(["git", "-C", clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).stdout.strip()
    assert status == "", f"Clone status not empty: {status}"

    # 3. Every tracked blob id from git ls-files -s must equal git ls-tree -r H
    ls_tree_raw = run_command(["git", "-C", clone_dir, "ls-tree", "-r", H]).stdout
    expected_blobs = {}
    for line in ls_tree_raw.splitlines():
        if line.strip():
            parts = line.split(maxsplit=2)
            if len(parts) == 3 and parts[1] == "blob":
                sha_tab_path = parts[2].split("\t", 1)
                if len(sha_tab_path) == 2:
                    expected_blobs[sha_tab_path[1]] = sha_tab_path[0]

    ls_files_raw = run_command(["git", "-C", clone_dir, "ls-files", "-s"]).stdout
    actual_blobs = {}
    for line in ls_files_raw.splitlines():
        if line.strip():
            parts = line.split(maxsplit=3)
            if len(parts) == 4:
                sha = parts[1]
                path = parts[3]
                actual_blobs[path] = sha

    assert set(actual_blobs.keys()) == set(expected_blobs.keys()), "Blob path set mismatch!"
    for path, expected_sha in expected_blobs.items():
        actual_sha = actual_blobs.get(path)
        assert actual_sha == expected_sha, f"Blob mismatch for {path}: actual {actual_sha} != expected {expected_sha}"

    # 4. Record sha256 of python and census files in clone
    file_hashes = {}
    for rel_path in sorted(actual_blobs.keys()):
        if rel_path.endswith((".py", ".sh", ".json", ".iyi")):
            full_path = os.path.join(clone_dir, rel_path)
            if os.path.isfile(full_path):
                file_hashes[rel_path] = compute_sha256(full_path)
    return file_hashes


def main():
    print(f"=== E2c m20 Isolation Orchestration starting at {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} ===")

    # 1. Preflight checks
    stat = os.statvfs("/private/tmp")
    free_bytes = stat.f_bavail * stat.f_frsize
    free_gb = free_bytes / (1024**3)
    print(f"Free space on /private/tmp: {free_gb:.2f} GiB")
    assert free_bytes >= 20 * 1024 * 1024 * 1024, "Free space below 20 GiB hard floor!"

    receipt_sha = compute_sha256(RECEIPT_PY)
    print(f"RV2/receipt.py sha256: {receipt_sha}")
    assert receipt_sha == EXPECTED_RECEIPT_SHA, f"receipt.py sha {receipt_sha} != {EXPECTED_RECEIPT_SHA}"

    catalog_sha = compute_sha256(CATALOG_JSON)
    print(f"RV2/catalog.json sha256: {catalog_sha}")
    assert catalog_sha == EXPECTED_CATALOG_SHA, f"catalog.json sha {catalog_sha} != {EXPECTED_CATALOG_SHA}"

    driver_sha = compute_sha256(DRIVER_PY)
    print(f"RV2/e2/m20-isolation/e2c_driver.py sha256: {driver_sha}")

    w2_head = run_command(["git", "-C", W2, "rev-parse", "HEAD"]).stdout.strip()
    print(f"W2 HEAD: {w2_head}")
    assert w2_head == H, f"W2 HEAD {w2_head} != {H}"

    w2_status = run_command(["git", "-C", W2, "status", "--porcelain=v1"]).stdout.strip()
    assert w2_status == "", f"W2 status not empty: {w2_status}"

    # 2. Verify catalog bytes and actual H anchor once before patch
    print("\n--- Verifying catalog bytes and actual H anchor for m20 ---")
    with open(CATALOG_JSON, "r", encoding="utf-8") as f:
        catalog = json.load(f)

    m20_entry = next((m for m in catalog if m["id"] == "m20"), None)
    assert m20_entry is not None, "m20 not found in catalog.json!"

    m20_old = m20_entry["old"]
    m20_new = m20_entry["new"]
    m20_rel = m20_entry["rel"]
    assert m20_rel == "proof/run_proof.py"
    assert m20_entry["location"] == "rp:1371"

    # Read proof/run_proof.py from H
    h_file_content = run_command(["git", "-C", W2, "show", f"{H}:{m20_rel}"]).stdout
    h_lines = h_file_content.splitlines(keepends=True)
    h_blob_sha = run_command(["git", "-C", W2, "rev-parse", f"{H}:{m20_rel}"]).stdout.strip()
    h_file_sha256 = hashlib.sha256(h_file_content.encode("utf-8")).hexdigest()

    # Anchor checks
    anchor_matches = [i + 1 for i, line in enumerate(h_lines) if line == m20_old]
    assert len(anchor_matches) == 1, f"Expected exactly 1 occurrence of m20 anchor in H, found {len(anchor_matches)}"
    anchor_line = anchor_matches[0]
    assert anchor_line == 1371, f"Expected m20 anchor at line 1371, found at {anchor_line}"

    print(f"m20 anchor verified at H: line {anchor_line}, blob {h_blob_sha}, file sha256 {h_file_sha256}")

    # Generate canonical -U0 diff patch
    mutated_h_lines = list(h_lines)
    mutated_h_lines[anchor_line - 1] = m20_new
    mutated_h_content = "".join(mutated_h_lines)

    p_hash = subprocess.run(
        ["git", "hash-object", "--stdin"],
        input=mutated_h_content,
        capture_output=True,
        text=True,
        check=True,
    )
    mutated_blob_sha = p_hash.stdout.strip()

    canonical_diff = (
        f"diff --git a/{m20_rel} b/{m20_rel}\n"
        f"index {h_blob_sha[:9]}..{mutated_blob_sha[:9]} 100755\n"
        f"--- a/{m20_rel}\n"
        f"+++ b/{m20_rel}\n"
        f"@@ -1371 +1371 @@ def cmd_final(args, *, drivers: Sequence[str] = DRIVERS_29) -> int:\n"
        f"-{m20_old}"
        f"+{m20_new}"
    )
    diff_patch_path = os.path.join(M20_DIR, "m20_diff.patch")
    with open(diff_patch_path, "w", encoding="utf-8") as f:
        f.write(canonical_diff)
    diff_sha256 = hashlib.sha256(canonical_diff.encode("utf-8")).hexdigest()

    anchor_data = {
        "catalog_sha256": catalog_sha,
        "catalog_bytes": os.path.getsize(CATALOG_JSON),
        "mutant_id": "m20",
        "mutant_name": m20_entry.get("name"),
        "rel": m20_rel,
        "location": m20_entry.get("location"),
        "line_at_h": anchor_line,
        "anchor_count_in_h": len(anchor_matches),
        "h_blob_sha": h_blob_sha,
        "h_file_sha256": h_file_sha256,
        "old": m20_old,
        "new": m20_new,
        "diff_patch_path": "m20_diff.patch",
        "diff_sha256": diff_sha256,
        "diff_patch": canonical_diff,
    }
    anchor_json_path = os.path.join(M20_DIR, "m20_anchor.json")
    with open(anchor_json_path, "w", encoding="utf-8") as f:
        json.dump(anchor_data, f, indent=2, sort_keys=True)
    print(f"Saved {diff_patch_path} and {anchor_json_path}")

    # 3. Define the four separate jobs
    jobs = [
        {
            "id": "h-seed",
            "clone_name": "e2c-h-seed",
            "mutant": False,
            "expected_rc": 1,
            "expected_status": "FAIL",
            "expected_reasons": [],
            "description": "H-seed sets required.json=[] and calls cmd_final(drivers=()); expected rc1, FAIL, reasons[]",
        },
        {
            "id": "h-ctl",
            "clone_name": "e2c-h-ctl",
            "mutant": False,
            "expected_rc": 0,
            "expected_status": "PASS",
            "expected_reasons": [],
            "description": "H-ctl calls cmd_final(drivers=fx.drivers); expected rc0 PASS",
        },
        {
            "id": "m-seed",
            "clone_name": "e2c-m-seed",
            "mutant": True,
            "expected_rc": 0,
            "expected_status": "PASS",
            "expected_reasons": [],
            "description": "M-seed sets required.json=[] and calls cmd_final(drivers=()) with m20 mutant; expected rc0 PASS reasons[]",
        },
        {
            "id": "m-ctl",
            "clone_name": "e2c-m-ctl",
            "mutant": True,
            "expected_rc": 0,
            "expected_status": "PASS",
            "expected_reasons": [],
            "description": "M-ctl calls cmd_final(drivers=fx.drivers) with m20 mutant; expected rc0 PASS",
        },
    ]

    job_results = {}

    for job in jobs:
        job_id = job["id"]
        clone_name = job["clone_name"]
        is_mutant = job["mutant"]
        expected_rc = job["expected_rc"]
        expected_status = job["expected_status"]
        expected_reasons = job["expected_reasons"]

        job_dir = os.path.join(M20_DIR, job_id)
        clone_dir = os.path.join(RV2, "c", clone_name)
        pyc_dir = os.path.join(RV2, "pyc", clone_name)

        print(f"\n========================================================")
        print(f"Starting Job: {job_id.upper()} ({job['description']})")
        print(f"Job Dir: {job_dir}")
        print(f"Clone Dir: {clone_dir}")
        print(f"Pycache Dir: {pyc_dir}")
        print(f"========================================================")

        assert not os.path.exists(job_dir), f"job_dir {job_dir} already exists!"
        if os.path.exists(clone_dir):
            shutil.rmtree(clone_dir)
        if os.path.exists(pyc_dir):
            shutil.rmtree(pyc_dir)

        # Clone fresh from W2 at H
        print(f"Cloning fresh from W2 into {clone_dir}...")
        clone_res = run_command(["git", "clone", "--no-hardlinks", "--quiet", W2, clone_dir])
        assert clone_res.returncode == 0, f"git clone failed: {clone_res.stderr}"

        checkout_res = run_command(["git", "-C", clone_dir, "checkout", "--quiet", "--detach", H])
        assert checkout_res.returncode == 0, f"git checkout failed: {checkout_res.stderr}"

        print("Verifying clone integrity against H...")
        before_hashes = verify_and_hash_clone(clone_dir)
        print(f"Verified {len(before_hashes)} input files in clone.")

        # Apply mutation if mutant job
        if is_mutant:
            print("Applying m20 mutation to proof/run_proof.py in clone...")
            clone_file_path = os.path.join(clone_dir, m20_rel)
            with open(clone_file_path, "r", encoding="utf-8") as f:
                clone_lines = f.readlines()

            assert clone_lines[anchor_line - 1] == m20_old, f"Anchor mismatch in clone at line {anchor_line}"
            clone_lines[anchor_line - 1] = m20_new
            with open(clone_file_path, "w", encoding="utf-8") as f:
                f.writelines(clone_lines)

            # Check diff --name-only
            diff_names = run_command(["git", "-C", clone_dir, "diff", "--name-only"]).stdout.strip().splitlines()
            assert diff_names == [m20_rel], f"Unexpected modified files: {diff_names}"

            # Check diff -U0
            actual_diff = run_command(["git", "-C", clone_dir, "diff", "-U0", m20_rel]).stdout
            assert actual_diff == canonical_diff, f"Diff mismatch for {job_id}!\nActual:\n{actual_diff}\nExpected:\n{canonical_diff}"

            # Check status --porcelain
            mut_status = run_command(["git", "-C", clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).stdout
            assert mut_status.strip() == f"M {m20_rel}", f"Unexpected status after mutation: {mut_status}"
            print("m20 mutation successfully applied and verified.")

        # Execute through receipt.py
        print(f"Launching {job_id} through receipt.py...")
        cmd = [
            PY, "-B", RECEIPT_PY,
            job_dir,
            clone_dir,
            "GIT_OPTIONAL_LOCKS=0",
            "--",
            PY, "-B",
            f"-Xpycache_prefix={pyc_dir}",
            DRIVER_PY,
            "--mode", job_id,
            "--job-dir", job_dir,
        ]
        t0 = time.time()
        proc = run_command(cmd)
        t1 = time.time()
        elapsed = t1 - t0
        print(f"Job {job_id} finished in {elapsed:.2f}s with rc={proc.returncode} (expected rc={expected_rc})")

        assert proc.returncode == expected_rc, f"{job_id} expected rc {expected_rc}, got {proc.returncode}\nstdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"

        # Verify end.json
        end_json_path = os.path.join(job_dir, "end.json")
        assert os.path.exists(end_json_path), f"end.json missing in {job_dir}"
        with open(end_json_path, "r", encoding="utf-8") as f:
            end_data = json.load(f)
        assert end_data["rc"] == expected_rc, f"end.json rc {end_data['rc']} != {expected_rc}"

        # Verify assertions.json
        assertions_path = os.path.join(job_dir, "assertions.json")
        assert os.path.exists(assertions_path), f"assertions.json missing in {job_dir}"
        with open(assertions_path, "r", encoding="utf-8") as f:
            assertions_data = json.load(f)
        assert assertions_data["rc_match"] is True
        assert assertions_data["status_match"] is True
        assert assertions_data["reasons_match"] is True

        # Verify clone porcelain after execution
        post_status = run_command(["git", "-C", clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).stdout
        with open(os.path.join(job_dir, "clone_porcelain.txt"), "w", encoding="utf-8") as f:
            f.write(post_status)

        if not is_mutant:
            assert post_status.strip() == "", f"Clone status after unmutated run not empty:\n{post_status}"
            # Re-hash all files
            after_hashes = {}
            for rel_path, exp_sha in before_hashes.items():
                act_sha = compute_sha256(os.path.join(clone_dir, rel_path))
                assert act_sha == exp_sha, f"File {rel_path} changed during execution!"
                after_hashes[rel_path] = act_sha
            with open(os.path.join(job_dir, "input_hashes_verified.json"), "w", encoding="utf-8") as f:
                json.dump({"count": len(after_hashes), "all_matched": True, "hashes": after_hashes}, f, indent=2, sort_keys=True)
        else:
            assert post_status.strip() == f"M {m20_rel}", f"Clone status after mutant run unexpected:\n{post_status}"
            after_hashes = {}
            for rel_path, exp_sha in before_hashes.items():
                if rel_path == m20_rel:
                    continue
                act_sha = compute_sha256(os.path.join(clone_dir, rel_path))
                assert act_sha == exp_sha, f"Unintended file change in {rel_path}!"
                after_hashes[rel_path] = act_sha
            mutated_file_sha = compute_sha256(os.path.join(clone_dir, m20_rel))
            after_hashes[m20_rel] = mutated_file_sha
            with open(os.path.join(job_dir, "input_hashes_verified.json"), "w", encoding="utf-8") as f:
                json.dump({"count": len(after_hashes), "all_matched": True, "mutated_file": m20_rel, "hashes": after_hashes}, f, indent=2, sort_keys=True)
            # Copy patch and anchor into job_dir
            shutil.copyfile(diff_patch_path, os.path.join(job_dir, "diff.patch"))
            shutil.copyfile(anchor_json_path, os.path.join(job_dir, "anchor.json"))

        # Artifacts sha256 for job_dir
        job_artifacts = {}
        for root, dirs, files in os.walk(job_dir):
            for file in files:
                p = os.path.join(root, file)
                rel = os.path.relpath(p, job_dir)
                job_artifacts[rel] = compute_sha256(p)
        with open(os.path.join(job_dir, "artifacts_sha256.json"), "w", encoding="utf-8") as f:
            json.dump(job_artifacts, f, indent=2, sort_keys=True)

        # Clean up clone and pycache
        print(f"Cleaning up clone {clone_dir} and pycache {pyc_dir}...")
        shutil.rmtree(clone_dir)
        if os.path.exists(pyc_dir):
            shutil.rmtree(pyc_dir)
        print(f"Clone and pycache for {job_id} removed cleanly.")

        # Record summary for this job
        final_json_path = os.path.join(job_dir, "final.json")
        with open(final_json_path, "r", encoding="utf-8") as f:
            final_json_data = json.load(f)

        job_results[job_id] = {
            "job_dir": job_dir,
            "rc": proc.returncode,
            "expected_rc": expected_rc,
            "status": final_json_data.get("status"),
            "expected_status": expected_status,
            "reasons": final_json_data.get("reasons", []),
            "expected_reasons": expected_reasons,
            "required_contents": assertions_data["required_contents"],
            "drivers": assertions_data["drivers"],
            "elapsed_sec": elapsed,
            "verdict": "PASS",
        }

    # 4. Final summary and comparative analysis
    print("\n--- Verifying E2c Acceptance and Building Summary ---")
    receipts_jsonl_path = os.path.join(M20_DIR, "receipts.jsonl")
    assert os.path.exists(receipts_jsonl_path), f"receipts.jsonl missing at {receipts_jsonl_path}"
    with open(receipts_jsonl_path, "r", encoding="utf-8") as f:
        receipt_lines = [json.loads(line) for line in f if line.strip()]
    assert len(receipt_lines) == 4, f"Expected 4 receipt lines, found {len(receipt_lines)}"

    summary_data = {
        "unit": "E2c",
        "description": "m20 isolation on frozen H=6bbe1bf2e: four separate fresh-clone jobs",
        "rerun_disclosure": "Disclosed rerun-after-loss following machine reboot at 12:08 local which wiped /private/tmp. Original attempt-1 and attempt-2 files from pre-reboot were wiped; attempt-1 evidence survives only in transcript history://ProveM20IsolationH6bbe. This execution rebuilt final orchestrate_e2c.py and executed all four fresh-clone jobs cleanly once into RV2/e2/m20-isolation.",
        "h": H,
        "w2": W2,
        "receipt_py_sha256": receipt_sha,
        "catalog_json_sha256": catalog_sha,
        "driver_py_sha256": driver_sha,
        "orchestrator_sha256": compute_sha256(os.path.abspath(__file__)),
        "mutation": {
            "mutant_id": "m20",
            "rel": m20_rel,
            "location": "rp:1371",
            "line_at_h": 1371,
            "h_blob_sha": h_blob_sha,
            "h_file_sha256": h_file_sha256,
            "diff_sha256": diff_sha256,
            "diff_patch": canonical_diff,
        },
        "jobs": job_results,
        "comparative_analysis": {
            "h_seed_exact": (job_results["h-seed"]["rc"] == 1 and job_results["h-seed"]["status"] == "FAIL" and job_results["h-seed"]["reasons"] == []),
            "h_ctl_exact": (job_results["h-ctl"]["rc"] == 0 and job_results["h-ctl"]["status"] == "PASS"),
            "m_seed_exact": (job_results["m-seed"]["rc"] == 0 and job_results["m-seed"]["status"] == "PASS" and job_results["m-seed"]["reasons"] == []),
            "m_ctl_exact": (job_results["m-ctl"]["rc"] == 0 and job_results["m-ctl"]["status"] == "PASS"),
            "isolation_proved": True,
            "explanation": (
                "Under unmutated H (H-seed), setting required.json=[] with cmd_final(drivers=()) causes "
                "recomputed_required to match required ([] == []), so no required.json mismatch is added to reasons (reasons is empty). "
                "At rp:1371, 'elif reasons or not required or any(...)': 'not required' evaluates to True because required is empty, "
                "causing status to become 'FAIL' and cmd_final to exit with rc 1 while reasons remains empty []. "
                "Under mutated H (M-seed), m20 removes 'not required' from rp:1371. Because reasons is [] and any(...) is False, "
                "execution falls through to 'else: status = PASS' and cmd_final exits with rc 0 and reasons []. "
                "Both control jobs (H-ctl and M-ctl) pass cleanly (rc 0, status PASS). "
                "This isolates mutant m20 and proves that m20's behavior at rp:1371 is directly observed and discriminatory."
            ),
        },
        "overall_verdict": "PASS",
    }

    summary_path = os.path.join(M20_DIR, "m20_isolation_summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary_data, f, indent=2, sort_keys=True)
    print(f"Summary written to {summary_path}")

    # Check for leftover processes
    ps_check = run_command(["pgrep", "-f", "smoke_test|run_proof|e2c_driver"]).stdout.strip().splitlines()
    my_pid = str(os.getpid())
    leftover = [p for p in ps_check if p != my_pid]
    print(f"Leftover processes: {leftover}")
    assert len(leftover) == 0, f"Leftover processes detected: {leftover}"

    print(f"\n=== E2c m20 Isolation Orchestration COMPLETED SUCCESSFULLY at {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} ===")


if __name__ == "__main__":
    main()
