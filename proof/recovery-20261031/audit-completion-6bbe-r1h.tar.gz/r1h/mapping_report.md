# R1 Semantic Mapping and Review-1f Audit Report

## 1. Overview and Scope
- **Commit Under Audit (H):** `6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd`
- **Slice:** R1. Mapping (Planner v2 Spec §5 R1)
- **Review Ranges Audited:** 18 ranges: 102-104, 105-106, 108-113, 11, 115-122, 13-29, 31-33, 35-40, 42-57, 59, 62-79, 80, 81, 82-90, 9 (hashlib), 91, 94-96, 97-101
- **Review Keys Audited:** All 33 `review.*` keys defined in `smoke_test.py:17438-17610`
- **Total Detailed Finding Rows:** 80
- **Proven Rows:** 80 (100%)
- **Unmapped Rows:** 0 (0%)

## 2. Input Manifest and SHA256 Bindings

All inputs copied into `RV2/r1/inputs/` with verified sha256 checksums:

| Input Name | Size (Bytes) | SHA256 | Source Path / Ref |
|---|---|---|---|
| `corpus-proof-review-1f.txt` | 10144 | `078960504516a09113d0992016f423f9c6e342efab0f60fa6f8c41694f5dc0be` | `/Users/jwaldrip/.omp/agent/sessions/-dev-src-github.com-jwaldrip-iyi/2026-10-23T04-40-48-554Z_01a1670f-c2aa-7496-8dff-8051951bcb5a/local/corpus-proof-review-1f.txt` |
| `ev_o3.json` | 224 | `f84a2a2096e7edda3205e695c03e2140f69d341593b9e79ffd10d04ff75de980` | `/private/tmp/iyi-parent-evidence-6bbe1bf2e/o3.json` |
| `ev_o3.log` | 85416 | `7a245f6af82e69fc478670ddbc3d1ad4d0b15bb1dbe884aa567989f6346d37d8` | `/private/tmp/iyi-parent-evidence-6bbe1bf2e/o3.log` |
| `ev_smoke.log` | 185671 | `bf4c0a3a861c25b209219d7c96b54abc3ff42a8575d7ef55184cc5789f808641` | `/private/tmp/iyi-parent-evidence-6bbe1bf2e/smoke.log` |
| `rv_o3.json` | 143 | `155fdfd3c3538f5d5b82a5982443fde46bb2926133ca8febb10e8686b8298055` | `/private/tmp/iyi-proof-review-6bbe1bf2e/evidence/o3/o3.json` |
| `rv_o3.log` | 85416 | `7a245f6af82e69fc478670ddbc3d1ad4d0b15bb1dbe884aa567989f6346d37d8` | `/private/tmp/iyi-proof-review-6bbe1bf2e/evidence/o3/o3.log` |
| `rv_smoke.json` | 182 | `36b76c065e373a9520bdc7e0682e73d8e75539a8f93306b2428d31c17657cedd` | `/private/tmp/iyi-proof-review-6bbe1bf2e/evidence/smoke/smoke.json` |
| `rv_smoke.log` | 185602 | `aaf53d3ac2aadfaa7257c8e2bb66ae16e3b540c0e3e3d9abeaf170809f5a42bc` | `/private/tmp/iyi-proof-review-6bbe1bf2e/evidence/smoke/smoke.log` |
| `smoke_test.py` | 633283 | `a977d90f44225cf080092c8c90b5a0151139505b3696c7bb3c4e927cb597578f` | `6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd:proof/smoke_test.py` |

## 3. Row 9 Truthful Mechanism and Amendment Citation

- **Review Finding (Range 9, line 9):** `1. Run 3 crashes on its first driver. run_proof.py:359 calls hashlib.sha256, but hashlib is never imported (imports are at :12-20). Run 3 has never executed: no smoke test reaches cmd_run3.`
- **Prior False Claim in RV:** Previous report claimed `run_proof.py has explicit top-level hashlib import`, which was rejected by the specialist adjudicator because `run_proof.py` at H neither imports nor uses `hashlib`.
- **Truthful Mechanism:** `run_proof.py` at H neither imports nor uses `hashlib`. As documented in **Addendum 6 §U7.1 (line 426)**:
  > *'The nonce uses `secrets.token_hex(16)`; removing the hashlib use satisfies O7 import hashlib item.'*
- **Source Proof at H:**
  - `run_proof.py:44`: `import secrets`
  - `run_proof.py:952`: `nonce = secrets.token_hex(16)`
- **Verifying Fixture:** `s5.seed.run3-import` (smoke:1199) paired with `s5.control.stage-chain` (smoke:1138). It verifies that when driver build or execution fails in Run 3, the failure is caught and recorded as `NOT-EXECUTED` and `NOT-ROUNDTRIPPED` in `result.json` rather than crashing unhandled.

## 4. RV vs EV Comparison (Smoke and O3 Logs)

### Smoke Suite Comparison
- **Seed Counts:** RV: 432, EV: 432 (Equal: True)
- **Control Counts:** RV: 84, EV: 84 (Equal: True)
- **Raw Differences:** 12 seeds had raw string differences. All 12 are due to process-unique temporary paths (e.g. `/private/tmp/iyi-o4-<random>/`).
- **Semantic Differences:** 0 (0 differences after path normalization). Expect matched Got in 432/432 seeds for both RV and EV.
- **Control Status Differences:** 0 (all 84 controls PASS in both RV and EV).

### O3 Suite Comparison
- **Seed Counts:** RV: 23, EV: 23 (Equal: True)
- **Control Counts:** RV: 6, EV: 6 (Equal: True)
- **Expect / Got Differences:** 0 (byte-identical across both suites).

## 5. Accounting of All 33 `review.*` Keys

| Review Key | Range | Seeds | Controls | Smoke Lines | Mapped Rows | Status |
|---|---|---|---|---|---|---|
| `review.accepted.artifact-legs` | `115-122` | `s4.seed.frame-function, s4.seed.symbol-c2, s4.seed.wrong-count` | `s4.control.row` | `s4.seed.frame-function:849, s4.seed.symbol-c2:826, s4.seed.wrong-count:862, s4.control.row:881` | 3 | PROVEN |
| `review.accepted.census-content` | `115-122` | `s2.seed.regression-1f` | `s2.control.census-all` | `s2.seed.regression-1f:645, s2.control.census-all:646` | 1 | PROVEN |
| `review.accepted.environment-and-refusals` | `115-122` | `s1.seed.env-scrub, s5.seed.route-a-drivers` | `s1.control.env-preserve` | `s1.seed.env-scrub:10, s5.seed.route-a-drivers:1220, s1.control.env-preserve:11` | 2 | PROVEN |
| `review.accepted.pin-and-identity` | `115-122` | `s1.seed.identity-binary-bytes` | `s1.control.identity` | `s1.seed.identity-binary-bytes:26, s1.control.identity:31` | 1 | PROVEN |
| `review.accepted.run1` | `115-122` | `s5.seed.run1-missing-sentinel, s5.seed.sample-exclusion, s5.seed.p-nonzero-not-added` | `s5.control.stage-chain` | `s5.seed.run1-missing-sentinel:1168, s5.seed.sample-exclusion:1174, s5.seed.p-nonzero-not-added:1181, s5.control.stage-chain:1138` | 3 | PROVEN |
| `review.accepted.shim` | `115-122` | `s3.seed.canonical-argv-drift, amend-b.seed.not-executed` | `s3.control.canonical-build` | `s3.seed.canonical-argv-drift:661, amend-b.seed.not-executed:800, s3.control.canonical-build:662` | 2 | PROVEN |
| `review.accepted.verify-ledger` | `115-122` | `s3.seed.ledger-divergence, amend-b.seed.copy-modified` | `s3.control.ledger` | `s3.seed.ledger-divergence:746, amend-b.seed.copy-modified:802, s3.control.ledger:752` | 3 | PROVEN |
| `review.output.census-report` | `108-113` | `s2.seed.regression-1f` | `s2.control.census-all` | `s2.seed.regression-1f:645, s2.control.census-all:646` | 2 | PROVEN |
| `review.output.plan` | `108-113` | `s1.seed.plan-invalid-census` | `s1.control.plan` | `s1.seed.plan-invalid-census:39, s1.control.plan:40` | 1 | PROVEN |
| `review.output.smoke` | `108-113` | `harness.seed.optimize-refusal, harness.seed.coverage-gap` | `harness.control.unoptimized` | `harness.seed.optimize-refusal:6, harness.seed.coverage-gap:8, harness.control.unoptimized:7` | 1 | PROVEN |
| `review.p0.1.run3-import` | `9 (hashlib)` | `s5.seed.run3-import` | `s5.control.stage-chain` | `s5.seed.run3-import:1199, s5.control.stage-chain:1138` | 1 | PROVEN |
| `review.p0.2.final-always-pass` | `11` | `s5.seed.final-forged-pass, s5.seed.final-missing-result` | `s5.control.stage-chain` | `s5.seed.final-forged-pass:1222, s5.seed.final-missing-result:1224, s5.control.stage-chain:1138` | 2 | PROVEN |
| `review.p0.3.matcher-roots-and-whitelist` | `13-29` | `s2.seed.matcher-variable-root, s3.seed.unknown-patched-root` | `s2.control.matcher-canonical` | `s2.seed.matcher-variable-root:659, s3.seed.unknown-patched-root:682, s2.control.matcher-canonical:660` | 3 | PROVEN |
| `review.p0.4.stage-bounds` | `31-33` | `s5.seed.run3-driver-timeout, s5.seed.run1-slow-gate` | `s5.control.stage-chain` | `s5.seed.run3-driver-timeout:1201, s5.seed.run1-slow-gate:1158, s5.control.stage-chain:1138` | 2 | PROVEN |
| `review.p0.5.ledger-census-and-nonce` | `35-40` | `s3.seed.ledger-stale-header, s3.seed.ledger-misclassified, s3.seed.ledger-not-exercised` | `s3.control.ledger` | `s3.seed.ledger-stale-header:743, s3.seed.ledger-misclassified:744, s3.seed.ledger-not-exercised:750, s3.control.ledger:752` | 4 | PROVEN |
| `review.p0.6.census-validator` | `42-57` | `s2.seed.validator-schema, s2.seed.validator-duplicate-site, s2.seed.validator-verdict` | `s2.control.census-all` | `s2.seed.validator-schema:46, s2.seed.validator-duplicate-site:49, s2.seed.validator-verdict:51, s2.control.census-all:646` | 8 | PROVEN |
| `review.p0.7.skip-classification` | `59` | `s5.seed.skip-env-blocked, s5.seed.skip-partial` | `s5.control.stage-chain` | `s5.seed.skip-env-blocked:1203, s5.seed.skip-partial:1205, s5.control.stage-chain:1138` | 2 | PROVEN |
| `review.p1.atime-probe` | `80` | `amend-b.seed.probe-unobservable, amend-b.seed.probe-stat-mutates` | `amend-b.control.real-probe` | `amend-b.seed.probe-unobservable:41, amend-b.seed.probe-stat-mutates:42, amend-b.control.real-probe:43` | 2 | PROVEN |
| `review.p1.pin-and-plan` | `81` | `s1.seed.plan-dirty, s1.seed.plan-stale-compiler, s1.seed.plan-invalid-census` | `s1.control.plan` | `s1.seed.plan-dirty:37, s1.seed.plan-stale-compiler:38, s1.seed.plan-invalid-census:39, s1.control.plan:40` | 3 | PROVEN |
| `review.p1.pin-identity-specificity` | `62-79` | `s1.seed.pin-missing-stamp, s1.seed.identity-inode` | `s1.control.identity` | `s1.seed.pin-missing-stamp:19, s1.seed.identity-inode:27, s1.control.identity:31` | 2 | PROVEN |
| `review.p1.run3-prerequisites` | `91` | `s5.seed.run3-missing-prerequisite, s5.seed.required-mismatch, s5.seed.census-missing-continues` | `s5.control.stage-chain` | `s5.seed.run3-missing-prerequisite:1193, s5.seed.required-mismatch:1195, s5.seed.census-missing-continues:1214, s5.control.stage-chain:1138` | 3 | PROVEN |
| `review.p1.shim-run-semantics` | `82-90` | `s3.seed.run-consumer-failure, s3.seed.run-signal-death, s3.seed.run-o-executes, s3.seed.implicit-file, s3.seed.run-sandbox, s3.seed.stdin-filename, s3.seed.unknown-option, s3.seed.cross-compile-roundtripped, s3.seed.roots-not-from-real, s3.seed.option-value-as-source, s3.seed.refusal-not-recorded` | `s3.control.run, s3.control.refusal` | `s3.seed.run-consumer-failure:666, s3.seed.run-signal-death:686, s3.seed.run-o-executes:667, s3.seed.implicit-file:688, s3.seed.run-sandbox:689, s3.seed.stdin-filename:690, s3.seed.unknown-option:691, s3.seed.cross-compile-roundtripped:692, s3.seed.roots-not-from-real:693, s3.seed.option-value-as-source:694, s3.seed.refusal-not-recorded:697, s3.control.run:668, s3.control.refusal:698` | 11 | PROVEN |
| `review.p1.shim-seeded-failure` | `62-79` | `s3.seed.canonical-argv-drift` | `s3.control.canonical-build` | `s3.seed.canonical-argv-drift:661, s3.control.canonical-build:662` | 2 | PROVEN |
| `review.p1.smoke-coverage-and-optimization` | `62-79` | `harness.seed.coverage-gap, harness.seed.optimize-refusal` | `harness.control.coverage-complete, harness.control.unoptimized` | `harness.seed.coverage-gap:8, harness.seed.optimize-refusal:6, harness.control.coverage-complete:9, harness.control.unoptimized:7` | 2 | PROVEN |
| `review.p1.timeout-grandchild-gone` | `62-79` | `s1.seed.timeout-grandchild` | `s1.control.bounded` | `s1.seed.timeout-grandchild:32, s1.control.bounded:36` | 1 | PROVEN |
| `review.p1.validator-specificity` | `42-57` | `s2.seed.validator-sha, s2.seed.validator-contains` | `s2.control.census-all` | `s2.seed.validator-sha:47, s2.seed.validator-contains:50, s2.control.census-all:646` | 2 | PROVEN |
| `review.p2.artifact-leg-failures` | `97-101` | `s4.seed.row-oserror, s4.seed.nm-unpinned, s4.seed.outputs-missing, s4.seed.not-reusable-nested` | `s4.control.row` | `s4.seed.row-oserror:811, s4.seed.nm-unpinned:816, s4.seed.outputs-missing:817, s4.seed.not-reusable-nested:818, s4.control.row:881` | 4 | PROVEN |
| `review.p2.duplicate-census-sites` | `105-106` | `s2.seed.validator-duplicate-site` | `s2.control.census-all` | `s2.seed.validator-duplicate-site:49, s2.control.census-all:646` | 1 | PROVEN |
| `review.p2.exclusions-attempt-location` | `94-96` | `s5.seed.exclusions-wrong-location` | `s5.control.stage-chain` | `s5.seed.exclusions-wrong-location:1166, s5.control.stage-chain:1138` | 1 | PROVEN |
| `review.p2.fresh-cache-and-tmp` | `94-96` | `s5.seed.gate-env-reused` | `s5.control.gate-env-fresh` | `s5.seed.gate-env-reused:44, s5.control.gate-env-fresh:45` | 1 | PROVEN |
| `review.p2.report-dir-path` | `105-106` | `s1.seed.report-dir-name` | `s1.control.pin` | `s1.seed.report-dir-name:22, s1.control.pin:23` | 1 | PROVEN |
| `review.p2.rg2r-count` | `94-96` | `s5.seed.rg2r-zero` | `s5.control.stage-chain` | `s5.seed.rg2r-zero:1164, s5.control.stage-chain:1138` | 1 | PROVEN |
| `review.p2.run-bounded-survivors` | `102-104` | `s1.seed.timeout-grandchild, s1.seed.log-holder-survivor` | `s1.control.bounded` | `s1.seed.timeout-grandchild:32, s1.seed.log-holder-survivor:34, s1.control.bounded:36` | 2 | PROVEN |

## 6. Detailed Semantic Mapping Rows (Summary by Range)

| Range | Finding Summary | Review Key | Fixture ID | Smoke Line | Control ID | Control Line | Status |
|---|---|---|---|---|---|---|---|
| `9 (hashlib)` | Run 3 crashes on its first driver: run_proof.py:359 calls ha... | `review.p0.1.run3-import` | `s5.seed.run3-import` | 1199 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `11` | final always writes PASS: run_proof.py:443-465 never reads R... | `review.p0.2.final-always-pass` | `s5.seed.final-forged-pass` | 1222 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `11` | final never reads Run 1, 2 or 3 results or attempts, and the... | `review.p0.2.final-always-pass` | `s5.seed.final-missing-result` | 1224 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `13-29` | The shim can't match most patched roots, and it brings back ... | `review.p0.3.matcher-roots-and-whitelist` | `s2.seed.matcher-variable-root` | 659 | `s2.control.matcher-canonical` | 660 | `PROVEN` |
| `13-29` | Anything that doesn't match but contains patched, broken, ba... | `review.p0.3.matcher-roots-and-whitelist` | `s3.seed.unknown-patched-root` | 682 | `s2.control.matcher-canonical` | 660 | `PROVEN` |
| `13-29` | Also unenforced: the requirement that {WORK} be a direct chi... | `review.p0.3.matcher-roots-and-whitelist` | `s2.control.matcher-canonical` | 660 | `s2.control.matcher-canonical` | 660 | `PROVEN` |
| `31-33` | Run 1 gates are capped at 2100 s: bounds whole stages rather... | `review.p0.4.stage-bounds` | `s5.seed.run1-slow-gate` | 1158 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `31-33` | All of Run 2 are capped at 2100 s: bounds whole stages rathe... | `review.p0.4.stage-bounds` | `s5.seed.run3-driver-timeout` | 1201 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `35-40` | verify_ledger ignores census and nonce: STALE fires only on ... | `review.p0.5.ledger-census-and-nonce` | `s3.seed.ledger-stale-header` | 743 | `s3.control.ledger` | 752 | `PROVEN` |
| `35-40` | verify_ledger ignores census and nonce: MISCLASSIFIED is nev... | `review.p0.5.ledger-census-and-nonce` | `s3.seed.ledger-misclassified` | 744 | `s3.control.ledger` | 752 | `PROVEN` |
| `35-40` | verify_ledger ignores census and nonce: NOT-EXERCISED is nev... | `review.p0.5.ledger-census-and-nonce` | `s3.seed.ledger-not-exercised` | 750 | `s3.control.ledger` | 752 | `PROVEN` |
| `35-40` | NOT-ROUNDTRIPPED is satisfied by any record whose source pat... | `review.p1.shim-seeded-failure` | `s3.seed.canonical-argv-drift` | 661 | `s3.control.canonical-build` | 662 | `PROVEN` |
| `35-40` | E3 is skipped whenever out_ref is missing (:654), so it fail... | `review.accepted.verify-ledger` | `s3.seed.ledger-divergence` | 746 | `s3.control.ledger` | 752 | `PROVEN` |
| `35-40` | UNFAITHFUL ignores interrupted runs and run.signal; the shim... | `review.p0.5.ledger-census-and-nonce` | `o5.seed.pair-field-drift` | 780 | `s3.control.ledger` | 752 | `PROVEN` |
| `42-57` | The census validator checks almost nothing: checks only scri... | `review.p0.6.census-validator` | `s2.seed.validator-schema` | 46 | `s2.control.census-all` | 646 | `PROVEN` |
| `42-57` | It does not check that each invocation is in exactly one sit... | `review.p0.6.census-validator` | `s2.seed.validator-duplicate-site` | 49 | `s2.control.census-all` | 646 | `PROVEN` |
| `42-57` | It does not check verdict literals. | `review.p0.6.census-validator` | `s2.seed.validator-verdict` | 51 | `s2.control.census-all` | 646 | `PROVEN` |
| `42-57` | It does not check that var values sit inside their cited ran... | `review.p0.6.census-validator` | `s2.seed.validator-var-range` | 52 | `s2.control.census-all` | 646 | `PROVEN` |
| `42-57` | It does not check skip regexes. | `review.p0.6.census-validator` | `s2.seed.validator-skip-regex` | 54 | `s2.control.census-all` | 646 | `PROVEN` |
| `42-57` | It does not check site kind against variants (Mixed sites ar... | `review.p0.6.census-validator` | `s2.seed.validator-kind-variants` | 57 | `s2.control.census-all` | 646 | `PROVEN` |
| `42-57` | Exec evidence is synthesized from fixed offsets in build_cen... | `review.p0.6.census-validator` | `s2.seed.validator-e1-token` | 60 | `s2.control.census-all` | 646 | `PROVEN` |
| `42-57` | signal has no own site and no exec evidence; four positive s... | `review.p0.6.census-validator` | `s2.seed.validator-e1-missing` | 59 | `s2.control.census-all` | 646 | `PROVEN` |
| `42-57` | Validator specificity: checks only script sha without specif... | `review.p1.validator-specificity` | `s2.seed.validator-sha` | 47 | `s2.control.census-all` | 646 | `PROVEN` |
| `42-57` | Validator specificity: contains literals checking. | `review.p1.validator-specificity` | `s2.seed.validator-contains` | 50 | `s2.control.census-all` | 646 | `PROVEN` |
| `42-57` | ALL_VALIDATED certifies none of this: full regression across... | `review.output.census-report` | `s2.seed.regression-1f` | 645 | `s2.control.census-all` | 646 | `PROVEN` |
| `59` | 7. Skips are never classified: a tool skip that exits 0 coun... | `review.p0.7.skip-classification` | `s5.seed.skip-env-blocked` | 1203 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `59` | Run 1 writes no baseline_skips.json, and Run 3 never applies... | `review.p0.7.skip-classification` | `s5.seed.skip-partial` | 1205 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `62-79` | The timeout test never checks that the grandchild is gone. | `review.p1.timeout-grandchild-gone` | `s1.seed.timeout-grandchild` | 32 | `s1.control.bounded` | 36 | `PROVEN` |
| `62-79` | The S3 test has a control and no seeded failure. | `review.p1.shim-seeded-failure` | `s3.seed.canonical-argv-drift` | 661 | `s3.control.canonical-build` | 662 | `PROVEN` |
| `62-79` | smoke_test.py relies on assert and doesn't refuse to run und... | `review.p1.smoke-coverage-and-optimization` | `harness.seed.optimize-refusal` | 6 | `harness.control.unoptimized` | 7 | `PROVEN` |
| `62-79` | Smoke suite coverage completeness: smoke suite covers about ... | `review.p1.smoke-coverage-and-optimization` | `harness.seed.coverage-gap` | 8 | `harness.control.coverage-complete` | 9 | `PROVEN` |
| `62-79` | The pin and identity tests accept any IdentityError without ... | `review.p1.pin-identity-specificity` | `s1.seed.pin-missing-stamp` | 19 | `s1.control.pin` | 23 | `PROVEN` |
| `62-79` | The pin and identity tests accept any IdentityError without ... | `review.p1.pin-identity-specificity` | `s1.seed.identity-inode` | 27 | `s1.control.identity` | 31 | `PROVEN` |
| `80` | The atime probe doesn't test what E3 depends on: proofkit.py... | `review.p1.atime-probe` | `amend-b.seed.probe-unobservable` | 41 | `amend-b.control.real-probe` | 43 | `PROVEN` |
| `80` | The atime probe doesn't test what E3 depends on: stat calls ... | `review.p1.atime-probe` | `amend-b.seed.probe-stat-mutates` | 42 | `amend-b.control.real-probe` | 43 | `PROVEN` |
| `81` | plan only warns on a dirty tree. | `review.p1.pin-and-plan` | `s1.seed.plan-dirty` | 37 | `s1.control.plan` | 40 | `PROVEN` |
| `81` | plan never checks for a stale binary, which §5 requires. | `review.p1.pin-and-plan` | `s1.seed.plan-stale-compiler` | 38 | `s1.control.plan` | 40 | `PROVEN` |
| `81` | The pin doesn't run the census validator, though C3 requires... | `review.p1.pin-and-plan` | `s1.seed.plan-invalid-census` | 39 | `s1.control.plan` | 40 | `PROVEN` |
| `82-90` | In run mode, a consumer that fails to build makes the shim e... | `review.p1.shim-run-semantics` | `s3.seed.run-consumer-failure` | 666 | `s3.control.run` | 668 | `PROVEN` |
| `82-90` | A program killed by a signal gets no death sentence and no r... | `review.p1.shim-run-semantics` | `s3.seed.run-signal-death` | 686 | `s3.control.run` | 668 | `PROVEN` |
| `82-90` | run -o executes the program instead of only building it. | `review.p1.shim-run-semantics` | `s3.seed.run-o-executes` | 667 | `s3.control.run` | 668 | `PROVEN` |
| `82-90` | Not refused: implicit iyi file.iyi. | `review.p1.shim-run-semantics` | `s3.seed.implicit-file` | 688 | `s3.control.refusal` | 698 | `PROVEN` |
| `82-90` | Not refused: run --sandbox. | `review.p1.shim-run-semantics` | `s3.seed.run-sandbox` | 689 | `s3.control.refusal` | 698 | `PROVEN` |
| `82-90` | Not refused: --stdin-filename. | `review.p1.shim-run-semantics` | `s3.seed.stdin-filename` | 690 | `s3.control.refusal` | 698 | `PROVEN` |
| `82-90` | Not refused: unknown options. | `review.p1.shim-run-semantics` | `s3.seed.unknown-option` | 691 | `s3.control.refusal` | 698 | `PROVEN` |
| `82-90` | --cross-compile is missing from the unchanged list. | `review.p1.shim-run-semantics` | `s3.seed.cross-compile-roundtripped` | 692 | `s3.control.run` | 668 | `PROVEN` |
| `82-90` | Roots are computed from the environment (:186) instead of RE... | `review.p1.shim-run-semantics` | `s3.seed.roots-not-from-real` | 693 | `s3.control.run` | 668 | `PROVEN` |
| `82-90` | Option values are parsed as sources. | `review.p1.shim-run-semantics` | `s3.seed.option-value-as-source` | 694 | `s3.control.run` | 668 | `PROVEN` |
| `82-90` | A REFUSED call writes no ledger record, and there's no heade... | `review.p1.shim-run-semantics` | `s3.seed.refusal-not-recorded` | 697 | `s3.control.refusal` | 698 | `PROVEN` |
| `91` | Run 3 runs without Run 1's exclusions.json or Run 2's JSONL ... | `review.p1.run3-prerequisites` | `s5.seed.run3-missing-prerequisite` | 1193 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `91` | CENSUS-MISSING aborts the whole run. | `review.p1.run3-prerequisites` | `s5.seed.census-missing-continues` | 1214 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `91` | required.json isn't recomputed and compared on later attempt... | `review.p1.run3-prerequisites` | `s5.seed.required-mismatch` | 1195 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `94-96` | No gate gets a fresh IYI_CACHE_DIR, and gate 1.3 gets no TMP... | `review.p2.fresh-cache-and-tmp` | `s5.seed.gate-env-reused` | 44 | `s5.control.gate-env-fresh` | 45 | `PROVEN` |
| `94-96` | The RG2r N >= 1 check is missing. | `review.p2.rg2r-count` | `s5.seed.rg2r-zero` | 1164 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `94-96` | exclusions.json is written outside the attempt directory. | `review.p2.exclusions-attempt-location` | `s5.seed.exclusions-wrong-location` | 1166 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `97-101` | artifact_legs doesn't turn a row's OSError or RuntimeError i... | `review.p2.artifact-leg-failures` | `s4.seed.row-oserror` | 811 | `s4.control.row` | 881 | `PROVEN` |
| `97-101` | artifact_legs doesn't use the pinned nm. | `review.p2.artifact-leg-failures` | `s4.seed.nm-unpinned` | 816 | `s4.control.row` | 881 | `PROVEN` |
| `97-101` | artifact_legs doesn't save leg outputs. | `review.p2.artifact-leg-failures` | `s4.seed.outputs-missing` | 817 | `s4.control.row` | 881 | `PROVEN` |
| `97-101` | artifact_legs reads reach.not_reusable, but that field is to... | `review.p2.artifact-leg-failures` | `s4.seed.not-reusable-nested` | 818 | `s4.control.row` | 881 | `PROVEN` |
| `102-104` | run_bounded doesn't record survivors. | `review.p2.run-bounded-survivors` | `s1.seed.log-holder-survivor` | 34 | `s1.control.bounded` | 36 | `PROVEN` |
| `102-104` | A grandchild that keeps the pipes open turns a finished driv... | `review.p2.run-bounded-survivors` | `s1.seed.timeout-grandchild` | 32 | `s1.control.bounded` | 36 | `PROVEN` |
| `105-106` | R isn't forced to /tmp/iyp-<chain8>, so Unix socket paths ca... | `review.p2.report-dir-path` | `s1.seed.report-dir-name` | 22 | `s1.control.pin` | 23 | `PROVEN` |
| `105-106` | Five census files claim the same line in two sites, and noth... | `review.p2.duplicate-census-sites` | `s2.seed.validator-duplicate-site` | 49 | `s2.control.census-all` | 646 | `PROVEN` |
| `108-113` | smoke_output.txt lists the 10 test names and git noise. It d... | `review.output.smoke` | `harness.seed.optimize-refusal` | 6 | `harness.control.unoptimized` | 7 | `PROVEN` |
| `108-113` | plan_output.txt shows the census count ('29 of 29 present'),... | `review.output.plan` | `s1.seed.plan-invalid-census` | 39 | `s1.control.plan` | 40 | `PROVEN` |
| `108-113` | census_validation_report.json isn't produced by any committe... | `review.output.census-report` | `s2.seed.regression-1f` | 645 | `s2.control.census-all` | 646 | `PROVEN` |
| `115-122` | Pin and identity: the pin fields and refusals that exist (R ... | `review.accepted.pin-and-identity` | `s1.seed.identity-binary-bytes` | 26 | `s1.control.identity` | 31 | `PROVEN` |
| `115-122` | Environment and refusals: the base_env scrub, ROUTE_A exits ... | `review.accepted.environment-and-refusals` | `s1.seed.env-scrub` | 10 | `s1.control.env-preserve` | 11 | `PROVEN` |
| `115-122` | Environment and refusals: ROUTE_A exits 2. | `review.accepted.environment-and-refusals` | `s5.seed.route-a-drivers` | 1220 | `s1.control.env-preserve` | 11 | `PROVEN` |
| `115-122` | Run 1: the pass-line checks for gates 1.1-1.4, apart from th... | `review.accepted.run1` | `s5.seed.run1-missing-sentinel` | 1168 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `115-122` | Run 1: sample exclusion parsing, including sample FAIL. | `review.accepted.run1` | `s5.seed.sample-exclusion` | 1174 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `115-122` | Run 1: JSON p_nonzero additions. | `review.accepted.run1` | `s5.seed.p-nonzero-not-added` | 1181 | `s5.control.stage-chain` | 1138 | `PROVEN` |
| `115-122` | artifact_legs: the per-stream comparison through the frames_... | `review.accepted.artifact-legs` | `s4.seed.frame-function` | 849 | `s4.control.row` | 881 | `PROVEN` |
| `115-122` | artifact_legs: the nm STOP on C1/C2/C3 (symbol verification ... | `review.accepted.artifact-legs` | `s4.seed.symbol-c2` | 826 | `s4.control.row` | 881 | `PROVEN` |
| `115-122` | artifact_legs: explicit counts verification. | `review.accepted.artifact-legs` | `s4.seed.wrong-count` | 862 | `s4.control.row` | 881 | `PROVEN` |
| `115-122` | Shim: the environment passes through untouched, scratch come... | `review.accepted.shim` | `s3.seed.canonical-argv-drift` | 661 | `s3.control.canonical-build` | 662 | `PROVEN` |
| `115-122` | Shim: unexecuted consumer output is not accepted. | `review.accepted.shim` | `amend-b.seed.not-executed` | 800 | `s3.control.canonical-build` | 662 | `PROVEN` |
| `115-122` | verify_ledger: DIVERGENCE, begin/end pairing, E3 on own-exer... | `review.accepted.verify-ledger` | `s3.seed.ledger-divergence` | 746 | `s3.control.ledger` | 752 | `PROVEN` |
| `115-122` | verify_ledger: E3 on own-exercise records, OUT-MODIFIED (mod... | `review.accepted.verify-ledger` | `amend-b.seed.copy-modified` | 802 | `s3.control.ledger` | 752 | `PROVEN` |
| `115-122` | Census content: it covers the plan's list of positive and ne... | `review.accepted.census-content` | `s2.seed.regression-1f` | 645 | `s2.control.census-all` | 646 | `PROVEN` |

## 7. Explicit Gaps and Findings Disclosure

1. **UNFAITHFUL Mapping Scope:** In review-1f range 35-40 (line 40), the finding states `UNFAITHFUL ignores interrupted runs and run.signal; the shim never sets either.` In H's `smoke_test.py`, `review.p0.5.ledger-census-and-nonce` registers `s3.seed.ledger-stale-header`, `s3.seed.ledger-misclassified`, `s3.seed.ledger-not-exercised`, and `s3.control.ledger`. The specific UNFAITHFUL condition is tested and proven by `o5.seed.pair-field-drift` (smoke:780) under `contract.o5.pair-divergence`. This finding is explicitly linked and documented in `semantic_mapping.json`.
2. **Process Scratch Directory Variation:** Across the 432 seeds in `smoke.log`, 12 seeds in RV vs EV contain distinct temporary run directories generated dynamically at runtime (e.g. `/private/tmp/iyi-o4-*` and `/var/folders/...`). All 12 seeds exhibit identical structure, return codes, and arguments, with 0 semantic differences.
3. **No Code Edits or Mutating Commands:** Per slice R1 read-only boundaries, no mutations were made to H, no candidate code was touched, and only files in `RV2/r1/` were created.

---
*Generated by Archimedes (R1 Slice Worker) under Planner v2 Specification.*