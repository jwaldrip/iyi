# Exact code for §8.5 census spot checks
import json, os, glob, re

W = "/private/tmp/iyi-proof-complete-6bbe1bf2e/c/r2h"
census_dir = os.path.join(W, "proof", "census")

# Autocert
autocert_c = json.load(open(os.path.join(census_dir, "autocert.json")))
autocert_L = open(os.path.join(W, autocert_c["script"]), encoding="utf-8").read().splitlines()
def enclosing_function(lines, line_num):
    for k in range(line_num, 0, -1):
        m = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\(\)\s*\{", lines[k - 1])
        if m:
            return m.group(1), k
    return None, None

build_fn, build_fn_line = enclosing_function(autocert_L, 85)
exec_fn, exec_fn_line = enclosing_function(autocert_L, 103)

# Signal 68 vs Regex 522
signal_c = json.load(open(os.path.join(census_dir, "signal.json")))
signal_site68 = next(s for s in signal_c["sites"] if 68 in s["lines"])
signal_ev68 = [e for e in signal_c.get("exec_evidence", []) if e["site_line"] == 68]

regex_c = json.load(open(os.path.join(census_dir, "regex.json")))
regex_site522 = next(s for s in regex_c["sites"] if 522 in s["lines"])
regex_ev522 = [e for e in regex_c.get("exec_evidence", []) if e["site_line"] == 522]

# Positive sites
positive_sites = {}
for drv, line in [("compress", 464), ("math", 555), ("tls", 795), ("file", 628)]:
    c = json.load(open(os.path.join(census_dir, f"{drv}.json")))
    st = next(s for s in c["sites"] if line in s["lines"])
    ev = [e for e in c.get("exec_evidence", []) if e["site_line"] == line]
    positive_sites[f"{drv}:{line}"] = {
        "kind": st["kind"],
        "has_exec_evidence": len(ev) > 0,
        "evidence": ev
    }

# Fuzz token
fuzz_c = json.load(open(os.path.join(census_dir, "fuzz.json")))
fuzz_tokens = [e["exec_token"] for e in fuzz_c.get("exec_evidence", [])]

# DNS verdict failure marks
dns_c = json.load(open(os.path.join(census_dir, "dns.json")))
dns_L = open(os.path.join(W, dns_c["script"]), encoding="utf-8").read().splitlines()
dns_verdict_bad = []
for e in dns_c["exec_evidence"]:
    for n in e["verdict_lines"]:
        line_text = dns_L[n - 1]
        if not any(mark in line_text for mark in e["failure_marks"]):
            dns_verdict_bad.append({"line": n, "text": line_text.strip()})

# Shell syntax in templates and pattern variable reasons
templates_with_shell = []
pattern_vars = []
for path in sorted(glob.glob(os.path.join(census_dir, "*.json"))):
    c = json.load(open(path))
    drv = c["driver"]
    L = open(os.path.join(W, c["script"]), encoding="utf-8").read().splitlines()
    for s in c["sites"]:
        for v in s.get("variants", []):
            for fld in ("first_root", "output"):
                val = v.get(fld)
                if isinstance(val, str) and re.search(r"[$`*?\[]", val):
                    templates_with_shell.append({"driver": drv, "variant": v["id"], "field": fld, "value": val})
            for src in v.get("sources", []):
                if re.search(r"[$`*?\[]", src):
                    templates_with_shell.append({"driver": drv, "variant": v["id"], "field": "sources", "value": src})
            for var_name, var_spec in v.get("vars", {}).items():
                if "pattern" in var_spec:
                    reason = var_spec.get("pattern_reason_line")
                    pattern_vars.append({"driver": drv, "var": var_name, "reason": reason})
    for e in c.get("exec_evidence", []):
        tmpl = e.get("out_template")
        if tmpl and re.search(r"[$`*?\[]", tmpl):
            templates_with_shell.append({"driver": drv, "field": "out_template", "value": tmpl})
