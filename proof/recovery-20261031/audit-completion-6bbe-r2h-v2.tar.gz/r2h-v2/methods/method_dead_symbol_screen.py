# Exact AST predicate and analysis code for dead-symbol screen
# NOTE: _read_pid being unreferenced at smoke_test.py:377 is a screen observation of an
# unreferenced top-level symbol, not proof that it was deliberately retained; no intent is inferred.
import ast, os, glob

W = "/private/tmp/iyi-proof-complete-6bbe1bf2e/c/r2h"
proof_dir = os.path.join(W, "proof")
py_files = sorted(glob.glob(os.path.join(proof_dir, "*.py")))

definitions = {}
file_trees = {}
for path in py_files:
    mod_name = os.path.splitext(os.path.basename(path))[0]
    with open(path, "r", encoding="utf-8") as f:
        src = f.read()
    tree = ast.parse(src, filename=path)
    file_trees[mod_name] = tree
    defs = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            defs.append({"kind": "function", "name": node.name, "line": node.lineno})
        elif isinstance(node, ast.ClassDef):
            defs.append({"kind": "class", "name": node.name, "line": node.lineno})
        elif isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name):
                    defs.append({"kind": "assign", "name": t.id, "line": node.lineno})
        elif isinstance(node, ast.AnnAssign):
            if isinstance(node.target, ast.Name):
                defs.append({"kind": "assign", "name": node.target.id, "line": node.lineno})
    definitions[mod_name] = defs

name_references = {}
attr_references = {}
for mod_name, tree in file_trees.items():
    names = set()
    attrs = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            names.add(node.id)
        elif isinstance(node, ast.Attribute):
            attrs.add(node.attr)
    name_references[mod_name] = names
    attr_references[mod_name] = attrs

unreferenced = {}
for mod_name, defs in definitions.items():
    unref = []
    for d in defs:
        name = d["name"]
        kind = d["kind"]
        in_other_names = any(name in names for m, names in name_references.items() if m != mod_name)
        in_other_attrs = any(name in attrs for m, attrs in attr_references.items() if m != mod_name)
        same_mod_count = sum(1 for node in ast.walk(file_trees[mod_name]) if isinstance(node, ast.Name) and node.id == name)
        
        if kind in ("function", "class"):
            is_used_internally = same_mod_count > 0
        else:
            is_used_internally = same_mod_count > 1
            
        if not (in_other_names or in_other_attrs or is_used_internally):
            unref.append(d)
    unreferenced[mod_name] = unref
