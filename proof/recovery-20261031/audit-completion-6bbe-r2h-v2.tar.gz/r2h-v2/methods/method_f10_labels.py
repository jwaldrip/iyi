# Exact comparison method for F10 label accuracy against driver scripts
import json, os

W = "/private/tmp/iyi-proof-complete-6bbe1bf2e/c/r2h"
census_dir = os.path.join(W, "proof", "census")

f10_items = [
    {"driver": "regex", "script": "bench/std_regex_exercise.sh", "guard_lines": [50], "skip_line": 51, "expected_class": "tool", "expected_what": "python3"},
    {"driver": "xz", "script": "bench/std_xz_exercise.sh", "guard_lines": [47], "skip_line": 48, "expected_class": "tool", "expected_what": "python3"},
    {"driver": "xz", "script": "bench/std_xz_exercise.sh", "guard_lines": [51], "skip_line": 52, "expected_class": "tool", "expected_what": "Python lzma module"},
    {"driver": "zstd", "script": "bench/std_zstd_exercise.sh", "guard_lines": [20, 21, 22, 23, 24, 25, 26, 42], "skip_line": 43, "expected_class": "tool", "expected_what": "Python 3.14+ compression.zstd"}
]

for item in f10_items:
    c = json.load(open(os.path.join(census_dir, f"{item['driver']}.json")))
    L = open(os.path.join(W, item["script"]), encoding="utf-8").read().splitlines()
    entry = next(s for s in c["skips"] if s["line"] == item["skip_line"])
    assert entry["class"] == item["expected_class"]
    assert entry["what"] == item["expected_what"]
    assert entry["text"].strip() == L[item["skip_line"] - 1].strip()
