# Exact AST predicate and analysis code for F11
import ast, os, glob

W = "/private/tmp/iyi-proof-complete-6bbe1bf2e/c/r2h"
proof_dir = os.path.join(W, "proof")

def is_os_environ(node):
    if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name):
        return node.value.id == "os" and node.attr == "environ"
    return False

def analyze_file(filepath):
    relpath = os.path.relpath(filepath, W)
    with open(filepath, "r", encoding="utf-8") as f:
        source = f.read()
    tree = ast.parse(source, filename=relpath)

    setattr_calls = []
    imported_names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imported_names.add(alias.asname or alias.name.split('.')[0])
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                for alias in node.names:
                    imported_names.add(alias.asname or alias.name)

    module_attr_assigns = []
    environ_ops = []

    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == "setattr":
                setattr_calls.append({"line": node.lineno, "col": node.col_offset})

        targets = []
        if isinstance(node, ast.Assign):
            targets.extend(node.targets)
        elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
            if node.target:
                targets.append(node.target)

        for target in targets:
            if isinstance(target, ast.Attribute):
                if isinstance(target.value, ast.Name) and target.value.id in imported_names:
                    module_attr_assigns.append({
                        "line": target.lineno,
                        "module": target.value.id,
                        "attr": target.attr
                    })
            elif isinstance(target, ast.Subscript):
                if is_os_environ(target.value):
                    environ_ops.append({"line": target.lineno, "op": "subscript_assign"})

        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Attribute):
                if is_os_environ(node.func.value):
                    if node.func.attr in ("update", "clear", "pop", "setdefault"):
                        environ_ops.append({"line": node.lineno, "op": f"method_{node.func.attr}"})
        if isinstance(node, ast.Delete):
            for target in node.targets:
                if isinstance(target, ast.Subscript) and is_os_environ(target.value):
                    environ_ops.append({"line": target.lineno, "op": "del"})

    return {
        "file": relpath,
        "setattr_calls": setattr_calls,
        "module_attr_assigns": module_attr_assigns,
        "environ_ops": environ_ops
    }
