# Exact AST extraction of production limits
import ast, os

W = "/private/tmp/iyi-proof-complete-6bbe1bf2e/c/r2h"
with open(os.path.join(W, "proof", "artifact_legs.py"), "r", encoding="utf-8") as f:
    al_tree = ast.parse(f.read())
with open(os.path.join(W, "proof", "proofkit.py"), "r", encoding="utf-8") as f:
    pk_tree = ast.parse(f.read())

limits = {}
for node in al_tree.body:
    if isinstance(node, ast.Assign):
        for t in node.targets:
            if isinstance(t, ast.Name) and t.id in ("BUILD_TIMEOUT", "RUN_DEFAULT_TIMEOUT", "RUN_HEAVY_TIMEOUT", "DISK_MIN_GB"):
                limits[f"artifact_legs.{t.id}"] = node.value.value

for node in pk_tree.body:
    if isinstance(node, ast.Assign):
        for t in node.targets:
            if isinstance(t, ast.Name) and t.id in ("DRIVER_LIMIT_SEC", "GRACE_SEC", "DISK_MIN_GB"):
                limits[f"proofkit.{t.id}"] = node.value.value
