# Exact AST predicate and analysis code for registry hole detection
import ast, os

W = "/private/tmp/iyi-proof-complete-6bbe1bf2e/c/r2h"
filepath = os.path.join(W, "proof", "smoke_test.py")

with open(filepath, "r", encoding="utf-8") as f:
    source = f.read()

tree = ast.parse(source, filename="proof/smoke_test.py")

fixture_groups = {}
review_items_groups = {}

for node in tree.body:
    name = None
    val = None
    if isinstance(node, ast.Assign):
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            val = node.value
    elif isinstance(node, ast.AnnAssign):
        if isinstance(node.target, ast.Name):
            name = node.target.id
            val = node.value
            
    if name and val:
        if name.endswith("_FIXTURES") or name == "FIXTURES":
            if isinstance(val, (ast.Tuple, ast.List)):
                items = []
                for el in val.elts:
                    if isinstance(el, ast.Call):
                        if len(el.args) >= 2:
                            fid = el.args[0].value if isinstance(el.args[0], ast.Constant) else None
                            kind = el.args[1].value if isinstance(el.args[1], ast.Constant) else None
                            if fid and kind:
                                items.append((fid, kind))
                fixture_groups[name] = items
        elif "REVIEW_ITEMS" in name:
            if isinstance(val, ast.Dict):
                mapping = {}
                for k, v in zip(val.keys, val.values):
                    if isinstance(k, ast.Constant) and isinstance(v, (ast.Tuple, ast.List)):
                        mapping[k.value] = [el.value for el in v.elts if isinstance(el, ast.Constant)]
                review_items_groups[name] = mapping

all_fixtures = {}
for g in ("FIXTURES", "O3_FIXTURES", "O4_FIXTURES", "O5_FIXTURES", "O6_FIXTURES", "O7_FIXTURES"):
    for fid, kind in fixture_groups[g]:
        all_fixtures[fid] = kind

merged_all_review_items = {}
for g in ("REVIEW_ITEMS", "O4_REVIEW_ITEMS", "O5_REVIEW_ITEMS", "O6_REVIEW_ITEMS", "O7_REVIEW_ITEMS"):
    merged_all_review_items.update(review_items_groups[g])

all_mapped = set()
for item, fids in merged_all_review_items.items():
    all_mapped.update(fids)

unmapped_in_suite = sorted(list(set(all_fixtures.keys()) - all_mapped))
dangling_in_suite = sorted(list(all_mapped - set(all_fixtures.keys())))
