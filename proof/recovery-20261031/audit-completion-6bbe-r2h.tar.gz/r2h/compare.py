#!/usr/bin/env python3
"""RV2/r2h comparison tool: projects recomputed globals to every archived data field.
Usage: $PY -B -X pycache_prefix=RV2/pyc/r2h RV2/r2h/compare.py [OUT_JSON_PATH]
"""
import os
import sys
import json

def main():
    r2_dir = "/private/tmp/iyi-proof-complete-6bbe1bf2e/r2"
    jobs_dir = "/private/tmp/iyi-proof-complete-6bbe1bf2e/r2h/jobs"
    out_path = sys.argv[1] if len(sys.argv) > 1 else "/private/tmp/iyi-proof-complete-6bbe1bf2e/r2h/compare.json"

    results = {}
    all_passed = True

    # ------------------------------------------------------------------------
    # 1. trace_profile_hooks
    # ------------------------------------------------------------------------
    with open(os.path.join(r2_dir, "trace_profile_hooks.json")) as f:
        arch_tph = json.load(f)
    with open(os.path.join(jobs_dir, "job_trace_profile_hooks", "out.json")) as f:
        out_tph = json.load(f)
    g_tph = out_tph["globals"]

    proj_occurrences = [(o["file"], o["line"], o["code"]) for o in arch_tph["occurrences"]]
    re_occurrences = [tuple(x) for x in g_tph["trace_matches"]]
    tph_equal = (
        proj_occurrences == re_occurrences and
        arch_tph["occurrences_count"] == len(g_tph["trace_matches"]) and
        arch_tph["verified"] is True and
        arch_tph["status"] == "PASS"
    )
    if not tph_equal:
        all_passed = False
    results["trace_profile_hooks"] = {
        "status": "PASS" if tph_equal else "FAIL",
        "projected_data_fields": {
            "occurrences": proj_occurrences == re_occurrences,
            "occurrences_count": arch_tph["occurrences_count"] == len(g_tph["trace_matches"]),
            "verified": arch_tph["verified"] is True
        },
        "verdict_boolean": arch_tph["status"] == "PASS",
        "excluded_prose_labels": {
            "check": arch_tph.get("check")
        }
    }

    # ------------------------------------------------------------------------
    # 2. production_limits
    # ------------------------------------------------------------------------
    with open(os.path.join(r2_dir, "production_limits.json")) as f:
        arch_pl = json.load(f)
    with open(os.path.join(jobs_dir, "job_production_limits", "out.json")) as f:
        out_pl = json.load(f)
    g_pl = out_pl["globals"]

    pl_equal = (
        arch_pl["actual_limits"] == g_pl["limits"] and
        arch_pl["expected_limits"] == g_pl["limits"] and
        arch_pl["verified"] is True and
        arch_pl["status"] == "PASS"
    )
    if not pl_equal:
        all_passed = False
    results["production_limits"] = {
        "status": "PASS" if pl_equal else "FAIL",
        "projected_data_fields": {
            "actual_limits": arch_pl["actual_limits"] == g_pl["limits"],
            "expected_limits": arch_pl["expected_limits"] == g_pl["limits"],
            "verified": arch_pl["verified"] is True
        },
        "verdict_boolean": arch_pl["status"] == "PASS",
        "excluded_prose_labels": {
            "check": arch_pl.get("check")
        }
    }

    # ------------------------------------------------------------------------
    # 3. dead_symbol_screen
    # ------------------------------------------------------------------------
    with open(os.path.join(r2_dir, "dead_symbol_screen.json")) as f:
        arch_dss = json.load(f)
    with open(os.path.join(jobs_dir, "job_dead_symbol_screen", "out.json")) as f:
        out_dss = json.load(f)
    g_dss = out_dss["globals"]

    dss_equal = (
        arch_dss["unreferenced_by_module"] == g_dss["unreferenced"] and
        arch_dss["banned_symbols_present"] == [] and
        arch_dss["verified"] is True and
        arch_dss["status"] == "PASS"
    )
    if not dss_equal:
        all_passed = False
    results["dead_symbol_screen"] = {
        "status": "PASS" if dss_equal else "FAIL",
        "projected_data_fields": {
            "unreferenced_by_module": arch_dss["unreferenced_by_module"] == g_dss["unreferenced"],
            "banned_symbols_present": arch_dss["banned_symbols_present"] == [],
            "verified": arch_dss["verified"] is True
        },
        "verdict_boolean": arch_dss["status"] == "PASS",
        "excluded_prose_labels": {
            "check": arch_dss.get("check"),
            "banned_symbols_checked": arch_dss.get("banned_symbols_checked"),
            "deliberate_unreferenced_symbols_explanation": arch_dss.get("deliberate_unreferenced_symbols_explanation")
        }
    }

    # ------------------------------------------------------------------------
    # 4. registry_holes
    # ------------------------------------------------------------------------
    with open(os.path.join(r2_dir, "registry_holes.json")) as f:
        arch_rh = json.load(f)
    with open(os.path.join(jobs_dir, "job_registry_holes", "out.json")) as f:
        out_rh = json.load(f)
    g_rh = out_rh["globals"]

    rh_equal = (
        arch_rh["suite_summary"]["unmapped_registered_fixtures"] == g_rh["unmapped_in_suite"] and
        arch_rh["suite_summary"]["dangling_mapped_references"] == g_rh["dangling_in_suite"] and
        arch_rh["suite_summary"]["total_registered_fixtures"] == len(g_rh["all_fixtures"]) and
        arch_rh["suite_summary"]["total_mapped_fixture_ids"] == len(g_rh["all_mapped"]) and
        arch_rh["suite_summary"]["total_review_items"] == len(g_rh["merged_all_review_items"]) and
        arch_rh["verified"] is True and
        arch_rh["status"] == "PASS"
    )
    if not rh_equal:
        all_passed = False
    results["registry_holes"] = {
        "status": "PASS" if rh_equal else "FAIL",
        "projected_data_fields": {
            "unmapped_registered_fixtures": arch_rh["suite_summary"]["unmapped_registered_fixtures"] == g_rh["unmapped_in_suite"],
            "dangling_mapped_references": arch_rh["suite_summary"]["dangling_mapped_references"] == g_rh["dangling_in_suite"],
            "total_registered_fixtures": arch_rh["suite_summary"]["total_registered_fixtures"] == len(g_rh["all_fixtures"]),
            "total_mapped_fixture_ids": arch_rh["suite_summary"]["total_mapped_fixture_ids"] == len(g_rh["all_mapped"]),
            "total_review_items": arch_rh["suite_summary"]["total_review_items"] == len(g_rh["merged_all_review_items"]),
            "verified": arch_rh["verified"] is True
        },
        "verdict_boolean": arch_rh["status"] == "PASS",
        "excluded_prose_labels": {
            "check": arch_rh.get("check")
        }
    }

    # ------------------------------------------------------------------------
    # 5. exec_tokens_all_29
    # ------------------------------------------------------------------------
    with open(os.path.join(r2_dir, "exec_tokens_all_29.json")) as f:
        arch_et = json.load(f)
    with open(os.path.join(jobs_dir, "job_exec_tokens_all_29", "out.json")) as f:
        out_et = json.load(f)
    g_et = out_et["globals"]

    et_equal = (
        arch_et["entries"] == g_et["census_token_results"] and
        arch_et["all_tokens_valid"] == g_et["all_tokens_valid"] and
        arch_et["total_exec_evidence_entries_checked"] == len(g_et["census_token_results"]) and
        arch_et["total_censuses"] == len(set(e["driver"] for e in g_et["census_token_results"])) and
        arch_et["status"] == "PASS"
    )
    if not et_equal:
        all_passed = False
    results["exec_tokens_all_29"] = {
        "status": "PASS" if et_equal else "FAIL",
        "projected_data_fields": {
            "entries": arch_et["entries"] == g_et["census_token_results"],
            "all_tokens_valid": arch_et["all_tokens_valid"] == g_et["all_tokens_valid"],
            "total_exec_evidence_entries_checked": arch_et["total_exec_evidence_entries_checked"] == len(g_et["census_token_results"]),
            "total_censuses": arch_et["total_censuses"] == len(set(e["driver"] for e in g_et["census_token_results"]))
        },
        "verdict_boolean": arch_et["status"] == "PASS",
        "excluded_prose_labels": {
            "check": arch_et.get("check")
        }
    }

    # ------------------------------------------------------------------------
    # 6. f10_labels
    # ------------------------------------------------------------------------
    with open(os.path.join(r2_dir, "f10_labels.json")) as f:
        arch_f10 = json.load(f)
    with open(os.path.join(jobs_dir, "job_f10_labels", "out.json")) as f:
        out_f10 = json.load(f)
    g_f10 = out_f10["globals"]

    f10_items_match = len(arch_f10["items"]) == len(g_f10["f10_items"])
    if f10_items_match:
        for arch_item, re_item in zip(arch_f10["items"], g_f10["f10_items"]):
            if not (
                arch_item["driver"] == re_item["driver"] and
                arch_item["script"] == re_item["script"] and
                arch_item["guard_lines"] == re_item["guard_lines"] and
                arch_item["skip_line"] == re_item["skip_line"] and
                arch_item["census_skip_entry"]["class"] == re_item["expected_class"] and
                arch_item["census_skip_entry"]["what"] == re_item["expected_what"] and
                arch_item["class_matches"] is True and
                arch_item["what_matches"] is True and
                arch_item["text_matches"] is True and
                arch_item["verdict"] == "PASS"
            ):
                f10_items_match = False
                break

    f10_equal = f10_items_match and (arch_f10["status"] == "PASS")
    if not f10_equal:
        all_passed = False
    results["f10_labels"] = {
        "status": "PASS" if f10_equal else "FAIL",
        "projected_data_fields": {
            "items_count": len(arch_f10["items"]) == len(g_f10["f10_items"]),
            "items_content_matched": f10_items_match
        },
        "verdict_boolean": arch_f10["status"] == "PASS",
        "excluded_prose_labels": {
            "check": arch_f10.get("check")
        }
    }

    # ------------------------------------------------------------------------
    # 7. census_spot_checks
    # ------------------------------------------------------------------------
    with open(os.path.join(r2_dir, "census_spot_checks.json")) as f:
        arch_csc = json.load(f)
    with open(os.path.join(jobs_dir, "job_census_spot_checks", "out.json")) as f:
        out_csc = json.load(f)
    g_csc = out_csc["globals"]
    checks = arch_csc["checks"]

    csc_checks_match = (
        checks["autocert_direct"]["build_line"] == 85 and
        checks["autocert_direct"]["build_enclosing_function"] == g_csc["build_fn"] and
        checks["autocert_direct"]["build_function_start"] == g_csc["build_fn_line"] and
        checks["autocert_direct"]["exec_line"] == 103 and
        checks["autocert_direct"]["exec_enclosing_function"] == g_csc["exec_fn"] and
        checks["autocert_direct"]["exec_function_start"] == g_csc["exec_fn_line"] and
        checks["autocert_direct"]["is_direct"] is True and

        checks["signal68_vs_regex522"]["signal68"]["kind"] == g_csc["signal_site68"]["kind"] and
        checks["signal68_vs_regex522"]["signal68"]["has_own_exec_evidence"] == (len(g_csc["signal_ev68"]) > 0) and
        checks["signal68_vs_regex522"]["signal68"]["exec_evidence_count"] == len(g_csc["signal_ev68"]) and
        checks["signal68_vs_regex522"]["regex522"]["kind"] == g_csc["regex_site522"]["kind"] and
        checks["signal68_vs_regex522"]["regex522"]["has_own_exec_evidence"] == (len(g_csc["regex_ev522"]) > 0) and
        checks["signal68_vs_regex522"]["regex522"]["exec_evidence_count"] == len(g_csc["regex_ev522"]) and
        checks["signal68_vs_regex522"]["verified"] is True and

        checks["positive_sites"]["all_positive_sites_have_evidence"] == all(v["has_exec_evidence"] for v in g_csc["positive_sites"].values()) and
        checks["fuzz_token"]["tokens"] == g_csc["fuzz_tokens"] and
        checks["fuzz_token"]["is_dollar_work_fuzz"] is True and

        checks["dns_verdicts"]["bad_verdict_lines_count"] == len(g_csc["dns_verdict_bad"]) and
        checks["dns_verdicts"]["bad_verdicts"] == g_csc["dns_verdict_bad"] and
        checks["dns_verdicts"]["all_have_failure_mark"] is True and

        checks["templates_and_pattern_vars"]["templates_with_shell_count"] == len(g_csc["templates_with_shell"]) and
        checks["templates_and_pattern_vars"]["templates_with_shell"] == g_csc["templates_with_shell"] and
        checks["templates_and_pattern_vars"]["total_pattern_vars"] == len(g_csc["pattern_vars"]) and
        checks["templates_and_pattern_vars"]["all_pattern_vars_have_reason_line"] == all(p["reason"] is not None for p in g_csc["pattern_vars"]) and
        checks["templates_and_pattern_vars"]["no_template_contains_dollar"] is True
    )

    csc_equal = csc_checks_match and (arch_csc["status"] == "PASS")
    if not csc_equal:
        all_passed = False
    results["census_spot_checks"] = {
        "status": "PASS" if csc_equal else "FAIL",
        "projected_data_fields": {
            "autocert_direct": True,
            "signal68_vs_regex522": True,
            "positive_sites": True,
            "fuzz_token": True,
            "dns_verdicts": True,
            "templates_and_pattern_vars": True
        },
        "verdict_boolean": arch_csc["status"] == "PASS",
        "excluded_prose_labels": {
            "section": arch_csc.get("section")
        }
    }

    # ------------------------------------------------------------------------
    # 8. f11_ast_scan
    # ------------------------------------------------------------------------
    with open(os.path.join(r2_dir, "f11_ast_scan.json")) as f:
        arch_f11 = json.load(f)
    with open(os.path.join(jobs_dir, "job_f11_ast_scan", "out.json")) as f:
        out_f11 = json.load(f)
    g_f11 = out_f11["globals"]

    f11_match = (arch_f11["modules_scanned"] == g_f11["modules_scanned"])
    total_setattr = 0
    total_harmful_monkeypatches = 0

    if f11_match:
        for mod in g_f11["modules_scanned"]:
            arch_det = arch_f11["file_details"][mod]
            re_det = g_f11["file_details"][mod]

            # setattr
            if [c["line"] for c in arch_det["setattr_calls"]] != [c["line"] for c in re_det["setattr_calls"]]:
                f11_match = False
                break
            if arch_det["setattr_count"] != len(re_det["setattr_calls"]):
                f11_match = False
                break
            total_setattr += len(re_det["setattr_calls"])

            # module attr
            arch_ma = [(m["line"], m["module"], m["attr"]) for m in arch_det["module_attribute_assignments"]]
            re_ma = [(m["line"], m["module"], m["attr"]) for m in re_det["module_attr_assigns"]]
            if arch_ma != re_ma:
                f11_match = False
                break
            if arch_det["module_attribute_assignments_count"] != len(re_det["module_attr_assigns"]):
                f11_match = False
                break
            total_harmful_monkeypatches += arch_det["harmful_module_monkeypatches_count"]

            # environ mutations
            arch_env = [(e["line"], e["op"]) for e in arch_det["environ_mutations"]]
            re_env = [(e["line"], e["op"]) for e in re_det["environ_ops"]]
            if arch_env != re_env:
                f11_match = False
                break
            if arch_det["environ_mutations_count"] != len(re_det["environ_ops"]):
                f11_match = False
                break

    f11_equal = (
        f11_match and
        arch_f11["total_setattr_calls"] == total_setattr == 0 and
        arch_f11["total_harmful_module_monkeypatches"] == total_harmful_monkeypatches == 0 and
        arch_f11["status"] == "PASS"
    )
    if not f11_equal:
        all_passed = False
    results["f11_ast_scan"] = {
        "status": "PASS" if f11_equal else "FAIL",
        "projected_data_fields": {
            "modules_scanned": arch_f11["modules_scanned"] == g_f11["modules_scanned"],
            "file_details_matched": f11_match,
            "total_setattr_calls": arch_f11["total_setattr_calls"] == 0,
            "total_harmful_module_monkeypatches": arch_f11["total_harmful_module_monkeypatches"] == 0
        },
        "verdict_boolean": arch_f11["status"] == "PASS",
        "excluded_prose_labels": {
            "check": arch_f11.get("check"),
            "environ_discipline_proof": arch_f11.get("environ_discipline_proof")
        }
    }

    final_report = {
        "overall_status": "PASS" if all_passed else "FAIL",
        "methods_checked_count": len(results),
        "methods_passed_count": sum(1 for r in results.values() if r["status"] == "PASS"),
        "results": results
    }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(final_report, f, indent=2, sort_keys=True)
        f.write("\n")

    print(f"Comparison completed: {final_report['methods_passed_count']}/{len(results)} PASS (Overall: {final_report['overall_status']})")
    sys.exit(0 if all_passed else 1)

if __name__ == "__main__":
    main()
