import ctypes as C, sys, time, json, bisect
out = sys.argv[1]
CS = C.CDLL("/System/Library/Frameworks/CoreServices.framework/CoreServices")
CF = C.CDLL("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
u64, vp = C.c_uint64, C.c_void_p
CF.CFStringCreateWithCString.restype = vp; CF.CFStringCreateWithCString.argtypes = [vp, C.c_char_p, C.c_uint32]
CF.CFArrayCreate.restype = vp; CF.CFArrayCreate.argtypes = [vp, C.POINTER(vp), C.c_long, vp]
CB = C.CFUNCTYPE(None, vp, vp, C.c_size_t, C.POINTER(C.c_char_p), C.POINTER(C.c_uint32), C.POINTER(u64))
CS.FSEventStreamCreate.restype = vp; CS.FSEventStreamCreate.argtypes = [vp, CB, vp, vp, u64, C.c_double, C.c_uint32]
CS.FSEventStreamScheduleWithRunLoop.argtypes = [vp, vp, vp]
CS.FSEventStreamStart.argtypes = [vp]; CS.FSEventStreamStart.restype = C.c_bool
for n in ("FSEventStreamStop", "FSEventStreamInvalidate", "FSEventStreamRelease"): getattr(CS, n).argtypes = [vp]
CF.CFRunLoopGetCurrent.restype = vp; CF.CFRunLoopRunInMode.argtypes = [vp, C.c_double, C.c_bool]
mode = vp.in_dll(CF, "kCFRunLoopDefaultMode"); cbs = C.addressof(C.c_char.in_dll(CF, "kCFTypeArrayCallBacks"))
ROOT = "/Users/jwaldrip/dev/worktrees"
T = {"P": ROOT + "/iyi-stale-integration-repair", "W2": ROOT + "/iyi-audit-deadlines-seams-20261030", "E": ROOT + "/iyi-stale-recovery-evidence-20261030"}
TB = {k: v.encode() for k, v in T.items()}
ev, ids, drops, st = [], [], [], {"done": False}
def cb(s, i, n, ps, fl, es):
    for j in range(n):
        f, e, p = fl[j], es[j], ps[j]
        if f & 0x10: st["done"] = True; continue          # HistoryDone
        ids.append(e)
        if f & 0x7: drops.append((e, f, p))               # MustScanSubDirs|UserDropped|KernelDropped
        for k, b in TB.items():
            if p == b or p.startswith(b + b"/"): ev.append((e, f, k, p.decode(errors="replace"))); break
cbf = CB(cb)
arr = CF.CFArrayCreate(None, (vp * 1)(CF.CFStringCreateWithCString(None, ROOT.encode(), 0x08000100)), 1, cbs)
s = CS.FSEventStreamCreate(None, cbf, None, arr, 0, 0.0, 0x10 | 0x02 | 0x80)  # FileEvents|NoDefer|FullHistory
CS.FSEventStreamScheduleWithRunLoop(s, CF.CFRunLoopGetCurrent(), mode); ok = CS.FSEventStreamStart(s); t0 = time.time()
while not st["done"] and time.time() - t0 < 2400: CF.CFRunLoopRunInMode(mode, 1.0, False)
CS.FSEventStreamStop(s); CS.FSEventStreamInvalidate(s); CS.FSEventStreamRelease(s)
ev.sort(); ids.sort()
spec = T["E"] + "/proof/recovery-20261030/audit-completion-6bbe-spec-v2.txt"
A = max([e for e, f, k, p in ev if p == spec and f & 0x100] or [0])
r = {"ok": ok, "history_done": st["done"], "events_all": len(ids), "anchor_A": A, "trees": {}}
for k in T:
    rem = [e for e, f, kk, p in ev if kk == k and f & 0x200 and e > A]; B = min(rem) if rem else None
    r["trees"][k] = {"removal_start": B,
        "window_events": [(e, hex(f), p[len(T[k]):] or "/") for e, f, kk, p in ev if kk == k and A < e and (B is None or e < B)],
        "all_events_in_window": bisect.bisect_left(ids, B) - bisect.bisect_right(ids, A) if B else None,
        "last_before_A": [(e, hex(f), p[len(T[k]):] or "/") for e, f, kk, p in ev if kk == k and e <= A][-5:]}
assert A and r["trees"]["P"]["removal_start"] and r["trees"]["W2"]["removal_start"], r
Bmin = min(r["trees"]["P"]["removal_start"], r["trees"]["W2"]["removal_start"])
r["drops_in_window"] = [(e, hex(f), p.decode(errors="replace")) for e, f, p in drops if A < e < Bmin]
json.dump(r, open(out, "x"), indent=1)
