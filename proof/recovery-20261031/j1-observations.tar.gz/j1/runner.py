import json
import subprocess
import sys
import time
from datetime import datetime, timezone

cmd = [
    "/opt/homebrew/bin/python3",
    "-B",
    "-X",
    "pycache_prefix=/private/tmp/iyi-proof-complete-6bbe1bf2e/pyc/j1",
    "/private/tmp/iyi-proof-complete-6bbe1bf2e/recovery/j1/fsevents_replay.py",
    "/private/tmp/iyi-proof-complete-6bbe1bf2e/recovery/j1/j1.json"
]

t0 = time.time()
t0_iso = datetime.now(timezone.utc).isoformat()
print(f"Starting execution at {t0_iso}", flush=True)

with open("/private/tmp/iyi-proof-complete-6bbe1bf2e/recovery/j1/stdout.log", "wb") as out_f, \
     open("/private/tmp/iyi-proof-complete-6bbe1bf2e/recovery/j1/stderr.log", "wb") as err_f:
    proc = subprocess.Popen(cmd, stdout=out_f, stderr=err_f)
    rc = proc.wait()

t1 = time.time()
t1_iso = datetime.now(timezone.utc).isoformat()
print(f"Finished execution at {t1_iso} with rc={rc}, duration={t1 - t0:.2f}s", flush=True)

record = {
    "argv": cmd,
    "start_time_utc": t0_iso,
    "start_time_epoch": t0,
    "end_time_utc": t1_iso,
    "end_time_epoch": t1,
    "duration_seconds": t1 - t0,
    "returncode": rc,
    "stdout_path": "/private/tmp/iyi-proof-complete-6bbe1bf2e/recovery/j1/stdout.log",
    "stderr_path": "/private/tmp/iyi-proof-complete-6bbe1bf2e/recovery/j1/stderr.log",
    "output_json": "/private/tmp/iyi-proof-complete-6bbe1bf2e/recovery/j1/j1.json"
}

with open("/private/tmp/iyi-proof-complete-6bbe1bf2e/recovery/j1/execution_record.json", "w") as f:
    json.dump(record, f, indent=2)

sys.exit(rc)
