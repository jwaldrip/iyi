#!/usr/bin/env python3
import os
import sys
import json
import time
import subprocess
import hashlib
from datetime import datetime, timezone

PRIMARY = "/Users/jwaldrip/dev/src/github.com/jwaldrip/iyi"
P = "/Users/jwaldrip/dev/worktrees/iyi-stale-integration-repair"
P1 = "626463375298d357ffcb3223059f4d3adce6fb10"
RV2 = "/private/tmp/iyi-proof-complete-6bbe1bf2e"
RECOVERY = os.path.join(RV2, "recovery")
S3_AUX = os.path.join(RECOVERY, "s3_aux")
M1_PATH = "/private/tmp/iyi-parent-evidence-3ef29279-recovered/p1-binaries.json"
CACHE_DIR = "/private/tmp/iyi-p1-rebuild-20261031-cache"

os.makedirs(S3_AUX, exist_ok=True)

print("=== Stage 3: Rebuilding P1 Binaries as M2 ===")

# --- Step 1: Precondition Checks ---
print("[1/6] Verifying amended preconditions...")
preconditions = {}

# 1.1 Lease 21214 live
try:
    ps_out = subprocess.check_output(["ps", "-p", "21214", "-o", "pid,lstart,command"]).decode().strip()
    lsof_out = subprocess.check_output(["lsof", "-n", "-P", "-w", "-a", "-p", "21214", "-d", "cwd", "-Fn"]).decode().strip()
    lease_ok = (f"n{P}" in lsof_out)
    preconditions["lease_21214"] = {
        "status": "PASS" if lease_ok else "FAIL",
        "ps": ps_out,
        "lsof_cwd": lsof_out,
        "cwd_matches_P": lease_ok
    }
except Exception as e:
    preconditions["lease_21214"] = {"status": "FAIL", "error": str(e)}
assert preconditions["lease_21214"]["status"] == "PASS", f"Lease 21214 check failed: {preconditions['lease_21214']}"

# 1.2 P HEAD == P1, clean tracked tree
git_env = {"GIT_OPTIONAL_LOCKS": "0"}
head_sha = subprocess.check_output(["git", "-C", P, "rev-parse", "HEAD"], env=git_env).decode().strip()
porcelain_status = subprocess.check_output(["git", "-C", P, "status", "--porcelain=v1", "--untracked-files=all"], env=git_env).decode().strip()
preconditions["p_git"] = {
    "status": "PASS" if (head_sha == P1 and len(porcelain_status) == 0) else "FAIL",
    "head": head_sha,
    "head_equals_P1": (head_sha == P1),
    "porcelain_empty": (len(porcelain_status) == 0),
    "porcelain_output": porcelain_status
}
assert preconditions["p_git"]["status"] == "PASS", f"P git status check failed: {preconditions['p_git']}"

# 1.3 Ignored files: 9 files matching primary sha, nlink == 1, different inodes
ignored_list = subprocess.check_output(["git", "-C", P, "ls-files", "--others", "--ignored", "--exclude-standard"], env=git_env).decode().strip().splitlines()
ignored_list.sort()
expected_9 = [
    ".build/.library-path",
    ".build/crystal",
    ".build/crystal.dwarf",
    ".build/iyi",
    ".build/iyi.dwarf",
    "bench/__pycache__/doc_numbers.cpython-314.pyc",
    "files.dwarf",
    "hello.dwarf",
    "std_process_exercise.dwarf"
]
expected_9.sort()
ignored_matches = (ignored_list == expected_9)

file_checks = {}
all_files_safe = True
for rel in ignored_list:
    p_f = os.path.join(P, rel)
    prim_f = os.path.join(PRIMARY, rel)
    p_st = os.stat(p_f)
    prim_st = os.stat(prim_f)
    p_sha = hashlib.sha256(open(p_f, "rb").read()).hexdigest()
    prim_sha = hashlib.sha256(open(prim_f, "rb").read()).hexdigest()
    
    ok = (p_st.st_nlink == 1 and p_st.st_ino != prim_st.st_ino and p_sha == prim_sha)
    if not ok:
        all_files_safe = False
    file_checks[rel] = {
        "p_inode": p_st.st_ino,
        "prim_inode": prim_st.st_ino,
        "different_inode": (p_st.st_ino != prim_st.st_ino),
        "p_nlink": p_st.st_nlink,
        "p_size": p_st.st_size,
        "prim_size": prim_st.st_size,
        "p_mtime_ns": p_st.st_mtime_ns,
        "prim_mtime_ns": prim_st.st_mtime_ns,
        "p_sha256": p_sha,
        "prim_sha256": prim_sha,
        "sha_matches_primary": (p_sha == prim_sha)
    }

preconditions["ignored_files"] = {
    "status": "PASS" if (ignored_matches and all_files_safe) else "FAIL",
    "ignored_list": ignored_list,
    "matches_expected_9": ignored_matches,
    "all_files_safe": all_files_safe,
    "details": file_checks
}
assert preconditions["ignored_files"]["status"] == "PASS", f"Ignored files check failed: {preconditions['ignored_files']}"

# 1.4 Bootstrap crystal check
b_crystal = file_checks[".build/crystal"]
b_crystal_ok = (
    b_crystal["p_sha256"] == "756d3c4b00332a52354e530139c837adfb0283df01b59a67a11ca7be8d0f9ab5" and
    b_crystal["p_size"] == 38309704 and
    b_crystal["p_nlink"] == 1 and
    b_crystal["p_inode"] != 18014325
)
preconditions["bootstrap_crystal"] = {
    "status": "PASS" if b_crystal_ok else "FAIL",
    "sha256": b_crystal["p_sha256"],
    "size": b_crystal["p_size"],
    "nlink": b_crystal["p_nlink"],
    "inode": b_crystal["p_inode"]
}
assert preconditions["bootstrap_crystal"]["status"] == "PASS", f"Bootstrap crystal check failed: {preconditions['bootstrap_crystal']}"

# 1.5 Fresh cache absent
cache_absent = not os.path.exists(CACHE_DIR)
preconditions["cache_absent"] = {
    "status": "PASS" if cache_absent else "FAIL",
    "cache_dir": CACHE_DIR,
    "exists": not cache_absent
}
assert preconditions["cache_absent"]["status"] == "PASS", f"Cache dir check failed: {CACHE_DIR} exists!"

# 1.6 LLVM version
llvm_ver = subprocess.check_output(["llvm-config", "--version"]).decode().strip()
preconditions["llvm_version"] = {
    "status": "PASS" if llvm_ver == "22.1.8" else "FAIL",
    "version": llvm_ver
}
assert preconditions["llvm_version"]["status"] == "PASS", f"LLVM version check failed: {llvm_ver}"

with open(os.path.join(S3_AUX, "preconditions.json"), "w") as f:
    json.dump(preconditions, f, indent=2)

with open(os.path.join(S3_AUX, "p_git_status_before.json"), "w") as f:
    json.dump({"head": head_sha, "porcelain": porcelain_status, "ignored": ignored_list}, f, indent=2)

print("Preconditions PASS.")

# --- Step 2: Dry Run Guard (make -n) ---
print("[2/6] Running dry-run guard (make -n)...")
build_env = dict(os.environ)
for k in ["IYI_PATH", "CRYSTAL_PATH", "IYI_CACHE_DIR", "IYI_OPTS", "CRYSTAL_OPTS", "IYI_WARM", "IYI_DAEMON_SOCKET", "CRYSTAL_DAEMON_SOCKET"]:
    build_env.pop(k, None)
build_env["LIBRARY_PATH"] = "/opt/homebrew/opt/bdw-gc/lib"
build_env["PKG_CONFIG_PATH"] = "/opt/homebrew/opt/openssl@3/lib/pkgconfig"
build_env["CRYSTAL_CACHE_DIR"] = CACHE_DIR

dry_cmd = ["make", "-n", "iyi", "crystal", "iyi-daemon", "crystal-daemon"]
dry_proc = subprocess.run(dry_cmd, cwd=P, env=build_env, capture_output=True, text=True)

with open(os.path.join(S3_AUX, "dry_run_stdout.txt"), "w") as f:
    f.write(dry_proc.stdout)
with open(os.path.join(S3_AUX, "dry_run_stderr.txt"), "w") as f:
    f.write(dry_proc.stderr)

assert dry_proc.returncode == 0, f"make -n failed with rc={dry_proc.returncode}"
assert "is up to date" not in dry_proc.stdout, "make -n reported 'is up to date'!"
assert "is up to date" not in dry_proc.stderr, "make -n reported 'is up to date' in stderr!"

# Verify all 4 build commands are present
for target in ["iyi", "crystal", "iyi-daemon", "crystal-daemon"]:
    expected_out = f"-o .build/{target}"
    assert expected_out in dry_proc.stdout, f"make -n missing build command for {target} (-o .build/{target})"

dry_run_info = {
    "command": dry_cmd,
    "rc": dry_proc.returncode,
    "stdout_len": len(dry_proc.stdout),
    "stderr_len": len(dry_proc.stderr),
    "targets_verified": ["iyi", "crystal", "iyi-daemon", "crystal-daemon"]
}
with open(os.path.join(S3_AUX, "dry_run.json"), "w") as f:
    json.dump(dry_run_info, f, indent=2)

print("Dry-run guard PASS: all 4 build commands present, no 'up to date'.")

# Ensure fresh cache is completely absent before make starts
if os.path.exists(CACHE_DIR):
    if os.path.isdir(CACHE_DIR) and len(os.listdir(CACHE_DIR)) == 0:
        os.rmdir(CACHE_DIR)
assert not os.path.exists(CACHE_DIR), f"Fresh cache directory {CACHE_DIR} must not exist before make!"

# --- Step 3: Execute ONE same-P1 make ---
print("[3/6] Executing make iyi crystal iyi-daemon crystal-daemon...")
build_log_path = os.path.join(RECOVERY, "build-m2.log")

statvfs_before = os.statvfs("/private/tmp")
free_bytes_before = statvfs_before.f_bavail * statvfs_before.f_frsize

make_argv = ["make", "iyi", "crystal", "iyi-daemon", "crystal-daemon"]
make_start_utc = datetime.now(timezone.utc).isoformat()
make_start_epoch_ns = time.time_ns()
make_start_monotonic_ns = time.monotonic_ns()

with open(build_log_path, "wb") as log_file:
    # We flush immediately and combine stdout and stderr so shape matches build.log
    proc = subprocess.Popen(
        make_argv,
        cwd=P,
        env=build_env,
        stdin=subprocess.DEVNULL,
        stdout=log_file,
        stderr=subprocess.STDOUT
    )
    rc = proc.wait()
    log_file.flush()
    os.fsync(log_file.fileno())
make_end_utc = datetime.now(timezone.utc).isoformat()
make_end_epoch_ns = time.time_ns()
make_end_monotonic_ns = time.monotonic_ns()
elapsed_sec = (make_end_monotonic_ns - make_start_monotonic_ns) / 1e9

statvfs_after = os.statvfs("/private/tmp")
free_bytes_after = statvfs_after.f_bavail * statvfs_after.f_frsize

print(f"Make completed with rc={rc} in {elapsed_sec:.2f}s")
assert rc == 0, f"make failed with returncode {rc}! Check {build_log_path}"

# --- Step 4: Inspect, stat, hash, and --version each binary ---
print("[4/6] Inspecting and verifying produced binaries...")
with open(M1_PATH) as f:
    m1_list = json.load(f)
m1_by_name = {item["name"]: item for item in m1_list}

m2_list = []
raw_versions = {}
comparisons = {}

for name in ["iyi", "crystal", "iyi-daemon", "crystal-daemon"]:
    bin_path = os.path.join(P, ".build", name)
    assert os.path.exists(bin_path), f"Binary does not exist: {bin_path}"
    
    st = os.stat(bin_path)
    # Check mtime_ns > make_start_epoch_ns
    assert st.st_mtime_ns > make_start_epoch_ns, f"{name} mtime {st.st_mtime_ns} <= make start {make_start_epoch_ns}"
    
    with open(bin_path, "rb") as bf:
        bin_data = bf.read()
    sha256 = hashlib.sha256(bin_data).hexdigest()
    
    # Run --version
    ver_proc = subprocess.run([bin_path, "--version"], capture_output=True, text=True)
    raw_versions[name] = {
        "rc": ver_proc.returncode,
        "stdout": ver_proc.stdout,
        "stderr": ver_proc.stderr
    }
    assert ver_proc.returncode == 0, f"{name} --version returned rc={ver_proc.returncode}"
    
    # Byte-equal version check against M1
    m1_item = m1_by_name[name]
    m1_stdout = m1_item["stdout"]
    if ver_proc.stdout != m1_stdout:
        print(f"FATAL: {name} --version stdout mismatch!")
        print("M2 stdout:", repr(ver_proc.stdout))
        print("M1 stdout:", repr(m1_stdout))
        sys.exit(4)
    
    sha_equals = (sha256 == m1_item["sha256"])
    size_equals = (st.st_size == m1_item["size"])
    version_equals = (ver_proc.stdout == m1_stdout)
    
    comparisons[name] = {
        "m1_sha256": m1_item["sha256"],
        "m2_sha256": sha256,
        "sha_equals": sha_equals,
        "m1_size": m1_item["size"],
        "m2_size": st.st_size,
        "size_equals": size_equals,
        "m1_inode": m1_item["inode"],
        "m2_inode": st.st_ino,
        "m1_mtime_ns": m1_item["mtime_ns"],
        "m2_mtime_ns": st.st_mtime_ns,
        "version_equals": version_equals
    }
    
    m2_entry = {
        "name": name,
        "sha256": sha256,
        "size": st.st_size,
        "mtime_ns": st.st_mtime_ns,
        "inode": st.st_ino,
        "rc": ver_proc.returncode,
        "stdout": ver_proc.stdout,
        "stderr": ver_proc.stderr,
        "sha256_equals_m1": sha_equals,
        "size_equals_m1": size_equals,
        "version_stdout_equals_m1": version_equals,
        "sha_equals": sha_equals,
        "size_equals": size_equals,
        "version_equals": version_equals
    }
    m2_list.append(m2_entry)

# Write p1-binaries-m2.json
m2_path = os.path.join(RECOVERY, "p1-binaries-m2.json")
with open(m2_path, "w") as f:
    json.dump(m2_list, f, indent=2)

with open(os.path.join(S3_AUX, "raw_version_outputs.json"), "w") as f:
    json.dump(raw_versions, f, indent=2)

with open(os.path.join(S3_AUX, "m1_comparison.json"), "w") as f:
    json.dump(comparisons, f, indent=2)

print("Binary verification PASS: all 4 stdouts byte-equal to M1.")

# --- Step 5: Post-build Git Status Check ---
print("[5/6] Verifying P post-build git status...")
post_head = subprocess.check_output(["git", "-C", P, "rev-parse", "HEAD"], env=git_env).decode().strip()
post_porcelain = subprocess.check_output(["git", "-C", P, "status", "--porcelain=v1", "--untracked-files=all"], env=git_env).decode().strip()
post_ignored = subprocess.check_output(["git", "-C", P, "ls-files", "--others", "--ignored", "--exclude-standard"], env=git_env).decode().strip().splitlines()
post_ignored.sort()

assert post_head == P1, f"P HEAD changed! {post_head} != {P1}"
assert len(post_porcelain) == 0, f"P porcelain is not empty after build: {post_porcelain}"

with open(os.path.join(S3_AUX, "p_git_status_after.json"), "w") as f:
    json.dump({"head": post_head, "porcelain": post_porcelain, "ignored": post_ignored}, f, indent=2)

print("P git status PASS: porcelain is clean.")

# --- Step 6: Write build-m2-receipts.json ---
print("[6/6] Writing build-m2-receipts.json...")
toolchain_info = {
    "llvm_config_version": llvm_ver,
    "make_path": "/usr/bin/make",
    "crystal_bootstrap_sha256": b_crystal["p_sha256"],
    "crystal_bootstrap_size": b_crystal["p_size"],
    "crystal_bootstrap_inode": b_crystal["p_inode"]
}

receipts_data = {
    "candidate": "6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd",
    "p1_sha": P1,
    "worktree": P,
    "command": "make iyi crystal iyi-daemon crystal-daemon",
    "argv": make_argv,
    "cwd": P,
    "env_unsets": [
        "IYI_PATH", "CRYSTAL_PATH", "IYI_CACHE_DIR", "IYI_OPTS",
        "CRYSTAL_OPTS", "IYI_WARM", "IYI_DAEMON_SOCKET", "CRYSTAL_DAEMON_SOCKET"
    ],
    "env_sets": {
        "LIBRARY_PATH": "/opt/homebrew/opt/bdw-gc/lib",
        "PKG_CONFIG_PATH": "/opt/homebrew/opt/openssl@3/lib/pkgconfig",
        "CRYSTAL_CACHE_DIR": CACHE_DIR
    },
    "start_utc": make_start_utc,
    "start_epoch_ns": make_start_epoch_ns,
    "start_monotonic_ns": make_start_monotonic_ns,
    "end_utc": make_end_utc,
    "end_epoch_ns": make_end_epoch_ns,
    "end_monotonic_ns": make_end_monotonic_ns,
    "elapsed_sec": elapsed_sec,
    "rc": rc,
    "free_bytes_before": free_bytes_before,
    "free_bytes_after": free_bytes_after,
    "build_log": build_log_path,
    "build_log_size": os.stat(build_log_path).st_size,
    "build_log_sha256": hashlib.sha256(open(build_log_path, "rb").read()).hexdigest(),
    "binaries_manifest": m2_path,
    "binaries": m2_list,
    "toolchain": toolchain_info,
    "preconditions": preconditions,
    "dry_run": dry_run_info,
    "comparisons": comparisons,
    "prebuild_ignored_metadata_file": os.path.join(S3_AUX, "prebuild_ignored_metadata.json")
}

receipts_path = os.path.join(RECOVERY, "build-m2-receipts.json")
with open(receipts_path, "w") as f:
    json.dump(receipts_data, f, indent=2)

print(f"Receipts successfully written to {receipts_path}")
print("=== S3 Rebuild Execution Completed Successfully ===")
