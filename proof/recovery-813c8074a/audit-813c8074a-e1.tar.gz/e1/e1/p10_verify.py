#!/usr/bin/env python3
"""P10 verification script for E1 coverage.
Checks:
1. Each hard-coded P10 line / code excerpt equals git show H':<module> at that line.
2. analyze.py allowlist_spans equal the ALLOWLIST value parsed by AST from the H' clone.
3. p10.json has 7 rows, none forbidden, CLI refusals labelled.
"""

import os
import sys
import json
import ast
import textwrap
import subprocess

RV3 = "/private/tmp/iyi-proof-complete-813c8074a"
H_PRIME = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
W3 = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
CLONE_DIR = os.path.join(RV3, "c", "cov")
P10_JSON_PATH = os.path.join(RV3, "e1", "p10.json")
ANALYZE_PY_PATH = os.path.join(RV3, "tools", "e1", "analyze.py")
OUT_JSON_PATH = os.path.join(RV3, "e1", "p10_verify.json")

def git_show(rel_path):
    # Use clone if available, else W3
    target_repo = CLONE_DIR if os.path.exists(CLONE_DIR) else W3
    cmd = ["git", "-C", target_repo, "show", f"{H_PRIME}:{rel_path}"]
    env = dict(os.environ)
    env["GIT_OPTIONAL_LOCKS"] = "0"
    return subprocess.check_output(cmd, env=env).decode("utf-8").splitlines()

def main():
    print("Starting P10 verification against H'...")
    errors = []

    # 1. Parse ALLOWLIST from smoke_test.py in the H' clone via AST
    smoke_test_source_path = os.path.join(CLONE_DIR, "proof", "smoke_test.py") if os.path.exists(CLONE_DIR) else os.path.join(W3, "proof", "smoke_test.py")
    with open(smoke_test_source_path, "r", encoding="utf-8") as f:
        smoke_tree = ast.parse(f.read(), filename=smoke_test_source_path)

    allowlist_ast = None
    for node in smoke_tree.body:
        if isinstance(node, ast.AnnAssign) and getattr(node.target, "id", None) == "ALLOWLIST":
            allowlist_ast = ast.literal_eval(node.value)
            break
        elif isinstance(node, ast.Assign):
            for t in node.targets:
                if getattr(t, "id", None) == "ALLOWLIST":
                    allowlist_ast = ast.literal_eval(node.value)
                    break

    if allowlist_ast is None:
        print("ERROR: ALLOWLIST not found in smoke_test.py AST", file=sys.stderr)
        sys.exit(1)

    print(f"Parsed ALLOWLIST via AST: {len(allowlist_ast)} entries")

    # 2. Extract allowlist_spans from analyze.py via AST
    if not os.path.exists(ANALYZE_PY_PATH):
        print(f"ERROR: {ANALYZE_PY_PATH} not found", file=sys.stderr)
        sys.exit(1)

    with open(ANALYZE_PY_PATH, "r", encoding="utf-8") as f:
        analyze_tree = ast.parse(f.read(), filename=ANALYZE_PY_PATH)

    analyze_allowlist_spans = None
    for node in ast.walk(analyze_tree):
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if getattr(t, "id", None) == "allowlist_spans":
                    analyze_allowlist_spans = ast.literal_eval(node.value)
                    break

    if analyze_allowlist_spans is None:
        print("ERROR: allowlist_spans not found in analyze.py AST", file=sys.stderr)
        sys.exit(1)

    expected_spans = [(m, s, e, fx) for m, s, e, fx, obs in allowlist_ast]
    spans_equal = (analyze_allowlist_spans == expected_spans)
    if not spans_equal:
        errors.append(f"allowlist_spans mismatch: {analyze_allowlist_spans} != {expected_spans}")
    else:
        print("analyze.py allowlist_spans == ALLOWLIST value from H' clone AST: MATCH")

    # 3. Read p10.json
    if not os.path.exists(P10_JSON_PATH):
        print(f"ERROR: {P10_JSON_PATH} not found", file=sys.stderr)
        sys.exit(1)

    with open(P10_JSON_PATH, "r", encoding="utf-8") as f:
        p10_entries = json.load(f)

    if len(p10_entries) != 7:
        errors.append(f"p10.json has {len(p10_entries)} rows; expected 7")

    module_sources = {
        "proof.roundtrip_shim": git_show("proof/roundtrip_shim.py"),
        "proof.run_proof": git_show("proof/run_proof.py"),
        "proof.artifact_legs": git_show("proof/artifact_legs.py"),
    }

    statement_verifications = []
    for i, entry in enumerate(p10_entries):
        idx = entry.get("entry_index", i + 1)
        mod = entry.get("module")
        span = entry.get("span")
        fx_id = entry.get("fixture_id")
        obs_text = entry.get("observable_text")
        forbidden = entry.get("contains_forbidden_decision_code", False)

        if forbidden:
            errors.append(f"Entry {idx} ({mod}:{span}) marked contains_forbidden_decision_code=True")

        if i < len(allowlist_ast):
            al_mod, al_s, al_e, al_fx, al_obs = allowlist_ast[i]
            if mod != al_mod or span != [al_s, al_e] or fx_id != al_fx or obs_text != al_obs:
                errors.append(f"Entry {idx} metadata does not match ALLOWLIST[{i}]")

        mod_lines = module_sources.get(mod)
        if mod_lines is None:
            errors.append(f"Entry {idx} unknown module: {mod}")
            continue

        for s_idx, s in enumerate(entry.get("statements", [])):
            classification = s.get("classification")
            if classification not in ("glue", "CLI refusal"):
                errors.append(f"Entry {idx} statement {s_idx} has invalid classification: {classification}")

            if "line" in s:
                line_no = s["line"]
                actual = mod_lines[line_no - 1].strip()
                expected = s["code"].strip()
                match = (actual == expected)
                if not match:
                    errors.append(f"Entry {idx} line {line_no} mismatch: {actual!r} != {expected!r}")
                statement_verifications.append({
                    "entry_index": idx,
                    "module": mod,
                    "line": line_no,
                    "actual": actual,
                    "expected": expected,
                    "classification": classification,
                    "match": match
                })
            elif "lines" in s:
                start, end = s["lines"]
                actual_lines = [mod_lines[l - 1] for l in range(start, end + 1)]
                src_dedent = textwrap.dedent("\n".join(actual_lines))
                src_ast = ast.dump(ast.parse(src_dedent))

                code = s["code"]
                code_fixed = code.replace("; if ", "\nif ")
                ex_ast = ast.dump(ast.parse(code_fixed))
                match = (src_ast == ex_ast)
                if not match:
                    errors.append(f"Entry {idx} lines {start}-{end} AST mismatch")
                statement_verifications.append({
                    "entry_index": idx,
                    "module": mod,
                    "lines": [start, end],
                    "code": code,
                    "classification": classification,
                    "match": match
                })

    all_statements_match = all(sv["match"] for sv in statement_verifications) and (len(errors) == 0)

    result_data = {
        "status": "PASS" if all_statements_match else "FAIL",
        "allowlist_spans_equal": spans_equal,
        "p10_row_count": len(p10_entries),
        "none_forbidden": all(not e.get("contains_forbidden_decision_code", False) for e in p10_entries),
        "all_statements_match": all_statements_match,
        "statement_verifications": statement_verifications,
        "errors": errors
    }

    with open(OUT_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(result_data, f, indent=2)

    print("Wrote:", OUT_JSON_PATH)

    if errors:
        print("VERIFICATION FAILED:")
        for err in errors:
            print("  -", err)
        sys.exit(1)

    print("p10_verify all equal: PASS")
    sys.exit(0)

if __name__ == "__main__":
    main()
