#!/usr/bin/env python3
"""E2a Orchestrator: runs Seed and Control legs through receipt.py with fresh clones.

Produces:
- RV2/e2/seed5/seed/ with receipt and copied fixture artifacts
- RV2/e2/seed5/control/ with receipt and copied fixture artifacts
- RV2/e2/seed5/receipts.jsonl (2 fsynced lines)
- RV2/e2/seed5/raw_stub_diff.patch (exact one added sleep 30 line)
- RV2/e2/seed5/derived_census_diff.json (census diff and verification against _stage_driver_census)
- RV2/e2/seed5/e2a_summary.json (comprehensive execution and verification record)
"""
import difflib
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
sys.dont_write_bytecode = True
PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
W2 = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
H = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
RV2 = "/private/tmp/iyi-proof-complete-813c8074a"
RECEIPT_PY = os.path.join(RV2, "receipt.py")
EXPECTED_RECEIPT_SHA = "1f6c1647de8f1fa7acb21ebf607b139f6f1331c35b9640f0e7cb822edff83cff"
SEED5_DIR = os.path.join(RV2, "e2", "seed5")
DRIVER_PY = os.path.join(SEED5_DIR, "e2a_driver.py")


def compute_sha256(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def run_command(cmd: list[str], *, cwd: str | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        cwd=cwd,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        check=False,
    )


def main():
    print(f"=== E2a ManualSeed5 Leg Orchestration starting at {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} ===")

    # 1. Preflight checks
    stat = os.statvfs("/private/tmp")
    free_bytes = stat.f_bavail * stat.f_frsize
    free_gb = free_bytes / (1024**3)
    print(f"Free space on /private/tmp: {free_gb:.2f} GiB")
    assert free_bytes >= 20 * 1024 * 1024 * 1024, "Free space below 20 GiB hard floor!"

    receipt_sha = compute_sha256(RECEIPT_PY)
    print(f"RV2/receipt.py sha256: {receipt_sha}")
    assert receipt_sha == EXPECTED_RECEIPT_SHA, f"receipt.py sha {receipt_sha} != {EXPECTED_RECEIPT_SHA}"

    driver_sha = compute_sha256(DRIVER_PY)
    print(f"RV2/e2/seed5/e2a_driver.py sha256: {driver_sha}")

    w2_head = run_command(["git", "-C", W2, "rev-parse", "HEAD"]).stdout.strip()
    print(f"W2 HEAD: {w2_head}")
    assert w2_head == H, f"W2 HEAD {w2_head} != {H}"

    seed_job_dir = os.path.join(SEED5_DIR, "seed")
    control_job_dir = os.path.join(SEED5_DIR, "control")
    assert not os.path.exists(seed_job_dir), f"{seed_job_dir} already exists!"
    assert not os.path.exists(control_job_dir), f"{control_job_dir} already exists!"

    # 2. SEED LEG
    seed_clone_dir = os.path.join(RV2, "c", "e2a-seed")
    seed_pyc_dir = os.path.join(RV2, "pyc", "e2a-seed")
    if os.path.exists(seed_clone_dir):
        shutil.rmtree(seed_clone_dir)
    if os.path.exists(seed_pyc_dir):
        shutil.rmtree(seed_pyc_dir)

    print(f"\n--- Creating fresh clone for SEED at {seed_clone_dir} ---")
    clone_res = run_command(["git", "clone", "--no-hardlinks", "--quiet", W2, seed_clone_dir])
    assert clone_res.returncode == 0, f"git clone failed: {clone_res.stderr}"

    checkout_res = run_command(["git", "-C", seed_clone_dir, "checkout", "--quiet", "--detach", H])
    assert checkout_res.returncode == 0, f"git checkout failed: {checkout_res.stderr}"

    head_res = run_command(["git", "-C", seed_clone_dir, "rev-parse", "HEAD"]).stdout.strip()
    assert head_res == H, f"Clone HEAD {head_res} != {H}"

    status_res = run_command(["git", "-C", seed_clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).stdout.strip()
    assert status_res == "", f"Clone status not empty: {status_res}"
    print("Seed clone verified clean at H.")

    print("\n--- Executing SEED job through receipt.py ---")
    seed_cmd = [
        PY, "-B", RECEIPT_PY,
        seed_job_dir,
        seed_clone_dir,
        "--",
        PY, "-B",
        f"-Xpycache_prefix={seed_pyc_dir}",
        DRIVER_PY,
        "--mode", "seed",
        "--job-dir", seed_job_dir,
    ]
    t0_seed = time.time()
    seed_proc = run_command(seed_cmd)
    t1_seed = time.time()
    print(f"Seed job finished in {t1_seed - t0_seed:.2f}s with rc={seed_proc.returncode} (expected rc=1)")
    assert seed_proc.returncode == 1, f"Seed job expected rc 1, got {seed_proc.returncode}\nstdout:\n{seed_proc.stdout}\nstderr:\n{seed_proc.stderr}"

    # Record clone porcelain
    clone_status_seed = run_command(["git", "-C", seed_clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).stdout
    with open(os.path.join(seed_job_dir, "clone_porcelain.txt"), "w", encoding="utf-8") as f:
        f.write(clone_status_seed)
    print("Recorded seed clone porcelain. Removing seed clone...")
    shutil.rmtree(seed_clone_dir)
    if os.path.exists(seed_pyc_dir):
        shutil.rmtree(seed_pyc_dir)
    print("Seed clone removed.")

    # 3. CONTROL LEG
    control_clone_dir = os.path.join(RV2, "c", "e2a-control")
    control_pyc_dir = os.path.join(RV2, "pyc", "e2a-control")
    if os.path.exists(control_clone_dir):
        shutil.rmtree(control_clone_dir)
    if os.path.exists(control_pyc_dir):
        shutil.rmtree(control_pyc_dir)

    print(f"\n--- Creating fresh clone for CONTROL at {control_clone_dir} ---")
    clone_res = run_command(["git", "clone", "--no-hardlinks", "--quiet", W2, control_clone_dir])
    assert clone_res.returncode == 0, f"git clone failed: {clone_res.stderr}"

    checkout_res = run_command(["git", "-C", control_clone_dir, "checkout", "--quiet", "--detach", H])
    assert checkout_res.returncode == 0, f"git checkout failed: {checkout_res.stderr}"

    head_res = run_command(["git", "-C", control_clone_dir, "rev-parse", "HEAD"]).stdout.strip()
    assert head_res == H, f"Clone HEAD {head_res} != {H}"

    status_res = run_command(["git", "-C", control_clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).stdout.strip()
    assert status_res == "", f"Clone status not empty: {status_res}"
    print("Control clone verified clean at H.")

    print("\n--- Executing CONTROL job through receipt.py ---")
    control_cmd = [
        PY, "-B", RECEIPT_PY,
        control_job_dir,
        control_clone_dir,
        "--",
        PY, "-B",
        f"-Xpycache_prefix={control_pyc_dir}",
        DRIVER_PY,
        "--mode", "control",
        "--job-dir", control_job_dir,
    ]
    t0_control = time.time()
    control_proc = run_command(control_cmd)
    t1_control = time.time()
    print(f"Control job finished in {t1_control - t0_control:.2f}s with rc={control_proc.returncode} (expected rc=0)")
    assert control_proc.returncode == 0, f"Control job expected rc 0, got {control_proc.returncode}\nstdout:\n{control_proc.stdout}\nstderr:\n{control_proc.stderr}"

    # Record clone porcelain
    clone_status_control = run_command(["git", "-C", control_clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).stdout
    with open(os.path.join(control_job_dir, "clone_porcelain.txt"), "w", encoding="utf-8") as f:
        f.write(clone_status_control)
    print("Recorded control clone porcelain. Removing control clone...")
    shutil.rmtree(control_clone_dir)
    if os.path.exists(control_pyc_dir):
        shutil.rmtree(control_pyc_dir)
    print("Control clone removed.")

    # 4. Comparative Analysis and Diffs
    print("\n--- Computing comparative diffs and verification ---")
    ctl_script_path = os.path.join(control_job_dir, "std_stage_exercise.sh")
    seed_script_path = os.path.join(seed_job_dir, "std_stage_exercise.sh")

    with open(ctl_script_path, "r", encoding="utf-8") as f:
        ctl_lines = f.readlines()
    with open(seed_script_path, "r", encoding="utf-8") as f:
        seed_lines = f.readlines()

    diff_lines = list(
        difflib.unified_diff(
            ctl_lines,
            seed_lines,
            fromfile="control/std_stage_exercise.sh",
            tofile="seed/std_stage_exercise.sh",
        )
    )
    diff_text = "".join(diff_lines)
    patch_path = os.path.join(SEED5_DIR, "raw_stub_diff.patch")
    with open(patch_path, "w", encoding="utf-8") as f:
        f.write(diff_text)

    added_lines = [l for l in diff_lines if l.startswith("+") and not l.startswith("+++")]
    removed_lines = [l for l in diff_lines if l.startswith("-") and not l.startswith("---")]
    print(f"Raw stub diff lines added: {added_lines}")
    print(f"Raw stub diff lines removed: {removed_lines}")
    assert added_lines == ["+sleep 30\n"], f"Unexpected added lines: {added_lines}"
    assert removed_lines == [], f"Unexpected removed lines: {removed_lines}"
    print("Raw stub diff between control and seed is EXACTLY one added 'sleep 30' line.")

    # Census comparison
    ctl_census_path = os.path.join(control_job_dir, "stage.json")
    seed_census_path = os.path.join(seed_job_dir, "stage.json")
    with open(ctl_census_path, "r", encoding="utf-8") as f:
        ctl_census = json.load(f)
    with open(seed_census_path, "r", encoding="utf-8") as f:
        seed_census = json.load(f)

    sys.path.insert(0, W2)
    import proof.smoke_test as smoke_test

    ctl_script_bytes_derived, ctl_census_derived = smoke_test._stage_driver_census("stage", "control")
    seed_script_bytes_derived, seed_census_derived = smoke_test._stage_driver_census("stage", "driver-timeout")

    assert ctl_census == ctl_census_derived, "Control stage.json does not equal derived census"
    assert seed_census == seed_census_derived, "Seed stage.json does not equal derived census"

    census_field_diff = {}
    for k in set(ctl_census) | set(seed_census):
        if ctl_census.get(k) != seed_census.get(k):
            census_field_diff[k] = {
                "control": ctl_census.get(k),
                "seed": seed_census.get(k),
            }

    census_diff_record = {
        "control_equals_derived": True,
        "seed_equals_derived": True,
        "diff_keys": sorted(census_field_diff.keys()),
        "field_diff": census_field_diff,
    }
    census_diff_path = os.path.join(SEED5_DIR, "derived_census_diff.json")
    with open(census_diff_path, "w", encoding="utf-8") as f:
        json.dump(census_diff_record, f, indent=2, sort_keys=True)
        f.write("\n")
    print("Census verification and field diff recorded.")

    # Load assertions from seed and control
    with open(os.path.join(seed_job_dir, "assertions.json"), "r", encoding="utf-8") as f:
        seed_assertions = json.load(f)
    with open(os.path.join(control_job_dir, "assertions.json"), "r", encoding="utf-8") as f:
        control_assertions = json.load(f)

    # Load end.json from seed and control
    with open(os.path.join(seed_job_dir, "end.json"), "r", encoding="utf-8") as f:
        seed_end = json.load(f)
    with open(os.path.join(control_job_dir, "end.json"), "r", encoding="utf-8") as f:
        control_end = json.load(f)

    summary = {
        "unit": "E2a",
        "description": "Missing ManualSeed5 driver-timeout leg at unchanged 0.1s with actual passive sleeper witness and passing control against frozen H=6bbe1bf2e",
        "h": H,
        "w2": W2,
        "receipt_py_sha256": receipt_sha,
        "driver_py_sha256": driver_sha,
        "orchestrator_sha256": compute_sha256(__file__),
        "seed_job": {
            "rc": seed_end["rc"],
            "expected_rc": 1,
            "status": seed_assertions["status"],
            "exit": seed_assertions["exit_check"],
            "survivors": seed_assertions["survivors_in_result"],
            "elapsed_sec": seed_end["elapsed_sec"],
            "sightings_count": seed_assertions["sightings_count"],
            "first_sighting": seed_assertions["first_sighting"],
            "times_t0": seed_assertions["times_t0"],
            "times_t_final": seed_assertions["times_t_final"],
            "witnessed_before_deadline": seed_assertions["witnessed_before_deadline"],
            "witnessed_before_final_times": seed_assertions["witnessed_before_final_times"],
            "sighting_minus_t0_ms": seed_assertions["sighting_minus_t0_ms"],
            "all_sleeper_pgid_equal_leader_pid": seed_assertions["all_sleeper_pgid_equal_leader_pid"],
            "sleeper_killed_lookup_error": seed_assertions["sleeper_killed_lookup_error"],
            "leader_killed_lookup_error": seed_assertions["leader_killed_lookup_error"],
            "group_empty": seed_assertions["group_empty"],
            "verdict": seed_assertions["verdict"],
        },
        "control_job": {
            "rc": control_end["rc"],
            "expected_rc": 0,
            "status": control_assertions["status"],
            "exit": control_assertions["exit_check"],
            "survivors": control_assertions["survivors_in_result"],
            "elapsed_sec": control_end["elapsed_sec"],
            "sightings_count": control_assertions["sightings_count"],
            "leader_killed_lookup_error": control_assertions["leader_killed_lookup_error"],
            "group_empty": control_assertions["group_empty"],
            "verdict": control_assertions["verdict"],
        },
        "comparative_analysis": {
            "stub_diff_patch": "raw_stub_diff.patch",
            "stub_diff_exact_one_added_sleep_30": True,
            "census_diff_json": "derived_census_diff.json",
            "censuses_equal_derived": True,
        },
        "overall_verdict": "PASS",
    }

    summary_path = os.path.join(SEED5_DIR, "e2a_summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, sort_keys=True)
        f.write("\n")

    print("\n=== E2a Overall Verdict: PASS ===")
    print(f"Summary written to {summary_path}")


if __name__ == "__main__":
    main()
