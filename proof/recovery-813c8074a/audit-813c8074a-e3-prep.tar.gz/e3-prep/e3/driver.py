#!/usr/bin/env python3
"""E3 Independent Audit Driver (v5) for H'=813c8074acb2eed99ffeef78ea49e8c7832e4c01.

Incorporates all v1/v2/v3/v4 repairs, parent amendments A-E, and H' re-audit plan §3.6:
- Target head H'=813c8074acb2eed99ffeef78ea49e8c7832e4c01 in W3.
- All 43 mutants (including m01-m05) execute in Phase 2; dead Phase 3 removed.
- Subsets: S-ident61=61, GA=28, GB=30, GC=20 (baselines expect 61, 28, 30, 20).
- Full suite baseline from RV3/evidence/smoke/smoke.log (520 fixtures: 435 seeds / 85 controls).
- Anchor in_h dynamically computed from H' blob rather than hardcoded 1.
- E2c archive at E/proof/recovery-813c8074a/audit-813c8074a-e2c.tar.gz with raw files in RV3/e2/m20-isolation.
- Porcelain comparison normalized consistently across every site via normalize_porcelain().
- Supports --resume-baselines for restarting mutants cleanly without re-running baselines.
- Comprehensive normalization in normalize_text() covering workspace, scratch, pid, timestamps,
  inodes, commit hexes, sha hexes, and md5 chains. Verified on complete full-suite output.
"""

import os
import sys
import re
import json
import time
import shutil
import tarfile
import hashlib
import argparse
import subprocess

RV3 = "/private/tmp/iyi-proof-complete-813c8074a"
W3 = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
H_PRIME = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
RECEIPT_PY = os.path.join(RV3, "receipt.py")
RUN_FIXTURES_PY = os.path.join(RV3, "run_fixtures.py")
CATALOG_JSON = os.path.join(RV3, "catalog.json")
STATIC_EXP_JSON = os.path.join(RV3, "e3", "static_expectations.json")
ACCOUNTING_JSONL = os.path.join(RV3, "e3", "accounting.jsonl")
MUTANTS_ACCOUNTING_JSON = os.path.join(RV3, "e3", "mutants_accounting.json")
INVENTORY_JSON = os.path.join(RV3, "e3", "inventory.json")
RV_SMOKE_LOG = os.path.join(RV3, "evidence", "smoke", "smoke.log")
E2C_DIR = os.path.join(RV3, "e2", "m20-isolation")
E2C_TAR_PATH = "/Users/jwaldrip/dev/worktrees/iyi-stale-recovery-evidence-20261030/proof/recovery-813c8074a/audit-813c8074a-e2c.tar.gz"

SCRATCH_RE = re.compile(r"/(?:private/tmp|var/folders/\S+?|tmp)/(?:iyi-\S+?|not-iyp-\S+?|iyp-\S+?)(?=[/\"\x27\s\],;]|$)")
WORKSPACE_RE = re.compile(r"/private/tmp/iyi-proof-(?:review|complete)-813c8074a/(?:w|c/e3-[^/]+)")
PID_RE = re.compile(r"\b(child_pid|pid)=\d+\b")
TIMESTAMP_RE = re.compile(r"\b(mtime_ns|p_commit_ns|before_mtime_ns|after_mtime_ns)=\d+\b")
INODE_RE = re.compile(r"\b(before_inode|after_inode)=\d+\b")
HEX40_RE = re.compile(r"\b(old|new)=[0-9a-f]{40}\b")
HEX64_RE = re.compile(r"\b(before_sha|after_sha)=[0-9a-f]{64}\b")
MD5_RE = re.compile(r"\bchain=[0-9a-f]{32}->")
HASH_COLON_RE = re.compile(r":[0-9a-f]{64}(?=[;\"]|$)")

def normalize_text(text):
    text = WORKSPACE_RE.sub("<WORKSPACE>", text)
    text = SCRATCH_RE.sub("<SCRATCH>", text)
    text = PID_RE.sub(r"\1=<PID>", text)
    text = TIMESTAMP_RE.sub(r"\1=<TIMESTAMP>", text)
    text = INODE_RE.sub(r"\1=<INODE>", text)
    text = HEX40_RE.sub(r"\1=<HEX40>", text)
    text = HEX64_RE.sub(r"\1=<HEX64>", text)
    text = MD5_RE.sub("chain=<MD5>->", text)
    text = HASH_COLON_RE.sub(":<HEX64>", text)
    return text

def normalize_porcelain(porcelain_str):
    """Normalize git status --porcelain output across leading whitespace differences."""
    lines = []
    for line in porcelain_str.splitlines():
        line = line.strip()
        if line:
            parts = line.split(None, 1)
            if len(parts) == 2:
                lines.append(f"{parts[0]} {parts[1]}")
            else:
                lines.append(line)
    return "\n".join(sorted(lines))

def write_json_atomic(path, obj):
    data = (json.dumps(obj, indent=2, sort_keys=True) + "\n").encode("utf-8")
    dir_path = os.path.dirname(os.path.abspath(path))
    os.makedirs(dir_path, exist_ok=True)
    tmp_path = os.path.join(dir_path, f".{os.path.basename(path)}.tmp.{os.getpid()}")
    with open(tmp_path, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp_path, path)
    dir_fd = os.open(dir_path, os.O_RDONLY)
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)

def remove_tree_safely(path):
    if not os.path.exists(path):
        return
    def _onerror(func, p, exc_info):
        try:
            os.chmod(p, 0o777)
            func(p)
        except Exception:
            pass
    shutil.rmtree(path, onerror=_onerror)

def parse_run_fixtures_stdout(stdout_path):
    seeds = {}
    controls = {}
    counts = None
    result = None
    if not os.path.exists(stdout_path):
        raise RuntimeError(f"Missing stdout.log at {stdout_path}")
        
    with open(stdout_path, "r", encoding="utf-8", errors="surrogateescape") as f:
        lines = f.readlines()
        
    for line_idx, line in enumerate(lines, 1):
        line = line.strip()
        if not line:
            continue
        if line.startswith("SEED "):
            try:
                prefix, rest = line.split(" expect=", 1)
                fid = prefix[5:].strip()
                exp_str, rest = rest.split(" got=", 1)
                got_str, app_str = rest.split(" applied=", 1)
                exp = json.loads(exp_str)
                got = json.loads(got_str)
                seeds[fid] = {"expect": exp, "got": got, "applied": app_str, "raw": line}
            except Exception as e:
                raise ValueError(f"Strict parse error on SEED line {line_idx} in {stdout_path}: {e}\nLine: {line}")
        elif line.startswith("CONTROL "):
            try:
                parts = line[8:].split(None, 2)
                fid = parts[0]
                status = parts[1]
                if status == "PASS":
                    controls[fid] = {"status": "PASS", "raw": line}
                elif status == "FAIL":
                    rest = line.split(" expect=", 1)[1]
                    exp_str, got_str = rest.split(" got=", 1)
                    controls[fid] = {
                        "status": "FAIL",
                        "expect": json.loads(exp_str),
                        "got": json.loads(got_str),
                        "raw": line
                    }
                else:
                    raise ValueError(f"Unknown control status {status}")
            except Exception as e:
                raise ValueError(f"Strict parse error on CONTROL line {line_idx} in {stdout_path}: {e}\nLine: {line}")
        elif line.startswith("COUNTS fixtures "):
            try:
                counts = int(line[16:].strip())
            except Exception as e:
                raise ValueError(f"Invalid COUNTS line {line} in {stdout_path}: {e}")
        elif line.startswith("RESULT "):
            result = line[7:].strip()
            
    if counts is None or result is None:
        raise ValueError(f"Malformed run_fixtures output: missing COUNTS or RESULT in {stdout_path}")
        
    return seeds, controls, counts, result

def parse_full_suite_stdout(stdout_path):
    seeds = {}
    controls = {}
    total_line = None
    harness_line = None
    
    if not os.path.exists(stdout_path):
        raise RuntimeError(f"Missing full suite stdout.log at {stdout_path}")
        
    with open(stdout_path, "r", encoding="utf-8", errors="surrogateescape") as f:
        lines = f.readlines()
        
    for line_idx, line in enumerate(lines, 1):
        line = line.strip()
        if not line:
            continue
        if line.startswith("SEED "):
            try:
                prefix, rest = line.split(" expect=", 1)
                fid = prefix[5:].strip()
                exp_str, rest = rest.split(" got=", 1)
                got_str, app_str = rest.split(" applied=", 1)
                exp = json.loads(exp_str)
                got = json.loads(got_str)
                seeds[fid] = {"expect": exp, "got": got, "applied": app_str, "raw_expect": exp_str, "raw_got": got_str}
            except Exception as e:
                raise ValueError(f"Strict parse error on full suite SEED line {line_idx} in {stdout_path}: {e}\nLine: {line}")
        elif line.startswith("CONTROL "):
            try:
                parts = line[8:].split(None, 2)
                fid = parts[0]
                status = parts[1]
                if status == "PASS":
                    controls[fid] = {"status": "PASS"}
                elif status == "FAIL":
                    rest = line.split(" expect=", 1)[1]
                    exp_str, got_str = rest.split(" got=", 1)
                    controls[fid] = {
                        "status": "FAIL",
                        "expect": json.loads(exp_str),
                        "got": json.loads(got_str),
                        "raw_expect": exp_str,
                        "raw_got": got_str
                    }
                else:
                    raise ValueError(f"Unknown control status {status}")
            except Exception as e:
                raise ValueError(f"Strict parse error on full suite CONTROL line {line_idx} in {stdout_path}: {e}\nLine: {line}")
        elif line.startswith("TOTAL "):
            total_line = line
        elif line.startswith("HARNESS "):
            harness_line = line
            
    if total_line is None or harness_line is None:
        raise ValueError(f"Full suite truncated: missing TOTAL or HARNESS terminal marker in {stdout_path}")
        
    total_fixtures = len(seeds) + len(controls)
    if total_fixtures != 520 or len(seeds) != 435 or len(controls) != 85:
        raise ValueError(f"Full suite incomplete: executed {len(seeds)} seeds (exp 435) and {len(controls)} controls (exp 85) in {stdout_path}")
        
    return seeds, controls, total_line, harness_line

def parse_rv_baseline():
    seeds_rv = {}
    controls_rv = {}
    with open(RV_SMOKE_LOG, "r", encoding="utf-8", errors="surrogateescape") as f:
        for line in f:
            line = line.strip()
            if line.startswith("SEED "):
                try:
                    prefix, rest = line.split(" expect=", 1)
                    fid = prefix[5:].strip()
                    exp_str, rest = rest.split(" got=", 1)
                    got_str, app_str = rest.split(" applied=", 1)
                    seeds_rv[fid] = {
                        "expect": json.loads(exp_str),
                        "got": json.loads(got_str),
                        "applied": app_str,
                        "raw_expect": exp_str,
                        "raw_got": got_str
                    }
                except Exception as e:
                    raise ValueError(f"Parse error in pinned RV smoke.log SEED: {e}")
            elif line.startswith("CONTROL "):
                try:
                    parts = line[8:].split()
                    fid = parts[0]
                    status = parts[1]
                    if status == "PASS":
                        controls_rv[fid] = {"status": "PASS"}
                    else:
                        controls_rv[fid] = {"status": "FAIL"}
                except Exception as e:
                    raise ValueError(f"Parse error in pinned RV smoke.log CONTROL: {e}")
    assert len(seeds_rv) == 435 and len(controls_rv) == 85, f"RV baseline fixture counts mismatch: {len(seeds_rv)}, {len(controls_rv)}"
    return seeds_rv, controls_rv

def create_clone(tag):
    clone_dir = os.path.join(RV3, "c", tag)
    if os.path.exists(clone_dir):
        raise RuntimeError(f"Clone dir already exists (must not delete attempts): {clone_dir}")
        
    os.makedirs(os.path.dirname(clone_dir), exist_ok=True)
    subprocess.check_call(
        ["git", "clone", "--no-hardlinks", "--quiet", W3, clone_dir],
        env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
    )
    subprocess.check_call(
        ["git", "-C", clone_dir, "checkout", "--quiet", "--detach", H_PRIME],
        env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
    )
    head = subprocess.check_output(
        ["git", "-C", clone_dir, "rev-parse", "HEAD"],
        env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
    ).decode("utf-8").strip()
    assert head == H_PRIME, f"Clone {clone_dir} HEAD {head} != {H_PRIME}"
    porcelain = subprocess.check_output(
        ["git", "-C", clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"],
        env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
    ).decode("utf-8")
    assert normalize_porcelain(porcelain) == "", f"Clone {clone_dir} not clean: {porcelain}"
    return clone_dir

def run_receipt_job(job_dir, cwd, argv, pyc_dir):
    if os.path.exists(job_dir):
        raise RuntimeError(f"Job dir already exists (must not delete attempts): {job_dir}")
        
    parent_dir = os.path.dirname(os.path.abspath(job_dir))
    os.makedirs(parent_dir, exist_ok=True)
    
    env = dict(os.environ)
    env["GIT_OPTIONAL_LOCKS"] = "0"
    
    cmd = [
        PY, "-B", RECEIPT_PY, job_dir, cwd, "--",
        PY, "-B", "-X", f"pycache_prefix={pyc_dir}", *argv
    ]
    p = subprocess.Popen(
        cmd,
        env=env,
        stdin=subprocess.DEVNULL
    )
    rc = p.wait()
    return rc

def read_receipt_end(job_dir):
    end_path = os.path.join(job_dir, "end.json")
    if not os.path.exists(end_path):
        raise RuntimeError(f"Job in {job_dir} is INCOMPLETE: missing end.json")
    with open(end_path, "r", encoding="utf-8") as f:
        return json.load(f)

def load_and_verify_existing_baselines(subsets):
    """Re-verify existing baselines in RV3/e3/baselines per parent amendment."""
    print("Verifying existing 4 baselines in RV3/e3/baselines...")
    baselines = {}
    base_order = ["S-ident61", "GA", "GB", "GC"]
    
    for group in base_order:
        expected_count = subsets[group]["count"]
        job_dir = os.path.join(RV3, "e3", "baselines", group.lower().replace("-", "_"))
        if not os.path.exists(job_dir):
            raise RuntimeError(f"Missing existing baseline directory: {job_dir}")
            
        end_path = os.path.join(job_dir, "end.json")
        start_path = os.path.join(job_dir, "start.json")
        stdout_path = os.path.join(job_dir, "stdout.log")
        stderr_path = os.path.join(job_dir, "stderr.log")
        
        if not (os.path.exists(end_path) and os.path.exists(start_path) and os.path.exists(stdout_path) and os.path.exists(stderr_path)):
            raise RuntimeError(f"Incomplete baseline files in {job_dir}")
            
        end_data = json.loads(open(end_path).read())
        if end_data.get("rc") != 0:
            raise RuntimeError(f"Baseline {group} rc {end_data.get('rc')} != 0")
            
        stdout_bytes = open(stdout_path, "rb").read()
        stderr_bytes = open(stderr_path, "rb").read()
        
        if len(stdout_bytes) != end_data.get("stdout_bytes") or hashlib.sha256(stdout_bytes).hexdigest() != end_data.get("stdout_sha256"):
            raise RuntimeError(f"Baseline {group} stdout stream bytes/hash mismatch")
        if len(stderr_bytes) != end_data.get("stderr_bytes") or hashlib.sha256(stderr_bytes).hexdigest() != end_data.get("stderr_sha256"):
            raise RuntimeError(f"Baseline {group} stderr stream bytes/hash mismatch")
            
        seeds, controls, counts, result = parse_run_fixtures_stdout(stdout_path)
        if counts != expected_count:
            raise RuntimeError(f"Baseline {group} counts {counts} != {expected_count}")
        if result != "PASS [] []":
            raise RuntimeError(f"Baseline {group} result '{result}' != 'PASS [] []'")
            
        for fid, obs in seeds.items():
            if obs["got"] != obs["expect"]:
                raise RuntimeError(f"Baseline {group} seed {fid} expect!=got: {obs['expect']} != {obs['got']}")
        for fid, obs in controls.items():
            if obs["status"] != "PASS":
                raise RuntimeError(f"Baseline {group} control {fid} status {obs['status']} != 'PASS'")
                
        baselines[group] = {
            "group": group,
            "expected_count": expected_count,
            "observed_count": counts,
            "seeds": seeds,
            "controls": controls,
            "job_dir": job_dir,
            "rc": 0,
            "receipt": end_data,
            "reused_existing_baseline": True
        }
        print(f"  Verified baseline {group}: {counts} fixtures green, stream hashes confirmed.")
        
    return baselines

def verify_m20_e2c_raw_and_archive():
    """Verify raw E2c files in RV3/e2/m20-isolation and byte-compare to E archive."""
    if not os.path.exists(E2C_DIR):
        return False, f"Missing local E2c directory: {E2C_DIR}"
    if not os.path.exists(E2C_TAR_PATH):
        return False, f"Missing E2c tar archive: {E2C_TAR_PATH}"
        
    tar_members = {}
    with tarfile.open(E2C_TAR_PATH, "r:gz") as tar:
        for m in tar.getmembers():
            if m.isfile():
                tar_members[m.name] = tar.extractfile(m).read()
                
    files_to_check = [
        "m20_diff.patch",
        "h-seed/end.json", "h-seed/final.json", "h-seed/assertions.json", "h-seed/clone_porcelain.txt",
        "h-ctl/end.json", "h-ctl/final.json", "h-ctl/assertions.json", "h-ctl/clone_porcelain.txt",
        "m-seed/end.json", "m-seed/final.json", "m-seed/assertions.json", "m-seed/clone_porcelain.txt",
        "m-ctl/end.json", "m-ctl/final.json", "m-ctl/assertions.json", "m-ctl/clone_porcelain.txt",
    ]
    
    file_bytes_evidence = {}
    for rel in files_to_check:
        local_p = os.path.join(E2C_DIR, rel)
        tar_k = f"m20-isolation/{rel}"
        if not os.path.exists(local_p):
            return False, f"Missing local E2c file {local_p}"
        if tar_k not in tar_members:
            return False, f"Missing E2c tar member {tar_k}"
        local_b = open(local_p, "rb").read()
        tar_b = tar_members[tar_k]
        if local_b != tar_b:
            return False, f"Byte mismatch in {rel}: local len {len(local_b)} != tar len {len(tar_b)}"
        file_bytes_evidence[rel] = {
            "size": len(local_b),
            "sha256": hashlib.sha256(local_b).hexdigest(),
            "archive_equal": True
        }
        
    expected_outcomes = {
        "h-seed": {"rc": 1, "status": "FAIL", "reasons": []},
        "h-ctl": {"rc": 0, "status": "PASS"},
        "m-seed": {"rc": 0, "status": "PASS", "reasons": []},
        "m-ctl": {"rc": 0, "status": "PASS"}
    }
    job_outcomes = {}
    for jname, exp in expected_outcomes.items():
        end_data = json.loads(open(os.path.join(E2C_DIR, jname, "end.json")).read())
        final_data = json.loads(open(os.path.join(E2C_DIR, jname, "final.json")).read())
        rc = end_data.get("rc")
        st = final_data.get("status")
        reas = final_data.get("reasons")
        if rc != exp["rc"]:
            return False, f"Job {jname} rc {rc} != {exp['rc']}"
        if st != exp["status"]:
            return False, f"Job {jname} status {st} != {exp['status']}"
        if "reasons" in exp and reas != exp["reasons"]:
            return False, f"Job {jname} reasons {reas} != {exp['reasons']}"
        job_outcomes[jname] = {
            "rc": rc,
            "status": st,
            "reasons": reas,
            "elapsed_sec": end_data.get("elapsed_sec")
        }
        
    return True, {
        "verified_files_count": len(files_to_check),
        "files": file_bytes_evidence,
        "job_outcomes": job_outcomes,
        "archive_path": E2C_TAR_PATH
    }

def main():
    parser = argparse.ArgumentParser(description="E3 Driver v5")
    parser.add_argument("--resume-baselines", action="store_true", help="Reuse verified baselines from RV3/e3/baselines")
    args = parser.parse_args()
    
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)
    print(f"=== E3 Driver (v5) starting at {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} (resume_baselines={args.resume_baselines}) ===")
    
    with open(STATIC_EXP_JSON) as f:
        static_data = json.load(f)

    subsets = static_data["subsets"]
    mutants_data = static_data["mutants"]
    execution_order = static_data["mutants_execution_order"]
    
    baselines = {}
    base_order = ["S-ident61", "GA", "GB", "GC"]
    
    # 1. Baselines
    print("\n--- PHASE 1: Baselines ---")
    if args.resume_baselines:
        baselines = load_and_verify_existing_baselines(subsets)
    else:
        if os.path.exists(os.path.join(RV3, "e3", "baselines")):
            raise RuntimeError("RV3/e3/baselines already exists (refusing to overwrite without --resume-baselines)")
        for group in base_order:
            info = subsets[group]
            expected_count = info["count"]
            tokens = info["tokens"]
            tag = f"e3-base-{group.lower().replace('-', '_')}"
            clone_dir = create_clone(tag)
            pyc_dir = os.path.join(RV3, "pyc", tag)
            job_dir = os.path.join(RV3, "e3", "baselines", group.lower().replace("-", "_"))
            
            print(f"Running baseline {group} ({expected_count} fixtures)...")
            argv = [RUN_FIXTURES_PY, "--w", clone_dir, *tokens]
            rc = run_receipt_job(job_dir, clone_dir, argv, pyc_dir)
            receipt_end = read_receipt_end(job_dir)
            
            stdout_path = os.path.join(job_dir, "stdout.log")
            seeds, controls, counts, result = parse_run_fixtures_stdout(stdout_path)
            
            print(f"  rc={rc}, counts={counts} (expected {expected_count}), result={result}")
            
            baseline_failed = False
            fail_reasons = []
            if rc != 0:
                baseline_failed = True
                fail_reasons.append(f"rc {rc} != 0")
            if counts != expected_count:
                baseline_failed = True
                fail_reasons.append(f"counts {counts} != {expected_count}")
            if not result or result != "PASS [] []":
                baseline_failed = True
                fail_reasons.append(f"result {result} != 'PASS [] []'")
                
            for fid, obs in seeds.items():
                if obs["got"] != obs["expect"]:
                    baseline_failed = True
                    fail_reasons.append(f"Seed {fid} expect {obs['expect']} != got {obs['got']}")
            for fid, obs in controls.items():
                if obs["status"] != "PASS":
                    baseline_failed = True
                    fail_reasons.append(f"Control {fid} status {obs['status']} != 'PASS'")
                    
            if baseline_failed:
                print(f"FATAL: Baseline {group} failed! Reasons: {fail_reasons}. Stopping driver.")
                fail_data = {
                    "group": group,
                    "rc": rc,
                    "counts": counts,
                    "expected_count": expected_count,
                    "result": result,
                    "fail_reasons": fail_reasons,
                    "receipt": receipt_end,
                    "stdout": open(stdout_path).read() if os.path.exists(stdout_path) else None
                }
                write_json_atomic(os.path.join(RV3, "e3", "baseline_failure.json"), fail_data)
                porcelain_on_fail = subprocess.check_output(
                    ["git", "-C", clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"],
                    env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
                ).decode("utf-8")
                print(f"  Clone porcelain before teardown: '{porcelain_on_fail}'")
                remove_tree_safely(clone_dir)
                remove_tree_safely(pyc_dir)
                sys.exit(1)
                
            porcelain = subprocess.check_output(
                ["git", "-C", clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"],
                env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
            ).decode("utf-8")
            assert normalize_porcelain(porcelain) == "", f"Baseline {group} clone not clean before removal: {porcelain}"
            
            remove_tree_safely(clone_dir)
            remove_tree_safely(pyc_dir)
            
            baselines[group] = {
                "group": group,
                "expected_count": expected_count,
                "observed_count": counts,
                "seeds": seeds,
                "controls": controls,
                "job_dir": job_dir,
                "rc": rc,
                "receipt": receipt_end,
                "clone_porcelain_before_removal": normalize_porcelain(porcelain)
            }
            print(f"  Baseline {group} GREEN (all {len(seeds)} seeds expect==got, all {len(controls)} controls PASS).")

    print("\nAll 4 baselines GREEN:")
    for g, b in baselines.items():
        print(f"  {g}: {b['observed_count']} fixtures PASS, rc 0")

    # Load RV baseline for full suite comparison
    print("\nLoading pinned RV smoke baseline for full suite diffs...")
    seeds_rv, controls_rv = parse_rv_baseline()
    print(f"Loaded {len(seeds_rv)} RV seeds and {len(controls_rv)} RV controls.")

    # 2. Run Mutants
    print("\n--- PHASE 2: Running 43 Mutants (Order: GC, GA, GB, S-ident61) ---")
    if os.path.exists(ACCOUNTING_JSONL):
        if os.path.getsize(ACCOUNTING_JSONL) > 0:
            raise RuntimeError(f"{ACCOUNTING_JSONL} exists and is non-empty (refusing to overwrite prior attempts)")
            
    accounting_rows = []
    
    for idx, mid in enumerate(execution_order, 1):
        m = mutants_data[mid]
        group = m["group"]
        rel = m["rel"]
        old = m["old"]
        new = m["new"]
        detector = m["detector"]
        paired_controls = m["paired_controls"]
        expected_status = m["expected_status"]
        
        print(f"\n[{idx}/43] Processing {mid} ({m['name']}) [Group: {group}, Expected: {expected_status}]")
        
        tag = f"e3-{mid}"
        clone_dir = create_clone(tag)
        pyc_dir = os.path.join(RV3, "pyc", tag)
        mutant_root = os.path.join(RV3, "e3", "mutants", mid)
        if os.path.exists(mutant_root):
            raise RuntimeError(f"Mutant directory {mutant_root} already exists (fail closed on prior attempts)")
        os.makedirs(mutant_root, exist_ok=True)
        
        target_file = os.path.join(clone_dir, rel)
        with open(target_file, "r", encoding="utf-8", errors="surrogateescape") as f:
            target_content = f.read()
            
        count_in_clone = target_content.count(old)
        assert count_in_clone == 1, f"Anchor for {mid} in clone occurs {count_in_clone} != 1 times"
        
        # Compute count_in_h dynamically
        h_content = subprocess.check_output(
            ["git", "-C", clone_dir, "show", f"HEAD:{rel}"],
            env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
        ).decode("utf-8", "surrogateescape")
        count_in_h = h_content.count(old)
        assert count_in_h == 1, f"Anchor for {mid} in H occurs {count_in_h} != 1 times"
        
        # Apply mutation
        mutated_content = target_content.replace(old, new, 1)
        with open(target_file, "w", encoding="utf-8", errors="surrogateescape") as f:
            f.write(mutated_content)
            
        # Verify diff
        changed_files = subprocess.check_output(
            ["git", "-C", clone_dir, "diff", "--name-only"],
            env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
        ).decode("utf-8").strip().splitlines()
        assert changed_files == [rel], f"Changed files for {mid} {changed_files} != [{rel}]"
        
        diff_patch = subprocess.check_output(
            ["git", "-C", clone_dir, "diff", "-U0"],
            env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
        )
        diff_patch_path = os.path.join(mutant_root, "diff.patch")
        with open(diff_patch_path, "wb") as f:
            f.write(diff_patch)
        diff_sha256 = hashlib.sha256(diff_patch).hexdigest()
        
        blob = subprocess.check_output(
            ["git", "-C", clone_dir, "rev-parse", f"HEAD:{rel}"],
            env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
        ).decode("utf-8").strip()
        
        line_at_h = m["line_at_h"]
        
        anchor_data = {
            "counts": {
                "in_h": count_in_h,
                "in_clone_before": count_in_clone
            },
            "line_at_h": line_at_h,
            "blob": blob,
            "diff_sha256": diff_sha256
        }
        write_json_atomic(os.path.join(mutant_root, "anchor.json"), anchor_data)
        
        expected_data = {
            "id": mid,
            "name": m["name"],
            "group": group,
            "rel": rel,
            "location": m.get("location"),
            "detector": detector,
            "paired_controls": paired_controls,
            "expected_collateral": m.get("expected_collateral"),
            "expected_status": expected_status,
            "notes": m.get("notes")
        }
        write_json_atomic(os.path.join(mutant_root, "expected.json"), expected_data)
        
        # Run subset job
        subset_tokens = subsets[group]["tokens"]
        subset_job_dir = os.path.join(mutant_root, "subset")
        argv = [RUN_FIXTURES_PY, "--w", clone_dir, *subset_tokens]
        subset_rc = run_receipt_job(subset_job_dir, clone_dir, argv, pyc_dir)
        subset_receipt = read_receipt_end(subset_job_dir)
        
        subset_stdout_path = os.path.join(subset_job_dir, "stdout.log")
        with open(subset_stdout_path, "rb") as f:
            subset_stdout_bytes = f.read()
        subset_stdout_sha256 = hashlib.sha256(subset_stdout_bytes).hexdigest()
        
        seeds_mut, controls_mut, counts_mut, result_mut = parse_run_fixtures_stdout(subset_stdout_path)
        base_seeds = baselines[group]["seeds"]
        base_controls = baselines[group]["controls"]
        
        # Analyze subset results
        detector_changed = False
        detector_observed = None
        detector_baseline = None
        detector_kind = None
        
        if detector:
            if detector in seeds_mut:
                detector_kind = "seed"
                detector_observed = seeds_mut[detector]
                detector_baseline = base_seeds.get(detector)
                if detector_observed["got"] != detector_observed["expect"]:
                    detector_changed = True
            elif detector in controls_mut:
                detector_kind = "control"
                detector_observed = controls_mut[detector]
                detector_baseline = base_controls.get(detector)
                if detector_observed["status"] != "PASS":
                    detector_changed = True
            else:
                detector_kind = "missing"
                
        # Check paired controls: every paired control MUST PASS
        paired_control_results = []
        all_paired_controls_passed = True
        for ctl in paired_controls:
            ctl_obs = controls_mut.get(ctl, {})
            ctl_status = ctl_obs.get("status", "MISSING")
            if ctl_status != "PASS":
                all_paired_controls_passed = False
            paired_control_results.append({
                "id": ctl,
                "status": ctl_status,
                "baseline_status": "PASS"
            })
            
        # Collect collateral changes
        collateral = []
        for fid, obs in seeds_mut.items():
            if fid != detector:
                b_obs = base_seeds.get(fid)
                if b_obs and (obs["got"] != b_obs["got"] or obs["got"] != obs["expect"]):
                    collateral.append({
                        "id": fid,
                        "kind": "seed",
                        "observed_got": obs["got"],
                        "baseline_got": b_obs["got"],
                        "expect": obs["expect"],
                        "failed": obs["got"] != obs["expect"]
                    })
        for fid, obs in controls_mut.items():
            if fid != detector and fid not in paired_controls:
                b_obs = base_controls.get(fid)
                if b_obs and obs["status"] != b_obs["status"]:
                    collateral.append({
                        "id": fid,
                        "kind": "control",
                        "observed_status": obs["status"],
                        "baseline_status": b_obs["status"]
                    })
                    
        # Determine status
        status = None
        full_suite_job_dir = None
        full_suite_rc = None
        full_suite_stdout_sha256 = None
        full_suite_comparison = None
        full_suite_receipt = None
        e2c_verification = None
        written_trace = None
        
        if mid == "m20":
            # m20 is predicted unchanged in subset run, masked by required.json mismatch.
            # Spec: m20 MASKED requires exact E2c evidence supplied by parent AND paired controls PASS.
            e2c_ok, e2c_data = verify_m20_e2c_raw_and_archive()
            e2c_verification = {"verified": e2c_ok, "evidence": e2c_data}
            if not e2c_ok:
                print(f"  {mid}: E2c verification failed: {e2c_data}")
                status = "INCOMPLETE"
            elif not all_paired_controls_passed:
                print(f"  {mid}: E2c verified but paired controls failed: {paired_control_results}")
                status = "FAIL"
            else:
                status = "MASKED"
                print(f"  {mid}: MASKED (verified exact E2c raw files & archive, paired controls PASS)")
        elif detector_changed and all_paired_controls_passed:
            status = "KILLED"
            print(f"  {mid}: KILLED by named detector {detector} (paired controls PASS)")
        elif detector_changed and not all_paired_controls_passed:
            status = "FAIL"
            print(f"  {mid}: FAIL (detector changed but paired control failed: {paired_control_results})")
        else:
            print(f"  {mid}: named detector changed={detector_changed} -> Running full DEFAULT suite...")
            p_status = subprocess.check_output(
                ["git", "-C", clone_dir, "status", "--porcelain=v1"],
                env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
            ).decode("utf-8")
            assert normalize_porcelain(p_status) == f"M {rel}", f"Porcelain before full suite {normalize_porcelain(p_status)} != M {rel}"
            
            full_suite_job_dir = os.path.join(mutant_root, "full_suite")
            full_pyc_dir = os.path.join(RV3, "pyc", f"{tag}-full")
            argv = ["proof/smoke_test.py"]
            full_suite_rc = run_receipt_job(full_suite_job_dir, clone_dir, argv, full_pyc_dir)
            full_suite_receipt = read_receipt_end(full_suite_job_dir)
            
            full_stdout_path = os.path.join(full_suite_job_dir, "stdout.log")
            with open(full_stdout_path, "rb") as f:
                full_stdout_bytes = f.read()
            full_suite_stdout_sha256 = hashlib.sha256(full_stdout_bytes).hexdigest()
            
            seeds_full, controls_full, total_line, harness_line = parse_full_suite_stdout(full_stdout_path)
            
            seed_id_mismatch = set(seeds_full.keys()) ^ set(seeds_rv.keys())
            ctl_id_mismatch = set(controls_full.keys()) ^ set(controls_rv.keys())
            if seed_id_mismatch or ctl_id_mismatch:
                status = "INCOMPLETE"
                full_suite_comparison = {
                    "error": "Fixture ID set mismatch against RV baseline",
                    "seed_id_mismatch": sorted(seed_id_mismatch),
                    "ctl_id_mismatch": sorted(ctl_id_mismatch)
                }
                print(f"  {mid}: INCOMPLETE (ID set mismatch: seeds {seed_id_mismatch}, ctls {ctl_id_mismatch})")
            else:
                actual_failing_fixtures = []
                semantic_expect_diffs = []
                semantic_got_diffs = []
                applied_diffs_after_norm = []
                
                for fid, rv_seed in seeds_rv.items():
                    cur = seeds_full[fid]
                    if cur["got"] != cur["expect"]:
                        actual_failing_fixtures.append({
                            "id": fid,
                            "kind": "seed",
                            "expect": cur["expect"],
                            "got": cur["got"],
                            "applied": cur.get("applied")
                        })
                    else:
                        norm_cur_exp = normalize_text(cur["raw_expect"])
                        norm_rv_exp = normalize_text(rv_seed["raw_expect"])
                        if norm_cur_exp != norm_rv_exp:
                            semantic_expect_diffs.append({"id": fid, "cur": norm_cur_exp, "rv": norm_rv_exp})
                            
                        norm_cur_got = normalize_text(cur["raw_got"])
                        norm_rv_got = normalize_text(rv_seed["raw_got"])
                        if norm_cur_got != norm_rv_got:
                            semantic_got_diffs.append({"id": fid, "cur": norm_cur_got, "rv": norm_rv_got})
                            
                        norm_cur_app = normalize_text(cur["applied"])
                        norm_rv_app = normalize_text(rv_seed["applied"])
                        if norm_cur_app != norm_rv_app:
                            applied_diffs_after_norm.append({"id": fid, "cur": norm_cur_app, "rv": norm_rv_app})
                            
                for fid, rv_ctl in controls_rv.items():
                    cur = controls_full[fid]
                    if cur["status"] != "PASS":
                        actual_failing_fixtures.append({
                            "id": fid,
                            "kind": "control",
                            "status": cur["status"],
                            "expect": cur.get("expect"),
                            "got": cur.get("got")
                        })
                    elif cur["status"] != rv_ctl["status"]:
                        actual_failing_fixtures.append({
                            "id": fid,
                            "kind": "control",
                            "status_mismatch": f"cur {cur['status']} != rv {rv_ctl['status']}"
                        })
                        
                full_suite_comparison = {
                    "fixtures_checked": 520,
                    "total_line": total_line,
                    "harness_line": harness_line,
                    "actual_failing_fixtures": actual_failing_fixtures,
                    "semantic_expect_diffs": semantic_expect_diffs,
                    "semantic_got_diffs": semantic_got_diffs,
                    "applied_diffs_after_norm": applied_diffs_after_norm
                }
                
                if actual_failing_fixtures:
                    if all_paired_controls_passed:
                        trace_lines = []
                        for aff in actual_failing_fixtures:
                            trace_lines.append(f"Mutant {mid} at {rel}:{line_at_h} caused failure in {aff['id']} (got: {aff.get('got')})")
                        written_trace = "\n".join(trace_lines)
                        status = "KILLED-ALT"
                        print(f"  {mid}: KILLED-ALT by full-suite fixtures: {[d['id'] for d in actual_failing_fixtures]}")
                    else:
                        status = "FAIL"
                        print(f"  {mid}: FAIL (failing fixture in full suite but paired control failed)")
                else:
                    if semantic_expect_diffs or semantic_got_diffs or applied_diffs_after_norm:
                        status = "UNCLASSIFIED"
                        print(f"  {mid}: UNCLASSIFIED (passing output differs from RV after normalization: exp {len(semantic_expect_diffs)}, got {len(semantic_got_diffs)}, app {len(applied_diffs_after_norm)})")
                    else:
                        status = "SURVIVED"
                        print(f"  {mid}: SURVIVED (complete full suite, exact ID set, every expect/got/control status equals RV's, applied equal after normalization)")
                        
            remove_tree_safely(full_pyc_dir)
            
        porcelain_before_removal = subprocess.check_output(
            ["git", "-C", clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"],
            env={"GIT_OPTIONAL_LOCKS": "0", "PATH": os.environ["PATH"]}
        ).decode("utf-8")
        norm_porcelain = normalize_porcelain(porcelain_before_removal)
        assert norm_porcelain == f"M {rel}", f"Unexpected clone porcelain before removal: '{norm_porcelain}' (raw: {repr(porcelain_before_removal)})"
        
        remove_tree_safely(clone_dir)
        remove_tree_safely(pyc_dir)
        
        row = {
            "id": mid,
            "name": m["name"],
            "group": group,
            "location": m.get("location"),
            "rel": rel,
            "status": status,
            "expected_status": expected_status,
            "detector": detector,
            "detector_kind": detector_kind,
            "detector_changed": detector_changed,
            "detector_observed": detector_observed,
            "detector_baseline": detector_baseline,
            "paired_controls": paired_control_results,
            "all_paired_controls_passed": all_paired_controls_passed,
            "collateral": collateral,
            "anchor": anchor_data,
            "receipts": {
                "subset_job_dir": subset_job_dir,
                "subset_rc": subset_rc,
                "subset_stdout_sha256": subset_stdout_sha256,
                "subset_receipt": subset_receipt,
                "full_suite_job_dir": full_suite_job_dir,
                "full_suite_rc": full_suite_rc,
                "full_suite_stdout_sha256": full_suite_stdout_sha256,
                "full_suite_receipt": full_suite_receipt
            },
            "full_suite_comparison": full_suite_comparison,
            "written_trace": written_trace,
            "e2c_verification": e2c_verification,
            "clone_porcelain_before_removal": norm_porcelain,
            "notes": m.get("notes")
        }
        
        line_bytes = (json.dumps(row, sort_keys=True) + "\n").encode("utf-8")
        with open(ACCOUNTING_JSONL, "ab") as f:
            f.write(line_bytes)
            f.flush()
            os.fsync(f.fileno())
            
        accounting_rows.append(row)
        
        next_group = mutants_data[execution_order[idx]]["group"] if idx < len(execution_order) else None
        if next_group != group:
            group_marker = {
                "group": group,
                "mutants_count": len([r for r in accounting_rows if r["group"] == group]),
                "total_rows_so_far": len(accounting_rows),
                "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "accounting_jsonl": ACCOUNTING_JSONL
            }
            write_json_atomic(os.path.join(RV3, "e3", f"group_{group.lower().replace('-', '_')}_complete.json"), group_marker)
            print(f"\n=== GROUP {group} COMPLETE: {group_marker['mutants_count']} mutants recorded in {ACCOUNTING_JSONL} (total {len(accounting_rows)}/43) ===", flush=True)
            
    # Write final accounting JSON
    write_json_atomic(MUTANTS_ACCOUNTING_JSON, accounting_rows)
    print(f"\nWrote {MUTANTS_ACCOUNTING_JSON} with {len(accounting_rows)} rows.")

    # 4. Generate Inventory
    print("\n--- PHASE 4: Generating File Inventory ---")
    inventory = {}
    e3_dir = os.path.join(RV3, "e3")
    for root, dirs, files in os.walk(e3_dir):
        for f in files:
            p = os.path.join(root, f)
            rel_p = os.path.relpath(p, RV3)
            sz = os.path.getsize(p)
            with open(p, "rb") as fp:
                h = hashlib.sha256(fp.read()).hexdigest()
            inventory[rel_p] = {"size": sz, "sha256": h}
            
    write_json_atomic(INVENTORY_JSON, inventory)
    print(f"Inventory written ({len(inventory)} files in RV3/e3).")

    # 5. Summary
    status_counts = {}
    for r in accounting_rows:
        status_counts[r["status"]] = status_counts.get(r["status"], 0) + 1
        
    print("\n=== SUMMARY OF 43 MUTANTS ===")
    for st, cnt in sorted(status_counts.items()):
        print(f"  {st}: {cnt}")
        
    killed_list = [r["id"] for r in accounting_rows if r["status"] in ("KILLED", "KILLED-ALT")]
    masked_list = [r["id"] for r in accounting_rows if r["status"] == "MASKED"]
    survived_list = [r["id"] for r in accounting_rows if r["status"] == "SURVIVED"]
    fail_list = [r["id"] for r in accounting_rows if r["status"] not in ("KILLED", "KILLED-ALT", "MASKED", "SURVIVED")]
    
    print(f"KILLED ({len(killed_list)}): {killed_list}")
    print(f"MASKED ({len(masked_list)}): {masked_list}")
    print(f"SURVIVED ({len(survived_list)}): {survived_list}")
    if fail_list:
        print(f"FAIL/UNCLASSIFIED/INCOMPLETE ({len(fail_list)}): {fail_list}")
        
    print(f"\nDriver complete at {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}")

if __name__ == "__main__":
    main()
