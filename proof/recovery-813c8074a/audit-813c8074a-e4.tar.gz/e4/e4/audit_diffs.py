#!/usr/bin/env python3
import os
import sys
import json
import glob

RV3 = "/private/tmp/iyi-proof-complete-813c8074a"
W3 = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
W2 = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030"
H = "6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd"
H_PRIME = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"

def main():
    print("Auditing diff files under RV3...")
    diff_files = []
    for root, dirs, files in os.walk(RV3):
        if root.startswith(os.path.join(RV3, "e4")):
            continue
        for f in files:
            if f.endswith(".diff"):
                diff_files.append(os.path.join(root, f))
    diff_files = sorted(diff_files)
    print(f"Found {len(diff_files)} diff files:")
    for df in diff_files:
        print(f"  {os.path.relpath(df, RV3)}")

    # Analyze each diff file
    results = {}
    for df in diff_files:
        rel = os.path.relpath(df, RV3)
        with open(df, "r", encoding="utf-8") as f:
            content = f.read()
        lines = content.splitlines()
        
        # Count additions, deletions
        adds = [l for l in lines if l.startswith("+") and not l.startswith("+++")]
        dels = [l for l in lines if l.startswith("-") and not l.startswith("---")]
        
        results[rel] = {
            "path": df,
            "total_lines": len(lines),
            "add_lines": len(adds),
            "del_lines": len(dels),
            "content": content
        }

    out_file = os.path.join(RV3, "e4", "diffs_audit.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
    print(f"Saved diff audit to {out_file}")

if __name__ == "__main__":
    main()
