#!/usr/bin/env python3
import os
import sys
import json
import hashlib

RV3 = "/private/tmp/iyi-proof-complete-813c8074a"

def hash_file(path):
    if not os.path.exists(path):
        return 0, hashlib.sha256(b"").hexdigest()
    with open(path, "rb") as f:
        data = f.read()
    return len(data), hashlib.sha256(data).hexdigest()

def main():
    print(f"Auditing receipts under {RV3}...")
    receipt_files = []
    for root, dirs, files in os.walk(RV3):
        # Exclude e4 itself from the check of prior units
        if root.startswith(os.path.join(RV3, "e4")):
            continue
        if "end.json" in files:
            receipt_files.append(root)

    print(f"Found {len(receipt_files)} job directories with end.json")
    
    errors = []
    job_summaries = []
    
    for job_dir in sorted(receipt_files):
        end_path = os.path.join(job_dir, "end.json")
        try:
            with open(end_path, "r", encoding="utf-8") as f:
                end_data = json.load(f)
        except Exception as e:
            errors.append(f"{job_dir}: failed to read end.json: {e}")
            continue

        stdout_path = os.path.join(job_dir, "stdout.log")
        stderr_path = os.path.join(job_dir, "stderr.log")
        
        actual_stdout_len, actual_stdout_sha = hash_file(stdout_path)
        actual_stderr_len, actual_stderr_sha = hash_file(stderr_path)
        
        # Check stream hashes
        if end_data.get("stdout_bytes") != actual_stdout_len:
            errors.append(f"{job_dir}: stdout_bytes mismatch: end.json={end_data.get('stdout_bytes')}, actual={actual_stdout_len}")
        if end_data.get("stdout_sha256") != actual_stdout_sha:
            errors.append(f"{job_dir}: stdout_sha256 mismatch: end.json={end_data.get('stdout_sha256')}, actual={actual_stdout_sha}")
        if end_data.get("stderr_bytes") != actual_stderr_len:
            errors.append(f"{job_dir}: stderr_bytes mismatch: end.json={end_data.get('stderr_bytes')}, actual={actual_stderr_len}")
        if end_data.get("stderr_sha256") != actual_stderr_sha:
            errors.append(f"{job_dir}: stderr_sha256 mismatch: end.json={end_data.get('stderr_sha256')}, actual={actual_stderr_sha}")

        # Check free bytes >= 20 GiB (21474836480)
        free_bytes = end_data.get("free_bytes", 0)
        if free_bytes < 20 * 1024 * 1024 * 1024:
            errors.append(f"{job_dir}: free_bytes below 20 GiB: {free_bytes}")

        # Check start.json
        start_path = os.path.join(job_dir, "start.json")
        if not os.path.exists(start_path):
            errors.append(f"{job_dir}: missing start.json")

        # Check command.json (DO NOT OPEN e1/cov/command.json per prompt instructions!)
        command_path = os.path.join(job_dir, "command.json")
        if not os.path.exists(command_path):
            errors.append(f"{job_dir}: missing command.json")

        job_summaries.append({
            "job_dir": os.path.relpath(job_dir, RV3),
            "rc": end_data.get("rc"),
            "elapsed_sec": end_data.get("elapsed_sec"),
            "stdout_bytes": actual_stdout_len,
            "stderr_bytes": actual_stderr_len,
            "free_bytes": free_bytes,
            "utc": end_data.get("utc")
        })

    # Now verify all receipts.jsonl files
    receipts_jsonl_files = []
    for root, dirs, files in os.walk(RV3):
        if root.startswith(os.path.join(RV3, "e4")):
            continue
        if "receipts.jsonl" in files:
            receipts_jsonl_files.append(os.path.join(root, "receipts.jsonl"))

    print(f"Found {len(receipts_jsonl_files)} receipts.jsonl files")
    jsonl_entry_count = 0
    for r_file in sorted(receipts_jsonl_files):
        with open(r_file, "r", encoding="utf-8") as f:
            for line_no, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                jsonl_entry_count += 1
                try:
                    entry = json.loads(line)
                except Exception as e:
                    errors.append(f"{r_file}:{line_no}: invalid json: {e}")
                    continue
                # Verify that job_dir matches
                jdir = entry.get("job_dir")
                if not jdir or not os.path.exists(jdir):
                    errors.append(f"{r_file}:{line_no}: job_dir not found: {jdir}")

    print(f"Total receipts.jsonl entries: {jsonl_entry_count}")
    print(f"Total errors: {len(errors)}")
    if errors:
        for err in errors[:20]:
            print(f"  ERROR: {err}")
        if len(errors) > 20:
            print(f"  ... and {len(errors) - 20} more errors")
    else:
        print("ALL receipts and stream hashes verified successfully!")

    out_file = os.path.join(RV3, "e4", "receipts_audit.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump({
            "total_jobs": len(job_summaries),
            "total_receipts_jsonl_files": len(receipts_jsonl_files),
            "total_receipts_entries": jsonl_entry_count,
            "error_count": len(errors),
            "errors": errors,
            "jobs": job_summaries
        }, f, indent=2)

if __name__ == "__main__":
    main()
