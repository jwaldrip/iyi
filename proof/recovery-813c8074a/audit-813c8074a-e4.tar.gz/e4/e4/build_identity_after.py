#!/usr/bin/env python3
import os
import sys
import json
import hashlib
import subprocess
from datetime import datetime, timezone

RV3 = "/private/tmp/iyi-proof-complete-813c8074a"
W3 = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
W2 = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030"
P = "/Users/jwaldrip/dev/worktrees/iyi-stale-integration-repair"
E = "/Users/jwaldrip/dev/worktrees/iyi-stale-recovery-evidence-20261030"

H = "6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd"
H_PRIME = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
P1 = "626463375298d357ffcb3223059f4d3adce6fb10"

def get_sha256(path):
    if not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

def run_git(cmd, cwd):
    env = dict(os.environ)
    env["GIT_OPTIONAL_LOCKS"] = "0"
    res = subprocess.run(["git", "-C", cwd] + cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    return res.returncode, res.stdout.decode("utf-8", "surrogateescape").strip(), res.stderr.decode("utf-8", "surrogateescape").strip()

def get_file_info(path, rel_to):
    rel_path = os.path.relpath(path, rel_to)
    st = os.stat(path)
    return {
        "rel_path": rel_path,
        "size": st.st_size,
        "sha256": get_sha256(path),
        "inode": st.st_ino,
        "mtime_ns": st.st_mtime_ns
    }

def main():
    print("Collecting identity-after data...")
    setup_path = os.path.join(RV3, "setup.json")
    with open(setup_path, "r", encoding="utf-8") as f:
        setup_data = json.load(f)

    # 1. Measure files in RV3
    files_after = {}
    for fname, finfo in setup_data["files"].items():
        p = finfo["path"]
        if os.path.exists(p):
            st = os.stat(p)
            files_after[fname] = {
                "path": p,
                "size": st.st_size,
                "sha256": get_sha256(p)
            }
        else:
            files_after[fname] = {
                "path": p,
                "missing": True
            }

    # 2. Measure W3
    rc, head_w3, _ = run_git(["rev-parse", "HEAD"], W3)
    rc, porcelain_w3, _ = run_git(["status", "--porcelain=v1", "--untracked-files=all"], W3)
    rc, ignored_w3_raw, _ = run_git(["status", "--porcelain=v1", "--ignored"], W3)
    ignored_w3 = [l[3:].strip() for l in ignored_w3_raw.splitlines() if l.startswith("!!")]
    rc, ls_remote_w3, _ = run_git(["ls-remote", "origin", "refs/heads/proof/audit-repair-g02-g18-20261031"], W3)
    ls_remote_w3_sha = ls_remote_w3.split()[0] if ls_remote_w3 else ""
    rc, parent_h, _ = run_git(["rev-parse", "HEAD^"], W3)
    rc_mb, _, _ = run_git(["merge-base", "--is-ancestor", P1, "HEAD"], W3)
    rc_diff, _, _ = run_git(["diff", "--quiet", P1, "HEAD", "--", ".", ":(exclude)proof"], W3)

    w3_after = {
        "path": W3,
        "head": head_w3,
        "clean": (porcelain_w3 == ""),
        "porcelain": porcelain_w3,
        "ignored_files": ignored_w3,
        "ignored_count": len(ignored_w3),
        "ls_remote_sha": ls_remote_w3_sha,
        "remote_at_h_prime": (ls_remote_w3_sha == H_PRIME),
        "parent_h": parent_h,
        "parent_equals_h": (parent_h == H),
        "merge_base_is_ancestor_p1": (rc_mb == 0),
        "product_diff_outside_proof_empty": (rc_diff == 0)
    }

    # 3. Measure W2
    rc, head_w2, _ = run_git(["rev-parse", "HEAD"], W2)
    rc, porcelain_w2, _ = run_git(["status", "--porcelain=v1", "--untracked-files=all"], W2)
    rc, ls_remote_w2, _ = run_git(["ls-remote", "origin", "refs/heads/proof/audit-deadlines-seams-20261030"], W2)
    ls_remote_w2_sha = ls_remote_w2.split()[0] if ls_remote_w2 else ""
    rc, ignored_w2_raw, _ = run_git(["status", "--porcelain=v1", "--ignored"], W2)
    ignored_w2_rel = sorted([l[3:].strip() for l in ignored_w2_raw.splitlines() if l.startswith("!!")])
    # Filter out pycache residue if reported separately in setup.json
    ignored_w2_files = []
    for rel in ignored_w2_rel:
        full_p = os.path.join(W2, rel)
        if os.path.isfile(full_p):
            ignored_w2_files.append(get_file_info(full_p, W2))
        elif os.path.isdir(full_p):
            for r, d, fs in os.walk(full_p):
                for f in fs:
                    ignored_w2_files.append(get_file_info(os.path.join(r, f), W2))
    ignored_w2_files = sorted(ignored_w2_files, key=lambda x: x["rel_path"])
    ignored_w2_rel_paths = sorted([x["rel_path"] for x in ignored_w2_files if not x["rel_path"].startswith("proof/__pycache__")])
    list_str = "\n".join(ignored_w2_rel_paths) + "\n"
    ignored_w2_hash = hashlib.sha256(list_str.encode("utf-8")).hexdigest()

    w2_after = {
        "path": W2,
        "head": head_w2,
        "clean": (porcelain_w2 == ""),
        "porcelain": porcelain_w2,
        "ls_remote_sha": ls_remote_w2_sha,
        "remote_at_h": (ls_remote_w2_sha == H),
        "ignored_count": len([x for x in ignored_w2_files if not x["rel_path"].startswith("proof/__pycache__")]),
        "ignored_files": [x for x in ignored_w2_files if not x["rel_path"].startswith("proof/__pycache__")],
        "ignored_path_list_sha256": ignored_w2_hash,
        "runtime_residue_pycache": setup_data["preflight"]["w2"].get("runtime_residue_pycache")
    }

    # 4. Measure P
    rc, head_p, _ = run_git(["rev-parse", "HEAD"], P)
    rc, porcelain_p, _ = run_git(["status", "--porcelain=v1", "--untracked-files=all"], P)
    rc, ignored_p_raw, _ = run_git(["status", "--porcelain=v1", "--ignored"], P)
    ignored_p_rel = sorted([l[3:].strip() for l in ignored_p_raw.splitlines() if l.startswith("!!")])
    ignored_p_files = []
    for rel in ignored_p_rel:
        full_p = os.path.join(P, rel)
        if os.path.isfile(full_p):
            ignored_p_files.append(get_file_info(full_p, P))
        elif os.path.isdir(full_p):
            for r, d, fs in os.walk(full_p):
                for f in fs:
                    ignored_p_files.append(get_file_info(os.path.join(r, f), P))
    ignored_p_files = sorted(ignored_p_files, key=lambda x: x["rel_path"])

    p_after = {
        "path": P,
        "head": head_p,
        "clean": (porcelain_p == ""),
        "porcelain": porcelain_p,
        "ignored_count": len(ignored_p_files),
        "ignored_files": ignored_p_files
    }

    # 5. Measure Binaries vs M2
    m2_path = os.path.join(RV3, "inputs", "p1-binaries-m2.json")
    with open(m2_path, "r", encoding="utf-8") as f:
        m2_items = json.load(f)
    m2_map = {item["name"]: item for item in m2_items}

    binaries_items = []
    all_match = True
    for name in ["iyi", "crystal", "iyi-daemon", "crystal-daemon"]:
        p_path = os.path.join(P, ".build", name)
        st = os.stat(p_path)
        sha = get_sha256(p_path)
        exp = m2_map[name]
        
        sha_match = (sha == exp["sha256"])
        sz_match = (st.st_size == exp["size"])
        ino_match = (st.st_ino == exp["inode"])
        mtime_match = (st.st_mtime_ns == exp["mtime_ns"])
        
        if not (sha_match and sz_match and ino_match and mtime_match):
            all_match = False
            
        binaries_items.append({
            "name": name,
            "path": p_path,
            "sha256": sha,
            "size": st.st_size,
            "inode": st.st_ino,
            "mtime_ns": st.st_mtime_ns,
            "expected_sha256": exp["sha256"],
            "expected_size": exp["size"],
            "expected_inode": exp["inode"],
            "expected_mtime_ns": exp["mtime_ns"],
            "sha256_match": sha_match,
            "size_match": sz_match,
            "inode_match": ino_match,
            "mtime_ns_match": mtime_match
        })

    binaries_after = {
        "manifest": "inputs/p1-binaries-m2.json",
        "all_match": all_match,
        "items": binaries_items
    }

    # 6. Measure tmp_storage
    stat_tmp = os.statvfs("/private/tmp")
    free_bytes = stat_tmp.f_bavail * stat_tmp.f_frsize
    free_gb = free_bytes / (1024 ** 3)
    
    scratch_entries = []
    for entry in sorted(os.listdir("/private/tmp")):
        if entry.startswith("iyi-") or entry.startswith("iyp-"):
            epath = os.path.join("/private/tmp", entry)
            st = os.stat(epath)
            mtime_dt = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat()
            scratch_entries.append({
                "name": entry,
                "path": epath,
                "mtime": mtime_dt,
                "mtime_ns": st.st_mtime_ns,
                "is_dir": os.path.isdir(epath)
            })

    tmp_storage_after = {
        "free_bytes": free_bytes,
        "free_gb": free_gb,
        "ge_20gib": (free_bytes >= 20 * 1024 * 1024 * 1024),
        "scratch_entries_count": len(scratch_entries),
        "scratch_entries": scratch_entries
    }

    # 7. Check running processes
    targets = ["smoke_test.py", "run_proof.py", "roundtrip_shim.py", "artifact_legs.py"]
    ps_res = subprocess.run(["ps", "-A", "-o", "pid,command"], stdout=subprocess.PIPE, text=True)
    found_procs = []
    for line in ps_res.stdout.splitlines():
        for t in targets:
            if t in line:
                found_procs.append(line.strip())
                break
    running_procs_after = {
        "targets": targets,
        "found_count": len(found_procs),
        "found_processes": found_procs
    }

    # 8. Check leases
    leases_items = []
    all_leases_alive = True
    for item in setup_data["preflight"]["leases"]["items"]:
        pid = item["pid"]
        svc = item["service"]
        lsof_res = subprocess.run(["lsof", "-n", "-P", "-w", "-a", "-p", str(pid), "-d", "cwd", "-Fn"], stdout=subprocess.PIPE, text=True)
        lsof_out = lsof_res.stdout.strip()
        ps_check = subprocess.run(["ps", "-p", str(pid)], stdout=subprocess.PIPE)
        alive = (ps_check.returncode == 0) and (len(lsof_out) > 0)
        if not alive:
            all_leases_alive = False
        leases_items.append({
            "service": svc,
            "pid": pid,
            "alive": alive,
            "lsof_cwd_output": lsof_out
        })

    leases_after = {
        "all_alive": all_leases_alive,
        "items": leases_items
    }

    # 9. Perform field-by-field comparison
    pre = setup_data["preflight"]
    comparison = {
        "w3_unchanged": {
            "head_match": (pre["w3"]["head"] == w3_after["head"] == H_PRIME),
            "clean_match": (pre["w3"]["clean"] == w3_after["clean"] == True),
            "ignored_count_match": (pre["w3"]["ignored_count"] == w3_after["ignored_count"] == 0),
            "ls_remote_match": (pre["w3"]["ls_remote_sha"] == w3_after["ls_remote_sha"] == H_PRIME),
            "remote_at_h_prime": w3_after["remote_at_h_prime"],
            "parent_h_match": (pre["w3"]["parent_h"] == w3_after["parent_h"] == H),
            "merge_base_is_ancestor_p1": w3_after["merge_base_is_ancestor_p1"],
            "product_diff_outside_proof_empty": w3_after["product_diff_outside_proof_empty"]
        },
        "w2_unchanged": {
            "head_match": (pre["w2"]["head"] == w2_after["head"] == H),
            "clean_match": (pre["w2"]["clean"] == w2_after["clean"] == True),
            "ls_remote_match": (pre["w2"]["ls_remote_sha"] == w2_after["ls_remote_sha"] == H),
            "ignored_count_match": (pre["w2"]["ignored_count"] == w2_after["ignored_count"] == 9),
            "ignored_hash_match": (pre["w2"]["ignored_path_list_sha256"] == w2_after["ignored_path_list_sha256"] == "0f82411aee9ddd7a4bacf1c35bc741fb404d89e9bce26109ca9580e60583ec69"),
            "ignored_files_identical": (pre["w2"]["ignored_files"] == w2_after["ignored_files"])
        },
        "p_unchanged": {
            "head_match": (pre["p"]["head"] == p_after["head"] == P1),
            "clean_match": (pre["p"]["clean"] == p_after["clean"] == True),
            "ignored_count_match": (pre["p"]["ignored_count"] == p_after["ignored_count"] == 13),
            "ignored_files_identical": (pre["p"]["ignored_files"] == p_after["ignored_files"])
        },
        "binaries_unchanged": {
            "all_match": all_match,
            "setup_all_match": pre["binaries"]["all_match"],
            "binaries_items_equal_to_setup": (pre["binaries"]["items"] == binaries_after["items"])
        },
        "leases_unchanged": {
            "all_alive": all_leases_alive,
            "pids_equal": ([x["pid"] for x in pre["leases"]["items"]] == [x["pid"] for x in leases_after["items"]]),
            "cwds_equal": ([x["lsof_cwd_output"] for x in pre["leases"]["items"]] == [x["lsof_cwd_output"] for x in leases_after["items"]])
        },
        "free_space": {
            "before_bytes": pre["tmp_storage"]["free_bytes"],
            "after_bytes": tmp_storage_after["free_bytes"],
            "after_ge_20gib": tmp_storage_after["ge_20gib"]
        }
    }

    identity_after = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "files": files_after,
        "postflight": {
            "w3": w3_after,
            "w2": w2_after,
            "p": p_after,
            "binaries": binaries_after,
            "tmp_storage": tmp_storage_after,
            "running_processes": running_procs_after,
            "leases": leases_after
        },
        "comparison": comparison
    }

    out_path = os.path.join(RV3, "e4", "identity-after.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(identity_after, f, indent=2)
    print(f"Saved identity-after.json to {out_path}")

if __name__ == "__main__":
    main()
