#!/usr/bin/env python3
import os
import sys
import json
import subprocess
from datetime import datetime, timezone

RV3 = "/private/tmp/iyi-proof-complete-813c8074a"

def main():
    print("Building residue.json...")
    setup_path = os.path.join(RV3, "setup.json")
    with open(setup_path, "r", encoding="utf-8") as f:
        setup_data = json.load(f)

    preflight_entries = {e["name"]: e for e in setup_data["preflight"]["tmp_storage"]["scratch_entries"]}
    
    current_entries = []
    for entry in sorted(os.listdir("/private/tmp")):
        if entry.startswith("iyi-") or entry.startswith("iyp-"):
            epath = os.path.join("/private/tmp", entry)
            st = os.stat(epath)
            mtime_dt = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat()
            current_entries.append({
                "name": entry,
                "path": epath,
                "mtime": mtime_dt,
                "mtime_ns": st.st_mtime_ns,
                "is_dir": os.path.isdir(epath),
                "is_preflight": (entry in preflight_entries)
            })

    # Find newly created entries since setup.json
    new_entries = [e for e in current_entries if not e["is_preflight"]]

    # Attribute new entries to receipts
    # Load all receipts
    receipts_audit_path = os.path.join(RV3, "e4", "receipts_audit.json")
    with open(receipts_audit_path, "r", encoding="utf-8") as f:
        receipts_audit = json.load(f)

    # Specific attribution for iyi-canary-6bbe1bf2e-7er4lzm0
    attributed_new_entries = []
    for entry in new_entries:
        attribution = {
            "entry": entry,
            "attributed_job": None,
            "note": None
        }
        if entry["name"].startswith("iyi-canary-"):
            # Check E2d canary job
            e2d_job_dir = os.path.join(RV3, "e2", "canary", "job")
            if os.path.exists(e2d_job_dir):
                with open(os.path.join(e2d_job_dir, "start.json")) as f:
                    s = json.load(f)
                with open(os.path.join(e2d_job_dir, "end.json")) as f:
                    e = json.load(f)
                attribution["attributed_job"] = {
                    "job_dir": os.path.relpath(e2d_job_dir, RV3),
                    "unit": "E2d (canaries C1/C2)",
                    "start_utc": s.get("utc"),
                    "end_utc": e.get("utc"),
                    "rc": e.get("rc")
                }
                attribution["note"] = (
                    "Scratch directory created by canaries.py during unit E2d. "
                    "Per reaudit plan §3.4, canaries.py was re-bound verbatim at sha 51db1867... "
                    "and therefore retains its hard-coded scratch prefix 'iyi-canary-6bbe1bf2e-'. "
                    "Nothing was deleted per protocol."
                )
        attributed_new_entries.append(attribution)

    # Disclosures of pre-existing and retained roots
    disclosed_roots = [
        {
            "name": "iyi-proof-complete-6bbe1bf2e",
            "path": "/private/tmp/iyi-proof-complete-6bbe1bf2e",
            "classification": "pre_existing_audit_root_at_H",
            "disclosed_in_setup": True,
            "deleted": False,
            "note": "Archived audit root from frozen head H run. Preserved untouched."
        },
        {
            "name": "iyi-proof-review-6bbe1bf2e",
            "path": "/private/tmp/iyi-proof-review-6bbe1bf2e",
            "classification": "pre_existing_audit_review_root_at_H",
            "disclosed_in_setup": True,
            "deleted": False,
            "note": "Archived audit review root from frozen head H run. Preserved untouched."
        },
        {
            "name": "iyi-canary-6bbe1bf2e-efmbfx4x",
            "path": "/private/tmp/iyi-canary-6bbe1bf2e-efmbfx4x",
            "classification": "pre_existing_canary_scratch_at_H",
            "disclosed_in_setup": True,
            "deleted": False,
            "note": "Canary scratch directory from earlier H run. Preserved untouched."
        },
        {
            "name": "iyi-canary-6bbe1bf2e-7er4lzm0",
            "path": "/private/tmp/iyi-canary-6bbe1bf2e-7er4lzm0",
            "classification": "new_canary_scratch_at_H_prime",
            "disclosed_in_setup": False,
            "deleted": False,
            "note": "Canary scratch directory created during H' E2d execution. Attributed to E2d receipt. Preserved untouched."
        },
        {
            "name": "iyi-proof-complete-813c8074a",
            "path": "/private/tmp/iyi-proof-complete-813c8074a",
            "classification": "active_reaudit_root_at_H_prime",
            "disclosed_in_setup": True,
            "deleted": False,
            "note": "RV3: Root of complete re-audit at H'. All units wrote here."
        }
    ]

    residue_data = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "summary": {
            "total_tmp_scratch_entries": len(current_entries),
            "preflight_entries_count": len(preflight_entries),
            "new_entries_count": len(new_entries),
            "deleted_count": 0,
            "all_new_entries_attributed": all(a["attributed_job"] is not None for a in attributed_new_entries)
        },
        "new_entries": attributed_new_entries,
        "disclosed_scratch_roots": disclosed_roots,
        "all_entries": current_entries
    }

    out_path = os.path.join(RV3, "e4", "residue.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(residue_data, f, indent=2)
    print(f"Saved residue.json to {out_path}")

if __name__ == "__main__":
    main()
