#!/usr/bin/env python3
import os
import sys
import json

RV3 = "/private/tmp/iyi-proof-complete-813c8074a"
W3 = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
W2 = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030"
P = "/Users/jwaldrip/dev/worktrees/iyi-stale-integration-repair"
E = "/Users/jwaldrip/dev/worktrees/iyi-stale-recovery-evidence-20261030"

H = "6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd"
H_PRIME = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
P1 = "626463375298d357ffcb3223059f4d3adce6fb10"

def parse_cover_file(path):
    missing_lines = []
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for idx, line in enumerate(f, 1):
            if line.startswith(">>>>>>"):
                missing_lines.append(idx)
    return missing_lines

def main():
    print("Computing G1-G10 table from raw artifacts (final accurate keys)...")
    g_results = {}

    # ----------------------------------------------------
    # G1a: source identity
    # ----------------------------------------------------
    with open(os.path.join(RV3, "setup.json")) as f:
        setup_j = json.load(f)
    with open(os.path.join(RV3, "e4", "identity-after.json")) as f:
        ident_after_j = json.load(f)
    with open(os.path.join(RV3, "evidence", "plan", "plan.json")) as f:
        rv_plan_j = json.load(f)
    with open(os.path.join(RV3, "ev", "plan", "plan.json")) as f:
        ev_plan_j = json.load(f)
    with open(os.path.join(RV3, "ev", "plan", "plan.log")) as f:
        ev_plan_log = f.read()

    w3_ok = (
        ident_after_j["postflight"]["w3"]["head"] == H_PRIME and
        ident_after_j["postflight"]["w3"]["clean"] is True and
        ident_after_j["postflight"]["w3"]["ignored_count"] == 0 and
        ident_after_j["postflight"]["w3"]["remote_at_h_prime"] is True and
        ident_after_j["postflight"]["w3"]["parent_equals_h"] is True and
        ident_after_j["postflight"]["w3"]["merge_base_is_ancestor_p1"] is True and
        ident_after_j["postflight"]["w3"]["product_diff_outside_proof_empty"] is True
    )
    w2_ok = (
        ident_after_j["postflight"]["w2"]["head"] == H and
        ident_after_j["postflight"]["w2"]["clean"] is True and
        ident_after_j["postflight"]["w2"]["remote_at_h"] is True
    )
    p_ok = (
        ident_after_j["postflight"]["p"]["head"] == P1 and
        ident_after_j["postflight"]["p"]["clean"] is True
    )
    plan_ok = (
        rv_plan_j.get("rc") == 0 and
        ev_plan_j.get("rc") == 0 and
        "W HEAD:    813c8074acb2eed99ffeef78ea49e8c7832e4c01" in rv_plan_j.get("stdout", "") and
        "W HEAD:    813c8074acb2eed99ffeef78ea49e8c7832e4c01" in ev_plan_log
    )
    g1a_status = "PASS" if (w3_ok and w2_ok and p_ok and plan_ok) else "FAIL"
    g_results["G1a"] = {
        "status": g1a_status,
        "name": "source identity",
        "cites": [
            "setup.json",
            "e4/identity-after.json",
            "evidence/plan/plan.json",
            "ev/plan/plan.json",
            "ev/plan/plan.log"
        ],
        "recomputed_numbers": {
            "w3_head": ident_after_j["postflight"]["w3"]["head"],
            "w3_clean": ident_after_j["postflight"]["w3"]["clean"],
            "w3_ignored": ident_after_j["postflight"]["w3"]["ignored_count"],
            "w3_remote": ident_after_j["postflight"]["w3"]["ls_remote_sha"],
            "w3_parent": ident_after_j["postflight"]["w3"]["parent_h"],
            "w2_head": ident_after_j["postflight"]["w2"]["head"],
            "w2_clean": ident_after_j["postflight"]["w2"]["clean"],
            "w2_remote": ident_after_j["postflight"]["w2"]["ls_remote_sha"],
            "p_head": ident_after_j["postflight"]["p"]["head"],
            "p_clean": ident_after_j["postflight"]["p"]["clean"],
            "rv_plan_rc": rv_plan_j.get("rc"),
            "ev_plan_rc": ev_plan_j.get("rc")
        }
    }

    # ----------------------------------------------------
    # G1b: inputs & binaries
    # ----------------------------------------------------
    bin_comp = ident_after_j["comparison"]["binaries_unchanged"]
    w2_comp = ident_after_j["comparison"]["w2_unchanged"]
    p_comp = ident_after_j["comparison"]["p_unchanged"]
    g1b_status = "PASS" if (
        bin_comp["all_match"] and
        bin_comp["binaries_items_equal_to_setup"] and
        w2_comp["ignored_count_match"] and
        w2_comp["ignored_hash_match"] and
        w2_comp["ignored_files_identical"] and
        p_comp["ignored_count_match"] and
        p_comp["ignored_files_identical"]
    ) else "FAIL"
    g_results["G1b"] = {
        "status": g1b_status,
        "name": "inputs and M2 binaries",
        "cites": [
            "setup.json",
            "e4/identity-after.json",
            "inputs/p1-binaries-m2.json"
        ],
        "recomputed_numbers": {
            "p_ignored_count": ident_after_j["postflight"]["p"]["ignored_count"],
            "w2_ignored_count": ident_after_j["postflight"]["w2"]["ignored_count"],
            "w2_ignored_hash": ident_after_j["postflight"]["w2"]["ignored_path_list_sha256"],
            "binaries_count": len(ident_after_j["postflight"]["binaries"]["items"]),
            "binaries_all_match": bin_comp["all_match"]
        }
    }

    # ----------------------------------------------------
    # G1c: scratch residue
    # ----------------------------------------------------
    with open(os.path.join(RV3, "e4", "residue.json")) as f:
        residue_j = json.load(f)
    g1c_status = "PASS" if (
        residue_j["summary"]["deleted_count"] == 0 and
        residue_j["summary"]["all_new_entries_attributed"] is True
    ) else "FAIL"
    g_results["G1c"] = {
        "status": g1c_status,
        "name": "scratch attribution",
        "cites": ["e4/residue.json"],
        "recomputed_numbers": {
            "total_tmp_entries": residue_j["summary"]["total_tmp_scratch_entries"],
            "new_entries_count": residue_j["summary"]["new_entries_count"],
            "deleted_count": residue_j["summary"]["deleted_count"],
            "all_new_attributed": residue_j["summary"]["all_new_entries_attributed"]
        }
    }

    # ----------------------------------------------------
    # G1d: code shape and layout
    # ----------------------------------------------------
    with open(os.path.join(RV3, "line-map-proof.json")) as f:
        line_map_proof = json.load(f)
    with open(os.path.join(RV3, "evidence", "layout", "delta_shape.json")) as f:
        delta_shape_j = json.load(f)
    with open(os.path.join(RV3, "evidence", "layout", "selftest.log")) as f:
        selftest_log = f.read()
    with open(os.path.join(RV3, "evidence", "layout", "layout-check.log")) as f:
        layout_check_h = f.read()
    with open(os.path.join(RV3, "evidence", "layout", "layout-check-hprime.log")) as f:
        layout_check_hp = f.read()

    layout_h_pass = ("C1 PASS" in layout_check_h and "C2 PASS" in layout_check_h and "C3 PASS" in layout_check_h and "C4 PASS" in layout_check_h and "C5 PASS" in layout_check_h)
    layout_hp_predicted = ("C1 PASS" in layout_check_hp and "C2 PASS" in layout_check_hp and "C3 PASS" in layout_check_hp and "C4 FAIL" in layout_check_hp and "C5 FAIL" in layout_check_hp and "run_proof" in layout_check_hp)
    
    g1d_status = "PASS" if (
        line_map_proof.get("status") == "PASS" and
        delta_shape_j.get("status") == "PASS" and
        layout_h_pass and
        layout_hp_predicted
    ) else "FAIL"
    g_results["G1d"] = {
        "status": g1d_status,
        "name": "code shape and layout",
        "cites": [
            "line-map.json",
            "line-map-proof.json",
            "evidence/layout/selftest.log",
            "evidence/layout/layout-check.log",
            "evidence/layout/layout-check-hprime.log",
            "evidence/layout/delta_shape.json"
        ],
        "recomputed_numbers": {
            "line_map_proof_status": line_map_proof.get("status"),
            "unchanged_lines_checked": line_map_proof.get("unchanged_lines_checked"),
            "delta_shape_status": delta_shape_j.get("status"),
            "delta_numstat": delta_shape_j.get("numstat_check", {}).get("actual"),
            "layout_base_h_c1_c5": "ALL_PASS",
            "layout_base_hprime_c1_c5": "C1_PASS, C2_PASS, C3_PASS, C4_FAIL(smoke_test.py), C5_FAIL(['run_proof'])"
        }
    }

    # ----------------------------------------------------
    # G2: reuse ledger & R1 comparison
    # ----------------------------------------------------
    with open(os.path.join(RV3, "e4", "reuse-ledger.json")) as f:
        reuse_ledger_j = json.load(f)
    with open(os.path.join(RV3, "r1", "compare.json")) as f:
        r1_compare_j = json.load(f)

    smoke_sum = r1_compare_j["summary"]["smoke"]
    o3_sum = r1_compare_j["summary"]["o3"]
    r1_smoke_equal = (
        smoke_sum["seeds_equal"] is True and
        smoke_sum["controls_equal"] is True and
        smoke_sum["seed_count"] == 435 and
        smoke_sum["control_count"] == 85 and
        smoke_sum["semantic_expect_diffs"] == 0 and
        smoke_sum["semantic_got_diffs"] == 0 and
        smoke_sum["control_diffs"] == 0
    )
    r1_o3_equal = (
        o3_sum["seeds_equal"] is True and
        o3_sum["controls_equal"] is True and
        o3_sum["seed_count"] == 23 and
        o3_sum["control_count"] == 6 and
        o3_sum["semantic_expect_diffs"] == 0 and
        o3_sum["semantic_got_diffs"] == 0 and
        o3_sum["control_diffs"] == 0
    )
    g2_status = "PASS" if (
        reuse_ledger_j["summary"]["all_matched_archive"] is True and
        reuse_ledger_j["summary"]["execution_evidence_reused"] is False and
        r1_smoke_equal and
        r1_o3_equal
    ) else "FAIL"
    g_results["G2"] = {
        "status": g2_status,
        "name": "reuse ledger and log comparison",
        "cites": [
            "e4/reuse-ledger.json",
            "r1/compare.json"
        ],
        "recomputed_numbers": {
            "rebound_items_count": reuse_ledger_j["summary"]["total_rebound_items"],
            "all_matched_archive": reuse_ledger_j["summary"]["all_matched_archive"],
            "execution_evidence_reused": reuse_ledger_j["summary"]["execution_evidence_reused"],
            "r1_smoke_fixtures": smoke_sum["seed_count"] + smoke_sum["control_count"],
            "r1_smoke_seeds_equal": smoke_sum["seeds_equal"],
            "r1_smoke_controls_equal": smoke_sum["controls_equal"],
            "r1_o3_fixtures": o3_sum["seed_count"] + o3_sum["control_count"],
            "r1_o3_seeds_equal": o3_sum["seeds_equal"],
            "r1_o3_controls_equal": o3_sum["controls_equal"]
        }
    }

    # ----------------------------------------------------
    # G3: coverage & P10
    # ----------------------------------------------------
    with open(os.path.join(RV3, "e1", "cov", "end.json")) as f:
        e1_end = json.load(f)
    with open(os.path.join(RV3, "e1", "cov", "stdout.log")) as f:
        e1_stdout = f.read()
    with open(os.path.join(RV3, "e1", "summary.json")) as f:
        e1_summary = json.load(f)
    with open(os.path.join(RV3, "e1", "p10.json")) as f:
        e1_p10 = json.load(f)
    with open(os.path.join(RV3, "e1", "p10_verify.json")) as f:
        e1_p10_verify = json.load(f)

    cov_out_dir = os.path.join(RV3, "e1", "cov-out")
    cov_missing = {
        "proofkit": len(parse_cover_file(os.path.join(cov_out_dir, "proof.proofkit.cover"))),
        "run_proof": len(parse_cover_file(os.path.join(cov_out_dir, "proof.run_proof.cover"))),
        "artifact_legs": len(parse_cover_file(os.path.join(cov_out_dir, "proof.artifact_legs.cover"))),
        "roundtrip_shim": len(parse_cover_file(os.path.join(cov_out_dir, "proof.roundtrip_shim.cover")))
    }
    missing_lines_equal_h = (
        cov_missing["proofkit"] == 0 and
        cov_missing["run_proof"] == 6 and
        cov_missing["artifact_legs"] == 1 and
        cov_missing["roundtrip_shim"] == 14
    )
    g3_status = "PASS" if (
        e1_end.get("rc") == 0 and
        "HARNESS PASS" in e1_stdout and
        "COVERAGE GATE PASS" in e1_stdout and
        missing_lines_equal_h and
        e1_summary.get("status") == "PASS" and
        len(e1_p10) == 7 and
        e1_p10_verify.get("status") == "PASS" and
        e1_p10_verify.get("all_statements_match") is True
    ) else "FAIL"
    g_results["G3"] = {
        "status": g3_status,
        "name": "coverage gate and P10 analysis",
        "cites": [
            "e1/cov/stdout.log",
            "e1/cov/end.json",
            "e1/cov-out/*.cover",
            "e1/summary.json",
            "e1/p10.json",
            "e1/p10_verify.json"
        ],
        "recomputed_numbers": {
            "cov_rc": e1_end.get("rc"),
            "cov_fixtures_executed": e1_summary["fixture_id_comparison"]["cov_fixture_count"],
            "missing_lines": cov_missing,
            "missing_lines_equal_h": missing_lines_equal_h,
            "p10_rows_count": len(e1_p10),
            "p10_verify_status": e1_p10_verify.get("status")
        }
    }

    # ----------------------------------------------------
    # G4: manual seeds and E2a
    # ----------------------------------------------------
    manual_seeds_file = os.path.join(RV3, "evidence", "manual_seeds", "seeds.jsonl")
    manual_rows = []
    with open(manual_seeds_file, "r") as f:
        for l in f:
            if l.strip():
                manual_rows.append(json.loads(l))

    with open(os.path.join(RV3, "e2", "seed5", "seed", "end.json")) as f:
        e2a_seed_end = json.load(f)
    with open(os.path.join(RV3, "e2", "seed5", "seed", "result.json")) as f:
        e2a_seed_result = json.load(f)
    with open(os.path.join(RV3, "e2", "seed5", "seed", "assertions.json")) as f:
        e2a_seed_assertions = json.load(f)
    with open(os.path.join(RV3, "e2", "seed5", "control", "end.json")) as f:
        e2a_ctl_end = json.load(f)
    with open(os.path.join(RV3, "e2", "seed5", "control", "result.json")) as f:
        e2a_ctl_result = json.load(f)

    manual_ok = (
        len(manual_rows) >= 8 and
        manual_rows[0].get("final_rc") == 0 and manual_rows[0].get("final_status") == "PASS" and
        "STALE" in manual_rows[1].get("seed_statuses", []) and
        manual_rows[2].get("rc") == 125 and
        manual_rows[3].get("rc") == 0 and
        manual_rows[4].get("final_rc") == 1 and manual_rows[4].get("final_status") == "FAIL" and
        "C5.7-template" in manual_rows[5].get("rule_ids", []) and
        "E1-exec-token" in manual_rows[6].get("rule_ids", []) and
        manual_rows[7].get("gate") == "PASS" and manual_rows[7].get("status") == "PASS" and manual_rows[7].get("rc") == 0
    )

    e2a_ok = (
        e2a_seed_end.get("rc") == 1 and
        e2a_seed_result.get("status") == "TIMEOUT" and
        e2a_seed_assertions.get("verdict") == "PASS" and
        e2a_ctl_end.get("rc") == 0 and
        e2a_ctl_result.get("status") == "PASS"
    )

    g4_status = "PASS" if (manual_ok and e2a_ok) else "FAIL"
    g_results["G4"] = {
        "status": g4_status,
        "name": "manual seeds 1-4, gate leg, and E2a",
        "cites": [
            "evidence/manual_seeds/seeds.jsonl",
            "evidence/manual_seeds/seed5-run1_1.times",
            "e2/seed5/seed/end.json",
            "e2/seed5/seed/result.json",
            "e2/seed5/seed/assertions.json",
            "e2/seed5/control/end.json",
            "e2/seed5/control/result.json"
        ],
        "recomputed_numbers": {
            "manual_seeds_rows_verified": len(manual_rows),
            "manual_seeds_1_8_all_expected": manual_ok,
            "e2a_seed_rc": e2a_seed_end.get("rc"),
            "e2a_seed_status": e2a_seed_result.get("status"),
            "e2a_seed_assertions_verdict": e2a_seed_assertions.get("verdict"),
            "e2a_control_rc": e2a_ctl_end.get("rc"),
            "e2a_control_status": e2a_ctl_result.get("status")
        }
    }

    # ----------------------------------------------------
    # G5: F guards & audit items
    # ----------------------------------------------------
    with open(os.path.join(RV3, "evidence", "fguards", "touch_unread.json")) as f:
        touch_unread_j = json.load(f)
    with open(os.path.join(RV3, "evidence", "fguards", "demo_final_required.json")) as f:
        demo_final_j = json.load(f)
    with open(os.path.join(RV3, "evidence", "fguards", "demo_misclassified.json")) as f:
        demo_misc_j = json.load(f)
    with open(os.path.join(RV3, "evidence", "fguards", "matcher_attacks.json")) as f:
        matcher_j = json.load(f)
    with open(os.path.join(RV3, "e2", "f3-run2", "f3_run2_summary.json")) as f:
        e2b_summary = json.load(f)
    with open(os.path.join(RV3, "evidence", "plan", "plan.log")) as f:
        plan_log = f.read()

    fguards_rows = []
    with open(os.path.join(RV3, "evidence", "fguards", "fguards.jsonl")) as f:
        for l in f:
            if l.strip():
                fguards_rows.append(json.loads(l))

    fguards_ok = len(fguards_rows) == 8 and all(len(r.get("violations", [])) == 1 for r in fguards_rows)
    touch_unread_ok = (touch_unread_j.get("verdict") == "PASS")
    demo_final_ok = (demo_final_j.get("final_rc") == 1 and demo_final_j.get("final_status") == "FAIL")
    matcher_ok = (matcher_j.get("all_pass") is True)
    e2b_ok = (e2b_summary.get("overall_verdict") == "PASS")
    plan_probe_line = [l for l in plan_log.splitlines() if "Probe:" in l]
    f9_ok = len(plan_probe_line) > 0

    g5_status = "PASS" if (
        fguards_ok and
        touch_unread_ok and
        demo_final_ok and
        matcher_ok and
        e2b_ok and
        f9_ok
    ) else "FAIL"
    g_results["G5"] = {
        "status": g5_status,
        "name": "F-guards and audit items",
        "cites": [
            "evidence/fguards/fguards.jsonl",
            "evidence/fguards/touch_unread.json",
            "evidence/fguards/demo_final_required.json",
            "evidence/fguards/demo_misclassified.json",
            "evidence/fguards/matcher_attacks.json",
            "e2/f3-run2/f3_run2_summary.json",
            "evidence/plan/plan.log"
        ],
        "recomputed_numbers": {
            "fguards_rows": len(fguards_rows),
            "fguards_all_passed": fguards_ok,
            "touch_unread_verdict": touch_unread_j.get("verdict"),
            "demo_final_rc": demo_final_j.get("final_rc"),
            "matcher_all_pass": matcher_j.get("all_pass"),
            "e2b_status": e2b_summary.get("overall_verdict"),
            "plan_probe_line": plan_probe_line[0] if plan_probe_line else None
        }
    }

    # ----------------------------------------------------
    # G6: E-probes & Matrix
    # ----------------------------------------------------
    matrix_rows = []
    with open(os.path.join(RV3, "evidence", "matrix", "matrix_results.jsonl")) as f:
        for l in f:
            if l.strip():
                matrix_rows.append(json.loads(l))
    
    with open(os.path.join(RV3, "evidence", "matrix", "file-required-values", "results.json")) as f:
        req_val_j = json.load(f)

    e3_accounting = []
    with open(os.path.join(RV3, "e3", "accounting.jsonl")) as f:
        for l in f:
            if l.strip():
                e3_accounting.append(json.loads(l))
    e3_map = {r["id"]: r for r in e3_accounting}

    g09_12_killed = all(e3_map.get(m, {}).get("status") == "KILLED" for m in ["g09", "g10", "g11", "g12"])

    matrix_ok = (len(matrix_rows) == 70 and all(r.get("verdict") == "PASS" for r in matrix_rows))
    req_val_ok = (len(req_val_j) == 17 and all(r.get("pass") is True for r in req_val_j))

    g6_status = "PASS" if (matrix_ok and req_val_ok and g09_12_killed) else "FAIL"
    g_results["G6"] = {
        "status": g6_status,
        "name": "matrix 70 and file required values 17",
        "cites": [
            "evidence/matrix/matrix_results.jsonl",
            "evidence/matrix/file-required-values/results.json",
            "e3/accounting.jsonl"
        ],
        "recomputed_numbers": {
            "matrix_rows_count": len(matrix_rows),
            "matrix_all_pass": matrix_ok,
            "required_values_count": len(req_val_j),
            "required_values_all_pass": req_val_ok,
            "g09_g12_killed": g09_12_killed
        }
    }

    # ----------------------------------------------------
    # G7: mutants (42 KILLED + m20 MASKED)
    # ----------------------------------------------------
    with open(os.path.join(RV3, "e2", "m20-isolation", "m20_isolation_summary.json")) as f:
        m20_iso_summary = json.load(f)
    with open(os.path.join(RV3, "x1", "anchors.json")) as f:
        x1_anchors = json.load(f)
    with open(os.path.join(RV3, "x1", "summary.json")) as f:
        x1_summary = json.load(f)

    status_counts = {}
    for r in e3_accounting:
        st = r.get("status")
        status_counts[st] = status_counts.get(st, 0) + 1
    killed_count = status_counts.get("KILLED", 0)
    masked_count = status_counts.get("MASKED", 0)
    total_mutants = len(e3_accounting)

    e3_ok = (killed_count == 42 and masked_count == 1 and total_mutants == 43 and e3_map.get("m20", {}).get("status") == "MASKED")
    m20_iso_ok = (m20_iso_summary.get("overall_verdict") == "PASS")
    x1_ok = (x1_summary.get("status") == "PASS" and len(x1_anchors) == 43 and all(a["counts"]["in_h_prime"] == 1 for a in x1_anchors))

    g7_status = "PASS" if (e3_ok and m20_iso_ok and x1_ok) else "FAIL"
    g_results["G7"] = {
        "status": g7_status,
        "name": "all 43 mutants (42 KILLED + m20 MASKED)",
        "cites": [
            "e3/accounting.jsonl",
            "e3/mutants_accounting.json",
            "e2/m20-isolation/m20_isolation_summary.json",
            "x1/anchors.json",
            "x1/summary.json"
        ],
        "recomputed_numbers": {
            "total_mutants": total_mutants,
            "killed_count": killed_count,
            "masked_count": masked_count,
            "m20_status": e3_map.get("m20", {}).get("status"),
            "m20_isolation_status": m20_iso_summary.get("overall_verdict"),
            "x1_anchors_count": len(x1_anchors),
            "x1_all_anchors_unique_in_h_prime": all(a["counts"]["in_h_prime"] == 1 for a in x1_anchors)
        }
    }

    # ----------------------------------------------------
    # G8: registration and fence review
    # ----------------------------------------------------
    with open(os.path.join(RV3, "evidence", "registration", "run", "fixed-observation.json")) as f:
        reg_fixed = json.load(f)
    with open(os.path.join(RV3, "evidence", "registration", "run", "mutant-observation.json")) as f:
        reg_mutant = json.load(f)
    with open(os.path.join(RV3, "evidence", "registration", "run", "mutation.json")) as f:
        reg_mutation = json.load(f)
    with open(os.path.join(RV3, "cit", "summary.json")) as f:
        cit_summary = json.load(f)
    with open(os.path.join(RV3, "s4", "report.json")) as f:
        s4_report = json.load(f)

    reg_ok = (
        reg_fixed.get("escaped") is None and
        len(reg_fixed.get("result", {}).get("survivors", [])) == 0 and
        reg_mutant.get("escaped") is not None and
        reg_mutation.get("anchor_matches") == 1 and
        reg_fixed.get("source_sha256") == "25aac5d00de62b49aad7e351cc3a10f491e8a882d40be986d0ba76a3d722d9c3" and
        reg_mutant.get("source_sha256") == "c7ad3de09751ffece5808a6dedb1af0103bfbaa4fa127d4fbc2985e99c168a5b"
    )
    cit_ok = (
        cit_summary.get("status") == "PASS" and
        cit_summary.get("acceptance", {}).get("differing_regions_count") == 0 and
        cit_summary.get("acceptance", {}).get("total_citations") == 155 and
        cit_summary.get("acceptance", {}).get("every_region_byte_identical_between_H_and_H_prime") is True
    )
    s4_ok = (
        s4_report.get("meta", {}).get("status") == "PASS" and
        s4_report.get("meta", {}).get("weakening_findings_count") == 0 and
        s4_report.get("meta", {}).get("verifications", {}).get("negative_invariants") == "PASS"
    )

    g8_status = "PASS" if (reg_ok and cit_ok and s4_ok) else "FAIL"
    g_results["G8"] = {
        "status": g8_status,
        "name": "registration interval proof and readiness fence",
        "cites": [
            "evidence/registration/run/fixed-observation.json",
            "evidence/registration/run/mutant-observation.json",
            "evidence/registration/run/mutation.json",
            "cit/summary.json",
            "cit/regions.json",
            "s4/report.json"
        ],
        "recomputed_numbers": {
            "registration_fixed_escaped": reg_fixed.get("escaped"),
            "registration_fixed_survivors": len(reg_fixed.get("result", {}).get("survivors", [])),
            "registration_mutant_escaped": reg_mutant.get("escaped"),
            "registration_anchor_matches": reg_mutation.get("anchor_matches"),
            "citations_total": cit_summary.get("acceptance", {}).get("total_citations"),
            "citations_differing_regions": cit_summary.get("acceptance", {}).get("differing_regions_count"),
            "citations_quotes_found": cit_summary.get("acceptance", {}).get("real_string_quotes_extracted"),
            "s4_weakening_findings": s4_report.get("meta", {}).get("weakening_findings_count"),
            "s4_negative_invariants": s4_report.get("meta", {}).get("verifications", {}).get("negative_invariants")
        }
    }

    # ----------------------------------------------------
    # G9: mapping
    # ----------------------------------------------------
    with open(os.path.join(RV3, "r1", "summary.json")) as f:
        r1_summary = json.load(f)
    with open(os.path.join(RV3, "r1", "translation_proof.json")) as f:
        r1_trans_proof = json.load(f)

    r1_ok = (
        r1_summary.get("proven_mapping_rows") == 80 and
        r1_summary.get("unmapped_rows") == 0 and
        r1_summary.get("review_keys_proven") == 33 and
        r1_trans_proof.get("status") == "PASS" and
        r1_trans_proof.get("all_citations_span_text_equal") is True
    )
    g9_status = "PASS" if r1_ok else "FAIL"
    g_results["G9"] = {
        "status": g9_status,
        "name": "R1 semantic mapping and translation proof",
        "cites": [
            "r1/summary.json",
            "r1/translation_proof.json",
            "r1/semantic_mapping.json",
            "r1/review_keys_accounting.json"
        ],
        "recomputed_numbers": {
            "mapping_rows_proven": r1_summary.get("proven_mapping_rows"),
            "mapping_rows_unmapped": r1_summary.get("unmapped_rows"),
            "review_keys_total": r1_summary.get("review_keys_total"),
            "review_keys_proven": r1_summary.get("review_keys_proven"),
            "translation_proof_span_text_equal": r1_trans_proof.get("all_citations_span_text_equal")
        }
    }

    # ----------------------------------------------------
    # G10: static checks & process hygiene
    # ----------------------------------------------------
    with open(os.path.join(RV3, "r2", "summary.json")) as f:
        r2_summary = json.load(f)
    with open(os.path.join(RV3, "r2", "residue_grep.json")) as f:
        r2_grep = json.load(f)
    with open(os.path.join(RV3, "e4", "receipts_audit.json")) as f:
        receipts_audit = json.load(f)

    r2_ok = (
        r2_summary.get("overall_status") == "PASS" and
        r2_summary.get("leaf_accounting", {}).get("unaccounted") == 0 and
        r2_grep.get("build_census", {}).get("rc") == 1 and
        r2_grep.get("helper_exec", {}).get("rc") == 1
    )
    receipts_ok = (
        receipts_audit.get("error_count") == 0 and
        receipts_audit.get("total_jobs") >= 106
    )
    leases_ok = ident_after_j["postflight"]["leases"]["all_alive"] is True

    g10_status = "PASS" if (r2_ok and receipts_ok and leases_ok and s4_ok) else "FAIL"
    g_results["G10"] = {
        "status": g10_status,
        "name": "static checks and process hygiene",
        "cites": [
            "r2/summary.json",
            "r2/compare.json",
            "r2/residue_grep.json",
            "e4/receipts_audit.json",
            "e4/identity-after.json",
            "s4/report.json"
        ],
        "recomputed_numbers": {
            "r2_overall_status": r2_summary.get("overall_status"),
            "r2_total_leaves": r2_summary.get("leaf_accounting", {}).get("total_leaves"),
            "r2_unaccounted_leaves": r2_summary.get("leaf_accounting", {}).get("unaccounted"),
            "r2_leaf_breakdown": r2_summary.get("leaf_accounting", {}).get("counts"),
            "r2_build_census_hits": r2_grep.get("build_census", {}).get("hits_count"),
            "r2_helper_exec_hits": r2_grep.get("helper_exec", {}).get("hits_count"),
            "receipts_total_jobs": receipts_audit.get("total_jobs"),
            "receipts_errors": receipts_audit.get("error_count"),
            "leases_all_alive": leases_ok
        }
    }

    out_file = os.path.join(RV3, "e4", "g_table.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(g_results, f, indent=2)

    print(f"Saved G1-G10 table to {out_file}")
    for gid in ["G1a", "G1b", "G1c", "G1d", "G2", "G3", "G4", "G5", "G6", "G7", "G8", "G9", "G10"]:
        print(f"  {gid} ({g_results[gid]['name']}): {g_results[gid]['status']}")

if __name__ == "__main__":
    main()
