#!/usr/bin/env python3
import os
import sys
import json
import re

RV3 = "/private/tmp/iyi-proof-complete-813c8074a"
W3 = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
W2 = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030"
H = "6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd"
H_PRIME = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"

def analyze_diff(rel_path, content):
    hunks = []
    current_hunk = None
    
    for line in content.splitlines():
        if line.startswith("@@"):
            if current_hunk:
                hunks.append(current_hunk)
            current_hunk = {"header": line, "dels": [], "adds": []}
        elif current_hunk is not None:
            if line.startswith("-") and not line.startswith("---"):
                current_hunk["dels"].append(line[1:])
            elif line.startswith("+") and not line.startswith("+++"):
                current_hunk["adds"].append(line[1:])
    if current_hunk:
        hunks.append(current_hunk)

    return hunks

def main():
    diffs_path = os.path.join(RV3, "e4", "diffs_audit.json")
    with open(diffs_path, "r", encoding="utf-8") as f:
        diffs = json.load(f)

    report = {}
    for rel_path, data in sorted(diffs.items()):
        content = data["content"]
        hunks = analyze_diff(rel_path, content)
        report[rel_path] = {
            "hunk_count": len(hunks),
            "hunks": hunks
        }

    out_file = os.path.join(RV3, "e4", "diffs_detailed.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(f"Detailed diffs written to {out_file}")

if __name__ == "__main__":
    main()
