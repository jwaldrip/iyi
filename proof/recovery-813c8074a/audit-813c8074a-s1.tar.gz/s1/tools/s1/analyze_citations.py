import json
import re

with open("/private/tmp/iyi-proof-complete-813c8074a/tools/s1/generate_final_r1_artifacts.py.orig") as f:
    content = f.read()

matches = re.findall(r"smoke_test\.py:(\d+)-(\d+)", content)
print("Count of smoke_test.py:a-b matches in generate_final_r1_artifacts.py.orig:", len(matches))

all_smoke = re.findall(r"smoke_test\.py:[^\s\"\'\),]+", content)
print("Count of all smoke_test.py mentions:", len(all_smoke))
non_ab = [c for c in all_smoke if not re.match(r"smoke_test\.py:\d+-\d+$", c)]
print("Non a-b mentions:", non_ab)

# Check write_summary_and_report.py.orig
with open("/private/tmp/iyi-proof-complete-813c8074a/tools/s1/write_summary_and_report.py.orig") as f:
    ws_content = f.read()

ws_matches = re.findall(r"smoke_test\.py:(\d+)-(\d+)", ws_content)
print("Count of smoke_test.py:a-b matches in write_summary_and_report.py.orig:", len(ws_matches))
print("Matches in write_summary_and_report.py.orig:", ws_matches)
