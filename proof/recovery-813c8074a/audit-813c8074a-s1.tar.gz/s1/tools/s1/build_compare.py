#!/usr/bin/env python3
import json
import re

RV_SMOKE_LOG = "/private/tmp/iyi-proof-complete-813c8074a/r1/inputs/rv_smoke.log"
EV_SMOKE_LOG = "/private/tmp/iyi-proof-complete-813c8074a/r1/inputs/ev_smoke.log"
RV_O3_LOG = "/private/tmp/iyi-proof-complete-813c8074a/r1/inputs/rv_o3.log"
EV_O3_LOG = "/private/tmp/iyi-proof-complete-813c8074a/r1/inputs/ev_o3.log"

def parse_log(path):
    seeds = {}
    controls = {}
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line_str = line.strip()
            if line_str.startswith("SEED "):
                m = re.match(r"^SEED\s+(\S+)\s+expect=(.*?)\s+got=(.*?)\s+applied=(.*)$", line_str)
                if m:
                    fix_id, exp_s, got_s, app_s = m.groups()
                    seeds[fix_id] = {
                        "line": line_no,
                        "expect": exp_s,
                        "got": got_s,
                        "applied": app_s,
                    }
            elif line_str.startswith("CONTROL "):
                parts = line_str.split()
                if len(parts) >= 3:
                    controls[parts[1]] = {
                        "line": line_no,
                        "status": parts[2],
                    }
    return seeds, controls

rv_smoke_seeds, rv_smoke_controls = parse_log(RV_SMOKE_LOG)
ev_smoke_seeds, ev_smoke_controls = parse_log(EV_SMOKE_LOG)

rv_o3_seeds, rv_o3_controls = parse_log(RV_O3_LOG)
ev_o3_seeds, ev_o3_controls = parse_log(EV_O3_LOG)

SCRATCH_RE = re.compile(r"/(?:private/tmp|var/folders/\S+?)/(?:iyi-\S+?|not-iyp-\S+?|iyp-\S+?)(?=[/\"\s'\],])")

def normalize_scratch(text):
    return SCRATCH_RE.sub("<SCRATCH>", text)

def compare_suite(name, rv_s, rv_c, ev_s, ev_c):
    rv_s_keys = set(rv_s.keys())
    ev_s_keys = set(ev_s.keys())
    rv_c_keys = set(rv_c.keys())
    ev_c_keys = set(ev_c.keys())

    expect_diffs_raw = {}
    got_diffs_raw = {}
    expect_diffs_semantic = {}
    got_diffs_semantic = {}
    applied_diffs_raw = {}
    per_seed = {}

    for sid in sorted(rv_s_keys & ev_s_keys):
        rv_item = rv_s[sid]
        ev_item = ev_s[sid]

        # Raw check
        exp_match_raw = (rv_item["expect"] == ev_item["expect"])
        got_match_raw = (rv_item["got"] == ev_item["got"])
        applied_match_raw = (rv_item["applied"] == ev_item["applied"])

        # Semantic check (normalizing scratch paths)
        exp_norm_rv = normalize_scratch(rv_item["expect"])
        exp_norm_ev = normalize_scratch(ev_item["expect"])
        exp_match_semantic = (exp_norm_rv == exp_norm_ev)

        got_norm_rv = normalize_scratch(rv_item["got"])
        got_norm_ev = normalize_scratch(ev_item["got"])
        got_match_semantic = (got_norm_rv == got_norm_ev)

        # Internal consistency: does RV expect == RV got?
        rv_internal_match = (rv_item["expect"] == rv_item["got"])
        ev_internal_match = (ev_item["expect"] == ev_item["got"])

        if not exp_match_raw:
            expect_diffs_raw[sid] = {"rv": rv_item["expect"], "ev": ev_item["expect"]}
        if not got_match_raw:
            got_diffs_raw[sid] = {"rv": rv_item["got"], "ev": ev_item["got"]}
        if not exp_match_semantic:
            expect_diffs_semantic[sid] = {"rv": rv_item["expect"], "ev": ev_item["expect"]}
        if not got_match_semantic:
            got_diffs_semantic[sid] = {"rv": rv_item["got"], "ev": ev_item["got"]}
        if not applied_match_raw:
            applied_diffs_raw[sid] = {"rv": rv_item["applied"], "ev": ev_item["applied"]}

        per_seed[sid] = {
            "rv_line": rv_item["line"],
            "ev_line": ev_item["line"],
            "rv_expect_equals_got": rv_internal_match,
            "ev_expect_equals_got": ev_internal_match,
            "expect_match_raw": exp_match_raw,
            "got_match_raw": got_match_raw,
            "semantic_match": exp_match_semantic and got_match_semantic,
            "rv_expect": rv_item["expect"],
            "ev_expect": ev_item["expect"],
            "rv_got": rv_item["got"],
            "ev_got": ev_item["got"],
            "scratch_path_variant": not (exp_match_raw and got_match_raw) and (exp_match_semantic and got_match_semantic),
        }

    control_diffs = {}
    per_control = {}
    for cid in sorted(rv_c_keys & ev_c_keys):
        rv_status = rv_c[cid]["status"]
        ev_status = ev_c[cid]["status"]
        match = (rv_status == ev_status)
        if not match:
            control_diffs[cid] = {"rv": rv_status, "ev": ev_status}
        per_control[cid] = {
            "rv_line": rv_c[cid]["line"],
            "ev_line": ev_c[cid]["line"],
            "rv_status": rv_status,
            "ev_status": ev_status,
            "status_match": match,
        }

    return {
        "suite": name,
        "seed_counts": {"rv": len(rv_s_keys), "ev": len(ev_s_keys)},
        "control_counts": {"rv": len(rv_c_keys), "ev": len(ev_c_keys)},
        "seed_sets_equal": (rv_s_keys == ev_s_keys),
        "control_sets_equal": (rv_c_keys == ev_c_keys),
        "seeds_missing_in_rv": sorted(list(ev_s_keys - rv_s_keys)),
        "seeds_missing_in_ev": sorted(list(rv_s_keys - ev_s_keys)),
        "controls_missing_in_rv": sorted(list(ev_c_keys - rv_c_keys)),
        "controls_missing_in_ev": sorted(list(rv_c_keys - ev_c_keys)),
        "raw_expect_differences_count": len(expect_diffs_raw),
        "raw_expect_differences": expect_diffs_raw,
        "raw_got_differences_count": len(got_diffs_raw),
        "raw_got_differences": got_diffs_raw,
        "semantic_expect_differences_count": len(expect_diffs_semantic),
        "semantic_expect_differences": expect_diffs_semantic,
        "semantic_got_differences_count": len(got_diffs_semantic),
        "semantic_got_differences": got_diffs_semantic,
        "scratch_path_variant_seeds_count": sum(1 for v in per_seed.values() if v.get("scratch_path_variant")),
        "applied_differences_count": len(applied_diffs_raw),
        "applied_differences_note": "Differences in applied strings arise from unique temporary run paths (e.g. /tmp/iyi-o2-pin-*) across distinct executions.",
        "control_differences_count": len(control_diffs),
        "control_differences": control_diffs,
        "per_seed_comparison": per_seed,
        "per_control_comparison": per_control,
    }

smoke_comp = compare_suite("smoke", rv_smoke_seeds, rv_smoke_controls, ev_smoke_seeds, ev_smoke_controls)
o3_comp = compare_suite("o3", rv_o3_seeds, rv_o3_controls, ev_o3_seeds, ev_o3_controls)

output_data = {
    "summary": {
        "smoke": {
            "seeds_equal": smoke_comp["seed_sets_equal"],
            "controls_equal": smoke_comp["control_sets_equal"],
            "seed_count": smoke_comp["seed_counts"]["rv"],
            "control_count": smoke_comp["control_counts"]["rv"],
            "raw_expect_diffs": smoke_comp["raw_expect_differences_count"],
            "raw_got_diffs": smoke_comp["raw_got_differences_count"],
            "semantic_expect_diffs": smoke_comp["semantic_expect_differences_count"],
            "semantic_got_diffs": smoke_comp["semantic_got_differences_count"],
            "scratch_path_variants": smoke_comp["scratch_path_variant_seeds_count"],
            "control_diffs": smoke_comp["control_differences_count"],
        },
        "o3": {
            "seeds_equal": o3_comp["seed_sets_equal"],
            "controls_equal": o3_comp["control_sets_equal"],
            "seed_count": o3_comp["seed_counts"]["rv"],
            "control_count": o3_comp["control_counts"]["rv"],
            "raw_expect_diffs": o3_comp["raw_expect_differences_count"],
            "raw_got_diffs": o3_comp["raw_got_differences_count"],
            "semantic_expect_diffs": o3_comp["semantic_expect_differences_count"],
            "semantic_got_diffs": o3_comp["semantic_got_differences_count"],
            "scratch_path_variants": o3_comp["scratch_path_variant_seeds_count"],
            "control_diffs": o3_comp["control_differences_count"],
        }
    },
    "smoke": smoke_comp,
    "o3": o3_comp,
}

COMPARE_JSON_PATH = "/private/tmp/iyi-proof-complete-813c8074a/r1/compare.json"
with open(COMPARE_JSON_PATH, "w", encoding="utf-8") as f:
    json.dump(output_data, f, indent=2)

print(f"Comparison complete. Written to {COMPARE_JSON_PATH}")
print(f"Smoke semantic diffs: expect={smoke_comp['semantic_expect_differences_count']}, got={smoke_comp['semantic_got_differences_count']}")
print(f"O3 semantic diffs: expect={o3_comp['semantic_expect_differences_count']}, got={o3_comp['semantic_got_differences_count']}")
