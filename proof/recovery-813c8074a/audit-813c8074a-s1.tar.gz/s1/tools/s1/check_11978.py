import json

with open("/private/tmp/iyi-proof-complete-813c8074a/line-map.json") as f:
    lm = json.load(f)

st_map = lm["smoke_test"]["mapping"]

print("11978 in map:", st_map.get("11978"))
print("11979 in map:", st_map.get("11979"))
