import re

with open("/private/tmp/iyi-proof-complete-813c8074a/tools/s1/generate_final_r1_artifacts.py.orig") as f:
    lines = f.readlines()

citations = []
for i, line in enumerate(lines, 1):
    m = re.findall(r'"(smoke_test\.py:[^"]+)"', line)
    for c in m:
        citations.append((i, c))

print(f"Total citations found: {len(citations)}")
ab_citations = [c for c in citations if re.match(r'^smoke_test\.py:\d+-\d+$', c[1])]
non_ab_citations = [c for c in citations if not re.match(r'^smoke_test\.py:\d+-\d+$', c[1])]

print(f"a-b citations: {len(ab_citations)}")
print(f"non a-b citations: {len(non_ab_citations)}")
for line_no, c in non_ab_citations:
    print(f"  Line {line_no}: {c}")
