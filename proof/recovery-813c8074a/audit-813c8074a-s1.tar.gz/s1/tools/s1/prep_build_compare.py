import os
import subprocess

tools_dir = "/private/tmp/iyi-proof-complete-813c8074a/tools/s1"
orig_path = os.path.join(tools_dir, "build_compare.py.orig")
new_path = os.path.join(tools_dir, "build_compare.py")
diff_path = os.path.join(tools_dir, "build_compare.py.diff")

with open(orig_path, "r", encoding="utf-8") as f:
    content = f.read()

# Apply L1
content_new = content.replace("/private/tmp/iyi-proof-complete-6bbe1bf2e", "/private/tmp/iyi-proof-complete-813c8074a")

with open(new_path, "w", encoding="utf-8") as f:
    f.write(content_new)

# Save diff -u
diff_cmd = ["diff", "-u", "build_compare.py.orig", "build_compare.py"]
proc = subprocess.run(diff_cmd, cwd=tools_dir, capture_output=True, text=True)
with open(diff_path, "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print(f"build_compare.py written ({len(content_new)} bytes). Diff:")
print(proc.stdout)
