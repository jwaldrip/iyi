import json
import os
import re
import subprocess

tools_dir = "/private/tmp/iyi-proof-complete-813c8074a/tools/s1"
orig_path = os.path.join(tools_dir, "generate_final_r1_artifacts.py.orig")
new_path = os.path.join(tools_dir, "generate_final_r1_artifacts.py")
diff_path = os.path.join(tools_dir, "generate_final_r1_artifacts.py.diff")

with open(orig_path, "r", encoding="utf-8") as f:
    content = f.read()

# Load line map
with open("/private/tmp/iyi-proof-complete-813c8074a/line-map.json") as f:
    lm = json.load(f)
mapping = lm["smoke_test"]["mapping"]

# 1. Apply L1 to path literals
content = content.replace("/private/tmp/iyi-proof-complete-6bbe1bf2e", "/private/tmp/iyi-proof-complete-813c8074a")

# 2. Redirect SMOKE_TEST_PATH
# In E30: SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"
# Redirect to clone: "/private/tmp/iyi-proof-complete-813c8074a/c/s1/proof/smoke_test.py"
content = content.replace(
    'SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"',
    'SMOKE_TEST_PATH = "/private/tmp/iyi-proof-complete-813c8074a/c/s1/proof/smoke_test.py"'
)

# 3. Translate the 158 smoke_test.py:a-b citations
# We will do regex substitution for "smoke_test.py:a-b"
translated_count = 0
translation_records = []

def replace_citation(match):
    global translated_count
    a = match.group(1)
    b = match.group(2)
    a_hp = mapping.get(a)
    b_hp = mapping.get(b)
    assert a_hp is not None and b_hp is not None, f"Unmapped: {a}-{b}"
    translated_count += 1
    translation_records.append({
        "h_cite": f"smoke_test.py:{a}-{b}",
        "hp_cite": f"smoke_test.py:{a_hp}-{b_hp}",
        "a_h": int(a),
        "b_h": int(b),
        "a_hp": int(a_hp),
        "b_hp": int(b_hp)
    })
    return f"smoke_test.py:{a_hp}-{b_hp}"

content = re.sub(r"smoke_test\.py:(\d+)-(\d+)", replace_citation, content)

print(f"Total citations translated in generate_final_r1_artifacts.py: {translated_count}")
assert translated_count == 158, f"Expected 158, got {translated_count}"

with open(new_path, "w", encoding="utf-8") as f:
    f.write(content)

# Generate diff
proc = subprocess.run(["diff", "-u", "generate_final_r1_artifacts.py.orig", "generate_final_r1_artifacts.py"], cwd=tools_dir, capture_output=True, text=True)
with open(diff_path, "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print(f"generate_final_r1_artifacts.py written ({len(content)} bytes). Diff lines: {len(proc.stdout.splitlines())}")
