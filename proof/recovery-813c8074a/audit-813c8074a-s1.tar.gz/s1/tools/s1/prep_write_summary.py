import os
import subprocess

tools_dir = "/private/tmp/iyi-proof-complete-813c8074a/tools/s1"
orig_path = os.path.join(tools_dir, "write_summary_and_report.py.orig")
new_path = os.path.join(tools_dir, "write_summary_and_report.py")
diff_path = os.path.join(tools_dir, "write_summary_and_report.py.diff")

with open(orig_path, "r", encoding="utf-8") as f:
    content = f.read()

# 1. Apply L1
content = content.replace("/private/tmp/iyi-proof-complete-6bbe1bf2e", "/private/tmp/iyi-proof-complete-813c8074a")
content = content.replace("RV2/r1", "RV3/r1")

# 2. Apply L6 (commit sha)
content = content.replace("6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd", "813c8074acb2eed99ffeef78ea49e8c7832e4c01")

# 3. Apply L10 (line 97 span 17438-17610 -> 17647-17819)
content = content.replace("smoke_test.py:17438-17610", "smoke_test.py:17647-17819")

with open(new_path, "w", encoding="utf-8") as f:
    f.write(content)

# Generate diff
proc = subprocess.run(["diff", "-u", "write_summary_and_report.py.orig", "write_summary_and_report.py"], cwd=tools_dir, capture_output=True, text=True)
with open(diff_path, "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print(f"write_summary_and_report.py written ({len(content)} bytes). Diff:")
print(proc.stdout)
