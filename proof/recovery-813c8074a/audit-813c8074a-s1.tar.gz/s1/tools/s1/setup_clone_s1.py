import subprocess
import os

W3 = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
HP = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
clone_dir = "/private/tmp/iyi-proof-complete-813c8074a/c/s1"
pyc_dir = "/private/tmp/iyi-proof-complete-813c8074a/pyc/s1"

os.makedirs(pyc_dir, exist_ok=True)

if os.path.exists(clone_dir):
    print(f"Clone dir {clone_dir} already exists.")
else:
    print(f"Cloning W3 to {clone_dir}...")
    subprocess.run(["git", "clone", "--no-hardlinks", "--quiet", W3, clone_dir], check=True)
    subprocess.run(["git", "-C", clone_dir, "checkout", "--quiet", "--detach", HP], check=True)

# 1. Assert HEAD == HP
head_sha = subprocess.check_output(["git", "-C", clone_dir, "rev-parse", "HEAD"]).decode("utf-8").strip()
assert head_sha == HP, f"HEAD mismatch: {head_sha} != {HP}"
print(f"HEAD verified: {head_sha}")

# 2. Assert porcelain is empty
porcelain = subprocess.check_output(["git", "-C", clone_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).decode("utf-8")
assert porcelain == "", f"Porcelain not empty: {porcelain}"
print("Porcelain clean (including untracked and ignored).")

# 3. Assert ls-files -s blob ids equal ls-tree -r H'
ls_files_out = subprocess.check_output(["git", "-C", clone_dir, "ls-files", "-s"]).decode("utf-8").strip().split("\n")
ls_files_map = {}
for line in ls_files_out:
    parts = line.split()
    mode, blob_id, stage, path = parts[0], parts[1], parts[2], parts[3]
    ls_files_map[path] = blob_id

ls_tree_out = subprocess.check_output(["git", "-C", clone_dir, "ls-tree", "-r", HP]).decode("utf-8").strip().split("\n")
ls_tree_map = {}
for line in ls_tree_out:
    parts = line.split()
    mode, kind, blob_id, path = parts[0], parts[1], parts[2], parts[3]
    ls_tree_map[path] = blob_id

assert set(ls_files_map.keys()) == set(ls_tree_map.keys()), "Paths mismatch between ls-files and ls-tree"
for path, blob_id in ls_files_map.items():
    assert blob_id == ls_tree_map[path], f"Blob mismatch for {path}: {blob_id} != {ls_tree_map[path]}"
print(f"All {len(ls_files_map)} tracked blobs in clone match git ls-tree -r H'.")

smoke_blob = ls_files_map["proof/smoke_test.py"]
assert smoke_blob == "64064290c895a97754f1aa9ca2d6c85b89dfa437", f"smoke_test blob mismatch: {smoke_blob}"
print(f"Verified clone smoke_test.py blob: {smoke_blob}")
