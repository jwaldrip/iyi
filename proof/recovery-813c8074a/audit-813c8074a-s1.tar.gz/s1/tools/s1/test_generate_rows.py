import json
import re
import ast

# 1. Read H' smoke_test.py
SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031/proof/smoke_test.py"
with open(SMOKE_TEST_PATH, "r", encoding="utf-8") as f:
    source_lines = f.readlines()
tree = ast.parse("".join(source_lines), filename=SMOKE_TEST_PATH)

review_items = {}
for node in tree.body:
    if isinstance(node, ast.AnnAssign):
        if isinstance(node.target, ast.Name) and node.target.id == "REVIEW_ITEMS":
            if isinstance(node.value, ast.Dict):
                review_items = ast.literal_eval(node.value)
                break
review_keys = {k: v for k, v in review_items.items() if k.startswith("review.")}

# 2. Read H' RV smoke log
RV_SMOKE_LOG = "/private/tmp/iyi-proof-complete-813c8074a/evidence/smoke/smoke.log"
seeds = {}
controls = {}
with open(RV_SMOKE_LOG, "r", encoding="utf-8") as f:
    for line_no, line in enumerate(f, 1):
        line_str = line.strip()
        if line_str.startswith("SEED "):
            m = re.match(r"^SEED\s+(\S+)\s+expect=(.*?)\s+got=(.*?)\s+applied=(.*)$", line_str)
            if m:
                fix_id, exp_s, got_s, app_s = m.groups()
                seeds[fix_id] = {
                    "line": line_no,
                    "expect": exp_s,
                    "got": got_s,
                    "applied": app_s,
                }
        elif line_str.startswith("CONTROL "):
            parts = line_str.split()
            if len(parts) >= 3:
                controls[parts[1]] = {
                    "line": line_no,
                    "status": parts[2],
                }

print(f"H' seeds in RV smoke: {len(seeds)}")
print(f"H' controls in RV smoke: {len(controls)}")

# Load line map
with open("/private/tmp/iyi-proof-complete-813c8074a/line-map.json") as f:
    lm = json.load(f)
mapping = lm["smoke_test"]["mapping"]

def trans_cite(cite):
    if not cite:
        return cite
    m = re.match(r"^smoke_test\.py:(\d+)-(\d+)$", cite)
    if m:
        a, b = m.groups()
        return f"smoke_test.py:{mapping[a]}-{mapping[b]}"
    return cite

# Load H semantic mapping from E30
import tarfile
tar_path = "/Users/jwaldrip/dev/worktrees/iyi-stale-recovery-evidence-20261030/proof/recovery-20261030/audit-completion-6bbe-r1.tar.gz"
with tarfile.open(tar_path, "r:gz") as tar:
    h_rows = json.load(tar.extractfile("r1/semantic_mapping.json"))

print(f"Total H rows: {len(h_rows)}")

# Simulate generating H' rows from H rows with translation + H' smoke log
hp_rows = []
for r in h_rows:
    r_new = dict(r)
    r_new["expected_literal_citation"] = trans_cite(r["expected_literal_citation"])
    r_new["applied_change_citation"] = trans_cite(r["applied_change_citation"])
    
    # Read from H' log
    fid = r["fixture_id"]
    cid = r["control_id"]
    
    s_info = seeds.get(fid)
    c_info = controls.get(cid) if cid else None
    
    if not s_info and fid in controls:
        c_as_s = controls[fid]
        r_new["smoke_line"] = c_as_s["line"]
        r_new["expected"] = "PASS"
        r_new["observed"] = c_as_s["status"]
        r_new["applied_evidence"] = "control execution as detector"
    elif s_info:
        r_new["smoke_line"] = s_info["line"]
        r_new["expected"] = s_info["expect"]
        r_new["observed"] = s_info["got"]
        r_new["applied_evidence"] = s_info["applied"]
    else:
        print(f"MISSING fixture {fid} in H' smoke log!")
        
    if c_info:
        r_new["control_smoke_line"] = c_info["line"]
        r_new["control_status"] = c_info["status"]
    elif cid:
        print(f"MISSING control {cid} in H' smoke log!")
        
    hp_rows.append(r_new)

print(f"Total H' rows generated: {len(hp_rows)}")
proven_count = sum(1 for r in hp_rows if r["status"] == "PROVEN")
unmapped_count = sum(1 for r in hp_rows if r["status"] == "UNMAPPED")
print(f"Proven: {proven_count}, Unmapped: {unmapped_count}")

# Check seed and control PASS
for r in hp_rows:
    assert r["status"] == "PROVEN"
    assert r["control_status"] == "PASS", f"Control {r['control_id']} did not pass: {r['control_status']}"
    assert r["expected"] == r["observed"], f"Seed {r['fixture_id']} expect != observed: {r['expected']} != {r['observed']}"
print("All 102 rows PROVEN with matching expected==observed and control_status==PASS!")
