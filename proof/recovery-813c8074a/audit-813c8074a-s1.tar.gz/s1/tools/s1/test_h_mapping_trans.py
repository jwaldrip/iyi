import json
import tarfile
import re

# Load H semantic mapping from E30
tar_path = "/Users/jwaldrip/dev/worktrees/iyi-stale-recovery-evidence-20261030/proof/recovery-20261030/audit-completion-6bbe-r1.tar.gz"
with tarfile.open(tar_path, "r:gz") as tar:
    h_mapping = json.load(tar.extractfile("r1/semantic_mapping.json"))

# Load line map
with open("/private/tmp/iyi-proof-complete-813c8074a/line-map.json") as f:
    lm = json.load(f)
mapping = lm["smoke_test"]["mapping"]

# Build translation table for all 158 a-b citations
trans_table = {}
with open("/private/tmp/iyi-proof-complete-813c8074a/tools/s1/generate_final_r1_artifacts.py.orig") as f:
    content = f.read()

ab_matches = re.findall(r"smoke_test\.py:(\d+)-(\d+)", content)
for a_str, b_str in ab_matches:
    c_h = f"smoke_test.py:{a_str}-{b_str}"
    a_hp = mapping[a_str]
    b_hp = mapping[b_str]
    c_hp = f"smoke_test.py:{a_hp}-{b_hp}"
    trans_table[c_h] = c_hp

print(f"Translation table entries: {len(trans_table)}")

# Check H mapping rows
for i, r in enumerate(h_mapping):
    exp_c = r.get("expected_literal_citation")
    app_c = r.get("applied_change_citation")
    if exp_c and exp_c in trans_table:
        pass
    if app_c and app_c in trans_table:
        pass

print("Checked H mapping rows against translation table.")
