import json
import re

with open("/private/tmp/iyi-proof-complete-813c8074a/line-map.json") as f:
    lm = json.load(f)

mapping = lm["smoke_test"]["mapping"]

with open("/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py") as f:
    h_lines = f.readlines()

with open("/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031/proof/smoke_test.py") as f:
    hp_lines = f.readlines()

with open("/private/tmp/iyi-proof-complete-813c8074a/tools/s1/generate_final_r1_artifacts.py.orig") as f:
    content = f.read()

ab_matches = re.findall(r"smoke_test\.py:(\d+)-(\d+)", content)
print(f"Total a-b matches found: {len(ab_matches)}")

translation_table = {}
mismatches = []
unmapped = []

for a_str, b_str in ab_matches:
    cite_h = f"smoke_test.py:{a_str}-{b_str}"
    if cite_h in translation_table:
        continue
    
    a_hp = mapping.get(a_str)
    b_hp = mapping.get(b_str)
    if a_hp is None or b_hp is None:
        unmapped.append((cite_h, a_hp, b_hp))
        continue
    
    cite_hp = f"smoke_test.py:{a_hp}-{b_hp}"
    
    # Check span text equality
    a_int, b_int = int(a_str), int(b_str)
    ahp_int, bhp_int = int(a_hp), int(b_hp)
    
    h_span = "".join(h_lines[a_int-1:b_int])
    hp_span = "".join(hp_lines[ahp_int-1:bhp_int])
    
    if h_span != hp_span:
        mismatches.append((cite_h, cite_hp, h_span, hp_span))
    else:
        translation_table[cite_h] = cite_hp

print(f"Unique citations translated: {len(translation_table)}")
print(f"Total occurrences translated: {sum(content.count(k) for k in translation_table)}")
print(f"Unmapped: {len(unmapped)}")
print(f"Mismatches: {len(mismatches)}")

if mismatches:
    for c_h, c_hp, hs, hps in mismatches[:3]:
        print(f"Mismatch: {c_h} -> {c_hp}")
        print("H:", repr(hs[:50]))
        print("H':", repr(hps[:50]))
