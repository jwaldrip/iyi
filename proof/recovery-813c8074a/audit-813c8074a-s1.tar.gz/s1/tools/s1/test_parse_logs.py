import json
import re

RV_SMOKE_LOG = "/private/tmp/iyi-proof-complete-813c8074a/evidence/smoke/smoke.log"
EV_SMOKE_LOG = "/private/tmp/iyi-proof-complete-813c8074a/ev/smoke/smoke.log"
RV_O3_LOG = "/private/tmp/iyi-proof-complete-813c8074a/evidence/o3/o3.log"
EV_O3_LOG = "/private/tmp/iyi-proof-complete-813c8074a/ev/o3/o3.log"

def parse_log(path):
    seeds = {}
    controls = {}
    with open(path, "r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            line_str = line.strip()
            if line_str.startswith("SEED "):
                m = re.match(r"^SEED\s+(\S+)\s+expect=(.*?)\s+got=(.*?)\s+applied=(.*)$", line_str)
                if m:
                    fix_id, exp_s, got_s, app_s = m.groups()
                    seeds[fix_id] = {
                        "line": line_no,
                        "expect": exp_s,
                        "got": got_s,
                        "applied": app_s,
                    }
            elif line_str.startswith("CONTROL "):
                parts = line_str.split()
                if len(parts) >= 3:
                    controls[parts[1]] = {
                        "line": line_no,
                        "status": parts[2],
                    }
    return seeds, controls

rv_s, rv_c = parse_log(RV_SMOKE_LOG)
ev_s, ev_c = parse_log(EV_SMOKE_LOG)
rv_o3_s, rv_o3_c = parse_log(RV_O3_LOG)
ev_o3_s, ev_o3_c = parse_log(EV_O3_LOG)

print(f"Smoke seeds: rv={len(rv_s)}, ev={len(ev_s)}, equal_sets={set(rv_s.keys()) == set(ev_s.keys())}")
print(f"Smoke controls: rv={len(rv_c)}, ev={len(ev_c)}, equal_sets={set(rv_c.keys()) == set(ev_c.keys())}")
print(f"O3 seeds: rv={len(rv_o3_s)}, ev={len(ev_o3_s)}, equal_sets={set(rv_o3_s.keys()) == set(ev_o3_s.keys())}")
print(f"O3 controls: rv={len(rv_o3_c)}, ev={len(ev_o3_c)}, equal_sets={set(rv_o3_c.keys()) == set(ev_o3_c.keys())}")
