import json
import re

with open("/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031/proof/smoke_test.py") as f:
    hp_lines = f.readlines()

with open("/private/tmp/iyi-proof-complete-813c8074a/line-map.json") as f:
    lm = json.load(f)
mapping = lm["smoke_test"]["mapping"]

def trans_cite(cite):
    if not cite:
        return cite
    m = re.match(r"^smoke_test\.py:(\d+)-(\d+)$", cite)
    if m:
        a, b = m.groups()
        return f"smoke_test.py:{mapping[a]}-{mapping[b]}"
    m2 = re.match(r"^smoke_test\.py:(\d+)$", cite)
    if m2:
        s = m2.group(1)
        return f"smoke_test.py:{mapping[s]}"
    return cite

import tarfile
tar_path = "/Users/jwaldrip/dev/worktrees/iyi-stale-recovery-evidence-20261030/proof/recovery-20261030/audit-completion-6bbe-r1.tar.gz"
with tarfile.open(tar_path, "r:gz") as tar:
    h_rows = json.load(tar.extractfile("r1/semantic_mapping.json"))

row_details = []

for i, r in enumerate(h_rows, 1):
    fid = r["fixture_id"]
    exp_c_hp = trans_cite(r["expected_literal_citation"])
    app_c_hp = trans_cite(r["applied_change_citation"])
    
    m_exp = re.match(r"^smoke_test\.py:(\d+)(?:-(\d+))?$", exp_c_hp)
    exp_start = int(m_exp.group(1))
    exp_end = int(m_exp.group(2)) if m_exp.group(2) else exp_start
    exp_text = "".join(hp_lines[exp_start-1:exp_end])
    
    m_app = re.match(r"^smoke_test\.py:(\d+)(?:-(\d+))?$", app_c_hp)
    app_start = int(m_app.group(1))
    app_end = int(m_app.group(2)) if m_app.group(2) else app_start
    app_text = "".join(hp_lines[app_start-1:app_end])
    
    row_details.append({
        "row": i,
        "fixture_id": fid,
        "exp_cite": exp_c_hp,
        "exp_snippet": exp_text.strip().replace("\n", " ")[:60],
        "app_cite": app_c_hp,
        "app_snippet": app_text.strip().replace("\n", " ")[:60],
    })

print(f"Verified {len(row_details)} rows.")
for rd in row_details[:10]:
    print(f"Row {rd['row']:2d} ({rd['fixture_id']}): exp=[{rd['exp_cite']}] {rd['exp_snippet']} | app=[{rd['app_cite']}] {rd['app_snippet']}")
print("...")
for rd in row_details[24:28]:
    print(f"Row {rd['row']:2d} ({rd['fixture_id']}): exp=[{rd['exp_cite']}] {rd['exp_snippet']} | app=[{rd['app_cite']}] {rd['app_snippet']}")
