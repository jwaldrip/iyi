import subprocess
import json
import re

W3 = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
H = "6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd"
HP = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"

# Get hunks from git diff
cmd = ["git", "-C", W3, "diff", "-U0", H, HP, "--", "proof/smoke_test.py"]
diff_out = subprocess.check_output(cmd, text=True)

hunks = []
# Parse @@ -a,b +c,d @@
for line in diff_out.splitlines():
    if line.startswith("@@"):
        m = re.match(r"^@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@", line)
        if m:
            h_start = int(m.group(1))
            h_len = int(m.group(2)) if m.group(2) is not None else 1
            hp_start = int(m.group(3))
            hp_len = int(m.group(4)) if m.group(4) is not None else 1
            hunks.append({
                "header": line,
                "h_range": (h_start, h_start + h_len - 1) if h_len > 0 else (h_start, h_start),
                "hp_range": (hp_start, hp_start + hp_len - 1) if hp_len > 0 else (hp_start, hp_start),
                "h_len": h_len,
                "hp_len": hp_len
            })

print(f"Total hunks: {len(hunks)}")
for i, hnk in enumerate(hunks, 1):
    print(f"Hunk {i:2d}: H {hnk['h_range']}, H' {hnk['hp_range']} | {hnk['header']}")

# Load all citations from generate_final_r1_artifacts.py.orig
with open("/private/tmp/iyi-proof-complete-813c8074a/tools/s1v2/generate_final_r1_artifacts.py.orig") as f:
    gen_text = f.read()

cites_ab = re.findall(r"smoke_test\.py:(\d+)-(\d+)", gen_text)
single_cites = re.findall(r"smoke_test\.py:(\d+)(?![\d\-])", gen_text)

print(f"\nTotal range cites: {len(cites_ab)}")
print(f"Total single cites: {len(single_cites)}")

# Check overlap of any citation with hunks
overlapping_cites = []

for a_str, b_str in cites_ab:
    a, b = int(a_str), int(b_str)
    for hnk in hunks:
        h_s, h_e = hnk["h_range"]
        # Overlap test: max(a, h_s) <= min(b, h_e)
        if hnk["h_len"] > 0 and max(a, h_s) <= min(b, h_e):
            overlapping_cites.append((f"smoke_test.py:{a}-{b}", hnk))

for s_str in single_cites:
    s = int(s_str)
    for hnk in hunks:
        h_s, h_e = hnk["h_range"]
        if hnk["h_len"] > 0 and h_s <= s <= h_e:
            overlapping_cites.append((f"smoke_test.py:{s}", hnk))

print(f"\nOverlapping citations with changed hunks: {len(overlapping_cites)}")
if overlapping_cites:
    for c, hnk in overlapping_cites:
        print(f"  {c} overlaps {hnk['header']}")
else:
    print("  ZERO citations overlap any changed hunk!")
