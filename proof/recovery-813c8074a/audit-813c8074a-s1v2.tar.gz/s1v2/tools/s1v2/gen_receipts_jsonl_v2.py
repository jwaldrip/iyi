import os
import json

jobs_dir = "/private/tmp/iyi-proof-complete-813c8074a/r1v2/jobs"
job_subdirs = ["01_build_compare", "02_generate_final_r1_artifacts", "03_write_summary_and_report"]

receipts = []
for sub in job_subdirs:
    p = os.path.join(jobs_dir, sub)
    with open(os.path.join(p, "command.json")) as f:
        cmd = json.load(f)
    with open(os.path.join(p, "start.json")) as f:
        st = json.load(f)
    with open(os.path.join(p, "end.json")) as f:
        ed = json.load(f)
    
    rec = {
        "argv": cmd["argv"],
        "cwd": cmd["cwd"],
        "elapsed_sec": ed["elapsed_sec"],
        "end_utc": ed["utc"],
        "job_dir": p,
        "rc": ed["rc"],
        "start_utc": st["utc"],
        "stderr_bytes": ed["stderr_bytes"],
        "stderr_sha256": ed["stderr_sha256"],
        "stdout_bytes": ed["stdout_bytes"],
        "stdout_sha256": ed["stdout_sha256"]
    }
    receipts.append(rec)

receipts_jsonl_path = os.path.join(jobs_dir, "receipts.jsonl")
with open(receipts_jsonl_path, "w", encoding="utf-8") as f:
    for r in receipts:
        f.write(json.dumps(r) + "\n")

print(f"receipts.jsonl written with {len(receipts)} receipts.")
