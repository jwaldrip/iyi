import os
import re
import subprocess
import json

tools_dir = "/private/tmp/iyi-proof-complete-813c8074a/tools/s1v2"

# Load line map
with open("/private/tmp/iyi-proof-complete-813c8074a/line-map.json") as f:
    lm = json.load(f)
mapping = lm["smoke_test"]["mapping"]

# ==========================================
# 1. generate_final_r1_artifacts.py
# ==========================================
gen_orig_path = os.path.join(tools_dir, "generate_final_r1_artifacts.py.orig")
with open(gen_orig_path, "r", encoding="utf-8") as f:
    gen_orig = f.read()

# Step A: Only redirects (L1 and SMOKE_TEST_PATH redirect to clone)
gen_redir = gen_orig
gen_redir = gen_redir.replace("/private/tmp/iyi-proof-complete-6bbe1bf2e/r1", "/private/tmp/iyi-proof-complete-813c8074a/r1v2")
gen_redir = gen_redir.replace(
    'SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"',
    'SMOKE_TEST_PATH = "/private/tmp/iyi-proof-complete-813c8074a/c/s1v2/proof/smoke_test.py"'
)

gen_redir_path = os.path.join(tools_dir, "generate_final_r1_artifacts.py.redirects.py")
with open(gen_redir_path, "w", encoding="utf-8") as f:
    f.write(gen_redir)

# Redirect diff
proc = subprocess.run(["diff", "-u", "generate_final_r1_artifacts.py.orig", "generate_final_r1_artifacts.py.redirects.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "generate_final_r1_artifacts.py.redirects.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

# Step B: Translations
gen_final = gen_redir

# Translate 158 range citations
trans_range_count = 0
def repl_range(m):
    global trans_range_count
    a, b = m.group(1), m.group(2)
    a_hp = mapping[a]
    b_hp = mapping[b]
    trans_range_count += 1
    return f"smoke_test.py:{a_hp}-{b_hp}"

gen_final = re.sub(r"smoke_test\.py:(\d+)-(\d+)", repl_range, gen_final)
assert trans_range_count == 158, f"Expected 158, got {trans_range_count}"

# Translate 2 single-line citations (lines 387 and 397)
assert "smoke_test.py:11978" in gen_final
assert "smoke_test.py:11979" in gen_final
gen_final = gen_final.replace("smoke_test.py:11978", f"smoke_test.py:{mapping['11978']}")
gen_final = gen_final.replace("smoke_test.py:11979", f"smoke_test.py:{mapping['11979']}")
assert "smoke_test.py:12017" in gen_final
assert "smoke_test.py:12018" in gen_final

gen_final_path = os.path.join(tools_dir, "generate_final_r1_artifacts.py")
with open(gen_final_path, "w", encoding="utf-8") as f:
    f.write(gen_final)

# Translations diff
proc = subprocess.run(["diff", "-u", "generate_final_r1_artifacts.py.redirects.py", "generate_final_r1_artifacts.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "generate_final_r1_artifacts.py.translations.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

# Full diff against orig
proc = subprocess.run(["diff", "-u", "generate_final_r1_artifacts.py.orig", "generate_final_r1_artifacts.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "generate_final_r1_artifacts.py.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print("generate_final_r1_artifacts.py files and diffs created successfully.")

# ==========================================
# 2. write_summary_and_report.py
# ==========================================
ws_orig_path = os.path.join(tools_dir, "write_summary_and_report.py.orig")
with open(ws_orig_path, "r", encoding="utf-8") as f:
    ws_orig = f.read()

# Step A: Only redirects (L1 and L6)
ws_redir = ws_orig
ws_redir = ws_redir.replace("/private/tmp/iyi-proof-complete-6bbe1bf2e/r1", "/private/tmp/iyi-proof-complete-813c8074a/r1v2")
ws_redir = ws_redir.replace("6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd", "813c8074acb2eed99ffeef78ea49e8c7832e4c01")

ws_redir_path = os.path.join(tools_dir, "write_summary_and_report.py.redirects.py")
with open(ws_redir_path, "w", encoding="utf-8") as f:
    f.write(ws_redir)

proc = subprocess.run(["diff", "-u", "write_summary_and_report.py.orig", "write_summary_and_report.py.redirects.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "write_summary_and_report.py.redirects.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

# Step B: Translations and documented prose edits
ws_final = ws_redir
# Line 97 translation:
ws_final = ws_final.replace("smoke_test.py:17438-17610", "smoke_test.py:17647-17819")
# Documented prose line edits (RV2/r1 -> RV3/r1v2 in markdown report):
ws_final = ws_final.replace("RV2/r1/inputs/", "RV3/r1v2/inputs/")
ws_final = ws_final.replace("RV2/r1/", "RV3/r1v2/")

ws_final_path = os.path.join(tools_dir, "write_summary_and_report.py")
with open(ws_final_path, "w", encoding="utf-8") as f:
    f.write(ws_final)

proc = subprocess.run(["diff", "-u", "write_summary_and_report.py.redirects.py", "write_summary_and_report.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "write_summary_and_report.py.translations.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

proc = subprocess.run(["diff", "-u", "write_summary_and_report.py.orig", "write_summary_and_report.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "write_summary_and_report.py.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print("write_summary_and_report.py files and diffs created successfully.")
