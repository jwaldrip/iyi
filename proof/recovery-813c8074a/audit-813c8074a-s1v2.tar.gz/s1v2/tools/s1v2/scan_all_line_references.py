import re
import json

files = {
    "generate": "/private/tmp/iyi-proof-complete-813c8074a/tools/s1v2/generate_final_r1_artifacts.py.orig",
    "write_summary": "/private/tmp/iyi-proof-complete-813c8074a/tools/s1v2/write_summary_and_report.py.orig",
    "build_compare": "/private/tmp/iyi-proof-complete-813c8074a/tools/s1v2/build_compare.py.orig",
}

for name, path in files.items():
    print(f"================ Scanning {name} ({path}) ================")
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    
    # 1. Any mention of smoke_test
    for i, line in enumerate(lines, 1):
        if "smoke_test" in line:
            print(f"Line {i:4d}: {line.strip()}")
            
    # 2. Any pattern like smoke_test.py:something
    full_text = "".join(lines)
    cites = re.findall(r"smoke_test\.py:[^\s\"\'\),]+", full_text)
    print(f"\nAll smoke_test.py citations in {name}: {len(cites)}")
    for c in sorted(set(cites)):
        count = cites.count(c)
        print(f"  {c} (x{count})")
        
    # 3. Any pattern mentioning line numbers or smoke numbers
    smoke_num_patterns = re.findall(r"(?:smoke|line)\s*[:#]?\s*(\d+)", full_text, re.IGNORECASE)
    print(f"\nPotential line/smoke numbers in {name}: {len(smoke_num_patterns)}")
    for m in sorted(set(smoke_num_patterns)):
        print(f"  number: {m}")
