import re

with open("/private/tmp/iyi-proof-complete-813c8074a/tools/s1v2/generate_final_r1_artifacts.py.orig") as f:
    gen_lines = f.readlines()

print("=== Scanning generate_final_r1_artifacts.py.orig for ANY line number or cite ===")
for i, l in enumerate(gen_lines, 1):
    # Check for smoke_test or smoke or line
    if re.search(r"smoke_test\.py", l):
        print(f"Line {i:4d}: {l.strip()}")
    elif re.search(r"(?:smoke|line)\s*[:#]\s*\d+", l, re.IGNORECASE):
        print(f"Line {i:4d} (smoke/line ref): {l.strip()}")

with open("/private/tmp/iyi-proof-complete-813c8074a/tools/s1v2/write_summary_and_report.py.orig") as f:
    ws_lines = f.readlines()

print("\n=== Scanning write_summary_and_report.py.orig for ANY line number or cite ===")
for i, l in enumerate(ws_lines, 1):
    if re.search(r"smoke_test\.py", l):
        print(f"Line {i:4d}: {l.strip()}")
    elif re.search(r"(?:smoke|line)\s*[:#]?\s*\d+", l, re.IGNORECASE):
        print(f"Line {i:4d} (smoke/line ref): {l.strip()}")
