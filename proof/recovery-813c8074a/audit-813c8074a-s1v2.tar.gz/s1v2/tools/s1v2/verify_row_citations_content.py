import json
import re

with open("/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031/proof/smoke_test.py") as f:
    hp_lines = f.readlines()

with open("/private/tmp/iyi-proof-complete-813c8074a/tools/s1v2/generate_final_r1_artifacts.py.orig") as f:
    gen_text = f.read()

# Load line map
with open("/private/tmp/iyi-proof-complete-813c8074a/line-map.json") as f:
    lm = json.load(f)
mapping = lm["smoke_test"]["mapping"]

def trans_cite(cite):
    if not cite:
        return cite
    m = re.match(r"^smoke_test\.py:(\d+)-(\d+)$", cite)
    if m:
        a, b = m.groups()
        return f"smoke_test.py:{mapping[a]}-{mapping[b]}"
    m2 = re.match(r"^smoke_test\.py:(\d+)$", cite)
    if m2:
        s = m2.group(1)
        return f"smoke_test.py:{mapping[s]}"
    return cite

# Load rows from H semantic_mapping
import tarfile
tar_path = "/Users/jwaldrip/dev/worktrees/iyi-stale-recovery-evidence-20261030/proof/recovery-20261030/audit-completion-6bbe-r1.tar.gz"
with tarfile.open(tar_path, "r:gz") as tar:
    h_rows = json.load(tar.extractfile("r1/semantic_mapping.json"))

print(f"Checking {len(h_rows)} rows for citation content in H'...")

findings_verified = []

for i, r in enumerate(h_rows, 1):
    fid = r["fixture_id"]
    exp_c_h = r["expected_literal_citation"]
    app_c_h = r["applied_change_citation"]
    
    exp_c_hp = trans_cite(exp_c_h)
    app_c_hp = trans_cite(app_c_h)
    
    # Extract H' text for expected citation
    m_exp = re.match(r"^smoke_test\.py:(\d+)(?:-(\d+))?$", exp_c_hp)
    exp_start = int(m_exp.group(1))
    exp_end = int(m_exp.group(2)) if m_exp.group(2) else exp_start
    exp_text = "".join(hp_lines[exp_start-1:exp_end])
    
    # Extract H' text for applied citation
    m_app = re.match(r"^smoke_test\.py:(\d+)(?:-(\d+))?$", app_c_hp)
    app_start = int(m_app.group(1))
    app_end = int(m_app.group(2)) if m_app.group(2) else app_start
    app_text = "".join(hp_lines[app_start-1:app_end])
    
    # For rows 485/504 (s5.seed.skip-env-blocked and s5.seed.skip-partial):
    if fid in ("s5.seed.skip-env-blocked", "s5.seed.skip-partial"):
        print(f"Row {i} ({fid}):")
        print(f"  exp: {exp_c_h} -> {exp_c_hp} | snippet: {exp_text.strip()[:60]}")
        print(f"  app: {app_c_h} -> {app_c_hp} | snippet: {app_text.strip()[:60]}")
        
    findings_verified.append({
        "row_index": i,
        "fixture_id": fid,
        "exp_cite_hp": exp_c_hp,
        "exp_lines": (exp_start, exp_end),
        "exp_text_len": len(exp_text),
        "app_cite_hp": app_c_hp,
        "app_lines": (app_start, app_end),
        "app_text_len": len(app_text)
    })

print(f"All {len(findings_verified)} rows extracted cleanly from H' smoke_test.py.")
