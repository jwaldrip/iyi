import ast
import json
import re

smoke_path = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031/proof/smoke_test.py"
with open(smoke_path, "r", encoding="utf-8") as f:
    source = f.read()
    smoke_lines = source.splitlines(keepends=True)
tree = ast.parse(source, filename=smoke_path)

func_defs = {node.name: node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}

call_graph = {name: set() for name in func_defs}
for name, fnode in func_defs.items():
    for sub in ast.walk(fnode):
        if isinstance(sub, ast.Call):
            if isinstance(sub.func, ast.Name) and sub.func.id in func_defs:
                call_graph[name].add(sub.func.id)
            elif isinstance(sub.func, ast.Attribute) and sub.func.attr in func_defs:
                call_graph[name].add(sub.func.attr)
        elif isinstance(sub, ast.Name):
            if sub.id in func_defs and sub.id != name:
                call_graph[name].add(sub.id)

# StageFixture connection
for fnode in func_defs.values():
    if "StageFixture" in ast.dump(fnode):
        if "_stage_stub_payloads" in func_defs:
            call_graph[fnode.name].add("_stage_stub_payloads")

registered_fixtures = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Call):
        func_name = None
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr
        if func_name == "Fixture":
            if len(node.args) >= 3:
                fid = node.args[0].value if isinstance(node.args[0], ast.Constant) else None
                kind = node.args[1].value if isinstance(node.args[1], ast.Constant) else None
                callable_node = node.args[2]
                entry_funcs = set()
                for sub in ast.walk(callable_node):
                    if isinstance(sub, ast.Name) and sub.id in func_defs:
                        entry_funcs.add(sub.id)
                registered_fixtures[fid] = {
                    "kind": kind,
                    "entry_funcs": entry_funcs,
                    "ast_node": callable_node
                }

def compute_closure(initial_funcs):
    visited = set(initial_funcs)
    queue = list(initial_funcs)
    while queue:
        curr = queue.pop(0)
        for neighbor in call_graph.get(curr, ()):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return visited

fixture_closures = {fid: compute_closure(meta["entry_funcs"]) for fid, meta in registered_fixtures.items()}

with open("/private/tmp/iyi-proof-complete-813c8074a/r1v2/semantic_mapping.json") as f:
    rows = json.load(f)

def parse_span(cite):
    m = re.match(r"^smoke_test\.py:(\d+)(?:-(\d+))?$", cite)
    if not m:
        return None, None
    s = int(m.group(1))
    e = int(m.group(2)) if m.group(2) else s
    return s, e

def span_in_closure(start, end, closure):
    for fname in closure:
        fnode = func_defs.get(fname)
        if fnode and fnode.lineno <= start and end <= fnode.end_lineno:
            return True, fname
    return False, None

failing_rows = []
for idx, r in enumerate(rows, 1):
    fid = r["fixture_id"]
    closure = fixture_closures.get(fid, set())
    exp_s, exp_e = parse_span(r["expected_literal_citation"])
    app_s, app_e = parse_span(r["applied_change_citation"])
    exp_ok, exp_fn = span_in_closure(exp_s, exp_e, closure)
    app_ok, app_fn = span_in_closure(app_s, app_e, closure)
    if not exp_ok or not app_ok:
        failing_rows.append((idx, r, exp_ok, exp_fn, app_ok, app_fn))

print(f"Total failing rows: {len(failing_rows)}")
for idx, r, exp_ok, exp_fn, app_ok, app_fn in failing_rows:
    fid = r["fixture_id"]
    print(f"Row {idx:2d} ({fid:35s}, rng={r['review_range']:7s}): exp_ok={str(exp_ok):5s} ({str(exp_fn):20s}), app_ok={str(app_ok):5s} ({str(app_fn):20s})")
