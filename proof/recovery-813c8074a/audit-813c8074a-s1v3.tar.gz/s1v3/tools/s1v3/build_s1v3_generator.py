import ast
import os
import re
import subprocess
import json
import sys

tools_dir = "/private/tmp/iyi-proof-complete-813c8074a/tools/s1v3"
sys.path.insert(0, tools_dir)

# Load line map
with open("/private/tmp/iyi-proof-complete-813c8074a/line-map.json") as f:
    lm = json.load(f)
mapping = lm["smoke_test"]["mapping"]

# 1. build_compare.py
orig_bc = os.path.join(tools_dir, "build_compare.py.orig")
with open(orig_bc, "r", encoding="utf-8") as f:
    bc_text = f.read()

bc_new = bc_text.replace("/private/tmp/iyi-proof-complete-6bbe1bf2e/r1", "/private/tmp/iyi-proof-complete-813c8074a/r1v3")
with open(os.path.join(tools_dir, "build_compare.py"), "w", encoding="utf-8") as f:
    f.write(bc_new)

proc = subprocess.run(["diff", "-u", "build_compare.py.orig", "build_compare.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "build_compare.py.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print("build_compare.py and diff written.")

# 2. write_summary_and_report.py
orig_ws = os.path.join(tools_dir, "write_summary_and_report.py.orig")
with open(orig_ws, "r", encoding="utf-8") as f:
    ws_text = f.read()

ws_new = ws_text.replace("/private/tmp/iyi-proof-complete-6bbe1bf2e/r1", "/private/tmp/iyi-proof-complete-813c8074a/r1v3")
ws_new = ws_new.replace("6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd", "813c8074acb2eed99ffeef78ea49e8c7832e4c01")
ws_new = ws_new.replace("smoke_test.py:17438-17610", "smoke_test.py:17647-17819")
ws_new = ws_new.replace("RV2/r1/inputs/", "RV3/r1v3/inputs/")
ws_new = ws_new.replace("RV2/r1/", "RV3/r1v3/")

with open(os.path.join(tools_dir, "write_summary_and_report.py"), "w", encoding="utf-8") as f:
    f.write(ws_new)

proc = subprocess.run(["diff", "-u", "write_summary_and_report.py.orig", "write_summary_and_report.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "write_summary_and_report.py.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print("write_summary_and_report.py and diff written.")

# 3. generate_final_r1_artifacts.py
# First build the base (redirected + translated line-map literals)
orig_gen = os.path.join(tools_dir, "generate_final_r1_artifacts.py.orig")
with open(orig_gen, "r", encoding="utf-8") as f:
    gen_text = f.read()

gen_base = gen_text.replace("/private/tmp/iyi-proof-complete-6bbe1bf2e/r1", "/private/tmp/iyi-proof-complete-813c8074a/r1v3")
gen_base = gen_base.replace(
    'SMOKE_TEST_PATH = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030/proof/smoke_test.py"',
    'SMOKE_TEST_PATH = "/private/tmp/iyi-proof-complete-813c8074a/c/s1v3/proof/smoke_test.py"'
)

# Translate line-map literals
def repl_range(m):
    a, b = m.group(1), m.group(2)
    return f"smoke_test.py:{mapping[a]}-{mapping[b]}"

gen_base = re.sub(r"smoke_test\.py:(\d+)-(\d+)", repl_range, gen_base)
gen_base = gen_base.replace("smoke_test.py:11978", f"smoke_test.py:{mapping['11978']}")
gen_base = gen_base.replace("smoke_test.py:11979", f"smoke_test.py:{mapping['11979']}")

base_path = os.path.join(tools_dir, "generate_final_r1_artifacts.py.base.py")
with open(base_path, "w", encoding="utf-8") as f:
    f.write(gen_base)

from derive_all_row_citations import new_citations

# Read base lines
with open(base_path, "r", encoding="utf-8") as f:
    base_lines = f.readlines()

row_blocks = []
curr_row_idx = 0

tree = ast.parse("".join(base_lines))
for node in ast.walk(tree):
    if isinstance(node, ast.Call):
        func_name = getattr(node.func, "id", None)
        if func_name == "make_row":
            curr_row_idx += 1
            exp_node = node.args[5]
            app_node = node.args[6]
            row_blocks.append({
                "row_idx": curr_row_idx,
                "exp_lineno": exp_node.lineno,
                "exp_val": exp_node.value,
                "app_lineno": app_node.lineno,
                "app_val": app_node.value,
            })

print(f"Parsed {len(row_blocks)} make_row calls in generate script.")
assert len(row_blocks) == 80

final_lines = list(base_lines)
citation_changes_report = []

for rb in row_blocks:
    ridx = rb["row_idx"]
    if ridx in new_citations:
        new_exp = new_citations[ridx]["exp"]
        new_app = new_citations[ridx]["app"]
        
        old_exp_line = final_lines[rb["exp_lineno"] - 1]
        old_app_line = final_lines[rb["app_lineno"] - 1]
        
        assert rb["exp_val"] in old_exp_line, f"exp_val {rb['exp_val']} not in {old_exp_line}"
        assert rb["app_val"] in old_app_line, f"app_val {rb['app_val']} not in {old_app_line}"
        
        final_lines[rb["exp_lineno"] - 1] = old_exp_line.replace(rb["exp_val"], new_exp)
        final_lines[rb["app_lineno"] - 1] = old_app_line.replace(rb["app_val"], new_app)
        
        citation_changes_report.append({
            "row_idx": ridx,
            "old_exp": rb["exp_val"],
            "new_exp": new_exp,
            "old_app": rb["app_val"],
            "new_app": new_app,
        })

print(f"Applied citation changes to {len(citation_changes_report)} rows.")

final_gen_path = os.path.join(tools_dir, "generate_final_r1_artifacts.py")
with open(final_gen_path, "w", encoding="utf-8") as f:
    f.writelines(final_lines)

# Diff against base (shows ONLY citation changes!)
proc = subprocess.run(["diff", "-u", "generate_final_r1_artifacts.py.base.py", "generate_final_r1_artifacts.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "generate_final_r1_artifacts.py.citations.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

# Full diff against orig
proc = subprocess.run(["diff", "-u", "generate_final_r1_artifacts.py.orig", "generate_final_r1_artifacts.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "generate_final_r1_artifacts.py.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print("generate_final_r1_artifacts.py, base, citations.diff and full diff created successfully.")
