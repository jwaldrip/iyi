import ast
import json
import re

smoke_path = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031/proof/smoke_test.py"
with open(smoke_path, "r", encoding="utf-8") as f:
    source = f.read()
    smoke_lines = source.splitlines(keepends=True)
tree = ast.parse(source, filename=smoke_path)

# 1. Map all FunctionDef nodes
func_defs = {}
for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef):
        func_defs[node.name] = node

print(f"Total FunctionDefs: {len(func_defs)}")

# 2. Build direct call/ref graph between FunctionDefs
call_graph = {name: set() for name in func_defs}

for name, fnode in func_defs.items():
    for sub in ast.walk(fnode):
        # Calls
        if isinstance(sub, ast.Call):
            if isinstance(sub.func, ast.Name) and sub.func.id in func_defs:
                call_graph[name].add(sub.func.id)
            elif isinstance(sub.func, ast.Attribute) and sub.func.attr in func_defs:
                call_graph[name].add(sub.func.attr)
        # Name references (e.g. passing function as argument)
        elif isinstance(sub, ast.Name):
            if sub.id in func_defs and sub.id != name:
                call_graph[name].add(sub.id)

# 3. Map all registered fixtures: Fixture(id, kind, callable)
registered_fixtures = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Call):
        func_name = None
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr
        if func_name == "Fixture":
            if len(node.args) >= 3:
                fid = node.args[0].value if isinstance(node.args[0], ast.Constant) else None
                kind = node.args[1].value if isinstance(node.args[1], ast.Constant) else None
                callable_node = node.args[2]
                
                # Extract initial entry point functions from callable_node
                entry_funcs = set()
                for sub in ast.walk(callable_node):
                    if isinstance(sub, ast.Name) and sub.id in func_defs:
                        entry_funcs.add(sub.id)
                registered_fixtures[fid] = {
                    "kind": kind,
                    "entry_funcs": entry_funcs,
                    "ast_node": callable_node
                }

print(f"Total registered fixtures: {len(registered_fixtures)}")

# 4. Compute transitive closure for each fixture
def compute_closure(initial_funcs):
    visited = set(initial_funcs)
    queue = list(initial_funcs)
    while queue:
        curr = queue.pop(0)
        for neighbor in call_graph.get(curr, ()):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return visited

fixture_closures = {}
for fid, fmeta in registered_fixtures.items():
    closure = compute_closure(fmeta["entry_funcs"])
    fixture_closures[fid] = closure

# Check specific examples mentioned by reviewer:
# - s2.seed.validator-duplicate-site
print("\ns2.seed.validator-duplicate-site closure:")
print(fixture_closures.get("s2.seed.validator-duplicate-site"))

# - s3.seed.run-sandbox
print("\ns3.seed.run-sandbox closure:")
print(fixture_closures.get("s3.seed.run-sandbox"))
