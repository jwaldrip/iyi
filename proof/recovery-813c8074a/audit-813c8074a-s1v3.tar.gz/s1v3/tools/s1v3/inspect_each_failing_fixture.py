import ast
import json
import re

smoke_path = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031/proof/smoke_test.py"
with open(smoke_path, "r", encoding="utf-8") as f:
    source = f.read()
    smoke_lines = source.splitlines(keepends=True)
tree = ast.parse(source, filename=smoke_path)

func_defs = {node.name: node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}

# Look up registrations of specific fixtures
failing_ids = [
    "s1.seed.pin-missing-stamp",
    "s1.seed.identity-inode",
    "s1.seed.identity-binary-bytes",
    "s1.seed.plan-dirty",
    "s1.seed.plan-stale-compiler",
    "s1.seed.plan-invalid-census",
    "s1.seed.report-dir-name",
    "s3.seed.run-signal-death",
    "s3.seed.run-o-executes",
    "s5.seed.rg2r-zero",
    "s4.seed.symbol-c2",
    "amend-b.seed.not-executed",
    "amend-b.seed.copy-modified",
]

for node in ast.walk(tree):
    if isinstance(node, ast.Call):
        func_name = None
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr
        if func_name == "Fixture":
            if len(node.args) >= 3:
                fid = node.args[0].value if isinstance(node.args[0], ast.Constant) else None
                if fid in failing_ids:
                    print(f"=== {fid} ===")
                    print(ast.unparse(node))
                    print()
