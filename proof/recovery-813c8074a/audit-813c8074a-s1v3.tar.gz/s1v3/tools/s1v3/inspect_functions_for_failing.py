smoke_path = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031/proof/smoke_test.py"
with open(smoke_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

def show_fn(name, start, end):
    print(f"\n=================== {name} ({start}-{end}) ===================")
    for idx in range(start - 1, min(end, len(lines))):
        print(f"{idx+1:4d}: {lines[idx]}", end="")

import ast
tree = ast.parse("".join(lines), filename=smoke_path)
fns = {n.name: (n.lineno, n.end_lineno) for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)}

targets = [
    "_mutate_missing_stamp", "_pin_reason_seed",
    "_mutate_compiler_inode", "_identity_reason_seed",
    "_mutate_compiler_bytes",
    "_mutate_dirty_p", "_plan_reason_seed",
    "_mutate_stale_compiler",
    "_mutate_plan_census",
    "_mutate_bad_report_name",
    "_o4_own_run_verifier_seed",
    "_o4_run_fixture",
    "_fixture_rg2r_zero_seed",
    "_fixture_o6_symbol_seed",
    "_deferred_amend_b_fixture",
]

for t in targets:
    if t in fns:
        show_fn(t, fns[t][0], fns[t][1])
    else:
        print(f"NOT FOUND: {t}")
