import ast

smoke_path = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031/proof/smoke_test.py"
with open(smoke_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

def print_fn(name, start, end):
    print(f"=== {name} ({start}-{end}) ===")
    for idx in range(start - 1, min(end, len(lines))):
        print(f"{idx+1:4d}: {lines[idx]}", end="")

tree = ast.parse("".join(lines), filename=smoke_path)
for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef) and "validator" in node.name:
        print(f"{node.name}: {node.lineno}-{node.end_lineno}")

for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef) and node.name.startswith("_mutate_"):
        print(f"{node.name}: {node.lineno}-{node.end_lineno}")
