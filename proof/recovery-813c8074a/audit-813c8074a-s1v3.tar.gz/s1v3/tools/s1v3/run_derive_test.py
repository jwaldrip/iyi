import ast
import json
import re

smoke_path = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031/proof/smoke_test.py"
with open(smoke_path, "r", encoding="utf-8") as f:
    source = f.read()
    smoke_lines = source.splitlines(keepends=True)
tree = ast.parse(source, filename=smoke_path)

func_defs = {node.name: node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}

call_graph = {name: set() for name in func_defs}
for name, fnode in func_defs.items():
    for sub in ast.walk(fnode):
        if isinstance(sub, ast.Call):
            if isinstance(sub.func, ast.Name) and sub.func.id in func_defs:
                call_graph[name].add(sub.func.id)
            elif isinstance(sub.func, ast.Attribute) and sub.func.attr in func_defs:
                call_graph[name].add(sub.func.attr)
        elif isinstance(sub, ast.Name):
            if sub.id in func_defs and sub.id != name:
                call_graph[name].add(sub.id)

for fnode in func_defs.values():
    if "StageFixture" in ast.dump(fnode):
        if "_stage_stub_payloads" in func_defs:
            call_graph[fnode.name].add("_stage_stub_payloads")
        if "_stage_driver_census" in func_defs:
            call_graph[fnode.name].add("_stage_driver_census")

registered_fixtures = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Call):
        func_name = None
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr
        if func_name == "Fixture":
            if len(node.args) >= 3:
                fid = node.args[0].value if isinstance(node.args[0], ast.Constant) else None
                kind = node.args[1].value if isinstance(node.args[1], ast.Constant) else None
                callable_node = node.args[2]
                entry_funcs = set()
                for sub in ast.walk(callable_node):
                    if isinstance(sub, ast.Name) and sub.id in func_defs:
                        entry_funcs.add(sub.id)
                registered_fixtures[fid] = {
                    "kind": kind,
                    "entry_funcs": entry_funcs,
                    "ast_node": callable_node
                }

def compute_closure(initial_funcs):
    visited = set(initial_funcs)
    queue = list(initial_funcs)
    while queue:
        curr = queue.pop(0)
        for neighbor in call_graph.get(curr, ()):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return visited

fixture_closures = {fid: compute_closure(meta["entry_funcs"]) for fid, meta in registered_fixtures.items()}

# Let's verify each of the 33 failing rows and specify exact new spans
# Row mapping:
new_citations = {}

# Row 10: s3.seed.ledger-misclassified
# _o5_ledger_fixture: 7783-8199
# case == "ledger-misclassified" is lines 7844-7856
new_citations[10] = {
    "exp": "smoke_test.py:7855-7856", # expected = ("MISCLASSIFIED",)
    "app": "smoke_test.py:7845-7854", # records.append(_o5_exec_record(... mode="observed-negative" ...))
}

# Row 11: s3.seed.ledger-not-exercised
# _o5_ledger_fixture: lines 7903-7911
new_citations[11] = {
    "exp": "smoke_test.py:7910-7911", # expected = ("NOT-EXERCISED",)
    "app": "smoke_test.py:7904-7909", # _o5_add_variant(census, variant_id="demo.negative.missing", ...)
}

# Row 14: o5.seed.pair-field-drift
# _o5_ledger_fixture: lines 8160-8163
new_citations[14] = {
    "exp": "smoke_test.py:8162-8163", # expected = ("UNFAITHFUL",)
    "app": "smoke_test.py:8161-8161", # records[1]["cwd"] = os.path.join(repo, "drifted")
}

# Validator rows:
# Expected for all rule seeds: _isolated_validator_seed: 2042-2049
# expected = {"control": [], "seed": [target_rule]}
# Mutators:
# Row 16 & 63: s2.seed.validator-duplicate-site -> _mutate_duplicate_site: 2364-2371
new_citations[16] = {"exp": "smoke_test.py:2042-2049", "app": "smoke_test.py:2364-2371"}
new_citations[63] = {"exp": "smoke_test.py:2042-2049", "app": "smoke_test.py:2364-2371"}

# Row 17: s2.seed.validator-verdict -> _mutate_verdict_literal: 2386-2400
new_citations[17] = {"exp": "smoke_test.py:2042-2049", "app": "smoke_test.py:2386-2400"}

# Row 18: s2.seed.validator-var-range -> _mutate_var_range: 2403-2414
new_citations[18] = {"exp": "smoke_test.py:2042-2049", "app": "smoke_test.py:2403-2414"}

# Row 19: s2.seed.validator-skip-regex -> _mutate_skip_regex: 2429-2436
new_citations[19] = {"exp": "smoke_test.py:2042-2049", "app": "smoke_test.py:2429-2436"}

# Row 20: s2.seed.validator-kind-variants -> _mutate_kind_variants: 2474-2496
new_citations[20] = {"exp": "smoke_test.py:2042-2049", "app": "smoke_test.py:2474-2496"}

# Row 21: s2.seed.validator-e1-token -> _mutate_e1_token: 2535-2571
new_citations[21] = {"exp": "smoke_test.py:2042-2049", "app": "smoke_test.py:2535-2571"}

# Row 22: s2.seed.validator-e1-missing -> _mutate_e1_missing: 2513-2532
new_citations[22] = {"exp": "smoke_test.py:2042-2049", "app": "smoke_test.py:2513-2532"}

# Row 23: s2.seed.validator-sha -> _mutate_sha: 2343-2349
new_citations[23] = {"exp": "smoke_test.py:2042-2049", "app": "smoke_test.py:2343-2349"}

# Row 24: s2.seed.validator-contains -> _mutate_contains: 2374-2383
new_citations[24] = {"exp": "smoke_test.py:2042-2049", "app": "smoke_test.py:2374-2383"}

# Pin / Identity / Plan rows:
# Row 32: s1.seed.pin-missing-stamp
# _pin_reason_seed: 635-644, _mutate_missing_stamp: 596-603
new_citations[32] = {"exp": "smoke_test.py:643-644", "app": "smoke_test.py:596-603"}

# Row 33: s1.seed.identity-inode
# _identity_reason_seed: 814-824, _mutate_compiler_inode: 784-796
new_citations[33] = {"exp": "smoke_test.py:823-824", "app": "smoke_test.py:784-796"}

# Row 36: s1.seed.plan-dirty
# _plan_reason_seed: 875-906 (exp 896-905), _mutate_dirty_p: 540-545
new_citations[36] = {"exp": "smoke_test.py:896-905", "app": "smoke_test.py:540-545"}

# Row 37: s1.seed.plan-stale-compiler
# _plan_reason_seed: 875-906, _mutate_stale_compiler: 589-593
new_citations[37] = {"exp": "smoke_test.py:896-905", "app": "smoke_test.py:589-593"}

# Row 38: s1.seed.plan-invalid-census
# _plan_reason_seed: 875-906, _mutate_plan_census: 857-872
new_citations[38] = {"exp": "smoke_test.py:896-905", "app": "smoke_test.py:857-872"}

# Row 40: s3.seed.run-signal-death
# _o4_own_run_verifier_seed: 5093-5150
new_citations[40] = {"exp": "smoke_test.py:5136-5141", "app": "smoke_test.py:5119-5123"}

# Row 41: s3.seed.run-o-executes
# _o4_run_fixture: 4818-4923
new_citations[41] = {"exp": "smoke_test.py:4888-4894", "app": "smoke_test.py:4829-4835"}

# Row 42: s3.seed.implicit-file
# _o4_refusal_fixture: 5578-5611
new_citations[42] = {"exp": "smoke_test.py:5602-5608", "app": "smoke_test.py:5582-5583"}

# Row 43: s3.seed.run-sandbox
# _o4_refusal_fixture: 5578-5611
new_citations[43] = {"exp": "smoke_test.py:5602-5608", "app": "smoke_test.py:5584-5585"}

# Row 44: s3.seed.stdin-filename
# _o4_refusal_fixture: 5578-5611
new_citations[44] = {"exp": "smoke_test.py:5602-5608", "app": "smoke_test.py:5586-5587"}

# Row 45: s3.seed.unknown-option
# _o4_refusal_fixture: 5578-5611
new_citations[45] = {"exp": "smoke_test.py:5602-5608", "app": "smoke_test.py:5588-5589"}

# Row 46: s3.seed.cross-compile-roundtripped
# _o4_exec_plan_fixture: 5153-5268
new_citations[46] = {"exp": "smoke_test.py:5217-5225", "app": "smoke_test.py:5176-5177"}

# Row 49: s3.seed.refusal-not-recorded
# _o4_refusal_fixture: 5578-5611
new_citations[49] = {"exp": "smoke_test.py:5602-5608", "app": "smoke_test.py:5588-5589"}

# Row 54: s5.seed.rg2r-zero
# _run1_seed: 12429-12454, _stage_stub_payloads: 11874
new_citations[54] = {"exp": "smoke_test.py:12444-12448", "app": "smoke_test.py:11874-11874"}

# Row 62: s1.seed.report-dir-name
# _pin_reason_seed: 635-644, _mutate_bad_report_name: 625-632
new_citations[62] = {"exp": "smoke_test.py:643-644", "app": "smoke_test.py:625-632"}

# Row 65: s1.seed.plan-invalid-census
# _plan_reason_seed: 875-906, _mutate_plan_census: 857-872
new_citations[65] = {"exp": "smoke_test.py:896-905", "app": "smoke_test.py:857-872"}

# Row 67: s1.seed.identity-binary-bytes
# _identity_reason_seed: 814-824, _mutate_compiler_bytes: 770-781
new_citations[67] = {"exp": "smoke_test.py:823-824", "app": "smoke_test.py:770-781"}

# Row 74: s4.seed.symbol-c2
# _fixture_o6_symbol_seed: 9990-10035
new_citations[74] = {"exp": "smoke_test.py:10025-10030", "app": "smoke_test.py:9997-10008"}

# Row 77: amend-b.seed.not-executed
# _o7_amend_b_fixture: 14210-14245, _stage_driver_census: 11667-11679
new_citations[77] = {"exp": "smoke_test.py:14234-14238", "app": "smoke_test.py:11667-11679"}

# Row 79: amend-b.seed.copy-modified
# _o7_amend_b_fixture: 14210-14245, _stage_driver_census: 11680-11685
new_citations[79] = {"exp": "smoke_test.py:14234-14238", "app": "smoke_test.py:11680-11685"}

print(f"Total re-derived citations: {len(new_citations)}")
assert len(new_citations) == 33

with open("/private/tmp/iyi-proof-complete-813c8074a/r1v2/semantic_mapping.json") as f:
    rows = json.load(f)

def parse_span(cite):
    m = re.match(r"^smoke_test\.py:(\d+)(?:-(\d+))?$", cite)
    if not m:
        return None, None
    s = int(m.group(1))
    e = int(m.group(2)) if m.group(2) else s
    return s, e

def span_in_closure(start, end, closure):
    for fname in closure:
        fnode = func_defs.get(fname)
        if fnode and fnode.lineno <= start and end <= fnode.end_lineno:
            return True, fname
    return False, None

all_pass = True
updated_rows = []

for idx, r in enumerate(rows, 1):
    fid = r["fixture_id"]
    closure = fixture_closures.get(fid, set())
    
    if idx in new_citations:
        exp_cite = new_citations[idx]["exp"]
        app_cite = new_citations[idx]["app"]
    else:
        exp_cite = r["expected_literal_citation"]
        app_cite = r["applied_change_citation"]
        
    exp_s, exp_e = parse_span(exp_cite)
    app_s, app_e = parse_span(app_cite)
    
    exp_ok, exp_fn = span_in_closure(exp_s, exp_e, closure)
    app_ok, app_fn = span_in_closure(app_s, app_e, closure)
    
    if not exp_ok or not app_ok:
        print(f"FAILED Row {idx:2d} ({fid}): exp_ok={exp_ok} ({exp_fn}), app_ok={app_ok} ({app_fn})")
        all_pass = False
    else:
        # Check text snippet
        exp_text = "".join(smoke_lines[exp_s-1:exp_e]).strip().replace("\n", " ")[:50]
        app_text = "".join(smoke_lines[app_s-1:app_e]).strip().replace("\n", " ")[:50]
        updated_rows.append({
            "row": idx,
            "fid": fid,
            "exp_cite": exp_cite,
            "exp_fn": exp_fn,
            "exp_snippet": exp_text,
            "app_cite": app_cite,
            "app_fn": app_fn,
            "app_snippet": app_text,
        })

print(f"\nAll 80 rows pass closure check: {all_pass} (total passed: {len(updated_rows)}/80)")
