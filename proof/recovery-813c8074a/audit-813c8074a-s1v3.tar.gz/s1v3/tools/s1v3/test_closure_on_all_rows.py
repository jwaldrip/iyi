import ast
import json
import re

smoke_path = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031/proof/smoke_test.py"
with open(smoke_path, "r", encoding="utf-8") as f:
    source = f.read()
    smoke_lines = source.splitlines(keepends=True)
tree = ast.parse(source, filename=smoke_path)

func_defs = {}
for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef):
        func_defs[node.name] = node

call_graph = {name: set() for name in func_defs}
for name, fnode in func_defs.items():
    for sub in ast.walk(fnode):
        if isinstance(sub, ast.Call):
            if isinstance(sub.func, ast.Name) and sub.func.id in func_defs:
                call_graph[name].add(sub.func.id)
            elif isinstance(sub.func, ast.Attribute) and sub.func.attr in func_defs:
                call_graph[name].add(sub.func.attr)
        elif isinstance(sub, ast.Name):
            if sub.id in func_defs and sub.id != name:
                call_graph[name].add(sub.id)

registered_fixtures = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Call):
        func_name = None
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr
        if func_name == "Fixture":
            if len(node.args) >= 3:
                fid = node.args[0].value if isinstance(node.args[0], ast.Constant) else None
                kind = node.args[1].value if isinstance(node.args[1], ast.Constant) else None
                callable_node = node.args[2]
                entry_funcs = set()
                for sub in ast.walk(callable_node):
                    if isinstance(sub, ast.Name) and sub.id in func_defs:
                        entry_funcs.add(sub.id)
                registered_fixtures[fid] = {
                    "kind": kind,
                    "entry_funcs": entry_funcs,
                    "ast_node": callable_node
                }

def compute_closure(initial_funcs):
    visited = set(initial_funcs)
    queue = list(initial_funcs)
    while queue:
        curr = queue.pop(0)
        for neighbor in call_graph.get(curr, ()):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    return visited

# Also add legitimately indirect helpers:
# Stage fixtures: StageFixture methods and _stage_stub_payloads
# StageFixture uses _stage_stub_payloads
for fnode in func_defs.values():
    if "StageFixture" in ast.dump(fnode):
        if "_stage_stub_payloads" in func_defs:
            call_graph[fnode.name].add("_stage_stub_payloads")

fixture_closures = {}
for fid, fmeta in registered_fixtures.items():
    closure = compute_closure(fmeta["entry_funcs"])
    fixture_closures[fid] = closure

# Load the current H' semantic_mapping.json from r1v2
with open("/private/tmp/iyi-proof-complete-813c8074a/r1v2/semantic_mapping.json") as f:
    rows = json.load(f)

def parse_span(cite):
    m = re.match(r"^smoke_test\.py:(\d+)(?:-(\d+))?$", cite)
    if not m:
        return None, None
    s = int(m.group(1))
    e = int(m.group(2)) if m.group(2) else s
    return s, e

def span_in_closure(start, end, closure):
    # Check if [start, end] is contained inside any function in closure
    for fname in closure:
        fnode = func_defs.get(fname)
        if fnode and fnode.lineno <= start and end <= fnode.end_lineno:
            return True, fname
    return False, None

failing_rows = []
passing_rows = []

for idx, r in enumerate(rows, 1):
    fid = r["fixture_id"]
    exp_cite = r["expected_literal_citation"]
    app_cite = r["applied_change_citation"]
    
    closure = fixture_closures.get(fid, set())
    
    exp_s, exp_e = parse_span(exp_cite)
    app_s, app_e = parse_span(app_cite)
    
    exp_ok, exp_fn = span_in_closure(exp_s, exp_e, closure)
    app_ok, app_fn = span_in_closure(app_s, app_e, closure)
    
    if not exp_ok or not app_ok:
        failing_rows.append({
            "row": idx,
            "fixture_id": fid,
            "range": r["review_range"],
            "exp_cite": exp_cite,
            "exp_ok": exp_ok,
            "exp_fn": exp_fn,
            "app_cite": app_cite,
            "app_ok": app_ok,
            "app_fn": app_fn,
            "closure": list(closure)
        })
    else:
        passing_rows.append(idx)

print(f"Total rows: {len(rows)}")
print(f"Passing rows: {len(passing_rows)}")
print(f"Failing rows: {len(failing_rows)}")
print("\nFirst 10 failing rows:")
for fr in failing_rows[:10]:
    print(f"Row {fr['row']:2d} ({fr['fixture_id']}, range {fr['range']}): exp_ok={fr['exp_ok']} ({fr['exp_fn']}), app_ok={fr['app_ok']} ({fr['app_fn']})")
