with open("/private/tmp/iyi-proof-complete-813c8074a/r1v2/semantic_mapping.json") as f:
    rows = json.load(f)

def parse_span(cite):
    m = re.match(r"^smoke_test\.py:(\d+)(?:-(\d+))?$", cite)
    if not m:
        return None, None
    s = int(m.group(1))
    e = int(m.group(2)) if m.group(2) else s
    return s, e

def span_in_closure(start, end, closure):
    for fname in closure:
        fnode = func_defs.get(fname)
        if fnode and fnode.lineno <= start and end <= fnode.end_lineno:
            return True, fname
    return False, None

all_pass = True
updated_rows = []

for idx, r in enumerate(rows, 1):
    fid = r["fixture_id"]
    closure = fixture_closures.get(fid, set())
    
    if idx in new_citations:
        exp_cite = new_citations[idx]["exp"]
        app_cite = new_citations[idx]["app"]
    else:
        exp_cite = r["expected_literal_citation"]
        app_cite = r["applied_change_citation"]
        
    exp_s, exp_e = parse_span(exp_cite)
    app_s, app_e = parse_span(app_cite)
    
    exp_ok, exp_fn = span_in_closure(exp_s, exp_e, closure)
    app_ok, app_fn = span_in_closure(app_s, app_e, closure)
    
    if not exp_ok or not app_ok:
        print(f"FAILED Row {idx:2d} ({fid}): exp_ok={exp_ok} ({exp_fn}), app_ok={app_ok} ({app_fn})")
        all_pass = False
    else:
        # Check text snippet
        exp_text = "".join(smoke_lines[exp_s-1:exp_e]).strip().replace("\n", " ")[:50]
        app_text = "".join(smoke_lines[app_s-1:app_e]).strip().replace("\n", " ")[:50]
        updated_rows.append({
            "row": idx,
            "fid": fid,
            "exp_cite": exp_cite,
            "exp_fn": exp_fn,
            "exp_snippet": exp_text,
            "app_cite": app_cite,
            "app_fn": app_fn,
            "app_snippet": app_text,
        })

print(f"\nAll 80 rows pass closure check: {all_pass} (total passed: {len(updated_rows)}/80)")
