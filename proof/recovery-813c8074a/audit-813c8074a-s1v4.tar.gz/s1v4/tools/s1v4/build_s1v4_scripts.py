import os
import subprocess
import re
import ast

tools_dir = "/private/tmp/iyi-proof-complete-813c8074a/tools/s1v4"
v3_tools_dir = "/private/tmp/iyi-proof-complete-813c8074a/tools/s1v3"

# 1. build_compare.py
orig_bc = os.path.join(tools_dir, "build_compare.py.orig")
with open(orig_bc, "r", encoding="utf-8") as f:
    bc_text = f.read()

bc_new = bc_text.replace("/private/tmp/iyi-proof-complete-6bbe1bf2e/r1", "/private/tmp/iyi-proof-complete-813c8074a/r1v4")
with open(os.path.join(tools_dir, "build_compare.py"), "w", encoding="utf-8") as f:
    f.write(bc_new)

proc = subprocess.run(["diff", "-u", "build_compare.py.orig", "build_compare.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "build_compare.py.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print("build_compare.py written.")

# 2. write_summary_and_report.py
orig_ws = os.path.join(tools_dir, "write_summary_and_report.py.orig")
with open(orig_ws, "r", encoding="utf-8") as f:
    ws_text = f.read()

ws_new = ws_text.replace("/private/tmp/iyi-proof-complete-6bbe1bf2e/r1", "/private/tmp/iyi-proof-complete-813c8074a/r1v4")
ws_new = ws_new.replace("6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd", "813c8074acb2eed99ffeef78ea49e8c7832e4c01")
ws_new = ws_new.replace("smoke_test.py:17438-17610", "smoke_test.py:17647-17819")
ws_new = ws_new.replace("RV2/r1/inputs/", "RV3/r1v4/inputs/")
ws_new = ws_new.replace("RV2/r1/", "RV3/r1v4/")

with open(os.path.join(tools_dir, "write_summary_and_report.py"), "w", encoding="utf-8") as f:
    f.write(ws_new)

proc = subprocess.run(["diff", "-u", "write_summary_and_report.py.orig", "write_summary_and_report.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "write_summary_and_report.py.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print("write_summary_and_report.py written.")

# 3. generate_final_r1_artifacts.py
# Base is v3 generator with r1v3 -> r1v4 and c/s1v3 -> c/s1v4
v3_gen_path = os.path.join(v3_tools_dir, "generate_final_r1_artifacts.py")
with open(v3_gen_path, "r", encoding="utf-8") as f:
    v3_text = f.read()

gen_base = v3_text.replace("/private/tmp/iyi-proof-complete-813c8074a/r1v3", "/private/tmp/iyi-proof-complete-813c8074a/r1v4")
gen_base = gen_base.replace("/private/tmp/iyi-proof-complete-813c8074a/c/s1v3", "/private/tmp/iyi-proof-complete-813c8074a/c/s1v4")

base_path = os.path.join(tools_dir, "generate_final_r1_artifacts.py.base.py")
with open(base_path, "w", encoding="utf-8") as f:
    f.write(gen_base)

# Parse base lines and replace the 3 rows:
base_lines = gen_base.splitlines(keepends=True)
tree = ast.parse(gen_base)

row_calls = []
for node in ast.walk(tree):
    if isinstance(node, ast.Call) and getattr(node.func, "id", None) == "make_row":
        row_calls.append(node)

# Sort row_calls by lineno
row_calls.sort(key=lambda n: n.lineno)
assert len(row_calls) == 80

# Row 9 (index 8): s3.seed.ledger-stale-header
# Row 13 (index 12): s3.seed.ledger-divergence
# Row 78 (index 77): s3.seed.ledger-divergence
target_indices = [8, 12, 77] # 0-indexed: 9, 13, 78

replacements = {
    8: {"exp": "smoke_test.py:7842", "app": "smoke_test.py:7841"},
    12: {"exp": "smoke_test.py:7874", "app": "smoke_test.py:7862-7873"},
    77: {"exp": "smoke_test.py:7874", "app": "smoke_test.py:7862-7873"},
}

final_lines = list(base_lines)

for idx, repl in replacements.items():
    rcall = row_calls[idx]
    exp_node = rcall.args[5]
    app_node = rcall.args[6]
    
    exp_lno = exp_node.lineno - 1
    app_lno = app_node.lineno - 1
    
    old_exp_line = final_lines[exp_lno]
    old_app_line = final_lines[app_lno]
    
    assert exp_node.value in old_exp_line, f"exp_val {exp_node.value} not in {old_exp_line}"
    assert app_node.value in old_app_line, f"app_val {app_node.value} not in {old_app_line}"
    
    final_lines[exp_lno] = old_exp_line.replace(exp_node.value, repl["exp"])
    final_lines[app_lno] = old_app_line.replace(app_node.value, repl["app"])

final_path = os.path.join(tools_dir, "generate_final_r1_artifacts.py")
with open(final_path, "w", encoding="utf-8") as f:
    f.writelines(final_lines)

# Generate citations diff between base (v3 with path updates) and final (v4)
proc = subprocess.run(["diff", "-u", "generate_final_r1_artifacts.py.base.py", "generate_final_r1_artifacts.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "generate_final_r1_artifacts.py.citations.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print("generate_final_r1_artifacts.py.citations.diff written:")
print(proc.stdout)

# Generate full diff against .orig
proc = subprocess.run(["diff", "-u", "generate_final_r1_artifacts.py.orig", "generate_final_r1_artifacts.py"], cwd=tools_dir, capture_output=True, text=True)
with open(os.path.join(tools_dir, "generate_final_r1_artifacts.py.diff"), "w", encoding="utf-8") as f:
    f.write(proc.stdout)

print("generate_final_r1_artifacts.py and diffs written successfully.")
