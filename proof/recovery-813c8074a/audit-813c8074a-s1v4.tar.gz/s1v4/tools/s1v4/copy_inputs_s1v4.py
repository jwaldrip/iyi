import hashlib
import json
import os
import shutil
import subprocess

RV3 = "/private/tmp/iyi-proof-complete-813c8074a"
R1_DIR = os.path.join(RV3, "r1v4")
INPUTS_DIR = os.path.join(R1_DIR, "inputs")
os.makedirs(INPUTS_DIR, exist_ok=True)

SOURCES = {
    "corpus-proof-review-1f.txt": "/Users/jwaldrip/.omp/agent/sessions/-dev-src-github.com-jwaldrip-iyi/2026-10-23T04-40-48-554Z_01a1670f-c2aa-7496-8dff-8051951bcb5a/local/corpus-proof-review-1f.txt",
    "rv_smoke.log": os.path.join(RV3, "evidence", "smoke", "smoke.log"),
    "ev_smoke.log": os.path.join(RV3, "ev", "smoke", "smoke.log"),
    "rv_o3.log": os.path.join(RV3, "evidence", "o3", "o3.log"),
    "ev_o3.log": os.path.join(RV3, "ev", "o3", "o3.log"),
    "rv_smoke.json": os.path.join(RV3, "evidence", "smoke", "smoke.json"),
    "ev_smoke.json": os.path.join(RV3, "ev", "smoke", "smoke.json"),
    "rv_o3.json": os.path.join(RV3, "evidence", "o3", "o3.json"),
    "ev_o3.json": os.path.join(RV3, "ev", "o3", "o3.json"),
}

manifest = {}

for name, src_path in SOURCES.items():
    if not os.path.exists(src_path):
        print(f"Warning: {src_path} does not exist!")
        continue
    dest_path = os.path.join(INPUTS_DIR, name)
    shutil.copy2(src_path, dest_path)
    with open(dest_path, "rb") as f:
        data = f.read()
    sha = hashlib.sha256(data).hexdigest()
    manifest[name] = {
        "source_path": src_path,
        "copied_path": dest_path,
        "size_bytes": len(data),
        "sha256": sha,
    }
    print(f"Copied {name}: {len(data)} bytes, sha256={sha}")

# Extract H' smoke_test.py blob via git show H':proof/smoke_test.py
W3_DIR = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
HP = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
cmd = ["git", "-C", W3_DIR, "show", f"{HP}:proof/smoke_test.py"]
blob_data = subprocess.check_output(cmd)

smoke_test_dest = os.path.join(INPUTS_DIR, "smoke_test.py")
with open(smoke_test_dest, "wb") as f:
    f.write(blob_data)

smoke_test_sha = hashlib.sha256(blob_data).hexdigest()

proc = subprocess.run(["git", "hash-object", smoke_test_dest], capture_output=True, text=True, check=True)
blob_id = proc.stdout.strip()

expected_blob_id = subprocess.check_output(["git", "-C", W3_DIR, "rev-parse", f"{HP}:proof/smoke_test.py"]).decode().strip()
assert blob_id == expected_blob_id, f"Blob ID mismatch: {blob_id} != {expected_blob_id}"
print(f"Verified smoke_test.py blob id: {blob_id} == {expected_blob_id}")

manifest["smoke_test.py"] = {
    "source_blob": f"{HP}:proof/smoke_test.py",
    "copied_path": smoke_test_dest,
    "size_bytes": len(blob_data),
    "sha256": smoke_test_sha,
    "blob_id": blob_id,
}

manifest_path = os.path.join(INPUTS_DIR, "inputs_manifest.json")
with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)

print(f"Manifest written to {manifest_path}")
