import json

with open("/private/tmp/iyi-proof-complete-813c8074a/r1v3/semantic_mapping.json") as f:
    v3_rows = json.load(f)

with open("/private/tmp/iyi-proof-complete-813c8074a/r1v4/semantic_mapping.json") as f:
    v4_rows = json.load(f)

assert len(v3_rows) == len(v4_rows) == 80

diff_rows = []
for i, (r3, r4) in enumerate(zip(v3_rows, v4_rows), 1):
    diff_fields = []
    for k in r3:
        if r3[k] != r4[k]:
            diff_fields.append((k, r3[k], r4[k]))
    if diff_fields:
        diff_rows.append((i, r4["fixture_id"], diff_fields))

print(f"Total differing rows between v3 and v4: {len(diff_rows)}")
for idx, fid, dfs in diff_rows:
    print(f"\nRow {idx} ({fid}):")
    for k, v3_val, v4_val in dfs:
        print(f"  Field {k}:")
        print(f"    v3: {v3_val}")
        print(f"    v4: {v4_val}")

assert len(diff_rows) == 3, f"Expected exactly 3 differing rows, got {len(diff_rows)}"
assert set(r[0] for r in diff_rows) == {9, 13, 78}, f"Differing row indices mismatch: {[r[0] for r in diff_rows]}"
for idx, fid, dfs in diff_rows:
    fields = [d[0] for d in dfs]
    assert set(fields) == {"expected_literal_citation", "applied_change_citation"}, f"Unexpected fields changed in row {idx}: {fields}"

print("\nVERIFIED: Exactly rows 9, 13, and 78 differ from v3, and ONLY their two citation fields differ!")
