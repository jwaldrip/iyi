#!/usr/bin/env python3
import os, json, hashlib

RV3 = "/private/tmp/iyi-proof-complete-813c8074a"
H_PRIME = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
BASE = "626463375298d357ffcb3223059f4d3adce6fb10"

# Check compare.json
with open(os.path.join(RV3, "r2", "compare.json")) as f:
    cmp = json.load(f)

assert cmp["overall_status"] == "PASS"
assert cmp["total_archived_leaves_accounted"] == 864
assert cmp["unaccounted_leaves"] == 0

counts = cmp["leaf_counts_by_status"]
assert counts["COMPARED_EQUAL"] == 814
assert counts["TRANSLATED_EQUAL"] == 23
assert counts["EXPECTED_DELTA"] == 5
assert counts["EXPLICIT_EXCLUSION"] == 11
assert counts["UNPROVEN_BY_METHOD"] == 8
assert counts["DISCLOSED_OBSERVATION"] == 3

# Check all checks PASS
for ch_name, ch_data in cmp["checks"].items():
    assert ch_data["status"] == "PASS", f"Check {ch_name} failed: {ch_data}"

# Check postflight verification
with open(os.path.join(RV3, "r2", "postflight_verification.json")) as f:
    post = json.load(f)
assert post["all_files_unchanged"] is True
assert post["porcelain_clean_with_ignored"] is True
assert post["total_read_files_verified"] == 63

# Check residue_grep.json
with open(os.path.join(RV3, "r2", "residue_grep.json")) as f:
    rg = json.load(f)
assert rg["status"] == "PASS"
assert rg["build_census"]["rc"] == 1
assert rg["helper_exec"]["rc"] == 1

# Check receipts
with open(os.path.join(RV3, "r2", "jobs", "receipts.jsonl")) as f:
    receipts = [json.loads(line) for line in f]
assert len(receipts) == 11
for r in receipts:
    assert r["rc"] == 0, f"Job {r['job_dir']} failed with rc={r['rc']}"

# Build inventory of r2 files
inv = {}
for root, dirs, files in os.walk(os.path.join(RV3, "r2")):
    for fn in files:
        fp = os.path.join(root, fn)
        rel = os.path.relpath(fp, os.path.join(RV3, "r2"))
        with open(fp, "rb") as f:
            c = f.read()
        inv[rel] = {
            "size_bytes": len(c),
            "sha256": hashlib.sha256(c).hexdigest()
        }

summary = {
    "slice": "R2_prime",
    "unit": "S2",
    "head": H_PRIME,
    "base": BASE,
    "overall_status": "PASS",
    "leaf_accounting": {
        "total_leaves": 864,
        "unaccounted": 0,
        "counts": counts
    },
    "checks": {
        "preflight": "PASS",
        "census_spot_checks": "PASS",
        "dead_symbol_screen": "PASS",
        "exec_tokens_all_29": "PASS",
        "f10_labels": "PASS",
        "f11_ast_scan": "PASS",
        "production_limits": "PASS",
        "registry_holes": "PASS",
        "trace_profile_hooks": "PASS",
        "compare": "PASS",
        "postflight": "PASS",
        "residue_grep": "PASS"
    },
    "semantic_invariants": {
        "settrace_setprofile_hooks": "at lines 18694 and 18703 in _COVERAGE_BOOTSTRAP (smoke_test.py)",
        "f11_ast": "0 setattr calls; module attribute assignments only sys at 43-44; 41 os.environ mutations all in set/restore pairs",
        "dead_symbols": "['_read_pid', 'run_o3_suite'] equal to H by name",
        "registry": "520 fixtures, 174 items, 0 unmapped, 0 dangling, O3 29",
        "byte_equal_to_H": ["production_limits", "f10_labels", "exec_tokens_all_29", "census_spot_checks"]
    },
    "unproven_by_method": [
        "census_spot_checks: checks/autocert_direct/is_direct (derived from build_fn=='build' and exec_fn=='run_own'; formal predicate unarchived)",
        "census_spot_checks: checks/signal68_vs_regex522/verified (derived from signal68 has evidence and regex522 has none; formal predicate unarchived)",
        "f11_ast_scan: total_harmful_module_monkeypatches (2 sys attribute assignments exist at smoke_test.py:43-44; harmful=0 is unarchived heuristic treating sys as benign)",
        "f11_ast_scan: file_details/proof/smoke_test.py/harmful_module_monkeypatches_count",
        "f11_ast_scan: file_details/proof/artifact_legs.py/harmful_module_monkeypatches_count",
        "f11_ast_scan: file_details/proof/proofkit.py/harmful_module_monkeypatches_count",
        "f11_ast_scan: file_details/proof/roundtrip_shim.py/harmful_module_monkeypatches_count",
        "f11_ast_scan: file_details/proof/run_proof.py/harmful_module_monkeypatches_count"
    ],
    "disclosed_observations": [
        "f11_ast_scan: environ_discipline_proof (AST proves 41 smoke_test.py mutations and 0 production module mutations; pairing observations noted)",
        "f11_ast_scan: runner_execution_disclosure (archived method_f11_ast_scan.py defines analyze_file without driver loop; runner executes on proof/*.py)",
        "dead_symbol_screen: deliberate_unreferenced_symbols_explanation (intent claim disclaimed; facts: 0 references outside definition at H')",
        "trace_profile_hooks: title_note (title states 'only at 18485'; recomputed data proves hits on line 18694 and 18703 at H')"
    ],
    "inventory": inv
}

with open(os.path.join(RV3, "r2", "summary.json"), "w", encoding="utf-8") as f:
    json.dump(summary, f, indent=2, sort_keys=True)
    f.write("\n")

print("summary.json written successfully. All assertions passed!")
