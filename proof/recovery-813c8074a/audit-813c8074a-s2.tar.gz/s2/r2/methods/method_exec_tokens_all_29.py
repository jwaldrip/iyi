# Exact verification predicate for exec_tokens in all 29 censuses
import json, os, glob

W = "/private/tmp/iyi-proof-complete-813c8074a/c/r2"
census_dir = os.path.join(W, "proof", "census")

census_token_results = []
all_tokens_valid = True

for path in sorted(glob.glob(os.path.join(census_dir, "*.json"))):
    c = json.load(open(path))
    drv = c["driver"]
    script_path = os.path.join(W, c["script"])
    L = open(script_path, encoding="utf-8").read().splitlines()
    for ev in c.get("exec_evidence", []):
        site_line = ev["site_line"]
        token = ev["exec_token"]
        for ln in ev["exec_lines"]:
            line_in_bounds = (0 < ln <= len(L))
            line_text = L[ln - 1].strip() if line_in_bounds else ""
            is_fi_return = line_text in ("fi", "return", "return 0", "return 1", "esac", "done")
            token_in_line = (token in line_text) if line_in_bounds else False
            valid = line_in_bounds and token_in_line and not is_fi_return
            if not valid:
                all_tokens_valid = False
            census_token_results.append({
                "driver": drv,
                "script": c["script"],
                "site_line": site_line,
                "exec_line": ln,
                "exec_token": token,
                "script_line_text": line_text,
                "token_present": token_in_line,
                "is_fi_or_return": is_fi_return,
                "valid": valid
            })
