# Exact detection method for settrace and setprofile hooks
import os, re

W = "/private/tmp/iyi-proof-complete-813c8074a/c/r2"
proof_dir = os.path.join(W, "proof")

trace_matches = []
for root, dirs, files in os.walk(proof_dir):
    for fn in files:
        if fn.endswith(".py"):
            fp = os.path.join(root, fn)
            rel = os.path.relpath(fp, W)
            with open(fp, "r", encoding="utf-8") as f:
                for idx, line in enumerate(f, 1):
                    if re.search(r"\bsettrace\b|\bsetprofile\b", line):
                        trace_matches.append((rel, idx, line.strip()))
