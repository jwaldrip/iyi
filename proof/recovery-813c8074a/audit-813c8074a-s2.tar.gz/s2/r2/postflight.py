#!/usr/bin/env python3
"""Postflight verification for R2h v2.
Verifies clean clone porcelain (including ignored), re-hashes all read files,
and checks that every file is unchanged against preflight before-read hashes.
"""
import os
import sys
import json
import glob
import hashlib
import subprocess

def main():
    CLONE = "/private/tmp/iyi-proof-complete-813c8074a/c/r2"
    H = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
    jobs_dir = "/private/tmp/iyi-proof-complete-813c8074a/r2/jobs"
    preflight_hashes_path = "/private/tmp/iyi-proof-complete-813c8074a/r2/preflight_hashes.json"
    out_postflight_path = "/private/tmp/iyi-proof-complete-813c8074a/r2/postflight_verification.json"

    # 1. HEAD check
    head = subprocess.check_output(["git", "-C", CLONE, "rev-parse", "HEAD"]).decode().strip()
    assert head == H, f"HEAD mismatch: {head} vs {H}"

    # 2. Porcelain check with --untracked-files=all --ignored
    status = subprocess.check_output(["git", "-C", CLONE, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).decode().strip()
    assert status == "", f"Porcelain status not clean: {status}"

    # 3. Load preflight hashes
    with open(preflight_hashes_path, "r", encoding="utf-8") as f:
        preflight = json.load(f)
    before_hashes = preflight["files"]

    # 4. Find all files opened by jobs
    opened_files = set()
    for job_p in glob.glob(os.path.join(jobs_dir, "job_*")):
        out_p = os.path.join(job_p, "out.json")
        if os.path.isfile(out_p):
            with open(out_p, "r", encoding="utf-8") as f:
                d = json.load(f)
                for f_rel in d.get("clone_source_files_opened", []):
                    opened_files.add(f_rel)

    # Add citation files
    opened_files.add("proof/smoke_test.py")
    opened_files.add("proof/proofkit.py")

    # 5. Re-hash each opened file and compare to preflight
    rehash_records = {}
    for f_rel in sorted(opened_files):
        abs_p = os.path.join(CLONE, f_rel)
        assert os.path.isfile(abs_p), f"Missing file: {abs_p}"
        with open(abs_p, "rb") as f:
            h = hashlib.sha256(f.read()).hexdigest()
        blob = subprocess.check_output(["git", "-C", CLONE, "hash-object", abs_p]).decode().strip()
        expected = before_hashes.get(f_rel)
        assert expected is not None, f"File not in preflight records: {f_rel}"
        assert h == expected["before_sha256"], f"SHA256 mismatch for {f_rel}: {h} vs {expected['before_sha256']}"
        assert blob == expected["blob"], f"Blob mismatch for {f_rel}: {blob} vs {expected['blob']}"
        rehash_records[f_rel] = {
            "blob": blob,
            "after_sha256": h,
            "matches_before": True
        }

    report = {
        "head": H,
        "clone": CLONE,
        "porcelain_clean_with_ignored": True,
        "total_read_files_verified": len(rehash_records),
        "all_files_unchanged": True,
        "files": rehash_records
    }

    with open(out_postflight_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, sort_keys=True)
        f.write("\n")

    print(f"Postflight PASS: porcelain clean with --ignored, all {len(rehash_records)} read files re-hashed and verified unchanged.")
    sys.exit(0)

if __name__ == "__main__":
    main()
