#!/usr/bin/env python3
"""Preflight verification for R2h v2.
Verifies clean clone porcelain (including ignored), checks tracked blobs vs H,
and records before-read sha256 hashes of all tracked files.
"""
import os
import sys
import json
import hashlib
import subprocess

def main():
    CLONE = "/private/tmp/iyi-proof-complete-813c8074a/c/r2"
    H = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
    out_hashes_path = "/private/tmp/iyi-proof-complete-813c8074a/r2/preflight_hashes.json"

    # 1. HEAD check
    head = subprocess.check_output(["git", "-C", CLONE, "rev-parse", "HEAD"]).decode().strip()
    assert head == H, f"HEAD mismatch: {head} vs {H}"

    # 2. Porcelain check with --untracked-files=all --ignored
    status = subprocess.check_output(["git", "-C", CLONE, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"]).decode().strip()
    assert status == "", f"Porcelain status not clean: {status}"

    # 3. Tracked blob parity vs git ls-tree -r H
    ls_files = subprocess.check_output(["git", "-C", CLONE, "ls-files", "-s"]).decode().splitlines()
    clone_blobs = {}
    for line in ls_files:
        parts = line.split()
        path = line.split("\t", 1)[1]
        clone_blobs[path] = {"mode": parts[0], "blob": parts[1]}

    ls_tree = subprocess.check_output(["git", "-C", CLONE, "ls-tree", "-r", H]).decode().splitlines()
    tree_blobs = {}
    for line in ls_tree:
        parts = line.split()
        path = line.split("\t", 1)[1]
        tree_blobs[path] = {"mode": parts[0], "blob": parts[2]}

    assert len(clone_blobs) == len(tree_blobs) == 3266
    for path, meta in clone_blobs.items():
        assert tree_blobs[path]["blob"] == meta["blob"], f"Blob mismatch for {path}"

    # 4. Record before-read sha256 for all tracked files
    file_hashes = {}
    for path, meta in clone_blobs.items():
        abs_p = os.path.join(CLONE, path)
        if os.path.isfile(abs_p):
            with open(abs_p, "rb") as f:
                h = hashlib.sha256(f.read()).hexdigest()
            file_hashes[path] = {
                "blob": meta["blob"],
                "mode": meta["mode"],
                "before_sha256": h
            }

    report = {
        "head": H,
        "clone": CLONE,
        "porcelain_clean_with_ignored": True,
        "total_tracked_blobs": len(clone_blobs),
        "all_blobs_match_tree_H": True,
        "total_files_hashed": len(file_hashes),
        "files": file_hashes
    }

    with open(out_hashes_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, sort_keys=True)
        f.write("\n")

    print(f"Preflight PASS: HEAD={H}, porcelain clean with --ignored, all 3266 tracked blobs verified equal to tree H, {len(file_hashes)} file hashes recorded.")
    sys.exit(0)

if __name__ == "__main__":
    main()
