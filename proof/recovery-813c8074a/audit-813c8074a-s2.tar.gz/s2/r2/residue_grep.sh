#!/bin/sh
W="/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
H="813c8074acb2eed99ffeef78ea49e8c7832e4c01"
git -C "$W" grep -n build_census "$H"
rc1=$?
git -C "$W" grep -n helper_exec "$H"
rc2=$?
test "$rc1" -eq 1 && test "$rc2" -eq 1
