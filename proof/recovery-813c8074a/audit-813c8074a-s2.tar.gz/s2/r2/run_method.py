#!/usr/bin/env python3
"""RV2/r2h/v2 runner for isolated method execution with audit hook logging.
Usage: $PY -B -X pycache_prefix=RV2/pyc/r2h_v2 RV2/r2h/v2/run_method.py METHOD_PATH OUT_JSON_PATH
"""
import os
import sys
import json
import glob
import types
import runpy
import hashlib
import subprocess

def get_sha256(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

def main():
    if len(sys.argv) < 3:
        sys.stderr.write("Usage: run_method.py METHOD_PATH OUT_JSON_PATH\n")
        sys.exit(2)

    method_path = os.path.abspath(sys.argv[1])
    out_json_path = os.path.abspath(sys.argv[2])
    runner_path = os.path.abspath(__file__)

    if not os.path.isfile(method_path):
        sys.stderr.write(f"Method not found: {method_path}\n")
        sys.exit(2)

    if os.path.exists(out_json_path):
        sys.stderr.write(f"Output path already exists (must be opened with x): {out_json_path}\n")
        sys.exit(2)

    method_sha256 = get_sha256(method_path)
    runner_sha256 = get_sha256(runner_path)

    CLONE_ROOT = "/private/tmp/iyi-proof-complete-813c8074a/c/r2"
    PYC_ROOT_V1 = "/private/tmp/iyi-proof-complete-813c8074a/pyc/r2"
    PYC_ROOT_V2 = "/private/tmp/iyi-proof-complete-813c8074a/pyc/r2"
    H = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"

    # Pre-load H blobs and trees outside audit hook
    ls_files_out = subprocess.check_output(["git", "-C", CLONE_ROOT, "ls-files", "-s"]).decode().splitlines()
    h_blobs = {}
    for line in ls_files_out:
        parts = line.split()
        path = line.split("\t", 1)[1]
        h_blobs[path] = parts[1]

    ls_tree_out = subprocess.check_output(["git", "-C", CLONE_ROOT, "ls-tree", "-r", "-d", H]).decode().splitlines()
    root_tree = subprocess.check_output(["git", "-C", CLONE_ROOT, "rev-parse", H + "^{tree}"]).decode().strip()
    h_trees = {"": root_tree}
    for line in ls_tree_out:
        parts = line.split()
        path = line.split("\t", 1)[1]
        h_trees[path] = parts[2]

    # Pre-record sha256 of candidate source files in clone before execution
    source_hashes_before = {}
    for rel_path in h_blobs:
        abs_p = os.path.join(CLONE_ROOT, rel_path)
        if os.path.isfile(abs_p):
            source_hashes_before[rel_path] = get_sha256(abs_p)

    # Tight stdlib prefixes (no wide /usr or /System fallback)
    stdlib_prefixes = [
        os.path.realpath(sys.prefix),
        os.path.realpath(sys.base_prefix)
    ]
    clone_real = os.path.realpath(CLONE_ROOT)
    pyc_reals = [os.path.realpath(PYC_ROOT_V1), os.path.realpath(PYC_ROOT_V2)]
    method_real = os.path.realpath(method_path)
    runner_real = os.path.realpath(runner_path)
    out_real = os.path.realpath(out_json_path)

    raw_events = []
    recording = True

    def audit_hook(event, args):
        nonlocal recording
        if not recording:
            return
        if event in ("open", "os.listdir", "os.scandir"):
            raw_events.append((event, args))

    sys.addaudithook(audit_hook)

    f11_runner_invoked = False
    f11_disclosure_note = None

    # Execute method
    g = {}
    try:
        g = runpy.run_path(method_path)
        # Disclosed execution for method_f11_ast_scan: method defines predicate analyze_file(filepath)
        # but contains no top-level loop over proof/*.py modules
        if "analyze_file" in g and callable(g["analyze_file"]) and "file_details" not in g:
            f11_runner_invoked = True
            f11_disclosure_note = "Archived method_f11_ast_scan.py defines analyze_file(filepath) without driver loop; runner executes analyze_file on proof/*.py modules"
            proof_dir = g.get("proof_dir", os.path.join(g.get("W", CLONE_ROOT), "proof"))
            py_files = sorted(glob.glob(os.path.join(proof_dir, "*.py")))
            g["modules_scanned"] = [os.path.relpath(p, g.get("W", CLONE_ROOT)) for p in py_files]
            g["file_details"] = {}
            for p in py_files:
                rel = os.path.relpath(p, g.get("W", CLONE_ROOT))
                g["file_details"][rel] = g["analyze_file"](p)
    except Exception as exc:
        recording = False
        sys.stderr.write(f"Method execution raised exception: {exc}\n")
        raise
    finally:
        recording = False

    # Process and classify events outside audit callback
    classified_events = []
    opened_clone_files = set()
    opened_clone_dirs = set()

    for event, args in raw_events:
        target = args[0]
        mode = "r"
        flags = None
        if event == "open":
            if len(args) > 1 and args[1] is not None:
                mode = args[1]
            if len(args) > 2 and args[2] is not None:
                flags = args[2]

        is_write_intent = False
        if any(m in str(mode) for m in ("w", "a", "+", "x")):
            is_write_intent = True
        if flags is not None:
            # Check POSIX write/creation flags
            write_mask = os.O_WRONLY | os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_TRUNC
            if (flags & write_mask) != 0:
                is_write_intent = True

        if isinstance(target, int):
            classified_events.append({
                "event": event,
                "target_fd": target,
                "mode": str(mode),
                "flags": flags,
                "class": "descriptor"
            })
            continue

        target_str = os.fspath(target)
        real_p = os.path.realpath(target_str)

        event_class = None
        blob_id = None
        tree_id = None

        if real_p == method_real:
            event_class = "method"
            if is_write_intent:
                raise RuntimeError(f"Illegal write mode on method: {target_str}")
        elif real_p == runner_real:
            event_class = "runner"
            if is_write_intent:
                raise RuntimeError(f"Illegal write mode on runner: {target_str}")
        elif real_p == out_real:
            event_class = "own-output"
        elif any(real_p.startswith(p_real) for p_real in pyc_reals):
            event_class = "pycache"
        elif any(real_p.startswith(pfx) for pfx in stdlib_prefixes):
            event_class = "stdlib"
            if is_write_intent:
                raise RuntimeError(f"Illegal write mode on stdlib: {target_str}")
        elif real_p.startswith(clone_real):
            event_class = "clone-source"
            rel_p = os.path.relpath(real_p, clone_real)
            if rel_p == ".":
                rel_p = ""

            if event == "open":
                if is_write_intent:
                    raise RuntimeError(f"Illegal write mode on clone source: {target_str}")
                if rel_p not in h_blobs:
                    raise RuntimeError(f"Opened file not in tracked H blobs: {rel_p}")
                blob_id = h_blobs[rel_p]
                opened_clone_files.add(rel_p)
            elif event in ("os.listdir", "os.scandir"):
                if rel_p not in h_trees:
                    raise RuntimeError(f"Listed directory not in tracked H trees: {rel_p}")
                tree_id = h_trees[rel_p]
                opened_clone_dirs.add(rel_p)
        else:
            raise RuntimeError(f"Disallowed read/write path in audit event: {event} {target_str} (realpath: {real_p})")

        rec = {
            "event": event,
            "path": target_str,
            "realpath": real_p,
            "mode": str(mode),
            "flags": flags,
            "class": event_class
        }
        if blob_id is not None:
            rec["blob_id"] = blob_id
        if tree_id is not None:
            rec["tree_id"] = tree_id
        classified_events.append(rec)

    # Verify all opened clone-source files against git hash-object and confirm before/after sha256
    for rel_p in opened_clone_files:
        abs_p = os.path.join(CLONE_ROOT, rel_p)
        git_hash = subprocess.check_output(["git", "-C", CLONE_ROOT, "hash-object", abs_p]).decode().strip()
        expected_blob = h_blobs[rel_p]
        if git_hash != expected_blob:
            raise RuntimeError(f"Hash-object mismatch for {rel_p}: {git_hash} vs {expected_blob}")
        after_sha = get_sha256(abs_p)
        before_sha = source_hashes_before.get(rel_p)
        if after_sha != before_sha:
            raise RuntimeError(f"File mutated during execution: {rel_p}")

    def to_json_val(obj):
        if isinstance(obj, (types.ModuleType, types.FunctionType, type)):
            raise TypeError("Not serializable")
        if isinstance(obj, set):
            return sorted([to_json_val(x) for x in obj])
        if isinstance(obj, (list, tuple)):
            return [to_json_val(x) for x in obj]
        if isinstance(obj, dict):
            return {str(k): to_json_val(v) for k, v in obj.items()}
        json.dumps(obj)
        return obj

    # Filter globals: drop modules, functions, classes, and names containing environ
    filtered_globals = {}
    for k, v in g.items():
        if k.startswith("__"):
            continue
        if "environ" in k.lower():
            continue
        try:
            filtered_globals[k] = to_json_val(v)
        except (TypeError, OverflowError):
            continue

    out_data = {
        "method": method_path,
        "method_sha256": method_sha256,
        "runner": runner_path,
        "runner_sha256": runner_sha256,
        "status": "PASS",
        "f11_runner_invoked": f11_runner_invoked,
        "f11_disclosure": f11_disclosure_note,
        "globals": filtered_globals,
        "event_log": classified_events,
        "total_events": len(classified_events),
        "clone_source_files_opened": sorted(list(opened_clone_files)),
        "clone_source_dirs_listed": sorted(list(opened_clone_dirs))
    }

    # Open out_json_path with mode 'x'
    raw_json = json.dumps(out_data, indent=2, sort_keys=True) + "\n"
    with open(out_json_path, "x", encoding="utf-8") as f:
        f.write(raw_json)
        f.flush()
        os.fsync(f.fileno())

    print(f"PASS: {os.path.basename(method_path)} -> {os.path.basename(out_json_path)} ({len(classified_events)} audit events logged)")
    sys.exit(0)

if __name__ == "__main__":
    main()
