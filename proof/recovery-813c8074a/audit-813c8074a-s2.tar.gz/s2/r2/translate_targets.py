#!/usr/bin/env python3
"""translate_targets.py: Map H archived R2 outputs to H' translated targets.
Translates smoke_test.py line fields using RV3/line-map.json, outputs to
RV3/inputs/h-r2-translated/, and generates translation-log.json and expected-deltas.json.
"""
import os
import sys
import json
import tarfile
import copy

def main():
    RV3 = "/private/tmp/iyi-proof-complete-813c8074a"
    LINE_MAP_PATH = os.path.join(RV3, "line-map.json")
    ARCHIVE_PATH = "/Users/jwaldrip/dev/worktrees/iyi-stale-recovery-evidence-20261030/proof/recovery-20261030/audit-completion-6bbe-r2-initial.tar.gz"
    OUT_DIR = os.path.join(RV3, "inputs", "h-r2-translated")
    LOG_PATH = os.path.join(RV3, "r2", "translation-log.json")
    DELTAS_PATH = os.path.join(RV3, "r2", "expected-deltas.json")

    os.makedirs(OUT_DIR, exist_ok=True)

    with open(LINE_MAP_PATH, "r", encoding="utf-8") as f:
        line_map_data = json.load(f)
    mapping = line_map_data["smoke_test"]["mapping"]

    # Extract all r2/*.json files from archive
    h_docs = {}
    with tarfile.open(ARCHIVE_PATH) as tar:
        for member in tar.getmembers():
            if member.name.startswith("r2/") and member.name.endswith(".json"):
                base_name = os.path.basename(member.name)
                h_docs[base_name] = json.load(tar.extractfile(member))

    translated_docs = copy.deepcopy(h_docs)
    translation_log = []

    # 1. trace_profile_hooks.json
    tph = translated_docs["trace_profile_hooks.json"]
    for idx, occ in enumerate(tph["occurrences"]):
        if occ.get("file") == "proof/smoke_test.py":
            orig_line = occ["line"]
            new_line = mapping[str(orig_line)]
            occ["line"] = new_line
            translation_log.append({
                "check": "trace_profile_hooks",
                "file": "trace_profile_hooks.json",
                "leaf_path": f"occurrences/{idx}/line",
                "original_value": orig_line,
                "translated_value": new_line,
                "offset": new_line - orig_line,
                "reason": f"settrace hook line in smoke_test.py shifted from {orig_line} to {new_line} (+{new_line - orig_line} offset) due to intervening hunks"
            })

    # 2. dead_symbol_screen.json
    dss = translated_docs["dead_symbol_screen.json"]
    for idx, sym in enumerate(dss["unreferenced_by_module"]["smoke_test"]):
        orig_line = sym["line"]
        new_line = mapping[str(orig_line)]
        if new_line != orig_line:
            sym["line"] = new_line
            translation_log.append({
                "check": "dead_symbol_screen",
                "file": "dead_symbol_screen.json",
                "leaf_path": f"unreferenced_by_module/smoke_test/{idx}/line",
                "original_value": orig_line,
                "translated_value": new_line,
                "offset": new_line - orig_line,
                "reason": f"Symbol {sym['name']} definition in smoke_test.py moved from line {orig_line} to {new_line} (+{new_line - orig_line} offset)"
            })
    # Also update explanation line citation if present
    exp = dss.get("deliberate_unreferenced_symbols_explanation", {})
    if "smoke_test.run_o3_suite" in exp:
        orig_exp = exp["smoke_test.run_o3_suite"]
        if "Line 18440:" in orig_exp:
            new_exp = orig_exp.replace("Line 18440:", "Line 18649:")
            exp["smoke_test.run_o3_suite"] = new_exp
            translation_log.append({
                "check": "dead_symbol_screen",
                "file": "dead_symbol_screen.json",
                "leaf_path": "deliberate_unreferenced_symbols_explanation/smoke_test.run_o3_suite",
                "original_value": orig_exp,
                "translated_value": new_exp,
                "offset": 209,
                "reason": "Updated line reference in run_o3_suite explanation from 18440 to 18649"
            })

    # 3. f11_ast_scan.json
    f11 = translated_docs["f11_ast_scan.json"]
    st_details = f11["file_details"]["proof/smoke_test.py"]
    for idx, env_mut in enumerate(st_details["environ_mutations"]):
        orig_line = env_mut["line"]
        new_line = mapping[str(orig_line)]
        if new_line != orig_line:
            env_mut["line"] = new_line
            translation_log.append({
                "check": "f11_ast_scan",
                "file": "f11_ast_scan.json",
                "leaf_path": f"file_details/proof/smoke_test.py/environ_mutations/{idx}/line",
                "original_value": orig_line,
                "translated_value": new_line,
                "offset": new_line - orig_line,
                "reason": f"environ mutation ({env_mut['op']}) in smoke_test.py shifted from line {orig_line} to {new_line} (+{new_line - orig_line} offset)"
            })

    # Write all translated docs to OUT_DIR
    for fname, doc in translated_docs.items():
        out_p = os.path.join(OUT_DIR, fname)
        with open(out_p, "w", encoding="utf-8") as f:
            json.dump(doc, f, indent=2, sort_keys=True)
            f.write("\n")

    # Write translation log
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        json.dump(translation_log, f, indent=2, sort_keys=True)
        f.write("\n")

    # Write expected deltas
    expected_deltas = [
        {
            "check": "registry_holes",
            "file": "registry_holes.json",
            "leaf_path": "suite_summary/total_registered_fixtures",
            "h_value": 516,
            "hp_value": 520,
            "delta": 4,
            "reason": "H' repair adds 4 registered fixtures: 3 new seeds (o7.seed.plan-probe-unobservable, o7.seed.validator-sentinel-iyivar, o7.seed.baseline-skip-captured) and 1 new control (o7.control.guard-m14-baseline-header)"
        },
        {
            "check": "registry_holes",
            "file": "registry_holes.json",
            "leaf_path": "suite_summary/registered_seeds_count",
            "h_value": 432,
            "hp_value": 435,
            "delta": 3,
            "reason": "H' repair adds 3 seeds: o7.seed.plan-probe-unobservable (g02'), o7.seed.validator-sentinel-iyivar (g18), o7.seed.baseline-skip-captured (m14)"
        },
        {
            "check": "registry_holes",
            "file": "registry_holes.json",
            "leaf_path": "suite_summary/registered_controls_count",
            "h_value": 84,
            "hp_value": 85,
            "delta": 1,
            "reason": "H' repair adds 1 control: o7.control.guard-m14-baseline-header"
        },
        {
            "check": "registry_holes",
            "file": "registry_holes.json",
            "leaf_path": "suite_summary/total_review_items",
            "h_value": 172,
            "hp_value": 174,
            "delta": 2,
            "reason": "H' repair adds 2 review items corresponding to repaired mutants g18 and m14"
        },
        {
            "check": "registry_holes",
            "file": "registry_holes.json",
            "leaf_path": "suite_summary/total_mapped_fixture_ids",
            "h_value": 516,
            "hp_value": 520,
            "delta": 4,
            "reason": "All 4 new fixtures added in H' are fully mapped to review items with zero unmapped or dangling references"
        }
    ]

    with open(DELTAS_PATH, "w", encoding="utf-8") as f:
        json.dump(expected_deltas, f, indent=2, sort_keys=True)
        f.write("\n")

    print(f"translate_targets.py completed: {len(translated_docs)} files written to {OUT_DIR}.")
    print(f"  Translation log: {len(translation_log)} leaves translated, written to {LOG_PATH}.")
    print(f"  Expected deltas: {len(expected_deltas)} deltas written to {DELTAS_PATH}.")

if __name__ == "__main__":
    main()
