# S4 Non-Weakening and Delta Review Report (H -> H')

**Base Head H:** `6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd`  
**Repaired Head H':** `813c8074acb2eed99ffeef78ea49e8c7832e4c01`  
**Status:** PASS  
**Weakening Findings:** 0  

---

## 1. In-Place Changed Fixtures: Non-Weakening Analysis

Three fixtures were modified in place between H and H':
1. `o5.seed.e2-unmatched-own`
2. `o7.seed.pk2-schema-sentinel-iyivar`
3. `o7.control.guard-m14-baseline-header`

Every assertion made by the H version of each fixture is preserved or strengthened in H'. Zero assertions were lost.

### 1.1 `o5.seed.e2-unmatched-own`
- **At H:** defined at `proof/smoke_test.py:8147-8160` (registered at 9246, smoke line 784). It used `_o5_pair` with `out_ref=None`. This asserted that an unmatched own output triggered `NOT-EXECUTED`, but because `out_ref` was `None`, it simultaneously triggered `pk:3748-3755` ('record has no out_ref') alongside `pk:3729-3735` ('matches no execution evidence'), masking mutant `g13`.
- **At H':** updated at `proof/smoke_test.py:8185-8199` (helper at `7641-7676`, registered at 9284, smoke line 784). It provides a real hard-linked copy of `/usr/bin/true`, valid `out_ref`, timestamps, inode, and hash. It isolates `pk:3729-3735`, asserting that an extra own build record matching no execution evidence yields `NOT-EXECUTED`.
- **Proof Old Paths Are Still Asserted:**
  - **Unmatched own record path (`pk:3729-3735`):** still asserted by `o5.seed.e2-unmatched-own` (`smoke_test.py:8185-8199`, smoke line 784).
  - **No `out_ref` path (`pk:3748-3755`):** proved still asserted by:
    - `o5.seed.e3-ref-missing` (`smoke_test.py:8604-8608`, registered at 9299, smoke line 787): explicitly sets `end['out_ref'] = None` and asserts `statuses = ("NOT-EXECUTED",)` with `stat_calls = 0`.
    - `amend-b.seed.run-form-not-counted` (`smoke_test.py:11711-11750, 14210-14240`, registered at 9374, smoke line 806): exercises run-form execution ledger without `out_ref`, asserting status `NOT-EXECUTED`.

### 1.2 `o7.seed.pk2-schema-sentinel-iyivar`
- **At H:** defined at `proof/smoke_test.py:15332-15341` (registered at 16564, smoke line 999). It set `regex = "IYIVAR"`. While intending to test literal IYIVAR rejection at `pk:2827-2834`, it also failed the fallback regex match at `pk:2835-2845`, emitting `C5.5-sentinel` regardless of `pk:2827`.
- **At H':** updated at `proof/smoke_test.py:15390-15399` (registered at 16744, smoke line 999). It sets `regex = f"(?:{mutated['pass_sentinel']['regex']})|IYIVAR"`. If `pk:2827` fires, `C5.5-sentinel` is emitted; if skipped (mutant `g18`), the fallback regex matches, returning `got = False` and killing `g18`.
- **Proof Old Paths Are Still Asserted:**
  - **Literal IYIVAR path (`pk:2827-2834`):** asserted by `o7.seed.pk2-schema-sentinel-iyivar` (`smoke_test.py:15390-15399`, smoke line 999) and by new seed `o7.seed.validator-sentinel-iyivar` (`smoke_test.py:16640-16664`, smoke line 1234).
  - **Regex mismatch fallback path (`pk:2835-2845`):** asserted by `s2.seed.validator-sentinel` (`smoke_test.py:2464-2470, 3751-3759`, smoke line 56). It sets `regex = "(?!)"` which contains no literal IYIVAR, so expected violation `["C5.5-sentinel"]` depends directly on `pk:2835-2845` failing to match the rendered output.

### 1.3 `o7.control.guard-m14-baseline-header`
- **At H:** defined at `proof/smoke_test.py:13621-13656` (registered at 16807, smoke line 1133). As an unseeded control, it asserted positive skip capture under a well-formed header (`len(hits) == 1`). Under mutant `m14` (broken header regex), `hits` became 0, causing the control to fail and inverting the guard pair.
- **At H':** rebuilt at `proof/smoke_test.py:13660-13714` (registered at 16987, smoke line 1133) with `case == "no-skip"`. It asserts that a well-formed header with no skip lines yields 0 hits (`expected = 0, got = 0`), which is stable under both base and mutant `m14`.
- **Proof Old Control Input Is Covered:**
  - **Positive skip capture under well-formed header:** covered by new seed `o7.seed.baseline-skip-captured` (`smoke_test.py:13660-13704`, registered at 17282, smoke line 1235). It tests the exact input of the old control (well-formed header + declared skip line) and strengthens the assertion from scalar length to exact structured dictionary equality `[{"class": "platform", "driver": "stage", "regex": "^fixture platform skipped$", "what": "fixture platform"}]`.
  - **Negative malformed header rejection:** still asserted by `o7.seed.guard-m14-baseline-header` (`smoke_test.py:13660-13714`, registered at 16982, smoke line 1132), expecting 0 hits.

---

## 2. H..H' Hunk Mapping and Negative Invariants

Every hunk between H and H' maps strictly to gap-fix Changes 1-8:

| Hunk | File | H Lines | H' Lines | Gap-Fix Change | Description |
|---|---|---|---|---|---|
| 1 | `proof/run_proof.py` | 324 | 324 | Change 1 | Thread `stat_fn=os.stat` into `cmd_plan` signature |
| 2 | `proof/run_proof.py` | 330 | 330 | Change 1 | Pass `stat_fn=stat_fn` to `probe_atime_observable` |
| 3 | `proof/smoke_test.py` | 7640 (insert) | 7641-7678 (+38) | Change 2 | Helper `_o5_executed_own_build_pair` |
| 4 | `proof/smoke_test.py` | 8147-8160 | 8185-8199 | Change 3 | `case == "e2-unmatched-own"` uses helper |
| 5 | `proof/smoke_test.py` | 13621-13656 | 13660-13714 | Change 4 | `_fixture_baseline_header_guard` parameterized by case |
| 6 | `proof/smoke_test.py` | 15334 | 15392 | Change 5 | `case == "schema-sentinel-iyivar"` regex alternation |
| 7 | `proof/smoke_test.py` | 16484 (insert) | 16543-16664 (+122) | Change 6 | Define `_fixture_plan_probe_guard` & sentinel IYIVAR helpers |
| 8 | `proof/smoke_test.py` | 16804 | 16984 | Change 7 | `o7.seed.guard-m14-baseline-header` case="malformed" |
| 9 | `proof/smoke_test.py` | 16809 | 16989 | Change 7 | `o7.control.guard-m14-baseline-header` case="no-skip" |
| 10 | `proof/smoke_test.py` | 17085 (insert) | 17266-17285 (+20) | Change 7 | Register 4 Fixtures in `O7_FIXTURES` |
| 11 | `proof/smoke_test.py` | 17333 (insert) | 17534 (+1) | Change 8 | Add `baseline-skip-captured` to `o7.guard-m14-baseline-header` |
| 12 | `proof/smoke_test.py` | 17431 (insert) | 17633-17640 (+8) | Change 8 | Add `o7.plan-probe` and `o7.validator-sentinel-iyivar` items |

### Negative Invariant Verifications
AST parsing and token verification of all added lines confirmed:
- **Imports added:** 0
- **Attribute assignments added:** 0
- **`setattr` calls added:** 0
- **`os.environ` usage:** 0
- **`subprocess` usage:** 0
- **`timeout` usage:** 0
- **Readiness-fence code calls (`run_bounded`, handlers, cancellation):** 0

---

## 3. New Fixture Discrimination Verification

Confirmed using native X1 execution evidence under `RV3/x1/`:

1. **`o7.seed.plan-probe-unobservable` (Mutant `g02`):**
   - Baseline (`RV3/x1/base-g02`): `expected={"applied": true, "reason": "EXEC-UNOBSERVABLE", "stdout_empty": true}`, `got=<same>`, rc 0, PASS.
   - Mutant `g02` (`RV3/x1/g02`): `got={"applied": false, "reason": "NO-REFUSAL", "stdout_empty": false}`, `RESULT FAIL ['o7.seed.plan-probe-unobservable'] []`, rc 1.
   - **Status:** DISCRIMINATES (Mutant KILLED).

2. **`o7.seed.validator-sentinel-iyivar` (Mutant `g18`):**
   - Baseline (`RV3/x1/base-g18`): `expected={"control": [], "seed": ["C5.5-sentinel"]}`, `got=<same>`, rc 0, PASS.
   - Mutant `g18` (`RV3/x1/g18`): `got={"control": [], "seed": []}`, `RESULT FAIL ['o7.seed.pk2-schema-sentinel-iyivar', 'o7.seed.validator-sentinel-iyivar'] []`, rc 1.
   - **Status:** DISCRIMINATES (Mutant KILLED).

3. **`o7.seed.baseline-skip-captured` (Mutant `m14`):**
   - Baseline (`RV3/x1/base-m14`): `expected=[{"class": "platform", "driver": "stage", "regex": "^fixture platform skipped$", "what": "fixture platform"}], got=<same>`, rc 0, PASS.
   - Mutant `m14` (`RV3/x1/m14`): `got=[]`, `RESULT FAIL ['o7.seed.baseline-skip-captured'] []`, rc 1.
   - **Status:** DISCRIMINATES (Mutant KILLED).

4. **`o5.seed.e2-unmatched-own` (Repaired seed, Mutant `g13`):**
   - Baseline (`RV3/x1/base-g13`): `expected=["NOT-EXECUTED"], got=<same>`, rc 0, PASS.
   - Mutant `g13` (`RV3/x1/g13`): `got=[]`, `RESULT FAIL ['o5.seed.e2-unmatched-own'] []`, rc 1.
   - **Status:** DISCRIMINATES (Mutant KILLED).

---

## 4. Conclusion
Unit S4 verification is fully green:
- Zero lost assertions between H and H'.
- Zero weakening findings.
- Exact hunk-to-change mapping across all 12 hunks.
- Zero forbidden language constructs or readiness-fence entanglements.
- 100% of new and repaired fixtures discriminate against targeted mutants.
