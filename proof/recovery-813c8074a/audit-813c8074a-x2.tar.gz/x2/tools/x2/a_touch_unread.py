"""touch_unread tool skip (file:529) must classify ENV-BLOCKED and never be waived,
even when the skip is present in the baseline set; control: no skip line -> PASS;
platform skip with baseline -> PASS with a platform-limit reason; platform skip
missing from baseline -> PARTIAL."""
import json
import os
import sys

AUD = "/private/tmp/iyi-proof-complete-813c8074a"
sys.path.insert(0, os.path.join(AUD, "w"))
import proof.run_proof as rp  # noqa: E402

census = json.load(open(os.path.join(AUD, "w", "proof", "census", "file.json")))
skip = [s for s in census["skips"] if s["line"] == 529][0]
line = "  touch and exists? of a file its owner may not read: not measured, this user reads it all the same"
log_hit = "== something\n" + line + "\nthe std/file exercise holds\n"
log_clean = "== something\nthe std/file exercise holds\n"
key = ("file", skip["class"], skip["what"], skip["regex"])
res = {}
res["control-no-skip-line"] = rp._classify_driver_skips(census, log_clean, set())
res["seed-skip-not-in-baseline"] = rp._classify_driver_skips(census, log_hit, set())
res["seed-skip-in-baseline-not-waived"] = rp._classify_driver_skips(census, log_hit, {key})
# platform-class skip contrast (math:698, uname-guarded)
math = json.load(open(os.path.join(AUD, "w", "proof", "census", "math.json")))
plat = [s for s in math["skips"] if s["class"] == "platform"]
res["math-platform-skips-in-census"] = [(s["line"], s["what"]) for s in plat]
print(json.dumps({"skip_entry": {k: skip[k] for k in ("line", "class", "what")}, "results": {k: v for k, v in res.items()}}, indent=1, default=str))
ok = (res["control-no-skip-line"][0] == "PASS" and res["seed-skip-not-in-baseline"][0] == "ENV-BLOCKED"
      and res["seed-skip-in-baseline-not-waived"][0] == "ENV-BLOCKED")
print("VERDICT", "PASS" if ok else "FAIL")
raise SystemExit(0 if ok else 1)
