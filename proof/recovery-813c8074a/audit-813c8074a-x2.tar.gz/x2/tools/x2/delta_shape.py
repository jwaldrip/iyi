#!/usr/bin/env python3
"""Delta shape check for H -> H' (G1d).
Verifies:
1. artifact_legs, proofkit and roundtrip_shim are byte-equal between H and H';
2. ALLOWLIST value has the same AST at H and H';
3. numstat matches §3.7: exactly 2 2 for proof/run_proof.py and 225 16 for proof/smoke_test.py;
4. run_proof hunks are exactly gap-fix Change 1;
5. smoke_test hunks are exactly the 10 hunks of the line map, each tagged with its gap-fix Change 2-8.
"""
import ast
import json
import os
import re
import subprocess
import sys

W3 = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
H = "6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd"
H_PRIME = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
RV3 = "/private/tmp/iyi-proof-complete-813c8074a"
OUT = os.path.join(RV3, "evidence/layout")


def git_show(rev, rel_path):
    return subprocess.check_output(
        ["git", "-C", W3, "show", f"{rev}:{rel_path}"],
        env=dict(os.environ, GIT_OPTIONAL_LOCKS="0"),
    )


def git_diff(rev1, rev2, *args, paths=None):
    cmd = ["git", "-C", W3, "diff"] + list(args) + [rev1, rev2]
    if paths:
        cmd.append("--")
        cmd.extend(paths)
    return subprocess.check_output(
        cmd,
        text=True,
        env=dict(os.environ, GIT_OPTIONAL_LOCKS="0"),
    )


def main():
    os.makedirs(OUT, exist_ok=True)
    results = {}

    # Check 1: byte-equal modules
    byte_equal = {}
    for mod in ["artifact_legs.py", "proofkit.py", "roundtrip_shim.py"]:
        b_h = git_show(H, f"proof/{mod}")
        b_hp = git_show(H_PRIME, f"proof/{mod}")
        eq = b_h == b_hp
        byte_equal[mod] = eq
        if not eq:
            raise RuntimeError(f"Module {mod} is not byte-equal between H and H'")
    results["1_byte_equal"] = byte_equal

    # Check 2: ALLOWLIST AST equal
    def extract_allowlist_ast(src_bytes):
        tree = ast.parse(src_bytes.decode("utf-8"))
        for node in tree.body:
            if isinstance(node, (ast.AnnAssign, ast.Assign)):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                if any(isinstance(t, ast.Name) and t.id == "ALLOWLIST" for t in targets):
                    return ast.dump(node.value, include_attributes=False)
        raise RuntimeError("ALLOWLIST not found")

    al_h = extract_allowlist_ast(git_show(H, "proof/smoke_test.py"))
    al_hp = extract_allowlist_ast(git_show(H_PRIME, "proof/smoke_test.py"))
    al_eq = al_h == al_hp
    if not al_eq:
        raise RuntimeError("ALLOWLIST AST differs between H and H'")
    results["2_allowlist_ast_equal"] = al_eq

    # Check 3: numstat matches §3.7
    numstat_raw = subprocess.check_output(
        ["git", "-C", W3, "diff", "--numstat", H, H_PRIME],
        text=True,
        env=dict(os.environ, GIT_OPTIONAL_LOCKS="0"),
    ).strip().splitlines()
    numstat_dict = {}
    for line in numstat_raw:
        parts = line.split("\t")
        if len(parts) == 3:
            numstat_dict[parts[2]] = [int(parts[0]), int(parts[1])]
    expected_numstat = {
        "proof/run_proof.py": [2, 2],
        "proof/smoke_test.py": [225, 16],
    }
    if numstat_dict != expected_numstat:
        raise RuntimeError(f"numstat mismatch: got {numstat_dict}, expected {expected_numstat}")
    results["3_numstat"] = numstat_dict

    # Check 4: run_proof hunks are exactly gap-fix Change 1
    rp_diff = git_diff(H, H_PRIME, "-U0", paths=["proof/run_proof.py"])
    rp_change1 = (
        "def cmd_plan(args, *, drivers: Sequence[str] = DRIVERS_29, stat_fn=os.stat) -> int:" in rp_diff
        and "probe = probe_atime_observable(probe_dir, stat_fn=stat_fn)" in rp_diff
    )
    if not rp_change1:
        raise RuntimeError("run_proof diff does not match Change 1")
    results["4_run_proof_change1"] = rp_change1

    # Check 5: smoke_test hunks are exactly the 10 hunks of the line map, each tagged with its gap-fix Change 2-8
    st_diff = git_diff(H, H_PRIME, paths=["proof/smoke_test.py"])
    hunk_headers = re.findall(r"^@@ -(\d+),(\d+) \+(\d+),(\d+) @@(.*)$", st_diff, re.M)
    if len(hunk_headers) != 10:
        raise RuntimeError(f"smoke_test diff expected 10 hunks, got {len(hunk_headers)}")

    hunk_tagging = [
        {"hunk": 1, "h_start": 7638, "hp_start": 7638, "tag": "Change 2: _o5_executed_own_build_pair"},
        {"hunk": 2, "h_start": 8146, "hp_start": 8184, "tag": "Change 3: _o5_ledger_fixture e2-unmatched-own"},
        {"hunk": 3, "h_start": 13618, "hp_start": 13657, "tag": "Change 4: _fixture_baseline_header_guard signature"},
        {"hunk": 4, "h_start": 13642, "hp_start": 13683, "tag": "Change 4: _fixture_baseline_header_guard body"},
        {"hunk": 5, "h_start": 15331, "hp_start": 15389, "tag": "Change 5: _proofkit_more_edge pass_sentinel regex"},
        {"hunk": 6, "h_start": 16482, "hp_start": 16540, "tag": "Change 6: _fixture_plan_probe_guard"},
        {"hunk": 7, "h_start": 16801, "hp_start": 16981, "tag": "Change 7: O7_FIXTURES malformed and no-skip"},
        {"hunk": 8, "h_start": 17083, "hp_start": 17263, "tag": "Change 7: O7_FIXTURES append 4 fixtures"},
        {"hunk": 9, "h_start": 17331, "hp_start": 17531, "tag": "Change 8: O7_REVIEW_ITEMS o7.guard-m14-baseline-header"},
        {"hunk": 10, "h_start": 17429, "hp_start": 17630, "tag": "Change 8: O7_REVIEW_ITEMS new review items"},
    ]
    verified_hunks = []
    for idx, (h_start, h_len, hp_start, hp_len, header_ctx) in enumerate(hunk_headers):
        expected = hunk_tagging[idx]
        if int(h_start) != expected["h_start"] or int(hp_start) != expected["hp_start"]:
            raise RuntimeError(f"Hunk {idx+1} mismatch: got -{h_start} +{hp_start}, expected -{expected['h_start']} +{expected['hp_start']}")
        verified_hunks.append({
            "hunk": idx + 1,
            "h_range": f"{h_start},{h_len}",
            "hp_range": f"{hp_start},{hp_len}",
            "tag": expected["tag"],
        })
    results["5_smoke_test_10_hunks"] = verified_hunks

    delta_shape_doc = {
        "status": "PASS",
        "h": H,
        "h_prime": H_PRIME,
        "checks": results,
    }
    out_path = os.path.join(OUT, "delta_shape.json")
    with open(out_path, "w") as f:
        json.dump(delta_shape_doc, f, indent=2)
    print("delta_shape PASS, written to", out_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
