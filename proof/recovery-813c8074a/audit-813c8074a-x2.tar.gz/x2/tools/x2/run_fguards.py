"""F-guards audit on RV/w."""
import copy
import hashlib
import json
import os
import pathlib
import sys

RV = pathlib.Path("/private/tmp/iyi-proof-complete-813c8074a")
W = RV / "w"
OUT = RV / "evidence/fguards"
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(W))

import proof.proofkit as pk


def load(driver):
    census = json.load(open(os.path.join(W, "proof", "census", f"{driver}.json")))
    script = open(os.path.join(W, census["script"]), "rb").read()
    return census, script


def check(driver, census):
    _, script = load(driver)
    sha = hashlib.sha256(script).hexdigest()
    if census["script_sha256"] != sha:
        raise SystemExit(f"sha drift {driver}")
    return pk.validate_census(census, script, census["script"])


REPORT = []


def emit(name, **fields):
    line = json.dumps({"seed": name, **fields}, sort_keys=True, default=str)
    print(line)
    REPORT.append(line)


def diff_paths(before, after, prefix=""):
    out = []
    if isinstance(before, dict) and isinstance(after, dict):
        for key in sorted(set(before) | set(after)):
            out.extend(diff_paths(before.get(key, "<absent>"), after.get(key, "<absent>"), f"{prefix}/{key}"))
    elif isinstance(before, list) and isinstance(after, list) and len(before) == len(after):
        for i, (b, a) in enumerate(zip(before, after)):
            out.extend(diff_paths(b, a, f"{prefix}[{i}]"))
    elif before != after:
        out.append((prefix, before, after))
    return out


# ---- F1: regex:231 declared canonical-other instead of mixed
base, _ = load("regex")[0], None
control = check("regex", base)
seed = copy.deepcopy(base)
hit = [s for s in seed["sites"] if s["lines"] == [231]]
hit[0]["kind"] = "canonical-other"
hit[0]["variants"] = []
changes = diff_paths(base, seed)
v = check("regex", seed)
emit("F1.regex231-canonical-other", control=[x[0] for x in control], applied_sites=len(hit),
     diff_count=len(changes), diff_paths=[c[0] for c in changes], violations=v,
     rule_ids=sorted({x[0] for x in v}))

# ---- F6: IYIVAR placeholder literal in a skip regex (dns:213)
base = load("dns")[0]
control = check("dns", base)
seed = copy.deepcopy(base)
target = [s for s in seed["skips"] if s["line"] == 213]
old = target[0]["regex"]
new = r'skipped: this nsupdate does not know the HTTPS type \(IYIVAR\): it said "IYIVAR"'
target[0]["regex"] = new
changes = diff_paths(base, seed)
v = check("dns", seed)
emit("F6.dns213-iyivar-literal", control=[x[0] for x in control], applied=len(target), old=old, new=new,
     diff_paths=[c[0] for c in changes], violations=v, rule_ids=sorted({x[0] for x in v}))

# ---- F6b: same but placeholder in the pass sentinel regex
seed = copy.deepcopy(base)
old = seed["pass_sentinel"]["regex"]
seed["pass_sentinel"]["regex"] = "the std/IYIVAR exercise holds"
v = check("dns", seed)
emit("F6.dns-sentinel-iyivar-literal", control=[x[0] for x in control], old=old,
     violations=v, rule_ids=sorted({x[0] for x in v}))

# ---- F10: tool-dependent skips are class tool; reclassify each as platform
for driver, line in (("regex", 51), ("xz", 48), ("xz", 52), ("zstd", 43)):
    base = load(driver)[0]
    control = check(driver, base)
    entry = [s for s in base["skips"] if s["line"] == line][0]
    seed = copy.deepcopy(base)
    hit = [s for s in seed["skips"] if s["line"] == line]
    old_class = hit[0]["class"]
    hit[0]["class"] = "platform"
    changes = diff_paths(base, seed)
    v = check(driver, seed)
    emit(f"F10.{driver}{line}-class-platform", current_class=entry["class"], current_what=entry.get("what"),
         control=[x[0] for x in control], applied=len(hit), old_class=old_class, diff_paths=[c[0] for c in changes],
         violations=v, rule_ids=sorted({x[0] for x in v}))

# ---- F8: fixed-offset fi appended to fuzz exec_lines
base, script = load("fuzz")
lines = script.decode().splitlines()
control = check("fuzz", base)
evidence = base["exec_evidence"][0]
site_line = evidence["site_line"]
first_fi = next(n for n in range(site_line + 1, len(lines) + 1) if lines[n - 1].strip() == "fi")
seed = copy.deepcopy(base)
seed["exec_evidence"][0]["exec_lines"] = evidence["exec_lines"] + [first_fi]
changes = diff_paths(base, seed)
v = check("fuzz", seed)
emit("F8.fuzz-append-fi", control=[x[0] for x in control], site_line=site_line, first_fi=first_fi,
     fi_text=lines[first_fi - 1], exec_lines_before=evidence["exec_lines"],
     exec_lines_after=seed["exec_evidence"][0]["exec_lines"], diff_paths=[c[0] for c in changes],
     violations=v, rule_ids=sorted({x[0] for x in v}))

open(os.path.join(OUT, "fguards.jsonl"), "w").write("\n".join(REPORT) + "\n")
print("All F-guards executed successfully.")
