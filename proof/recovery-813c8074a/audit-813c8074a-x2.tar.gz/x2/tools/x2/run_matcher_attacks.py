"""Amendment E attacks on the real matcher (match_variants) and ledger OUT regex."""
import json
import os
import pathlib
import subprocess
import sys

RV = pathlib.Path("/private/tmp/iyi-proof-complete-813c8074a")
W = RV / "w"
sys.path.insert(0, str(W))

import proof.proofkit as proofkit_mod
import proof.roundtrip_shim as shim_mod

ROOT = os.path.join(RV, "evidence/fguards/matcher-attacks")
os.makedirs(ROOT, exist_ok=True)
REPO = os.path.realpath(W)
census = json.load(open(os.path.join(W, "proof", "census", "dns.json")))
PLATFORM = os.path.realpath(subprocess.run(["getconf", "DARWIN_USER_TEMP_DIR"], capture_output=True, text=True, check=True).stdout.strip())
t = os.path.realpath(os.path.join(ROOT, "R", "run3", "dns", "a2", "t"))
stale_t = os.path.realpath(os.path.join(ROOT, "R", "run3", "dns", "a1", "t"))
for d in (t, stale_t):
    os.makedirs(d, exist_ok=True)
own = os.path.join(REPO, "bench", "std_dns_exercise.iyi")
os.makedirs(os.path.join(ROOT, "elsewhere"), exist_ok=True)
if not os.path.lexists(os.path.join(t, "link-out")):
    os.symlink(os.path.join(ROOT, "elsewhere"), os.path.join(t, "link-out"))
if not os.path.lexists(os.path.join(t, "link-platform")):
    os.symlink(os.path.join(PLATFORM, "tmp.SYMLINKED"), os.path.join(t, "link-platform"))
if not os.path.lexists(os.path.join(ROOT, "t-alias")):
    os.symlink(t, os.path.join(ROOT, "t-alias"))


def match(root, out, sources=(own,)):
    status, ids, kind, bindings = shim_mod.match_variants(
        census, "build", root, list(sources), out, t, REPO, platform_tmp=PLATFORM
    )
    return status, ids, kind, bindings


cases = [
    ("control: t/<w>/noquestion", os.path.join(t, "tmp.A", "noquestion"), os.path.join(t, "tmp.A", "noquestion", "program"), "matched"),
    ("control: platform/<w>/noquestion", os.path.join(PLATFORM, "tmp.A", "noquestion"), os.path.join(PLATFORM, "tmp.A", "noquestion", "program"), "matched"),
    ("outside both roots", str(RV / "x/noquestion"), str(RV / "x/noquestion/program"), "unclassified"),
    ("nested two below t", os.path.join(t, "tmp.A", "deeper", "noquestion"), os.path.join(t, "tmp.A", "deeper", "noquestion", "program"), "unclassified"),
    ("nested two below platform", os.path.join(PLATFORM, "tmp.A", "deeper", "noquestion"), os.path.join(PLATFORM, "tmp.A", "deeper", "noquestion", "program"), "unclassified"),
    ("t itself as WORK (one component)", os.path.join(t, "noquestion"), os.path.join(t, "noquestion", "program"), "unclassified"),
    ("stale attempt a1/t", os.path.join(stale_t, "tmp.A", "noquestion"), os.path.join(stale_t, "tmp.A", "noquestion", "program"), "unclassified"),
    ("platform prefix sibling", PLATFORM + "X/tmp.A/noquestion", PLATFORM + "X/tmp.A/noquestion/program", "unclassified"),
    ("symlink in t to outside", os.path.join(t, "link-out", "noquestion"), os.path.join(t, "link-out", "noquestion", "program"), "unclassified"),
    ("symlink in t to platform child", os.path.join(t, "link-platform", "noquestion"), os.path.join(t, "link-platform", "noquestion", "program"), "matched"),
    ("t reached via symlinked alias", os.path.join(ROOT, "t-alias", "tmp.A", "noquestion"), os.path.join(ROOT, "t-alias", "tmp.A", "noquestion", "program"), "matched"),
    ("WORK differs between root and output", os.path.join(t, "tmp.A", "noquestion"), os.path.join(t, "tmp.B", "noquestion", "program"), "unclassified"),
    ("WORK differs root(t) vs output(platform)", os.path.join(t, "tmp.A", "noquestion"), os.path.join(PLATFORM, "tmp.A", "noquestion", "program"), "unclassified"),
    ("undeclared dir value", os.path.join(t, "tmp.A", "notadir"), os.path.join(t, "tmp.A", "notadir", "program"), "unclassified"),
    ("copied exercise as source", os.path.join(t, "tmp.A", "noquestion"), os.path.join(t, "tmp.A", "noquestion", "program"), "unclassified"),
]

results = []
for label, root, out, expected_status in cases:
    sources = (own,)
    if label == "copied exercise as source":
        sources = ("/private/tmp/x/std_dns_exercise.iyi",)
    status, ids, kind, bindings = match(root, out, sources)
    ok = (status == expected_status)
    item = {
        "case": label, "status": status, "expected_status": expected_status, "ids": ids, "kind": kind,
        "bindings": bindings, "root_realpath": os.path.realpath(root), "pass": ok
    }
    results.append(item)
    print(json.dumps(item))

# verify_ledger E2 OUT regex
e2_results = []
pattern = proofkit_mod._ledger_out_regex("{WORK}/{name}", work_tmp=t, repo=REPO, name="dns-plain", platform_tmp=PLATFORM)
for label, out, expected_match in (
    ("e2 control t", os.path.join(t, "tmp.A", "dns-plain"), True),
    ("e2 control platform", os.path.join(PLATFORM, "tmp.A", "dns-plain"), True),
    ("e2 nested", os.path.join(t, "tmp.A", "x", "dns-plain"), False),
    ("e2 outside", "/private/tmp/q/dns-plain", False),
    ("e2 stale attempt", os.path.join(stale_t, "tmp.A", "dns-plain"), False)
):
    matched = bool(pattern.fullmatch(os.path.realpath(out)))
    ok = (matched == expected_match)
    e2_item = {"case": label, "fullmatch": matched, "expected": expected_match, "pass": ok}
    e2_results.append(e2_item)
    print(json.dumps(e2_item))

out_data = {
    "matcher_cases": results,
    "e2_regex_cases": e2_results,
    "all_pass": all(r["pass"] for r in results) and all(r["pass"] for r in e2_results)
}
out_path = os.path.join(RV, "evidence/fguards/matcher_attacks.json")
with open(out_path, "w") as f:
    json.dump(out_data, f, indent=2)

assert out_data["all_pass"], "Some matcher attacks or E2 regex checks failed"
print("All matcher attacks and E2 checks PASS, saved to", out_path)
