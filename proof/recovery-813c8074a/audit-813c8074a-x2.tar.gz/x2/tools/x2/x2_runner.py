#!/usr/bin/env python3
"""Runner for Unit X2 re-audit at H'.
Executes in table order:
1. O3 x2
2. Plan + isolation
3. Layout (G1d: three runs + delta_shape.py)
4. Refusals x4
5. Registration
6. Manual seeds 1-4 + gate
7. F guards (incl. touch_unread)
8. Matrix 70 + 17 values
At the end: porcelain checks of RV3/w and RV3/ev/w, then cleanup.
"""
import ast
import glob
import hashlib
import json
import os
import shutil
import subprocess
import sys

PY = "/Users/jwaldrip/.cache/iyi-corpus-venv/bin/python3"
RV3 = "/private/tmp/iyi-proof-complete-813c8074a"
W_RV = os.path.join(RV3, "w")
W_EV = os.path.join(RV3, "ev/w")
RECEIPT = os.path.join(RV3, "receipt.py")
TOOLS_X2 = os.path.join(RV3, "tools/x2")
PYC_BASE = os.path.join(RV3, "pyc")

W3 = "/Users/jwaldrip/dev/worktrees/iyi-audit-repair-g02-g18-20261031"
W2 = "/Users/jwaldrip/dev/worktrees/iyi-audit-deadlines-seams-20261030"
P = "/Users/jwaldrip/dev/worktrees/iyi-stale-integration-repair"
E30 = "/Users/jwaldrip/dev/worktrees/iyi-stale-recovery-evidence-20261030/proof/recovery-20261030"

H = "6bbe1bf2e484bc4ec33aa6d58667c43c096cd3bd"
H_PRIME = "813c8074acb2eed99ffeef78ea49e8c7832e4c01"
BASE = "451420109dfb0bbcdf800e0143c30768c73e3e0b"
P1 = "626463375298d357ffcb3223059f4d3adce6fb10"
BIN_SHA_M2 = "b8afdb5f55b03754b8194978e320cbca3c0816661cadcbd3083f0872a64ca418"


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def run_receipt(job_dir, cwd, *cmd, env_kv=None):
    os.makedirs(os.path.dirname(os.path.abspath(job_dir)), exist_ok=True)
    argv = [PY, "-B", RECEIPT, job_dir, cwd]
    if env_kv:
        argv.extend(env_kv)
    argv.append("--")
    argv.extend(cmd)
    print(f"--> [RECEIPT] job_dir={job_dir} cwd={cwd}")
    print(f"    cmd={' '.join(cmd)}")
    res = subprocess.run(argv)
    if not os.path.exists(os.path.join(job_dir, "end.json")):
        raise RuntimeError(f"receipt did not create end.json in {job_dir}")
    end = json.load(open(os.path.join(job_dir, "end.json")))
    stdout_file = os.path.join(job_dir, "stdout.log")
    stderr_file = os.path.join(job_dir, "stderr.log")
    stdout = open(stdout_file, "r", errors="replace").read() if os.path.exists(stdout_file) else ""
    stderr = open(stderr_file, "r", errors="replace").read() if os.path.exists(stderr_file) else ""
    return end["rc"], stdout, stderr, end


def git_porcelain(repo_dir):
    return subprocess.check_output(
        ["git", "-C", repo_dir, "status", "--porcelain=v1", "--untracked-files=all", "--ignored"],
        text=True,
        env=dict(os.environ, GIT_OPTIONAL_LOCKS="0"),
    ).strip()


def git_ignored_list(repo_dir):
    out = subprocess.check_output(
        ["git", "-C", repo_dir, "ls-files", "--others", "--ignored", "--exclude-standard"],
        text=True,
        env=dict(os.environ, GIT_OPTIONAL_LOCKS="0"),
    ).strip()
    return out.splitlines() if out else []


def capture_isolation(clone_dir):
    p_porcelain = subprocess.check_output(
        ["git", "-C", P, "status", "--porcelain=v1", "--untracked-files=all"],
        text=True, env=dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    ).strip()
    p_ignored = git_ignored_list(P)
    p_ignored_sha = hashlib.sha256("\n".join(p_ignored).encode() + (b"\n" if p_ignored else b"")).hexdigest()

    w3_porcelain = subprocess.check_output(
        ["git", "-C", W3, "status", "--porcelain=v1", "--untracked-files=all"],
        text=True, env=dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    ).strip()
    w3_ignored = git_ignored_list(W3)
    w3_ignored_sha = hashlib.sha256("\n".join(w3_ignored).encode() + (b"\n" if w3_ignored else b"")).hexdigest()

    w2_porcelain = subprocess.check_output(
        ["git", "-C", W2, "status", "--porcelain=v1", "--untracked-files=all"],
        text=True, env=dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    ).strip()
    w2_ignored = git_ignored_list(W2)
    w2_ignored_sha = hashlib.sha256("\n".join(w2_ignored).encode() + (b"\n" if w2_ignored else b"")).hexdigest()

    clone_porcelain = subprocess.check_output(
        ["git", "-C", clone_dir, "status", "--porcelain=v1", "--untracked-files=all"],
        text=True, env=dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    ).strip()
    clone_ignored = git_ignored_list(clone_dir)
    clone_ignored_sha = hashlib.sha256("\n".join(clone_ignored).encode() + (b"\n" if clone_ignored else b"")).hexdigest()

    iyp_roots = sorted(os.path.basename(p) for p in glob.glob("/private/tmp/iyp-*"))

    return {
        "P": {
            "porcelain": p_porcelain,
            "ignored": {
                "count": len(p_ignored),
                "sha256": p_ignored_sha,
                "lines": p_ignored,
            },
        },
        "W3": {
            "porcelain": w3_porcelain,
            "ignored": {
                "count": len(w3_ignored),
                "sha256": w3_ignored_sha,
                "lines": w3_ignored,
            },
        },
        "W2": {
            "porcelain": w2_porcelain,
            "ignored": {
                "count": len(w2_ignored),
                "sha256": w2_ignored_sha,
                "lines": w2_ignored,
            },
        },
        "clone": {
            "porcelain": clone_porcelain,
            "ignored": {
                "count": len(clone_ignored),
                "sha256": clone_ignored_sha,
                "lines": clone_ignored,
            },
        },
        "iyp_roots": iyp_roots,
    }


def step_1_o3():
    print("\n=== STEP 1: O3 x2 ===")
    rv_out_dir = os.path.join(RV3, "evidence/o3")
    ev_out_dir = os.path.join(RV3, "ev/o3")
    assert not os.path.exists(rv_out_dir), f"{rv_out_dir} must be absent"
    assert not os.path.exists(ev_out_dir), f"{ev_out_dir} must be absent"

    # 1.1 RV O3
    job_rv = os.path.join(rv_out_dir, "job")
    pyc_rv = os.path.join(PYC_BASE, "x2-o3")
    rc_rv, stdout_rv, stderr_rv, end_rv = run_receipt(
        job_rv, W_RV,
        PY, "-B", f"-Xpycache_prefix={pyc_rv}",
        "-c", "from proof.smoke_test import run_o3_suite; raise SystemExit(run_o3_suite())"
    )
    if rc_rv != 0:
        raise RuntimeError(f"RV O3 failed with rc={rc_rv}")
    assert "TOTAL seeds_executed=23 seeds_passed=23 seeds_missed=0 seeds_missing=0 controls_executed=6 controls_failed=0 controls_missing=0" in stdout_rv
    assert "HARNESS PASS" in stdout_rv
    assert f"HEADER head={H_PRIME}" in stdout_rv
    assert "HEADER clean=true" in stdout_rv

    rv_log = os.path.join(rv_out_dir, "o3.log")
    shutil.copyfile(os.path.join(job_rv, "stdout.log"), rv_log)
    rv_json = {
        "rc": rc_rv,
        "expected": 0,
        "seeds_executed": 23,
        "seeds_passed": 23,
        "controls_executed": 6,
        "controls_failed": 0,
        "pass": True,
    }
    with open(os.path.join(rv_out_dir, "o3.json"), "w") as f:
        json.dump(rv_json, f, indent=2)

    # 1.2 EV O3
    job_ev = os.path.join(ev_out_dir, "job")
    rc_ev, stdout_ev, stderr_ev, end_ev = run_receipt(
        job_ev, W_EV,
        PY, "-B",
        "-c", "from proof.smoke_test import run_o3_suite; raise SystemExit(run_o3_suite())"
    )
    if rc_ev != 0:
        raise RuntimeError(f"EV O3 failed with rc={rc_ev}")
    assert "TOTAL seeds_executed=23 seeds_passed=23 seeds_missed=0 seeds_missing=0 controls_executed=6 controls_failed=0 controls_missing=0" in stdout_ev
    assert "HARNESS PASS" in stdout_ev
    assert f"HEADER head={H_PRIME}" in stdout_ev
    assert "HEADER clean=true" in stdout_ev

    ev_log = os.path.join(ev_out_dir, "o3.log")
    shutil.copyfile(os.path.join(job_ev, "stdout.log"), ev_log)
    ev_json = {
        "argv": [
            PY,
            "-B",
            "-c",
            "from proof.smoke_test import run_o3_suite; raise SystemExit(run_o3_suite())",
        ],
        "rc": rc_ev,
        "expected": 0,
        "pass": True,
    }
    with open(os.path.join(ev_out_dir, "o3.json"), "w") as f:
        json.dump(ev_json, f, indent=2)

    sha_rv_log = sha256_file(rv_log)
    sha_ev_log = sha256_file(ev_log)
    print(f"O3 logs sha256: RV={sha_rv_log}, EV={sha_ev_log}")
    assert sha_rv_log == sha_ev_log, f"O3 logs differ: RV={sha_rv_log} != EV={sha_ev_log}"
    sha_h = "7a245f6af82e69fc478670ddbc3d1ad4d0b15bb1dbe884aa567989f6346d37d8"
    print(f"O3 H equality check: H sha was {sha_h}. H' sha is {sha_rv_log} (differs by HEADER head={H_PRIME})")
    print("STEP 1: O3 x2 PASS")


def step_2_plan():
    print("\n=== STEP 2: Plan + isolation ===")
    rv_out_dir = os.path.join(RV3, "evidence/plan")
    ev_out_dir = os.path.join(RV3, "ev/plan")
    assert not os.path.exists(rv_out_dir), f"{rv_out_dir} must be absent"
    assert not os.path.exists(ev_out_dir), f"{ev_out_dir} must be absent"

    compiler = os.path.join(P, ".build/iyi")

    # 2.1 RV Plan
    before_rv = capture_isolation(W_RV)
    job_rv = os.path.join(rv_out_dir, "job")
    rv_cmd = [
        PY, "-B", os.path.join(W_RV, "proof/run_proof.py"), "plan",
        "--p", P, "--w", W_RV, "--compiler", compiler
    ]
    rc_rv, stdout_rv, stderr_rv, end_rv = run_receipt(job_rv, W_RV, *rv_cmd)
    after_rv = capture_isolation(W_RV)

    if rc_rv != 0:
        raise RuntimeError(f"RV Plan failed with rc={rc_rv}")
    lines_rv = stdout_rv.strip().splitlines()
    assert len(lines_rv) == 12, f"RV Plan expected 12 lines, got {len(lines_rv)}"
    assert f"W HEAD:    {H_PRIME}" in stdout_rv
    assert f"P SHA:     {P1}" in stdout_rv
    assert f"BIN SHA:   {BIN_SHA_M2}" in stdout_rv
    assert lines_rv[10].strip().startswith("Probe:"), f"Line 11 is not Probe: {lines_rv[10]}"
    assert lines_rv[11].strip() == "Censuses:  29 validated", f"Line 12 mismatch: {lines_rv[11]}"
    assert before_rv == after_rv, f"Isolation violated in RV Plan: {before_rv} != {after_rv}"

    rv_log = os.path.join(rv_out_dir, "plan.log")
    shutil.copyfile(os.path.join(job_rv, "stdout.log"), rv_log)
    rv_json = {
        "cmd": rv_cmd,
        "rc": rc_rv,
        "stdout": stdout_rv,
        "before": before_rv,
        "after": after_rv,
        "isolated": True,
    }
    with open(os.path.join(rv_out_dir, "plan.json"), "w") as f:
        json.dump(rv_json, f, indent=2)

    # 2.2 EV Plan
    before_ev = capture_isolation(W_EV)
    job_ev = os.path.join(ev_out_dir, "job")
    ev_cmd = [
        PY, "-B", "proof/run_proof.py", "plan",
        "--p", P, "--w", W_EV, "--compiler", compiler
    ]
    rc_ev, stdout_ev, stderr_ev, end_ev = run_receipt(job_ev, W_EV, *ev_cmd)
    after_ev = capture_isolation(W_EV)

    if rc_ev != 0:
        raise RuntimeError(f"EV Plan failed with rc={rc_ev}")
    lines_ev = stdout_ev.strip().splitlines()
    assert len(lines_ev) == 12, f"EV Plan expected 12 lines, got {len(lines_ev)}"
    assert f"W HEAD:    {H_PRIME}" in stdout_ev
    assert f"P SHA:     {P1}" in stdout_ev
    assert f"BIN SHA:   {BIN_SHA_M2}" in stdout_ev
    assert lines_ev[10].strip().startswith("Probe:"), f"Line 11 is not Probe: {lines_ev[10]}"
    assert lines_ev[11].strip() == "Censuses:  29 validated", f"Line 12 mismatch: {lines_ev[11]}"
    assert before_ev == after_ev, f"Isolation violated in EV Plan: {before_ev} != {after_ev}"

    ev_log = os.path.join(ev_out_dir, "plan.log")
    shutil.copyfile(os.path.join(job_ev, "stdout.log"), ev_log)
    ev_json = {
        "argv": ev_cmd,
        "rc": rc_ev,
        "expected": 0,
        "pass": True,
    }
    with open(os.path.join(ev_out_dir, "plan.json"), "w") as f:
        json.dump(ev_json, f, indent=2)

    ev_isolation_json = {
        "before": before_ev,
        "after": after_ev,
        "unchanged": True,
        "result": ev_json,
    }
    with open(os.path.join(ev_out_dir, "plan-isolation.json"), "w") as f:
        json.dump(ev_isolation_json, f, indent=2)

    print("STEP 2: Plan + isolation PASS")


def step_3_layout():
    print("\n=== STEP 3: Layout (G1d: three runs + delta_shape.py) ===")
    out_dir = os.path.join(RV3, "evidence/layout")
    assert not os.path.exists(out_dir), f"{out_dir} must be absent"

    checker_script = os.path.join(TOOLS_X2, "artifact_legs_layout_check.py")
    delta_shape_script = os.path.join(TOOLS_X2, "delta_shape.py")

    # 3.1 Self-test
    job_selftest = os.path.join(out_dir, "job-selftest")
    rc_st, stdout_st, stderr_st, end_st = run_receipt(
        job_selftest, RV3,
        PY, "-B", "-I", checker_script, "--self-test", W3, BASE
    )
    if rc_st != 0:
        raise RuntimeError(f"Layout self-test failed with rc={rc_st}")
    st_log = os.path.join(out_dir, "selftest.log")
    shutil.copyfile(os.path.join(job_selftest, "stdout.log"), st_log)

    # Compare with H selftest.log
    h_st_log = subprocess.check_output(
        ["tar", "-xOzf", os.path.join(E30, "audit-6bbe1bf2e-reported-go-retained.tar.gz"), "evidence/layout/selftest.log"]
    ).decode("utf-8")
    assert stdout_st == h_st_log, "selftest.log is not byte-equal to H"
    print("3.1: selftest.log byte-equal to H PASS")

    # 3.2 Layout check H
    job_check_h = os.path.join(out_dir, "job-check-h")
    rc_h, stdout_h, stderr_h, end_h = run_receipt(
        job_check_h, RV3,
        PY, "-B", "-I", checker_script, W3, BASE, H
    )
    if rc_h != 0:
        raise RuntimeError(f"Layout check H failed with rc={rc_h}")
    check_h_log = os.path.join(out_dir, "layout-check.log")
    shutil.copyfile(os.path.join(job_check_h, "stdout.log"), check_h_log)

    # Compare with H layout-check.log
    h_lc_log = subprocess.check_output(
        ["tar", "-xOzf", os.path.join(E30, "audit-6bbe1bf2e-reported-go-retained.tar.gz"), "evidence/layout/layout-check.log"]
    ).decode("utf-8")
    assert stdout_h == h_lc_log, "layout-check.log on H is not byte-equal to H"
    print("3.2: layout-check.log (BASE, H) byte-equal to H PASS")

    # 3.3 Layout check H'
    job_check_hp = os.path.join(out_dir, "job-check-hprime")
    rc_hp, stdout_hp, stderr_hp, end_hp = run_receipt(
        job_check_hp, RV3,
        PY, "-B", "-I", checker_script, W3, BASE, H_PRIME
    )
    # Expected rc == 1
    assert rc_hp == 1, f"Expected rc=1 for layout check on H', got rc={rc_hp}"
    check_hp_log = os.path.join(out_dir, "layout-check-hprime.log")
    shutil.copyfile(os.path.join(job_check_hp, "stdout.log"), check_hp_log)

    assert "CHECK C1 PASS" in stdout_hp
    assert "CHECK C2 PASS" in stdout_hp
    assert "CHECK C3 PASS" in stdout_hp
    assert "CHECK C4 FAIL 'smoke_test AST differs from BASE outside the ALLOWLIST value'" in stdout_hp
    assert "CHECK C5 FAIL ['run_proof']" in stdout_hp
    assert f"LAYOUT CHECK FAIL base={BASE} candidate={H_PRIME}" in stdout_hp
    print("3.3: layout-check (BASE, H') shows C1-C3 PASS, C4 FAIL, C5 FAIL ['run_proof'], rc=1 as predicted PASS")

    # 3.4 delta_shape.py
    job_delta = os.path.join(out_dir, "job-delta-shape")
    rc_delta, stdout_delta, stderr_delta, end_delta = run_receipt(
        job_delta, RV3,
        PY, "-B", delta_shape_script
    )
    if rc_delta != 0:
        raise RuntimeError(f"delta_shape failed with rc={rc_delta}")
    delta_shape_json = os.path.join(out_dir, "delta_shape.json")
    assert os.path.exists(delta_shape_json), f"{delta_shape_json} not created"
    ds = json.load(open(delta_shape_json))
    assert ds.get("status") == "PASS", f"delta_shape status is not PASS: {ds}"
    print("3.4: delta_shape.json PASS")
    print("STEP 3: Layout PASS")


def step_4_refusals():
    print("\n=== STEP 4: Refusals x4 ===")
    rv_out_dir = os.path.join(RV3, "evidence/refusals")
    ev_out_dir = os.path.join(RV3, "ev/refusals")
    assert not os.path.exists(rv_out_dir), f"{rv_out_dir} must be absent"
    assert not os.path.exists(ev_out_dir), f"{ev_out_dir} must be absent"

    expected_line = "smoke_test.py refuses optimized Python: sys.flags.optimize=1\n"

    # 4.1 RV -O
    job_rv_flag = os.path.join(rv_out_dir, "job-flag")
    rc_rf, stdout_rf, stderr_rf, _ = run_receipt(
        job_rv_flag, W_RV,
        PY, "-B", "-O", "proof/smoke_test.py"
    )
    assert rc_rf == 2, f"Expected rc=2, got {rc_rf}"
    assert stderr_rf == expected_line, f"Unexpected stderr: {stderr_rf!r}"
    shutil.copyfile(os.path.join(job_rv_flag, "stderr.log"), os.path.join(rv_out_dir, "optimized-flag.log"))
    with open(os.path.join(rv_out_dir, "optimized-flag.json"), "w") as f:
        json.dump({"argv": [PY, "-B", "-O", "proof/smoke_test.py"], "rc": 2, "expected": 2, "pass": True}, f, indent=2)

    # 4.2 RV PYTHONOPTIMIZE=1
    job_rv_env = os.path.join(rv_out_dir, "job-env")
    rc_re, stdout_re, stderr_re, _ = run_receipt(
        job_rv_env, W_RV,
        PY, "-B", "proof/smoke_test.py",
        env_kv=["PYTHONOPTIMIZE=1"]
    )
    assert rc_re == 2, f"Expected rc=2, got {rc_re}"
    assert stderr_re == expected_line, f"Unexpected stderr: {stderr_re!r}"
    shutil.copyfile(os.path.join(job_rv_env, "stderr.log"), os.path.join(rv_out_dir, "optimized-env.log"))
    with open(os.path.join(rv_out_dir, "optimized-env.json"), "w") as f:
        json.dump({"argv": [PY, "-B", "proof/smoke_test.py"], "rc": 2, "expected": 2, "pass": True}, f, indent=2)

    # 4.3 EV -O
    job_ev_flag = os.path.join(ev_out_dir, "job-flag")
    rc_ef, stdout_ef, stderr_ef, _ = run_receipt(
        job_ev_flag, W_EV,
        PY, "-B", "-O", "proof/smoke_test.py"
    )
    assert rc_ef == 2, f"Expected rc=2, got {rc_ef}"
    assert stderr_ef == expected_line, f"Unexpected stderr: {stderr_ef!r}"
    shutil.copyfile(os.path.join(job_ev_flag, "stderr.log"), os.path.join(ev_out_dir, "optimized-flag.log"))
    with open(os.path.join(ev_out_dir, "optimized-flag.json"), "w") as f:
        json.dump({"argv": [PY, "-B", "-O", "proof/smoke_test.py"], "rc": 2, "expected": 2, "pass": True}, f, indent=2)

    # 4.4 EV PYTHONOPTIMIZE=1
    job_ev_env = os.path.join(ev_out_dir, "job-env")
    rc_ee, stdout_ee, stderr_ee, _ = run_receipt(
        job_ev_env, W_EV,
        PY, "-B", "proof/smoke_test.py",
        env_kv=["PYTHONOPTIMIZE=1"]
    )
    assert rc_ee == 2, f"Expected rc=2, got {rc_ee}"
    assert stderr_ee == expected_line, f"Unexpected stderr: {stderr_ee!r}"
    shutil.copyfile(os.path.join(job_ev_env, "stderr.log"), os.path.join(ev_out_dir, "optimized-env.log"))
    with open(os.path.join(ev_out_dir, "optimized-env.json"), "w") as f:
        json.dump({"argv": [PY, "-B", "proof/smoke_test.py"], "rc": 2, "expected": 2, "pass": True}, f, indent=2)

    print("STEP 4: Refusals x4 PASS")


def step_5_registration():
    print("\n=== STEP 5: Registration (G8) ===")
    out_dir = os.path.join(RV3, "evidence/registration")
    run_dir = os.path.join(out_dir, "run")
    assert not os.path.exists(out_dir), f"{out_dir} must be absent"

    reg_script = os.path.join(TOOLS_X2, "registration-interval-proof.py")
    source_path = os.path.join(W_RV, "proof/proofkit.py")

    job = os.path.join(out_dir, "job")
    rc, stdout, stderr, _ = run_receipt(
        job, RV3,
        PY, "-B", reg_script, "--source", source_path, "--output", run_dir
    )
    if rc != 0:
        raise RuntimeError(f"registration-interval-proof failed with rc={rc}")

    # Check 17 files in run_dir
    files = sorted(os.listdir(run_dir))
    assert len(files) == 17, f"Expected 17 files in {run_dir}, got {len(files)}: {files}"

    fixed_py = os.path.join(run_dir, "proofkit-fixed.py")
    mutant_py = os.path.join(run_dir, "proofkit-mutant.py")
    sha_fixed = sha256_file(fixed_py)
    sha_mutant = sha256_file(mutant_py)
    assert sha_fixed.startswith("25aac5d0"), f"Fixed sha256 mismatch: {sha_fixed}"
    assert sha_mutant.startswith("c7ad3de0"), f"Mutant sha256 mismatch: {sha_mutant}"

    fixed_obs = json.load(open(os.path.join(run_dir, "fixed-observation.json")))
    assert fixed_obs["escaped"] is None
    assert fixed_obs["result"]["interrupted_signal"] == 2
    assert fixed_obs["result"]["survivors"] == []

    mutant_obs = json.load(open(os.path.join(run_dir, "mutant-observation.json")))
    assert mutant_obs["escaped"] == {"type": "_BoundedSignal", "signum": 2}

    mutation_json = json.load(open(os.path.join(run_dir, "mutation.json")))
    assert mutation_json["anchor_matches"] == 1

    print(f"Registration verified: 17 files, fixed={sha_fixed[:16]}..., mutant={sha_mutant[:16]}..., anchor_matches=1")
    print("STEP 5: Registration PASS")


def step_6_manual_seeds():
    print("\n=== STEP 6: Manual seeds 1-4 + gate (G4) ===")
    out_dir = os.path.join(RV3, "evidence/manual_seeds")
    assert not os.path.exists(out_dir), f"{out_dir} must be absent"

    runner_script = os.path.join(TOOLS_X2, "run_manual_seeds.py")
    job = os.path.join(out_dir, "job")
    pyc_dir = os.path.join(PYC_BASE, "x2-manual-seeds")

    rc, stdout, stderr, _ = run_receipt(
        job, RV3,
        PY, "-B", f"-Xpycache_prefix={pyc_dir}", runner_script
    )
    if rc != 0:
        raise RuntimeError(f"run_manual_seeds failed with rc={rc}")

    seeds_jsonl_path = os.path.join(out_dir, "seeds.jsonl")
    assert os.path.exists(seeds_jsonl_path), f"{seeds_jsonl_path} not found"
    lines = [json.loads(line) for line in open(seeds_jsonl_path).read().splitlines() if line.strip()]
    assert len(lines) >= 8, f"Expected at least 8 lines, got {len(lines)}"

    # Line 1: forged-pass.control
    assert lines[0]["seed"] == "forged-pass.control"
    assert lines[0]["final_rc"] == 0 and lines[0]["final_status"] == "PASS"

    # Line 2: stale-nonce.verify
    assert lines[1]["seed"] == "stale-nonce.verify"
    assert "STALE" in lines[1]["seed_statuses"]

    # Line 3: stale-nonce.shim
    assert lines[2]["seed"] == "stale-nonce.shim"
    assert lines[2]["rc"] == 125 and lines[2]["unchanged"] is True

    # Line 4: stale-nonce.shim-control
    assert lines[3]["seed"] == "stale-nonce.shim-control"
    assert lines[3]["rc"] == 0 and lines[3]["unchanged"] is False

    # Line 5: forged-pass.seed
    assert lines[4]["seed"] == "forged-pass.seed"
    assert lines[4]["final_rc"] == 1 and lines[4]["final_status"] == "FAIL"

    # Line 6: dollar-dir.template
    assert lines[5]["seed"] == "dollar-dir.template"
    assert "C5.7-template" in lines[5]["rule_ids"]
    assert any("292" in str(v) for v in lines[5]["violations"])

    # Line 7: fixed-offset-fi
    assert lines[6]["seed"] == "fixed-offset-fi"
    assert "E1-exec-token" in lines[6]["rule_ids"]
    assert any("73" in str(v) for v in lines[6]["violations"])

    # Line 8: stage-bound.run1-gate
    assert lines[7]["seed"] == "stage-bound.run1-gate"
    assert lines[7]["rc"] == 0 and lines[7]["status"] == "PASS" and lines[7]["gate"] == "PASS"

    # Times check for seed5-run1_1.times
    times_file = os.path.join(out_dir, "seed5-run1_1.times")
    assert os.path.exists(times_file), f"{times_file} not found"
    time_lines = [l.strip().split() for l in open(times_file).read().splitlines() if l.strip()]
    t0 = int(time_lines[0][0])
    tf = int(time_lines[-1][0])
    diff_ns = tf - t0
    assert diff_ns > 100_000_000, f"t0 and tf must be > 1e8 ns apart, got {diff_ns} ns"

    print(f"Manual seeds 1-8 semantically verified. seed5-run1_1.times diff={diff_ns} ns (> 1e8 ns)")
    print("STEP 6: Manual seeds PASS")


def step_7_fguards():
    print("\n=== STEP 7: F guards (G5) ===")
    out_dir = os.path.join(RV3, "evidence/fguards")
    pyc_dir = os.path.join(PYC_BASE, "x2-fguards")

    # 7.1 run_fguards.py
    job_fg = os.path.join(out_dir, "job-fguards")
    if not os.path.exists(job_fg):
        rc_fg, _, _, _ = run_receipt(
            job_fg, RV3,
            PY, "-B", f"-Xpycache_prefix={pyc_dir}", os.path.join(TOOLS_X2, "run_fguards.py")
        )
        if rc_fg != 0:
            raise RuntimeError(f"run_fguards failed with rc={rc_fg}")
    fg_jsonl = os.path.join(out_dir, "fguards.jsonl")
    assert os.path.exists(fg_jsonl)
    fg_rows = [json.loads(l) for l in open(fg_jsonl).read().splitlines() if l.strip()]
    assert len(fg_rows) == 8, f"Expected 8 fguard rows, got {len(fg_rows)}"

    # 7.2 run_demo_final_required.py
    job_df = os.path.join(out_dir, "job-demo-final")
    if not os.path.exists(job_df):
        rc_df, _, _, _ = run_receipt(
            job_df, RV3,
            PY, "-B", f"-Xpycache_prefix={pyc_dir}", os.path.join(TOOLS_X2, "run_demo_final_required.py")
        )
        if rc_df != 0:
            raise RuntimeError(f"run_demo_final_required failed with rc={rc_df}")
    df_json = os.path.join(out_dir, "demo_final_required.json")
    assert os.path.exists(df_json)
    df_data = json.load(open(df_json))
    assert df_data["final_rc"] == 1
    assert df_data["final_status"] == "FAIL"
    assert len(df_data["final_reasons"]) >= 4

    # 7.3 run_demo_misclassified.py
    job_dm = os.path.join(out_dir, "job-demo-misclassified")
    if not os.path.exists(job_dm):
        rc_dm, _, _, _ = run_receipt(
            job_dm, RV3,
            PY, "-B", f"-Xpycache_prefix={pyc_dir}", os.path.join(TOOLS_X2, "run_demo_misclassified.py")
        )
        if rc_dm != 0:
            raise RuntimeError(f"run_demo_misclassified failed with rc={rc_dm}")
    dm_json = os.path.join(out_dir, "demo_misclassified.json")
    assert os.path.exists(dm_json)
    dm_data = json.load(open(dm_json))
    f2_guard = dm_data["f2_guard"]
    assert f2_guard["unchanged_noncanonical_misclassified"] is False
    assert f2_guard["passthrough_noncanonical_misclassified"] is True
    assert f2_guard["passthrough_canonical_misclassified"] is False
    # 7.4 run_matcher_attacks.py
    job_ma = os.path.join(out_dir, "job-matcher-attacks")
    rc_ma, _, _, _ = run_receipt(
        job_ma, RV3,
        PY, "-B", f"-Xpycache_prefix={pyc_dir}", os.path.join(TOOLS_X2, "run_matcher_attacks.py")
    )
    if rc_ma != 0:
        raise RuntimeError(f"run_matcher_attacks failed with rc={rc_ma}")
    ma_json = os.path.join(out_dir, "matcher_attacks.json")
    assert os.path.exists(ma_json)
    ma_data = json.load(open(ma_json))
    assert ma_data["all_pass"] is True
    assert len(ma_data["matcher_cases"]) == 15
    assert len(ma_data["e2_regex_cases"]) == 5

    # 7.5 a_touch_unread.py
    job_tu = os.path.join(out_dir, "job-touch-unread")
    rc_tu, stdout_tu, stderr_tu, _ = run_receipt(
        job_tu, W_RV,
        PY, "-B", os.path.join(TOOLS_X2, "a_touch_unread.py")
    )
    if rc_tu != 0:
        raise RuntimeError(f"a_touch_unread failed with rc={rc_tu}")
    assert "VERDICT PASS" in stdout_tu
    # Parse json part
    json_line = [l for l in stdout_tu.splitlines() if l.startswith("{")][0]
    # Actually stdout_tu has pretty-printed json: find { to }
    json_start = stdout_tu.find("{")
    json_end = stdout_tu.rfind("}") + 1
    tu_parsed = json.loads(stdout_tu[json_start:json_end])
    assert tu_parsed["results"]["control-no-skip-line"] == ["PASS", []]
    assert tu_parsed["results"]["seed-skip-not-in-baseline"] == ["ENV-BLOCKED", ["tool skip file: tool"]]
    assert tu_parsed["results"]["seed-skip-in-baseline-not-waived"] == ["ENV-BLOCKED", ["tool skip file: tool"]]
    three_results = {
        k: tu_parsed["results"][k]
        for k in [
            "control-no-skip-line",
            "seed-skip-not-in-baseline",
            "seed-skip-in-baseline-not-waived",
        ]
    }
    tu_doc = {
        "skip_entry": tu_parsed["skip_entry"],
        "results": three_results,
        "verdict": "PASS",
    }
    tu_json_path = os.path.join(out_dir, "touch_unread.json")
    with open(tu_json_path, "w") as f:
        json.dump(tu_doc, f, indent=2)

    print("STEP 7: F guards PASS")


def step_8_matrix():
    print("\n=== STEP 8: Matrix 70 + 17 values (G6) ===")
    out_dir = os.path.join(RV3, "evidence/matrix")
    assert not os.path.exists(out_dir), f"{out_dir} must be absent"

    pyc_dir = os.path.join(PYC_BASE, "x2-matrix")

    # 8.1 run_ledger_matrix.py
    job_lm = os.path.join(out_dir, "job-ledger-matrix")
    rc_lm, stdout_lm, stderr_lm, _ = run_receipt(
        job_lm, RV3,
        PY, "-B", f"-Xpycache_prefix={pyc_dir}", os.path.join(TOOLS_X2, "run_ledger_matrix.py")
    )
    if rc_lm != 0:
        raise RuntimeError(f"run_ledger_matrix failed with rc={rc_lm}")
    res_jsonl = os.path.join(out_dir, "matrix_results.jsonl")
    assert os.path.exists(res_jsonl)
    rows_lm = [json.loads(l) for l in open(res_jsonl).read().splitlines() if l.strip()]
    assert len(rows_lm) == 70, f"Expected 70 matrix rows, got {len(rows_lm)}"
    fails_lm = [r["case"] for r in rows_lm if r.get("verdict") != "PASS"]
    assert not fails_lm, f"Matrix failures: {fails_lm}"
    print("8.1: Matrix 70 cases all PASS")

    # 8.2 run_file_required_values.py
    job_fv = os.path.join(out_dir, "job-file-required-values")
    rc_fv, stdout_fv, stderr_fv, _ = run_receipt(
        job_fv, RV3,
        PY, "-B", f"-Xpycache_prefix={pyc_dir}", os.path.join(TOOLS_X2, "run_file_required_values.py")
    )
    if rc_fv != 0:
        raise RuntimeError(f"run_file_required_values failed with rc={rc_fv}")
    res_json = os.path.join(out_dir, "file-required-values/results.json")
    assert os.path.exists(res_json)
    rows_fv = json.load(open(res_json))
    assert len(rows_fv) == 17, f"Expected 17 required values rows, got {len(rows_fv)}"
    fails_fv = [r for r in rows_fv if not r.get("pass")]
    assert not fails_fv, f"File required values failures: {fails_fv}"
    print("8.2: File required values 17 rows all pass")
    print("STEP 8: Matrix PASS")


def step_cleanup():
    print("\n=== STEP 9: Final Porcelain Checks & Cleanup ===")
    porc_rv = git_porcelain(W_RV)
    porc_ev = git_porcelain(W_EV)
    print(f"RV3/w porcelain: {porc_rv!r}")
    print(f"RV3/ev/w porcelain: {porc_ev!r}")
    assert porc_rv == "", f"RV3/w is not clean: {porc_rv}"
    assert porc_ev == "", f"RV3/ev/w is not clean: {porc_ev}"

    # Remove RV3/w and RV3/ev/w
    print("Removing RV3/w and RV3/ev/w...")
    shutil.rmtree(W_RV)
    shutil.rmtree(W_EV)
    assert not os.path.exists(W_RV)
    assert not os.path.exists(W_EV)

    # Remove pycaches under pyc/x2*
    for pyc_path in glob.glob(os.path.join(PYC_BASE, "x2*")):
        print(f"Removing pycache: {pyc_path}")
        shutil.rmtree(pyc_path)

    print("Cleanup complete!")


def main():
    if not os.path.exists(os.path.join(RV3, "evidence/o3/o3.json")):
        step_1_o3()
    else:
        print("Step 1 (O3) already completed, skipping.")
    if not os.path.exists(os.path.join(RV3, "evidence/plan/plan.json")):
        step_2_plan()
    else:
        print("Step 2 (Plan) already completed, skipping.")
    if not os.path.exists(os.path.join(RV3, "evidence/layout/delta_shape.json")):
        step_3_layout()
    else:
        print("Step 3 (Layout) already completed, skipping.")
    if not os.path.exists(os.path.join(RV3, "evidence/refusals/optimized-env.json")):
        step_4_refusals()
    else:
        print("Step 4 (Refusals) already completed, skipping.")
    if not os.path.exists(os.path.join(RV3, "evidence/registration/run/results.json")):
        step_5_registration()
    else:
        print("Step 5 (Registration) already completed, skipping.")
    if not os.path.exists(os.path.join(RV3, "evidence/manual_seeds/seeds.jsonl")):
        step_6_manual_seeds()
    else:
        print("Step 6 (Manual seeds) already completed, skipping.")
    step_7_fguards()
    step_8_matrix()
    step_cleanup()
    print("\nALL X2 STEPS COMPLETED SUCCESSFULLY!")


if __name__ == "__main__":
    sys.exit(main())
