# Remote Harness Audit & Verification Report: Candidate H'' (`b932ce0d97775c7061102a13db706f507dc84117`)

**Date:** 2026-11-03 05:12:34Z
**Target Proof Revision (W):** `b932ce0d97775c7061102a13db706f507dc84117`
**Prior Audited Revision (H'):** `813c8074acb2eed99ffeef78ea49e8c7832e4c01`
**P1 Product Revision:** `626463375298d357ffcb3223059f4d3adce6fb10`
**Overall Gate Status:** **PASS**
**Total Execution Time:** 5363.93s

---

## 1. Executive Summary

This report documents the remote CI harness audit gate for candidate proof revision H'' (`b932ce0d9`), conducted in strict compliance with Plan Sections 2-3.

All required checks passed:
1. **Controller C & Pinned Clean W:** W cloned at `b932ce0d97775c7061102a13db706f507dc84117`, verified 100% clean, verified zero non-proof diff against P1.
2. **H' -> H'' Source Delta:** Confined strictly to `proof/run_proof.py` and `proof/smoke_test.py`. Census files and product source 100% identical.
3. **Producer/Consumer Grammar Agreement:** Verified exact match between `bench/stale_rg9.py` and `proof/run_proof.py`.
4. **Source-Derived Fixture Inventory:** 439 seeds and 85 controls (524 total fixtures), zero duplicates, zero overlap, all 4 new regression seeds verified and mapped.
5. **Full Suite and Coverage Gate:**
   - Command: `python3 -B proof/smoke_test.py --coverage <coverage-dir>`
   - Result: Exit 0, `HARNESS PASS`, `COVERAGE GATE PASS`.
   - Executed: 439/439 seeds passed, 85/85 controls passed, 0 missed, 0 failed.
   - Four coverage listings generated and verified; W remained completely clean.
6. **Verified Old-Parser Mutation:**
   - Dedicated disposable clone created and mutated.
   - Canonical control `o7.control.run1` failed at gate 1.3.
   - Bare summary rejection seeds `s5.seed.rg9-bare` and `s5.seed.rg9-bare-141` detected old parser acceptance and failed.
   - 140-count rejection remained enforced.
   - Restored exact saved bytes with bit-for-bit hash equality; scratch clone deleted.
7. **Line Map & Allowlist Verification:** Spans 1526-1533 verified against source.

---

## 2. Gate Verification Table

| Gate Item | Status | Details |
|---|---|---|
| **Pinned W Cleanliness** | **PASS** | HEAD `b932ce0d97775c7061102a13db706f507dc84117`, clean status, 0 non-proof diff vs P1 |
| **H' -> H'' Delta Audit** | **PASS** | Only `run_proof.py` and `smoke_test.py` changed, census identical |
| **Grammar Agreement** | **PASS** | `stale_rg9.py` sentence matches `run_proof.py` regex |
| **Source Inventory** | **PASS** | 439 seeds / 85 controls / 524 total / 0 duplicates |
| **Harness Smoke Suite** | **PASS** | Exit 0, `HARNESS PASS`, 524/524 fixtures executed and passed |
| **Coverage Gate** | **PASS** | `COVERAGE GATE PASS`, 4 listings generated, missing lines allowlisted |
| **Old-Parser Mutation** | **PASS** | Control failed at gate 1.3, bare seeds detected wrong acceptance, 140 rejected |
| **Restoration & Hygiene** | **PASS** | Exact bytes restored, hash matched, scratch deleted, W clean |

---

## 3. Artifact Files Generated

- `audit_summary.json`: Complete structured execution summary.
- `inventory/source_derived_inventory.json`: Full fixture listings and review item mappings.
- `coverage/coverage_summary.json`: Coverage listing statistics and allowlist verification.
- `coverage/*.cover`: The four annotated coverage listings.
- `mutation/baseline_targeted_results.json`: Targeted fixtures pre-mutation structured results.
- `mutation/baseline_raw_stdout.log`: Raw stdout of pre-mutation targeted fixtures.
- `mutation/baseline_raw_stderr.log`: Raw stderr of pre-mutation targeted fixtures.
- `mutation/baseline_execution.json`: Execution metadata for pre-mutation baseline run.
- `mutation/mutated_targeted_results.json`: Targeted fixtures post-mutation with failure signatures.
- `mutation/mutated_raw_stdout.log`: Raw stdout of mutated targeted fixtures.
- `mutation/mutated_raw_stderr.log`: Raw stderr of mutated targeted fixtures.
- `mutation/mutated_execution.json`: Execution metadata for mutated run.
- `mutation/mutation.patch`: Exact patch applied in scratch clone.
- `mutation/restoration_verification.json`: Bit-for-bit restoration receipts.
- `hprime_hprimeprime_delta/hprime_to_hprimeprime.patch`: Full source diff between H' and H''.
- `hprime_hprimeprime_delta/grammar_agreement.json`: Regex vs producer sentence proof.
- `logs/smoke_test_stdout.log`: Raw stdout of the full 524-fixture smoke test.

---

## 4. Construction Attempt History & Disclosure

- **Attempt 1 (Run 41362618094, commit `280cb538ef`):** FAILED in coverage step.
  - Root cause: Runner environment lacked `timeout` binary from GNU coreutils on `PATH` (`IdentityError: NO-TIMEOUT: timeout does not resolve on the pinned PATH`), causing 122 seeds to miss and 27 controls to fail in coverage mode. Additionally, audit parser previously expected `status=` on fixture lines rather than parsing raw `smoke_test.py` format.
  - Remediation: Added `brew install coreutils` and `gnubin` to `PATH` in workflow and script, added `timeout --version` pre-flight verification, and corrected raw stdout parsing in `remote_harness_audit.py`.
- **Attempt 2 (Run 41364838439, commit `c1d7dd7299`):** FAILED in coverage step.
  - Root cause: Blanket addition of coreutils `gnubin` to `PATH` shadowed genuine BSD `/usr/bin/mktemp` with GNU `mktemp`. GNU `mktemp -d` honors `TMPDIR` and created directory under `/tmp`, causing bare mktemp parent to resolve to `/private/tmp` instead of Darwin user temp dir `/private/var/folders/.../T`, triggering `IdentityError: PLATFORM-TMP-UNOBSERVABLE` (124 seeds missed, 27 controls failed).
  - Remediation: Removed blanket `gnubin` from `PATH`. Created task-owned directory exposing ONLY GNU `timeout` via symlink pointing to Homebrew `gtimeout`, keeping system `/usr/bin/mktemp` unshadowed. Added pre-flight check proving `command -v mktemp` is genuine BSD `/usr/bin/mktemp` and parent of bare `mktemp -d` agrees with `DARWIN_USER_TEMP_DIR`.
- **Attempt 3 (Run 41367231332, commit `4ffec12803`):** INCOMPLETE / KILLED.
  - Root cause: Job reached full coverage with correct prerequisites, but was externally killed by GitHub Actions runner host after reaching the accidental 60-minute job limit (`The job has exceeded the maximum execution time of 1h0m0s`). Because of GitHub's hard termination on job timeout, `if: always()` artifact upload did not run and no artifacts were produced.
  - Remediation: Increased GitHub Actions job timeout ceiling to 360 minutes (`timeout-minutes: 360`), the maximum GitHub-hosted job limit. No changes to native fixture timeouts, bounds, workload, allowlist, assertions, or classifications.
- **Attempt 4 (Run 41377702659, commit `01343ad2d7`):** FAILED in old-parser mutation step.
  - Root cause: Full suite and coverage gate passed all 524/524 fixtures (`HARNESS PASS`, `COVERAGE GATE PASS`, 439 seeds / 85 controls), but the subsequent old-parser mutation step failed with `JSONDecodeError: Expecting value: line 1 column 1 (char 0)` at line 911 because `json.loads(baseline_res.stdout)` attempted to parse `baseline_res.stdout`, which contained fixture console logs rather than JSON. Mutation was never executed.
  - Remediation: Decoupled fixture stdout logging from structured JSON capture. The runner adapter outputs native fixture logs to stdout/stderr while writing structured observation payloads directly to dedicated JSON artifact files. Added raw stream preservation (`baseline_raw_stdout.log`, `baseline_raw_stderr.log`, `mutated_raw_stdout.log`, `mutated_raw_stderr.log`) and strict structural validation for both stdout log lines and JSON payloads.
- **Attempt 5 (Current commit):** Running under 360-minute job limit with verified tool isolation and decoupled mutation runner output.
