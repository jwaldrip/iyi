#!/usr/bin/env python3
import hashlib
import json
import os
import sys

def main():
    if len(sys.argv) < 2:
        sys.exit(1)
    stage = sys.argv[1]
    capture_dir = os.environ.get("CAPTURE_DIR", ".")

    safe_vars = [
        "TMPDIR", "IYI_CACHE_DIR", "CRYSTAL_CACHE_DIR", "XDG_CACHE_HOME",
        "PATH", "HOME", "LIBRARY_PATH", "PKG_CONFIG_PATH",
        "LD_LIBRARY_PATH", "DYLD_LIBRARY_PATH"
    ]
    sensitive_exact = ["BASH_ENV", "ENV", "PROMPT_COMMAND", "HISTFILE", "INPUTRC"]

    safe_result = {}
    for k in safe_vars:
        if k not in os.environ:
            safe_result[k] = {"state": "unset"}
        elif os.environ[k] == "":
            safe_result[k] = {"state": "empty"}
        else:
            safe_result[k] = {"state": "set", "value": os.environ[k]}

    sensitive_result = {}
    for k, v in os.environ.items():
        is_sensitive = False
        if (k.startswith("IYI_") or k.startswith("CRYSTAL_")) and k not in safe_vars and k not in ("IYI", "IYI_PATH"):
            is_sensitive = True
        elif k in sensitive_exact:
            is_sensitive = True

        if is_sensitive:
            sensitive_result[k] = {
                "state": "empty" if v == "" else "set",
                "sha256": hashlib.sha256(v.encode("utf-8")).hexdigest(),
                "len": len(v)
            }

    out_file = os.path.join(capture_dir, f"env_{stage}.json")
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump({
            "stage": stage,
            "safe_path_variables": safe_result,
            "sensitive_variables_presence_and_hashes": sensitive_result
        }, f, indent=2, sort_keys=True)

if __name__ == "__main__":
    main()
