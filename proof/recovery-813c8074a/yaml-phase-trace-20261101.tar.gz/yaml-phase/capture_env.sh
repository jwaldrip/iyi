# Helper functions sourced by instrumented shell body
__iyi_diag_capture() {
  local stage="$1"
  [ -z "${CAPTURE_DIR:-}" ] && return 0

  # 1. Shell state (options, version, cwd, REPO, WORK, IYI)
  {
    printf "stage=%s\n" "$stage"
    printf "timestamp_iso=%s\n" "$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date)"
    printf "timestamp_ns=%s\n" "$(python3 -c 'import time; print(time.time_ns())' 2>/dev/null || date +%s%N 2>/dev/null || echo 0)"
    printf "bash_version=%s\n" "${BASH_VERSION:-}"
    printf "dash_options=%s\n" "$-"
    printf "bashopts=%s\n" "${BASHOPTS:-}"
    printf "shellopts=%s\n" "${SHELLOPTS:-}"
    printf "cwd=%s\n" "$(pwd)"
    printf "repo=%s\n" "${REPO:-}"
    printf "work=%s\n" "${WORK:-}"
    printf "iyi=%s\n" "${IYI:-}"
    printf "psep=%s\n" "${PSEP:-}"
  } > "$CAPTURE_DIR/shell_state_${stage}.txt" 2>/dev/null || true

  # 2. Resource limits
  ulimit -a > "$CAPTURE_DIR/ulimit_${stage}.txt" 2>/dev/null || true

  # 3. Functions (names and SHA-256 hashes of definitions, without dumping bodies)
  {
    while IFS= read -r fn_entry; do
      fn_name="${fn_entry##* }"
      [ -z "$fn_name" ] && continue
      fn_hash=$(type "$fn_name" 2>/dev/null | python3 -c 'import sys, hashlib; print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())' 2>/dev/null || echo "error")
      printf "%s %s\n" "$fn_name" "$fn_hash"
    done < <(declare -F 2>/dev/null || true)
  } > "$CAPTURE_DIR/functions_${stage}.txt" 2>/dev/null || true

  # 4. Commands resolution and hashes
  python3 -c '
import json, os, subprocess, hashlib, sys
cmds = ["timeout", "grep", "python3", "python"]
results = {}
for cmd in cmds:
    t_proc = subprocess.run(["bash", "-c", f"type -t {cmd}"], capture_output=True, text=True)
    cmd_type = t_proc.stdout.strip() if t_proc.returncode == 0 else "not_found"
    p_proc = subprocess.run(["bash", "-c", f"type -p {cmd}"], capture_output=True, text=True)
    cmd_path = p_proc.stdout.strip() if p_proc.returncode == 0 else ""
    cmd_hash = None
    if cmd_path and os.path.isfile(cmd_path):
        try:
            with open(cmd_path, "rb") as f:
                cmd_hash = hashlib.sha256(f.read()).hexdigest()
        except OSError:
            pass
    results[cmd] = {
        "command_type": cmd_type,
        "path": cmd_path,
        "sha256": cmd_hash,
    }
iyi_path = os.environ.get("IYI", "")
iyi_hash = None
if iyi_path and os.path.isfile(iyi_path):
    try:
        with open(iyi_path, "rb") as f:
            iyi_hash = hashlib.sha256(f.read()).hexdigest()
    except OSError:
        pass
results["iyi"] = {
    "path": iyi_path,
    "sha256": iyi_hash,
}
with open(os.path.join(sys.argv[1], f"commands_{sys.argv[2]}.json"), "w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, sort_keys=True)
' "$CAPTURE_DIR" "$stage" 2>/dev/null || true

  # 5. Environment classification
  if [ -f "$CAPTURE_DIR/capture_env.py" ]; then
    python3 "$CAPTURE_DIR/capture_env.py" "$stage" 2>/dev/null || true
  fi
}
